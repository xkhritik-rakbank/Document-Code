CREATE PROCEDURE [dbo].[TF_SaveChargeCollectionDetails] 
( 
    @ChargeCollectionData NVARCHAR(max), 
    @WINAME NVARCHAR(50),
    @WSNAME NVARCHAR(50)
) 
AS
SET NOCOUNT ON
BEGIN
    DECLARE @ChargeCollectionRecord NVARCHAR(max)
    DECLARE @Query NVARCHAR(max)
    DECLARE @count INT
    DECLARE @Loop INT
    DECLARE @Data3 NVARCHAR(50)  -- For ChargeType
    DECLARE @Data4 NVARCHAR(50)  -- For ChargeEventId
    DECLARE @Data5 NVARCHAR(50)  -- For Waiver
    DECLARE @Data6 NVARCHAR(50)  -- For User_Remarks

    SET @count = 0
    
    -- Count the number of records by counting the delimiters "|"
    SET @Loop = LEN(@ChargeCollectionData) - LEN(REPLACE(@ChargeCollectionData, '|', ''))
    PRINT 'Loop Count: ' + CAST(@Loop AS NVARCHAR)

    -- Check if @ChargeCollectionData is not empty
    IF (@ChargeCollectionData != '')
    BEGIN
        -- If the string contains "|", there are multiple records to process
        IF (@ChargeCollectionData LIKE '%|%')
        BEGIN
            WHILE (@Loop >= 0)
            BEGIN
                IF (@ChargeCollectionData != '')
                BEGIN
                    DECLARE @start INT, @end INT, @secondEnd INT, @thirdEnd INT, @fourthEnd INT
                    SELECT @start = 1, @end = CHARINDEX('|', @ChargeCollectionData)

                    IF (@ChargeCollectionData LIKE '%|%')
                    BEGIN
                        -- Extract the charge collection record
                        SELECT @ChargeCollectionRecord = SUBSTRING(@ChargeCollectionData, @start, @end - 1)

                        -- Extract Data3 (ChargeType), Data4 (ChargeEventId), Data5 (Waiver), and Data6 (User_Remarks)
                        SET @secondEnd = CHARINDEX('~', @ChargeCollectionRecord, @end + 1)
                        SET @thirdEnd = CHARINDEX('~', @ChargeCollectionRecord, @secondEnd + 1)
                        SET @fourthEnd = CHARINDEX('~', @ChargeCollectionRecord, @thirdEnd + 1)
                        SET @Data3 = SUBSTRING(@ChargeCollectionRecord, @secondEnd + 1, @thirdEnd - @secondEnd - 1)  -- ChargeType
                        SET @Data4 = SUBSTRING(@ChargeCollectionRecord, @thirdEnd + 1, @fourthEnd - @thirdEnd - 1)  -- ChargeEventId
                        SET @Data5 = SUBSTRING(@ChargeCollectionRecord, @fourthEnd + 1, CHARINDEX('~', @ChargeCollectionRecord, @fourthEnd + 1) - @fourthEnd - 1)  -- Waiver
                        SET @Data6 = SUBSTRING(@ChargeCollectionRecord, CHARINDEX('~', @ChargeCollectionRecord, @fourthEnd + 1) + 1, LEN(@ChargeCollectionRecord))  -- User_Remarks

                        -- Handle special characters like ~ and ENSQOUTES
                        SET @Data3 = REPLACE(@Data3, '~', ''',''') -- Replace ~ with quotes for SQL syntax if needed
                        SET @Data5 = REPLACE(@Data5, '~', ''',''')
                        SET @Data6 = REPLACE(@Data6, '~', ''',''')
                        SET @Data6 = REPLACE(@Data6, 'ENSQOUTES', '''''''')

                        -- Construct the UPDATE query with Data3 (ChargeType) and Data4 (ChargeEventId) in the WHERE clause
                        SET @Query = 'UPDATE USR_0_TF_ChargeCollection_Grid ' +
                                     'SET Waiver = ''' + @Data5 + ''', ' +  -- Set Waiver to Data5
                                     'User_Remarks = ''' + @Data6 + ''' ' +  -- Set User_Remarks to Data6
                                     'WHERE WINAME = ''' + @WINAME + ''' ' +
                                     'AND WSNAME = ''' + @WSNAME + ''' ' +
                                     'AND ChargeType = ''' + @Data3 + ''' ' +  -- WHERE condition based on ChargeType (Data3)
                                     'AND ChargeEventId = ''' + @Data4 + ''''  -- WHERE condition based on ChargeEventId (Data4)

                        PRINT @Query
                        EXEC(@Query)

                        -- Remove the processed part of @ChargeCollectionData
                        SET @ChargeCollectionData = RIGHT(@ChargeCollectionData, LEN(@ChargeCollectionData) - @end)
                        SET @count = @count + 1
                    END
                END
                SET @Loop = @Loop - 1
            END
        END
        ELSE
        BEGIN
            -- Single record (no delimiter)
            SET @ChargeCollectionRecord = @ChargeCollectionData
            SET @ChargeCollectionRecord = REPLACE(@ChargeCollectionRecord, '~', ''',''')
            SET @ChargeCollectionRecord = REPLACE(@ChargeCollectionRecord, 'ENSQOUTES', '''''''')

            -- Extract Data3 (ChargeType), Data4 (ChargeEventId), Data5 (Waiver), and Data6 (User_Remarks) from the single record
            SET @Data3 = @ChargeCollectionData
            SET @Data4 = @ChargeCollectionData
            SET @Data5 = @ChargeCollectionData
            SET @Data6 = @ChargeCollectionData

            -- Construct the UPDATE query with Data3 and Data4 in the WHERE clause
            SET @Query = 'UPDATE USR_0_TF_ChargeCollection_Grid ' +
                         'SET Waiver = ''' + @Data5 + ''', ' +
                         'User_Remarks = ''' + @Data6 + ''' ' + 
                         'WHERE WINAME = ''' + @WINAME + ''' ' +
                         'AND WSNAME = ''' + @WSNAME + ''' ' +
                         'AND ChargeType = ''' + @Data3 + ''' ' +
                         'AND ChargeEventId = ''' + @Data4 + ''''

            PRINT @Query
            EXEC(@Query)

            SET @ChargeCollectionData = RIGHT(@ChargeCollectionData, LEN(@ChargeCollectionData) - @end)
            SET @count = @count + 1
        END
    END
    
    -- Return the number of records processed
    SELECT @count
END
GO