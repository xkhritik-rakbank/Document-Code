package src;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class InteractiveMenu extends XMLModifier {
    private static String folderPath = "";

    public static void main(String[] args) {

        try {
            Scanner scanner = new Scanner(System.in);
            Properties properties = new Properties();
            FileInputStream input = null;
            input = new FileInputStream("C:\\Users\\newco\\OneDrive\\Desktop\\MQ Tester Advanced\\config\\updateConfig.properties");
            properties.load(input);
            String outputFilePath = properties.getProperty("outputFilePath");
            String cmdFilePath = properties.getProperty("cmdFilePath");
            String logFilePath = properties.getProperty("logFilePath");
            folderPath = properties.getProperty("folderPath");
            processMenu(scanner);
            File xmlFile = findXMLFile(folderPath);
            if (xmlFile != null) {
                modifyAndSaveXML(xmlFile, outputFilePath, getWInumber());

                runCmdFile(cmdFilePath);

                printLogFile(logFilePath);
            } else {
                System.out.println("No XML file found in the specified folder.");
            }

            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public String getSourcePath() {
        return folderPath;
    }
}
