package src;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.Scanner;
import java.util.regex.*;
import java.util.concurrent.TimeUnit;
import java.util.Properties;


public class XMLModifier {
    static InteractiveMenu obj = new InteractiveMenu();
    static int wiNum;

    public static void processMenu(Scanner scanner) {

        System.out.println("Choose process name:");
        System.out.println("1. DAO");
        System.out.println("2. DCC");
        System.out.println("3. DPL");
        System.out.print("Enter your option (1-3): ");
        int processChoice = scanner.nextInt();
        scanner.nextLine();

        String processName;
        switch (processChoice) {
            case 1:
                processName = "DAO";
                break;
            case 2:
                processName = "DCC";
                break;
            case 3:
                processName = "DPL";
                break;
            default:
                System.out.println("Invalid selection. Exiting...");
                return;
        }

        System.out.println("You selected: " + processName);


        System.out.println("\nChoose functionality:");
        System.out.println("1. Create new WI");
        System.out.println("2. Run Update");
        System.out.print("Enter your option (1-2): ");
        int functionalityChoice = scanner.nextInt();
        scanner.nextLine();

        if (functionalityChoice == 1) {
            System.out.println("\nCreating new WI for " + processName + "...");

        } else if (functionalityChoice == 2) {
            System.out.println("\nRunning update for " + processName + "...");

            String[] subprocesses = getSubprocesses(processName);
            if (subprocesses.length > 0) {
                System.out.println("\nSelect a subprocess:");
                for (int i = 0; i < subprocesses.length; i++) {
                    System.out.println((i + 1) + ". " + subprocesses[i]);
                }
                System.out.print("Enter your option: ");
                int subProcessOption = scanner.nextInt();
                scanner.nextLine();

                if (subProcessOption > 0 && subProcessOption <= subprocesses.length) {
                    String selectedSubprocess = subprocesses[subProcessOption - 1];
                    System.out.println("You selected subprocess: " + selectedSubprocess);

                    String filePath = obj.getSourcePath() + "/" + selectedSubprocess + ".xml";
                    File subprocessFile = new File(filePath);

                    if (!subprocessFile.exists()) {
                        System.out.println("Error: File for subprocess '" + selectedSubprocess + "' does not exist at " + filePath);
                        System.out.println("Exiting program...");
                        System.exit(0);
                    }

                    System.out.print("\nEnter WI number (numeric only): ");
                    while (!scanner.hasNextInt()) {
                        System.out.print("Invalid input. Please enter a numeric WI number: ");
                        scanner.next();
                    }
                    wiNum = scanner.nextInt();
                    scanner.nextLine();
                    String wiNumberStr = Integer.toString(wiNum);
                    System.out.println("\nProcessing WI number: " + wiNumberStr + " for subprocess: " + selectedSubprocess);

                    // Add logic to handle the WI and subprocess here.
                } else {
                    System.out.println("Invalid subprocess option selected.");
                }
            } else {
                System.out.println("No subprocesses available for the process " + processName);
            }
        } else {
            System.out.println("Invalid functionality option selected.");
        }
    }

    // Finds the first XML file in the specified folder
    public static File findXMLFile(String folderPath) {
        File folder = new File(folderPath);
        File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".xml"));

        return (files != null && files.length > 0) ? files[0] : null;
    }

    // Modifies WINUMBER and saves to another file
    public static void modifyAndSaveXML(File inputFile, String outputFilePath, int newNumber) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(inputFile);

            NodeList attributeList = document.getElementsByTagName("Attribute");
            for (int i = 0; i < attributeList.getLength(); i++) {
                Node attributeNode = attributeList.item(i);
                if (attributeNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element attributeElement = (Element) attributeNode;
                    NodeList nameList = attributeElement.getElementsByTagName("Name");

                    if (nameList.getLength() > 0 && "WINUMBER".equals(nameList.item(0).getTextContent())) {
                        NodeList valueList = attributeElement.getElementsByTagName("Value");
                        if (valueList.getLength() > 0) {
                            String oldWINumber = valueList.item(0).getTextContent();
                            String updatedWINumber = formatWINumber(oldWINumber, newNumber);

                            valueList.item(0).setTextContent(updatedWINumber);
                            break;
                        }
                    }
                }
            }

            // Save the modified XML to a new file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");

            DOMSource source = new DOMSource(document);
            StreamResult result = new StreamResult(new File(outputFilePath));

            transformer.transform(source, result);

            System.out.println("Modified XML saved to: " + outputFilePath);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Extracts the numeric part and formats it with leading zeroes
    private static String formatWINumber(String oldWINumber, int newNumber) {
        Pattern pattern = Pattern.compile("(.*?-)(\\d+)(-.*)");
        Matcher matcher = pattern.matcher(oldWINumber);

        if (matcher.matches()) {
            String prefix = matcher.group(1);
            String numberPart = matcher.group(2);
            String suffix = matcher.group(3);

            // Format new number with leading zeroes to match original length
            String formattedNumber = String.format("%0" + numberPart.length() + "d", newNumber);

            return prefix + formattedNumber + suffix;
        }

        return oldWINumber; // Return original if pattern doesn't match
    }

    static int getWInumber() {
        return wiNum;
    }

    public static void runCmdFile(String cmdFilePath) {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/c", cmdFilePath);
            processBuilder.redirectErrorStream(true); // Merge error output with standard output
            Process process = processBuilder.start();

            // Read output in a separate thread
            Thread outputThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        System.out.println(line);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            outputThread.start();

            // Set timeout (5 seconds)
            boolean finished = process.waitFor(5, TimeUnit.SECONDS);

            if (!finished) {
                System.out.println("CMD execution timed out. Destroying process...");
                process.destroy(); // Kill the process
            }

            outputThread.join(); // Ensure output is fully read before continuing

            System.out.println("CMD Execution Completed with Exit Code: " + process.exitValue());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void printLogFile(String logFilePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(logFilePath))) {
            String line;
            System.out.println("\n--- Log File Contents ---");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            System.out.println("--- End of Log File ---\n");
        } catch (FileNotFoundException e) {
            System.out.println("Log file not found: " + logFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String[] getSubprocesses(String processName) {
        String[] valueArray = null;
        try {

            Properties properties = new Properties();
            FileInputStream input = new FileInputStream("C:\\Users\\newco\\OneDrive\\Desktop\\MQ Tester Advanced\\config\\updateConfig.properties");
            properties.load(input);

            String propertyValue = "";
            if("DAO".equals(processName)){
                propertyValue = properties.getProperty("DAO-Updates");
            }
            else if("DCC".equals(processName)){
                propertyValue = properties.getProperty("DCC-Updates");
            }
            else if("DPL".equals(processName)){
                propertyValue = properties.getProperty("DPL-Updates");
            }
            valueArray = propertyValue.split(",");
            input.close();
        } catch (IOException ex ) {
            ex.printStackTrace();
        }
        return valueArray;
    }

}

