CREATE PROCEDURE [dbo].[TF_SaveChargeCollectionDetails] 
( 
    @ChargeCollectionData NVARCHAR(max), 
    @WINAME NVARCHAR(50),
    @WSNAME NVARCHAR(50)
) 
AS
SET NOCOUNT ON
BEGIN
    DECLARE @ChargeCollectionRecord NVARCHAR(max)
    DECLARE @Query NVARCHAR(max)
    DECLARE @count INT
    DECLARE @Loop INT
    DECLARE @Data3 NVARCHAR(50)  -- For WHERE condition (Data3)
    DECLARE @Data4 NVARCHAR(50)  -- For WHERE condition (Data4)

    SET @count = 0
    
    -- Count the number of records by counting the delimiters "|"
    SET @Loop = LEN(@ChargeCollectionData) - LEN(REPLACE(@ChargeCollectionData, '|', ''))
    PRINT 'Loop Count: ' + CAST(@Loop AS NVARCHAR)

    -- Check if @ChargeCollectionData is not empty
    IF (@ChargeCollectionData != '')
    BEGIN
        -- If the string contains "|", there are multiple records to process
        IF (@ChargeCollectionData LIKE '%|%')
        BEGIN
            WHILE (@Loop >= 0)
            BEGIN
                IF (@ChargeCollectionData != '')
                BEGIN
                    DECLARE @start INT, @end INT, @secondEnd INT
                    SELECT @start = 1, @end = CHARINDEX('|', @ChargeCollectionData)
                    
                    IF (@ChargeCollectionData LIKE '%|%')
                    BEGIN
                        -- Extract the charge collection record
                        SELECT @ChargeCollectionRecord = SUBSTRING(@ChargeCollectionData, @start, @end - 1)

                        -- Extract Data3 and Data4 from the string
                        -- Data3 is the 3rd value and Data4 is the 4th value
                        SET @secondEnd = CHARINDEX('|', @ChargeCollectionData, @end + 1)
                        SET @Data3 = SUBSTRING(@ChargeCollectionData, @end + 1, @secondEnd - @end - 1)
                        SET @Data4 = SUBSTRING(@ChargeCollectionData, @secondEnd + 1, LEN(@ChargeCollectionData) - @secondEnd)

                        -- Handle special characters like ~ and ENSQOUTES
                        SET @ChargeCollectionRecord = REPLACE(@ChargeCollectionRecord, '~', ''',''')
                        SET @ChargeCollectionRecord = REPLACE(@ChargeCollectionRecord, 'ENSQOUTES', '''''''')

                        -- Construct the UPDATE query with Data3 and Data4 in the WHERE clause
                        SET @Query = 'UPDATE USR_0_TF_ChargeCollection_Grid ' +
                                     'SET Waiver = ''' + @ChargeCollectionRecord + ''', ' + 
                                     'User_Remarks = ''' + @ChargeCollectionRecord + ''' ' +  -- You can adjust this as needed
                                     'WHERE WINAME = ''' + @WINAME + ''' ' +
                                     'AND WSNAME = ''' + @WSNAME + ''' ' +
                                     'AND DataColumn1 = ''' + @Data3 + ''' ' +  -- WHERE condition based on Data3
                                     'AND DataColumn2 = ''' + @Data4 + ''''  -- WHERE condition based on Data4

                        PRINT @Query
                        EXEC(@Query)

                        -- Remove the processed part of @ChargeCollectionData
                        SET @ChargeCollectionData = RIGHT(@ChargeCollectionData, LEN(@ChargeCollectionData) - @end)
                        SET @count = @count + 1
                    END
                    ELSE
                    BEGIN
                        -- Process the last record without delimiter
                        SET @ChargeCollectionRecord = @ChargeCollectionData
                        SET @ChargeCollectionRecord = REPLACE(@ChargeCollectionRecord, '~', ''',''')
                        SET @ChargeCollectionRecord = REPLACE(@ChargeCollectionRecord, 'ENSQOUTES', '''''''')

                        -- Extract Data3 and Data4 from the string
                        SET @Data3 = @ChargeCollectionData
                        SET @Data4 = @ChargeCollectionData

                        -- Construct the UPDATE query with Data3 and Data4 in the WHERE clause
                        SET @Query = 'UPDATE USR_0_TF_ChargeCollection_Grid ' +
                                     'SET Waiver = ''' + @ChargeCollectionRecord + ''', ' + 
                                     'User_Remarks = ''' + @ChargeCollectionRecord + ''' ' + 
                                     'WHERE WINAME = ''' + @WINAME + ''' ' +
                                     'AND WSNAME = ''' + @WSNAME + ''' ' +
                                     'AND DataColumn1 = ''' + @Data3 + ''' ' +  -- WHERE condition based on Data3
                                     'AND DataColumn2 = ''' + @Data4 + ''''  -- WHERE condition based on Data4

                        PRINT @Query
                        EXEC(@Query)

                        SET @ChargeCollectionData = RIGHT(@ChargeCollectionData, LEN(@ChargeCollectionData) - @end)
                        SET @count = @count + 1
                    END
                END
                SET @Loop = @Loop - 1
            END
        END
        ELSE
        BEGIN
            -- Single record (no delimiter)
            SET @ChargeCollectionRecord = @ChargeCollectionData
            SET @ChargeCollectionRecord = REPLACE(@ChargeCollectionRecord, '~', ''',''')
            SET @ChargeCollectionRecord = REPLACE(@ChargeCollectionRecord, 'ENSQOUTES', '''''''')

            -- Extract Data3 and Data4 from the string
            SET @Data3 = @ChargeCollectionData
            SET @Data4 = @ChargeCollectionData

            -- Construct the UPDATE query with Data3 and Data4 in the WHERE clause
            SET @Query = 'UPDATE USR_0_TF_ChargeCollection_Grid ' +
                         'SET Waiver = ''' + @ChargeCollectionRecord + ''', ' +
                         'User_Remarks = ''' + @ChargeCollectionRecord + ''' ' + 
                         'WHERE WINAME = ''' + @WINAME + ''' ' +
                         'AND WSNAME = ''' + @WSNAME + ''' ' +
                         'AND DataColumn1 = ''' + @Data3 + ''' ' +  -- WHERE condition based on Data3
                         'AND DataColumn2 = ''' + @Data4 + ''''  -- WHERE condition based on Data4

            PRINT @Query
            EXEC(@Query)

            SET @ChargeCollectionData = RIGHT(@ChargeCollectionData, LEN(@ChargeCollectionData) - @end)
            SET @count = @count + 1
        END
    END
    
    -- Return the number of records processed
    SELECT @count
END
GO
