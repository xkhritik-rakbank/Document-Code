USE [rakcas]
GO
/****** Object:  StoredProcedure [dbo].[LMS_dummy]    Script Date: 5/30/2024 12:19:16 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER procedure [dbo].[LMS_dummy]
(
@wi_name nvarchar(100)
)
as
DECLARE 
@LMS_Table nvarchar(100),
@LMS_Column nvarchar(100),
@DPL_Table nvarchar(100),
@DPL_Column nvarchar(100),
@DPL_COLValue nvarchar(100),
@RowCount int,
@Query nvarchar(300),
@EXT BIT,
@Dsql nvarchar(500);

BEGIN
	print('inside LMS_DataPush procedure:');
	set @RowCount =1;
	set @DPL_Table = '';
	select @RowCount = count(*) from LMS_DPL_MappingTable_dummy
	print(@RowCount)

	WHILE @RowCount>0
		BEGIN
			Select @LMS_Table=LMS_TableName,@LMS_Column=LMS_ColumneName,@DPL_Table=DPL_TableName,@DPL_Column=DPL_ColumnName from LMS_DPL_MappingTable_dummy where SNO = @RowCount
			print(@LMS_Table);
			print(@DPL_Table);
			print(@DPL_Column);
			print(@wi_name);
			set @RowCount = @RowCount-1
			set @Query = 'select '+QUOTENAME(@DPL_Column)+',WINAME from '+QUOTENAME( @DPL_Table)+' WHERE WINAME ='''+@wi_name+''''
			
			print(@Query)			
			set @Dsql= N'set @EXT = CASE WHEN EXISTS ('+@Query+') THEN 1 ELSE 0 END;'
			 print(@Dsql)
			exec sp_executesql @Dsql,N'@EXT BIT OUTPUT',@EXT OUTPUT;

			IF @EXT = 1
				BEGIN
					print(@Query)
					Create table #temp(DPL_COLValue nvarchar(100),wi nvarchar(100));
					insert into #temp exec sp_executesql @Query
					
					set @Query ='insert into '+@LMS_Table+'('+@LMS_Column+',wi_name) select TOP(1) DPL_COLValue,wi from #temp'
					
					print(@Query)
					exec sp_executesql @Query
						print('Insert complete')
						drop table #temp
				END


		END
END


