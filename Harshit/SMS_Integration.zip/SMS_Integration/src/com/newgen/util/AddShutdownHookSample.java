package com.newgen.util;



import java.io.File;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

public class AddShutdownHookSample 
{
  File file=null;
 static FileChannel channel=null;
  static FileLock lock=null;
  SMSAutoService SMSAutoService_obj= new SMSAutoService();
 
		
	 public void attachShutDownHook(File secFile)
	 {
	  file= secFile;
	  Runtime.getRuntime().addShutdownHook(new Thread() 
	  {
	   @Override
	   public void run()
	   {
	    try
		{
	    	
	    	SMSAutoService_obj.keepRunning = false;
			lock.release();
			channel.close();
		}
		catch(Exception ex)
		{
		 
		 //System.out.println("Caught exception in release lock or channel close");kkk
		}
	    // added by abhishek 
	   while(true)
	   {
		   if(SMSAutoService_obj.checkThreads == true )
		   {
			    if(file.delete())
				{
					//System.out.println("File deleted");jjj	
				}
				else
				{
					//System.out.println("File deleted error ****");jjj	
				}
			    break;
		   }		   
			
	    }
		
	   }
	  });
	  
	 }
	
 }