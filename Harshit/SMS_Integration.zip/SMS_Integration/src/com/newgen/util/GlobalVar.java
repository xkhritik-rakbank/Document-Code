
package com.newgen.util;
import java.io.*;

public class GlobalVar {
    public static boolean successLog = false;
    public static boolean errorLog = false;
    public static String logPath = System.getProperty("user.dir") + File.separatorChar + "Log";
    public static int pollInterval = 20;
    public static String titleName = "Utility";
    public static String sortTitleName = "Utility_Main";
    public static boolean logFlag = false;
    public static long strLogSize = 2;
	public static boolean mblnIsConnectToServer = false;
	public static boolean mblnIsUserLoggedIn = false;
	public static boolean printScreenflag = false;
}
