/*
Group                       : Application Projects 2
Product / Project           : 
Module                      : 
File Name                   : 
Author                      : 
Date written (DD/MM/YYYY)   : 
Date modified (DD/MM/YYYY)  : 
Description                 : 
-------------------------------------------------------------------------------------------------------------------
 */

package com.newgen.util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.channels.OverlappingFileLockException;
import java.nio.charset.Charset;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Random;

import javax.net.ssl.HttpsURLConnection;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.dom4j.Document;
//import org.w3c.dom.Node;
//import org.w3c.dom.NameList;
//import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.ibm.ws.odc.NodeList;
import com.newgen.dmsapi.DMSXmlList;
import com.newgen.dmsapi.DMSXmlResponse;
import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;

public class SMSAutoService implements Runnable {
	public static Logger mLogger;

	public static String cabinetName;
	public static String username;
	public static String password;
	public static String jtsIP;
	public static String jtsPort;
	private String sessionID;
	public static String ENDPOINTURL;
	private String SMSResponse;
	public static String SuccessCode;
	public static String FailCode;
	public static String SuccessResponseCode;
	public static String TableName;
	public static String ColNames;
	public static String ReadCode;
	public static String select_column;
	public static String SSL_Certificate_folder;
	public static String SSL_Certificate_name;
	public static String SSL_password;
	public String userID = "";
	public static int sleepTime = 0;
	public static int sleepTimeToWait = 0;
	boolean bRun = true;
	boolean bMatch = true;
	public static User user_password = new User();
	String lastProcessInstanceId = "";
	String lastWorkItemId = "";
	GenerateXml objXmlGen = new GenerateXml();
	public static NGEjbClient ngEjbClient;
	public static String strQuery1 = "";

	public static String TimeToRun1 = "";
	public static String TimeToRun2 = "";
	public static String TimeToRun3 = "";

	public static String TimeToRunFlag1 = "";
	public static String TimeToRunFlag2 = "";
	public static String TimeToRunFlag3 = "";

	String inputDate = "";
	String XMLExtra2 = "";
	XMLParser lobjXMLParser = new XMLParser();
	public static String fetch_date = "";
	Runtime r = Runtime.getRuntime();
	private static String Requireddateformat = "";
	public boolean keepRunning = true;
	boolean checkThreads = false;
	LoggerManager loggerManager = new LoggerManager();
	WebService service = new WebService();

	public static void main(String[] args) {
		// Checking if another instance is running
		InstanceChecker.CheckRunningInstances();

		// Start the SMSAutoService thread
		SMSAutoService service = new SMSAutoService();
		Thread serviceThread = new Thread(service);
		serviceThread.start();
	}

	public void run() {
		try {
			ConfigLoader config = new ConfigLoader();
			config.setProperties();
			mLogger.info("Thread is running.");
			bMatch = false;
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
			String time = sdf.format(cal.getTime());
			mLogger.info("Current System Time = " + time);

			if (time.equals(TimeToRun1)) {
				bMatch = true;
				TimeToRunFlag1 = "Y";
			} else if (time.equals(TimeToRun2)) {
				bMatch = true;
				TimeToRunFlag2 = "Y";
			} else if (time.equals(TimeToRun3)) {
				bMatch = true;
				TimeToRunFlag3 = "Y";
			}
			if (connectToServer()) {
				String str = connectToWorkFlow("N");
				String temp[] = str.split("~");
				if (!temp[0].equals("0")) {
					Thread.sleep(10000);
					if (reconnectToWorkflow()) {
						;
					}
				}
			}
		} catch (Exception ex) {
			mLogger.info(ex.toString());
		}

		while (keepRunning) {
			r.gc(); // garbage collector
			mLogger.info("Start of thread for " + GlobalVar.titleName);
			// System.out.println("Start of thread for " + GlobalVar.titleName);
			try {
				int iRet = this.loadAndProcessWorkItems();
				if (iRet == 11) {
					if (reconnectToWorkflow()) {
						this.loadAndProcessWorkItems();
					}
				}
				if (keepRunning) {
					mLogger.info("\n" + GlobalVar.titleName + " is sleeping\n");
					// System.out.println(GlobalVar.titleName + " is sleeping");
					waiteloop(GlobalVar.pollInterval * 100);
				}
			} catch (Exception ex) {
				mLogger.info(ex.toString());
			}
			mLogger.info("End of thread for " + GlobalVar.titleName);
			// System.out.println("End of thread for " + GlobalVar.titleName);
		}
		// added for shutdown hook

		// added by abhishek to set status flag of running threads to true start
		checkThreads = true;
		// added by abhishek to set status flag of running threads to true end

		try {
			disconnectFromWorkFlow();
			disconnectFromServer();
		} catch (Exception ex) {
			mLogger.info(ex.toString());
		}
	}

	private int loadAndProcessWorkItems() throws NumberFormatException, IOException, Exception {
		// TODO Auto-generated method stub
		loggerManager.createLogFile();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		String fetchdate = dateFormat.format(date).toString();
		mLogger.info(fetchdate);

		SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		XMLExtra2 = dateFormat2.format(date).toString();

		String requiredYear = fetchdate.substring(2, 4);
		String requiredMonth = fetchdate.substring(4, 6);
		String requiredDay = fetchdate.substring(6, 8);
		String requiredHours = Integer.toString(Integer.parseInt(fetchdate.substring(8, 10)) + 12);
		String requiredMin = fetchdate.substring(10, 12);
		String requiredSecond = fetchdate.substring(12, 14);

		Requireddateformat = requiredDay + requiredMonth + requiredYear + requiredHours + requiredMin + requiredSecond;

		if (TimeToRunFlag1.equalsIgnoreCase("Y")) {
			GenerateFileTimeToRun1();
		}

		try {
			Thread.sleep(sleepTimeToWait);
		} catch (Exception thread) {
			mLogger.info("Thread = " + thread);
		}
		return 0;
	}

	private void GenerateFileTimeToRun1() {

		try {
			strQuery1 = "SELECT top 10 " + select_column + " FROM " + TableName + " with (nolock) WHERE " + ColNames
					+ " = '" + ReadCode + "'";
			String fetchIInputXML = objXmlGen.APSelectWithColumnNames(cabinetName, strQuery1);
			mLogger.info("Supriyo Input XML before----->" + fetchIInputXML);
			String fetchIOutputXML = WFCallBroker.execute(fetchIInputXML, jtsIP, Integer.parseInt(jtsPort), 1);
			mLogger.info("Supriyo Output XML before----->" + fetchIOutputXML);
			fetchIOutputXML = fetchIOutputXML.replaceAll("&", "and");
			fetchIOutputXML = escapeXMLString(fetchIOutputXML, "Value");
			mLogger.info("Supriyo Output XML after----->" + fetchIOutputXML);

			DMSXmlList DMSGetWorkItemXmlList = null;
			String sReplacedXMLTag = "";
			ArrayList<String> ArrLstTableValues = new ArrayList<String>();
			String[] sArrSplitIT = null;

			String sSplit = "";
			DMSXmlResponse DMSGetWorkItemXmlResponse = null;
			DMSGetWorkItemXmlResponse = new DMSXmlResponse(fetchIOutputXML);
			mLogger.info("Output XML :\n" + DMSGetWorkItemXmlResponse + "\n");
			if (DMSGetWorkItemXmlResponse.getVal("MainCode").equals("0")) {
				mLogger.info("Data fetched successfully");
				DMSGetWorkItemXmlList = DMSGetWorkItemXmlResponse.createList("Records", "Record");
				for (int DMSGetWorkItemXmlLoopCnt = 0; DMSGetWorkItemXmlList
						.hasMoreElements(true); DMSGetWorkItemXmlList.skip(true), DMSGetWorkItemXmlLoopCnt++) {
					sReplacedXMLTag = DMSGetWorkItemXmlList.toString().replaceAll("<ALERT_INDEX>", "")
							.replaceAll("</ALERT_INDEX>", "#:;#").replaceAll("<Alert_name>", "")
							.replaceAll("</Alert_name>", "#:;#").replaceAll("<Alert_code>", "")
							.replaceAll("</Alert_code>", "#:;#").replaceAll("<Mobile_no>", "")
							.replaceAll("</Mobile_no>", "#:;#").replaceAll("<Alert_text>", "")
							.replaceAll("</Alert_text>", "#:;#").replaceAll("<Alert_Status>", "")
							.replaceAll("</Alert_Status>", "#:;#").replaceAll("<wi_Name>", "")
							.replaceAll("</wi_Name>", "#:;#").replaceAll("<Record>", "").replaceAll("</Record>", "")
							.trim();
					ArrLstTableValues.add(DMSGetWorkItemXmlLoopCnt, sReplacedXMLTag.trim());
				}
			} else if (DMSGetWorkItemXmlResponse.getVal("MainCode").equals("18")) {
				mLogger.info("Record not available....\n");
			} else if (DMSGetWorkItemXmlResponse.getVal("MainCode").equals("15")) {
				mLogger.info("Session out / sysnax error : \n" + strQuery1 + "\n");
			}

			if (!ArrLstTableValues.toString().equalsIgnoreCase("[]")) {

				for (int iIncCnt = 0; iIncCnt < ArrLstTableValues.size(); iIncCnt++) {

					sSplit = ArrLstTableValues.get(iIncCnt).toString().trim();
					sArrSplitIT = sSplit.split("#:;#");

					String sALERT_INDEX = sArrSplitIT[0].toString().trim();
					String sALERT_NAME = sArrSplitIT[1].toString().trim();
					String sALERT_CODE = sArrSplitIT[2].toString().trim();
					String sMOBILE_NO = sArrSplitIT[3].toString().trim();
					String sALERT_TEXT = sArrSplitIT[4].toString().trim();
					String sALERT_STATUS = sArrSplitIT[5].toString().trim();
					String sWORKITEM_NO = sArrSplitIT[6].toString().trim();

					Timestamp localTimestamp = new Timestamp(System.currentTimeMillis());
					Random rdn = new Random();
					String msgID = "CAS" + localTimestamp.getTime() + rdn.nextInt(100);

					String sInputXML = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>" + "<EE_EAI_MESSAGE>"
							+ "<EE_EAI_HEADER>" + "<MsgFormat>SEND_ADHOC_ALERT</MsgFormat>"
							+ "<MsgVersion>0000</MsgVersion>" + "<RequestorChannelId>CAS</RequestorChannelId>"
							+ "<RequestorUserId>OT_ADHOC_ALERT</RequestorUserId>"
							+ "<RequestorLanguage>E</RequestorLanguage>"
							+ "<RequestorSecurityInfo>Secure</RequestorSecurityInfo>" + "<ReturnCode>0000</ReturnCode>"
							+ "<ReturnDesc></ReturnDesc>" + "<MessageId>" + msgID + "</MessageId>" + "<Extra1>"
							+ "</Extra1>" + "<Extra2>2017-04-26 09:32:44</Extra2>" + "</EE_EAI_HEADER>"
							+ "<SendAdhocAlert>" + "<BankId>RAK</BankId>" + "<CustId>CAS_ADHOC_ALERT</CustId>"
							+ "<AlertMsgDelRec>" + "<CustGenInfo>" + "<CorpId>CAS_ADHOC_ALERT</CorpId>"
							+ "<EbankingUserId>CAS_ADHOC_ALERT</EbankingUserId>" + "<CustHostId>CRM</CustHostId>"
							+ "<CustDCId>CRM</CustDCId>" + "<ChannelId>SMS</ChannelId>" + "<LangId>001</LangId>"
							+ "<CustType>E</CustType>" + "<CustSubType>R</CustSubType>" + "</CustGenInfo>"
							+ "<AlertInfo>" + "<AlertName>" + sALERT_NAME + "</AlertName>"
							+ "<AlertSubj>CASSMS</AlertSubj>" + "<AlertMsg>" + sALERT_TEXT + "</AlertMsg>" + "<Addr>"
							+ sMOBILE_NO + "</Addr>" + "<Encoding>UTF-8</Encoding>" + "<isTrusted>Y</isTrusted>"
							+ "</AlertInfo>" + "</AlertMsgDelRec>" + "</SendAdhocAlert>" + "</EE_EAI_MESSAGE>";

					mLogger.info("InputXML:: " + sInputXML);

					SMSResponse = service.SMSWebservice(sInputXML);
					String whereCondition = "ALERT_INDEX =" + "'" + sALERT_INDEX + "'";
					SMSResponse = (SMSResponse.contains("<ReturnCode>"))
							? SMSResponse.substring(SMSResponse.indexOf("<ReturnCode>") + "</ReturnCode>".length() - 1,
									SMSResponse.indexOf("</ReturnCode>"))
							: "";
					if (SMSResponse.equalsIgnoreCase(SuccessResponseCode)) {
						updateStatus("'" + SuccessCode + "'", whereCondition);
					} else {
						updateStatus("'" + FailCode + "'", whereCondition);
					}
				}

			}
		} catch (IOException ex) {
			mLogger.info("IO Exception = " + ex.getMessage());
			mLogger.info("IO Exception = " + printException(ex));

		} catch (Exception ex) {
			mLogger.info("Error is saving Workitem Data = " + ex);
		}

	}

	public static String printException(Exception e) {
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		String exception = sw.toString();
		return exception;

	}

	private void updateStatus(String updatedValues, String whereClause) throws Exception {

		try {
			String updateIInputXML = objXmlGen.ExecuteQuery_APUpdate(TableName, ColNames, updatedValues, whereClause,
					cabinetName, sessionID);
			mLogger.info("Supriyo Input XML before----->" + updateIInputXML);
			String updateIOutputXML = WFCallBroker.execute(updateIInputXML, jtsIP, Integer.parseInt(jtsPort), 1);
			String mainCode2 = getTagValue(updateIOutputXML, "MainCode");
			mainCode2 = mainCode2.trim();
			mLogger.info("main code: " + mainCode2);

			if ("0".equalsIgnoreCase(mainCode2)) {
				mLogger.info("data updated sucessfully ");
				// System.exit(1);
			} else if ("11".equalsIgnoreCase(mainCode2)) {
				mLogger.info("Error during updation: " + updateIOutputXML);
				reconnectToWorkflow();
				updateStatus(updatedValues, whereClause);
			}

		} catch (IOException ex) {
			mLogger.info("Exception:" + ex.getMessage());
			ex.printStackTrace();
		}

	}

	void waiteloop(long wtime) {
		try {
			for (int i = 0; i < 10; i++) {
				Thread.yield();
				Thread.sleep(wtime / 10);
				if (!keepRunning) {
					break;
				}
			}
		} catch (InterruptedException e) {
			mLogger.info(e.toString());
			Thread.currentThread().interrupt();
		}
	}

	private String getTagValue(Node node, String tag) {
		// TODO Auto-generated method stub
		String value = "";
		NodeList nodeList = node.getChildNodes();
		int length = nodeList.getLength();

		for (int i = 0; i < length; ++i) {
			Node child = nodeList.item(i);
			if (child.getNodeType() == Node.ELEMENT_NODE && child.getNodeName().equalsIgnoreCase(tag)) {
				return child.getTextContent();
			}

		}
		// mLogger.info(tag+":"+value);
		return value;
	}

	public String connectToWorkFlow(String forceful) {
		int i = -9;
		String desc = null;
		String xmlInput = null;
		String xmlOutput = null;
		try {
			xmlInput = objXmlGen.get_WMConnect_Input(this.cabinetName, this.username, this.password, forceful);

			// System.out.println(xmlInput);

			xmlOutput = this.executeWithoutInLog(xmlInput);
			// System.out.println(xmlOutput);

			lobjXMLParser.setInputXML(xmlOutput);
			String s9 = lobjXMLParser.getValueOf("Option");
			if (!s9.equalsIgnoreCase("WMConnect")) {
				return "-9~Invalid Workflow Server IP and Port are registered.";
			}
			String s6 = lobjXMLParser.getValueOf("MainCode");
			i = Integer.parseInt(s6);
			if (i == 0) {
				sessionID = lobjXMLParser.getValueOf("SessionID");
				userID = lobjXMLParser.getValueOf("ID");

			} else {
				String s7 = lobjXMLParser.getValueOf("SubErrorCode");
				desc = lobjXMLParser.getValueOf("Description");
				i = Integer.parseInt(s7);
			}
		} catch (Exception e) {
			mLogger.info(e.toString());
			//
		}
		return i + "~" + desc;
	}

	public String executeWithoutInLog(String inXml) {
		try {
			String outXml = ngEjbClient.makeCall(inXml);
			if (GlobalVar.printScreenflag == true) {
				mLogger.info(outXml);
			}
			return outXml;
		} catch (NGException ngE) {
			mLogger.info(ngE.toString());
			disconnectFromServer();
			if (connectToServer()) {
				try {
					String outXml = ngEjbClient.makeCall(inXml);
					if (GlobalVar.printScreenflag == true) {
						mLogger.info(outXml);
					}
					return outXml;
				} catch (NGException ngE1) {
					mLogger.info(ngE1.toString());
				} catch (Exception ex) {
					mLogger.info(ex.toString());
				}
			}
			return "";
		}
	}

	private boolean reconnectToWorkflow() {
		try {
			disconnectFromWorkFlow();
			disconnectFromServer();
		} catch (Exception ex) {
			mLogger.info(ex.toString());
			return false;
		}
		try {
			if (connectToServer()) {
				String str = connectToWorkFlow("N");
				String temp[] = str.split("~");
				if (!temp[0].equals("0")) {
					Thread.sleep(10000);
					if (keepRunning) {
						if (reconnectToWorkflow()) {
							System.out.println("Reconnecting to Workflow server as first session got timed out...");
						}
					}
				}
			} else {
				return false;
			}
		} catch (Exception ex) {
			mLogger.info(ex.toString());
			return false;
		}
		return true;
	}

	public void disconnectFromWorkFlow() throws NGException {
		String str_inxml = objXmlGen.get_WMDisConnect_Input(this.cabinetName, this.sessionID);
		execute(str_inxml);
	}

	public void disconnectFromServer() {
		try {
			ngEjbClient = null;
		} catch (Exception e) {
			mLogger.info(e.toString());
		}
	}

	public String execute(String inXml) {
		try {
			if (GlobalVar.printScreenflag == true) {
				mLogger.info(inXml);
			}
			String outXml = ngEjbClient.makeCall(inXml);
			if (GlobalVar.printScreenflag == true) {
				mLogger.info(outXml);
			}
			return outXml;
		} catch (NGException ngE) {
			mLogger.info(ngE.toString());
			disconnectFromServer();
			if (connectToServer()) {
				try {
					if (GlobalVar.printScreenflag == true) {
						mLogger.info(inXml);
					}
					String outXml = ngEjbClient.makeCall(inXml);
					if (GlobalVar.printScreenflag == true) {
						mLogger.info(outXml);
					}
					return outXml;
				} catch (NGException ngE1) {
					mLogger.info(ngE1.toString());
				} catch (Exception ex) {
					mLogger.info(ex.toString());
				}
			}
			return "";
		}
	}

	private Document getDocument(String xml) throws ParserConfigurationException, SAXException, IOException {

		// Step 1: create a DocumentBuilderFactory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		// Step 2: create a DocumentBuilder
		DocumentBuilder db = dbf.newDocumentBuilder();

		// Step 3: parse the input file to get a Document object
		Document doc = db.parse(new InputSource(new StringReader(xml)));
		return doc;
	}

	private String getTagValue(String xml, String tag) throws ParserConfigurationException, SAXException, IOException {
		Document doc = getDocument(xml);
		NodeList nodeList = doc.getElementsByTagName(tag);

		int length = nodeList.getLength();
		// mLogger.info("NodeList Length: " + length);

		if (length > 0) {
			Node node = nodeList.item(0);
			// mLogger.info("Node : " + node);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				NodeList childNodes = node.getChildNodes();
				String value = "";
				int count = childNodes.getLength();
				for (int i = 0; i < count; i++) {
					Node item = childNodes.item(i);
					if (item.getNodeType() == Node.TEXT_NODE) {
						value += item.getNodeValue();
					}
				}
				return value;
			} else if (node.getNodeType() == Node.TEXT_NODE) {
				return node.getNodeValue();
			}

		}
		return "";
	}

	private int getMainCode(String xml) throws Exception {
		String code = "";
		try {
			code = getTagValue(xml, "MainCode");
		} catch (Exception e) {
			mLogger.info(e);
			throw e;
		}

		int mainCode = -1;
		try {
			mainCode = Integer.parseInt(code);
			mLogger.info("Main Code: " + mainCode);
		} catch (NumberFormatException e) {
			mainCode = -1;
		}

		return mainCode;

	}

	private boolean isSuccess(String xml) {
		if (xml.substring(xml.indexOf("<MainCode>") + 10, xml.indexOf("</MainCode>")).equals("0")) {
			return true;
		} else {
			return false;
		}
	}

	private String escapeXMLString(String sInputXML, String sTagName) {// BOA-2014/001
		String sStartTag = "<" + sTagName + ">";
		String sEndTag = "</" + sTagName + ">";
		int iStartIndex = sInputXML.indexOf(sStartTag);
		int iEndIndex = sInputXML.indexOf(sEndTag);
		mLogger.info("StartTag:" + sStartTag + "\n EndTag:" + sEndTag);
		mLogger.info("StartTag index:" + iStartIndex + "\n EndTag index:" + iEndIndex);
		while (iStartIndex >= 0) {
			StringBuilder sbXML = new StringBuilder();
			sbXML.append(sInputXML.substring(0, iStartIndex + sStartTag.length()));
			String sStringToBeReplaced = sInputXML.substring(iStartIndex + sStartTag.length(), iEndIndex);
			if (sStringToBeReplaced.length() > 0) {
				mLogger.info("Original value in XML tag:" + sStringToBeReplaced + ":to be replaced with----->"
						+ StringEscapeUtils.escapeXml(sStringToBeReplaced));
				// sInputXML=sInputXML.replaceFirst(sInputXML.substring(iStartIndex+sStartTag.length(),
				// iEndIndex), StringEscapeUtils.escapeXml(sStringToBeReplaced));
				sbXML.append(StringEscapeUtils.escapeXml(sStringToBeReplaced));
				sbXML.append(sInputXML.substring(iEndIndex, sInputXML.length()));
				sInputXML = sbXML.toString();
				iEndIndex = iStartIndex + sStartTag.length() + StringEscapeUtils.escapeXml(sStringToBeReplaced).length()
						+ sEndTag.length();
			} else {
				sbXML.append(sInputXML.substring(iEndIndex, sInputXML.length()));
				sInputXML = sbXML.toString();
				mLogger.info("else case iStartIndex:" + iStartIndex + "sStartTag.length:" + sStartTag.length());
				iEndIndex = iStartIndex + sStartTag.length();
			}
			// sbXML.append(sInputXML.substring(iEndIndex,sInputXML.length()));
			// sInputXML = sbXML.toString();
			iStartIndex = sInputXML.indexOf(sStartTag, iStartIndex + 1);
			iEndIndex = sInputXML.indexOf(sEndTag, iEndIndex + 1);
			mLogger.info("StartTag index:" + iStartIndex + "\n EndTag index:" + iEndIndex);
		}
		/* Replace escape character ">" by "&gt;" */
		return sInputXML;
	}

	/*
	 * public String SMSWebservice(String INPUTXML) { String outputString = ""; URL
	 * url = null; URLConnection connection = null; HttpURLConnection httpConn =
	 * null; HttpsURLConnection httpsConn = null; ByteArrayOutputStream bout = null;
	 * InputStreamReader isr = null; BufferedReader in = null; OutputStream out =
	 * null; String responseXML = ""; try { mLogger.info("SOAPResponse_xml" +
	 * INPUTXML);
	 * 
	 * String workingDirectory = System.getProperty("user.dir"); // String jksFile =
	 * workingDirectory + File.separator + SSL_Certificate_folder + //
	 * File.separator + SSL_Certificate_name; String cacertsFile = workingDirectory
	 * + File.separator + SSL_Certificate_folder + File.separator +
	 * SSL_Certificate_name;
	 * 
	 * String packageHndStr = "javax.net.ssl"; //
	 * java.lang.System.setProperty("java.protocol.handler.pkgs", packageHndStr); //
	 * java.lang.System.setProperty("Content-Type", "text/html"); //
	 * java.lang.System.setProperty("Content-Type",
	 * "application/soap+xml; charset=utf-8"); //
	 * java.lang.System.setProperty("javax.net.ssl.keyStore", cacertsFile); //
	 * java.lang.System.setProperty("javax.net.ssl.keyStoreType",
	 * java.security.KeyStore.getDefaultType()); //
	 * java.lang.System.setProperty("javax.net.ssl.keyStorePassword", SSL_password);
	 * // java.lang.System.setProperty("javax.net.ssl.trustStore", cacertsFile); //
	 * java.lang.System.setProperty("javax.net.ssl.trustStoreType",
	 * java.security.KeyStore.getDefaultType()); //
	 * java.lang.System.setProperty("javax.net.ssl.trustStorePassword",
	 * SSL_password);
	 * 
	 * String WSurl = ENDPOINTURL; url = new URL(WSurl); connection =
	 * url.openConnection(); mLogger.info("connected"); if (WSurl.contains("https"))
	 * { httpsConn = (HttpsURLConnection) connection;
	 * httpsConn.setConnectTimeout(Integer.parseInt("10000"));
	 * httpsConn.setReadTimeout(Integer.parseInt("20000"));
	 * 
	 * bout = new ByteArrayOutputStream(); String ipXML = INPUTXML; ipXML =
	 * ipXML.replaceAll("plussign", "+");
	 * 
	 * byte[] buffer = new byte[ipXML.length()]; buffer =
	 * ipXML.getBytes(StandardCharsets.UTF_8); bout.write(buffer); byte[] b =
	 * bout.toByteArray();
	 * 
	 * httpsConn.setRequestProperty("Content-Length", String.valueOf(b.length));
	 * httpsConn.setRequestProperty("Content-Type",
	 * "application/xml; charset=utf-8");
	 * 
	 * httpsConn.setRequestMethod("POST"); httpsConn.setDoOutput(true);
	 * httpsConn.setDoInput(true);
	 * 
	 * out = httpsConn.getOutputStream();
	 * 
	 * out.write(b); out.close(); isr = new
	 * InputStreamReader(httpsConn.getInputStream()); in = new BufferedReader(isr);
	 * String responseString; while ((responseString = in.readLine()) != null) {
	 * outputString = outputString + responseString;
	 * 
	 * } responseXML = outputString; mLogger.info("outputString https: " +
	 * responseXML); } else { httpConn = (HttpURLConnection) connection;
	 * httpConn.setConnectTimeout(Integer.parseInt("10000"));
	 * httpConn.setReadTimeout(Integer.parseInt("20000"));
	 * 
	 * bout = new ByteArrayOutputStream(); String ipXML = INPUTXML; ipXML =
	 * ipXML.replaceAll("plussign", "+");
	 * 
	 * byte[] buffer = new byte[ipXML.length()]; buffer =
	 * ipXML.getBytes(Charset.forName("UTF-8")); bout.write(buffer); byte[] b =
	 * bout.toByteArray();
	 * 
	 * httpConn.setRequestProperty("Content-Length", String.valueOf(b.length));
	 * httpConn.setRequestProperty("Content-Type",
	 * "application/xml; charset=utf-8");
	 * 
	 * httpConn.setRequestMethod("POST"); httpConn.setDoOutput(true);
	 * httpConn.setDoInput(true);
	 * 
	 * out = httpConn.getOutputStream();
	 * 
	 * out.write(b); out.close(); isr = new
	 * InputStreamReader(httpConn.getInputStream()); in = new BufferedReader(isr);
	 * String responseString; while ((responseString = in.readLine()) != null) {
	 * outputString = outputString + responseString;
	 * 
	 * } responseXML = outputString; mLogger.info("outputString http: " +
	 * responseXML); }
	 * 
	 * } catch (ConnectException e) { outputString = ""; responseXML = e.toString();
	 * mLogger.info("outputString: " + responseXML);
	 * mLogger.info("Exception Occured: " + e.getMessage()); e.printStackTrace(); }
	 * catch (SocketTimeoutException e) { outputString = ""; responseXML =
	 * e.toString(); mLogger.info("outputString: " + responseXML);
	 * mLogger.info("Exception Occured: " + e.getMessage()); e.printStackTrace(); }
	 * catch (Exception e) { outputString = ""; responseXML = e.toString();
	 * mLogger.info("outputString: " + responseXML);
	 * mLogger.info("Exception Occured: " + e.getMessage()); e.printStackTrace(); }
	 * 
	 * finally { try { if (httpConn != null) { httpConn.disconnect(); } else { if
	 * (null != httpsConn) { httpsConn.disconnect(); } } if (null != bout) {
	 * bout.close(); } if (null != isr) { isr.close(); } if (null != in) {
	 * in.close(); } if (null != out) { out.close(); } } catch (Exception e) {
	 * e.printStackTrace(); mLogger.info("Exception Occured in final block: " +
	 * e.getMessage());
	 * 
	 * } }
	 * 
	 * return "Response.... " + responseXML; }
	 */

	public boolean connectToServer() {
		try {
			ngEjbClient = NGEjbClient.getSharedInstance();
			ngEjbClient.initialize(this.jtsIP, String.valueOf(this.jtsPort), "JTS");
			return true;
		} catch (NGException ngE) {
			mLogger.info(ngE.toString());
			return false;
		}
	}

}

/*
 * class SleepThread implements Runnable {
 * 
 * @Override public void run() { System.out.println("Inside SleepThread Class."
 * ); } }
 * 
 * public class SMSAutoService {
 * 
 * 
 * public static void main(String[] args) { ThreadClient objTC = new
 * ThreadClient(); Thread objThread = new Thread(objTC); objThread.start(); } }
 */