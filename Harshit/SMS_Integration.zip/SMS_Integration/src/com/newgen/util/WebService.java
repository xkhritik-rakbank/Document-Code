package com.newgen.util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;

import javax.net.ssl.HttpsURLConnection;

public class WebService {
	
	
	public String SMSWebservice(String INPUTXML) {
		String outputString = "";
		URL url = null;
		URLConnection connection = null;
		HttpURLConnection httpConn = null;
		HttpsURLConnection httpsConn = null;
		ByteArrayOutputStream bout = null;
		InputStreamReader isr = null;
		BufferedReader in = null;
		OutputStream out = null;
		String responseXML = "";
		try {
			SMSAutoService.mLogger.info("SOAPResponse_xml" + INPUTXML);

			String workingDirectory = System.getProperty("user.dir");
			// String jksFile = workingDirectory + File.separator + SSL_Certificate_folder +
			// File.separator + SSL_Certificate_name;
			String cacertsFile = workingDirectory + File.separator + SMSAutoService.SSL_Certificate_folder + File.separator
					+ SMSAutoService.SSL_Certificate_name;

			String packageHndStr = "javax.net.ssl";
//			java.lang.System.setProperty("java.protocol.handler.pkgs", packageHndStr);
//			java.lang.System.setProperty("Content-Type", "text/html");
//			java.lang.System.setProperty("Content-Type", "application/soap+xml; charset=utf-8");
//			java.lang.System.setProperty("javax.net.ssl.keyStore", cacertsFile);
//			java.lang.System.setProperty("javax.net.ssl.keyStoreType", java.security.KeyStore.getDefaultType());
//			java.lang.System.setProperty("javax.net.ssl.keyStorePassword", SSL_password);
//			java.lang.System.setProperty("javax.net.ssl.trustStore", cacertsFile);
//			java.lang.System.setProperty("javax.net.ssl.trustStoreType", java.security.KeyStore.getDefaultType());
//			java.lang.System.setProperty("javax.net.ssl.trustStorePassword", SSL_password);

			String WSurl = SMSAutoService.ENDPOINTURL;
			url = new URL(WSurl);
			connection = url.openConnection();
			SMSAutoService.mLogger.info("connected");
			if (WSurl.contains("https")) {
				httpsConn = (HttpsURLConnection) connection;
				httpsConn.setConnectTimeout(Integer.parseInt("10000"));
				httpsConn.setReadTimeout(Integer.parseInt("20000"));

				bout = new ByteArrayOutputStream();
				String ipXML = INPUTXML;
				ipXML = ipXML.replaceAll("plussign", "+");

				byte[] buffer = new byte[ipXML.length()];
				buffer = ipXML.getBytes(StandardCharsets.UTF_8);
				bout.write(buffer);
				byte[] b = bout.toByteArray();

				httpsConn.setRequestProperty("Content-Length", String.valueOf(b.length));
				httpsConn.setRequestProperty("Content-Type", "application/xml; charset=utf-8");

				httpsConn.setRequestMethod("POST");
				httpsConn.setDoOutput(true);
				httpsConn.setDoInput(true);

				out = httpsConn.getOutputStream();

				out.write(b);
				out.close();
				isr = new InputStreamReader(httpsConn.getInputStream());
				in = new BufferedReader(isr);
				String responseString;
				while ((responseString = in.readLine()) != null) {
					outputString = outputString + responseString;

				}
				responseXML = outputString;
				SMSAutoService.mLogger.info("outputString https: " + responseXML);
			} else {
				httpConn = (HttpURLConnection) connection;
				httpConn.setConnectTimeout(Integer.parseInt("10000"));
				httpConn.setReadTimeout(Integer.parseInt("20000"));

				bout = new ByteArrayOutputStream();
				String ipXML = INPUTXML;
				ipXML = ipXML.replaceAll("plussign", "+");

				byte[] buffer = new byte[ipXML.length()];
				buffer = ipXML.getBytes(Charset.forName("UTF-8"));
				bout.write(buffer);
				byte[] b = bout.toByteArray();

				httpConn.setRequestProperty("Content-Length", String.valueOf(b.length));
				httpConn.setRequestProperty("Content-Type", "application/xml; charset=utf-8");

				httpConn.setRequestMethod("POST");
				httpConn.setDoOutput(true);
				httpConn.setDoInput(true);

				out = httpConn.getOutputStream();

				out.write(b);
				out.close();
				isr = new InputStreamReader(httpConn.getInputStream());
				in = new BufferedReader(isr);
				String responseString;
				while ((responseString = in.readLine()) != null) {
					outputString = outputString + responseString;

				}
				responseXML = outputString;
				SMSAutoService.mLogger.info("outputString http: " + responseXML);
			}

		} catch (ConnectException e) {
			outputString = "";
			responseXML = e.toString();
			SMSAutoService.mLogger.info("outputString: " + responseXML);
			SMSAutoService.mLogger.info("Exception Occured: " + e.getMessage());
			e.printStackTrace();
		} catch (SocketTimeoutException e) {
			outputString = "";
			responseXML = e.toString();
			SMSAutoService.mLogger.info("outputString: " + responseXML);
			SMSAutoService.mLogger.info("Exception Occured: " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			outputString = "";
			responseXML = e.toString();
			SMSAutoService.mLogger.info("outputString: " + responseXML);
			SMSAutoService.mLogger.info("Exception Occured: " + e.getMessage());
			e.printStackTrace();
		}

		finally {
			try {
				if (httpConn != null) {
					httpConn.disconnect();
				} else {
					if (null != httpsConn) {
						httpsConn.disconnect();
					}
				}
				if (null != bout) {
					bout.close();
				}
				if (null != isr) {
					isr.close();
				}
				if (null != in) {
					in.close();
				}
				if (null != out) {
					out.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
				SMSAutoService.mLogger.info("Exception Occured in final block: " + e.getMessage());

			}
		}

		return "Response.... " + responseXML;
	}

}
