package mainPkg;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class InteractiveMenu extends XMLModifier {
	private static String updateSRpath = "";
	private static String outputFilePath = "";
	private static String customerSRpath = "";

	public static void main(String[] args) {

		try {
			Scanner scanner = new Scanner(System.in);
			Properties properties = new Properties();
			FileInputStream input = null;
			input = new FileInputStream("D:\\Custom_utility\\MQ Tester Advanced\\config\\updateConfig.properties");
			properties.load(input);
			outputFilePath = properties.getProperty("outputFilePath");
			String cmdFilePath = properties.getProperty("cmdFilePath");
			String logFilePath = properties.getProperty("logFilePath");
			updateSRpath = properties.getProperty("updateSRpath");
			customerSRpath = properties.getProperty("customerSRPath");
			String callName = processMenu(scanner);
			String[] updateSR = callName.split("~");

			if ("CUSTOMER_SR".equals(callName)) {
				System.out.println("Inside: " + callName);

				runCmdFile(cmdFilePath);

				printLogFile(logFilePath);
			} else if ("UPDATE_SR".equals(updateSR[0])) {
				System.out.println("Inside: " + updateSR[0]);
				File xmlFile = findXMLFile(updateSRpath, updateSR[1]);
				if (xmlFile != null) {
					modifyAndSaveXML(xmlFile, outputFilePath, getWInumber());

					runCmdFile(cmdFilePath);

					printLogFile(logFilePath);
				} else {
					System.out.println("\nNo XML file found in the specified folder.");
				}
			}

			else if ("0".equals(callName)) {
				System.out.println("\nEFMS update successful! Exiting........");
			} else if ("-1".equals(callName)) {
				System.out.println("\nEFMS update failed or invalid for selected process! Exiting........");
			}

			scanner.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public String getSourcePath() {
		return updateSRpath;
	}

	public String getOutputPath() {
		return outputFilePath;
	}

	public String getCustSRPath() {
		return customerSRpath;
	}
}
