package mainPkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class SQLConnection {

	private static final String URL = "jdbc:sqlserver://10.15.14.79:5301;databaseName=rakcas;encrypt=false";
	private static final String USER = "newgen";
	private static final String PASSWORD = "newgen@123";

	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		return DriverManager.getConnection(URL, USER, PASSWORD);
	}

	protected static String executeQuery(String processName, String initialQuery) {
		String prospect = "";
		int count = 0;

		try (Connection connection = getConnection()) {

			// Prepare the first query to fetch the prospect value
			try (PreparedStatement prospectStmt = connection.prepareStatement(initialQuery);
					ResultSet rs = prospectStmt.executeQuery()) {

				if (rs.next()) {
					if ("DAO".equals(processName) || "DCC".equals(processName)) {
						prospect = rs.getString("Prospect_ID");
					} else {
						prospect = rs.getString("ProspectID");
					}
				}
			}

			// Prepare the second query for checking the count
			String countQuery = "SELECT COUNT(*) as Count FROM NG_"
					+ (("DAO".equals(processName) || "DCC".equals(processName))
							? processName + "_EXTTABLE WHERE Prospect_ID = ?"
							: "DPL_EXTTABLE WHERE ProspectID = ?");
			
			try (PreparedStatement countStmt = connection.prepareStatement(countQuery)) {
				do {
					int prospectInt = Integer.parseInt(prospect) + 1;
					//Logs added
					countStmt.setString(1, String.valueOf(prospectInt));
					System.out.println(countStmt);

					try (ResultSet rs1 = countStmt.executeQuery()) {
						//Logs added
						System.out.println(countStmt.toString());
						System.out.println(rs1.toString());
						if (rs1.next()) {
							count = rs1.getInt("Count");
							if (count > 0) {
								prospect = String.valueOf(prospectInt);
							}
						}
					}
				} while (count > 0);
			}

			System.out.println("Final Prospect: " + prospect);
			return prospect;

		} catch (ClassNotFoundException e) {
			System.err.println("SQL Server JDBC Driver not found!");
			e.printStackTrace();
		} catch (SQLException e) {
			System.err.println("Query execution failed!");
			e.printStackTrace();
		}

		return "";
	}
	
	protected static String updateInsert(String efmsQuery) {
		int rowsAffected = 0;
		try (Connection connection = getConnection();
			PreparedStatement updateStmt = connection.prepareStatement(efmsQuery)){
			
			rowsAffected = updateStmt.executeUpdate();
			System.out.println("Query executed. Rows affected: "+ rowsAffected);
			
		}
		catch (ClassNotFoundException e) {
			System.err.println("SQL Server JDBC Driver not found!");
			e.printStackTrace();
		} 
		catch (SQLException e) {
			System.err.println("Update execution failed!");
			e.printStackTrace();
		}
		
		return String.valueOf(rowsAffected);
	}
	
}