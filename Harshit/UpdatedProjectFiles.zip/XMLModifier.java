
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.Scanner;
import java.util.regex.*;
import java.util.concurrent.TimeUnit;
import java.util.Properties;

public class XMLModifier {
    // ANSI escape codes for terminal colors
    public static final String RESET = "\u001B[0m";
    public static final String RED = "\u001B[31m";
    public static final String GREEN = "\u001B[32m";
    public static final String YELLOW = "\u001B[33m";
    public static final String CYAN = "\u001B[36m";

    public static void runCmdFile(String cmdFilePath) {
        try {
            File parentDir = new File(cmdFilePath);
            ProcessBuilder processBuilder = new ProcessBuilder("cmd.exe", "/c", parentDir.getAbsolutePath());
            processBuilder.redirectErrorStream(true);
            processBuilder.directory(parentDir.getParentFile());
            Process process = processBuilder.start();

            Thread outputThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        System.out.println(GREEN + line + RESET);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            outputThread.start();
            boolean finished = process.waitFor(5, TimeUnit.SECONDS);

            if (!finished) {
                System.out.println(RED + "CMD execution timed out. Destroying process..." + RESET);
                process.destroy();
            }

            outputThread.join();
            System.out.println(GREEN + "CMD Execution Completed with Exit Code: " + process.exitValue() + RESET);

        } catch (Exception e) {
            System.err.println(RED + "CMD execution failed!" + RESET);
            e.printStackTrace();
        }
    }

    public static void printLogFile(String logFilePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(logFilePath))) {
            String line;
            System.out.println(YELLOW + "\n--- Log File Contents ---" + RESET);
            while ((line = reader.readLine()) != null) {
                System.out.println(CYAN + line + RESET);
            }
            System.out.println(YELLOW + "--- End of Log File ---\n" + RESET);
        } catch (FileNotFoundException e) {
            System.out.println(RED + "Log file not found: " + logFilePath + RESET);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void modifyAndSaveXML(File inputFile, String outputFilePath, int newNumber) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(inputFile);
            document.getDocumentElement().normalize();

            NodeList attributeList = document.getElementsByTagName("Attribute");
            for (int i = 0; i < attributeList.getLength(); i++) {
                Element attributeElement = (Element) attributeList.item(i);
                if ("WINUMBER".equals(attributeElement.getElementsByTagName("Name").item(0).getTextContent())) {
                    String oldWINumber = attributeElement.getElementsByTagName("Value").item(0).getTextContent();
                    String updatedWINumber = String.format("%010d", newNumber);
                    attributeElement.getElementsByTagName("Value").item(0).setTextContent(updatedWINumber);
                    break;
                }
            }

            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "no");
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

            transformer.transform(new DOMSource(document), new StreamResult(new File(outputFilePath)));
            System.out.println(GREEN + "Modified XML saved to: " + outputFilePath + RESET);

        } catch (Exception e) {
            System.err.println(RED + "Failed to modify and save XML." + RESET);
            e.printStackTrace();
        }
    }
}
