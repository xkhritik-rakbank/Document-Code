package passwordEncryp;

import adminclient.*;

public class Encoding {

	private static final char[] HEX = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E',
			'F' };

	public static String encrypt(String text) throws Exception {
		byte[] byteArray = OSASecurity.encode(text.getBytes("UTF-8"));
		StringBuffer hexBuffer = new StringBuffer(byteArray.length * 2);
		for (int i = 0; i < byteArray.length; ++i)
			for (int j = 1; j >= 0; --j)
				hexBuffer.append(HEX[(byteArray[i] >> j * 4 & 0xF)]);
		return hexBuffer.toString();
	}

	private static String decrypt(String pass) {
		int len = pass.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(pass.charAt(i), 16) << 4) + Character.digit(pass.charAt(i + 1), 16));
		}
		String password = OSASecurity.decode(data, "UTF-8");
		return password;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String s =encrypt("DLINT");
			System.out.println(s);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
