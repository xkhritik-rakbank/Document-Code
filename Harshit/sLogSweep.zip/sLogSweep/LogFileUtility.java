import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

public class LogFileUtility {

    // For color coded messages
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String BLUE = "\u001B[34m";
    private static final String YELLOW = "\u001B[33m";

    public static void main(String[] args) {
        System.out.println("********************************************************");
        System.out.println();
        System.out.println("* ----------Built with GPT-4 by Harshit Rai----------- *");
        System.out.println();
        System.out.println("********************************************************");
        System.out.println(YELLOW + "Welcome to the Log File Cleaner Utility!" + RESET);

        // Load directories from properties file
        List<String> directories = loadDirectoriesFromProperties("D:/sLogSweep/config.properties");

        if (directories.isEmpty()) {
            System.out.println(RED + "No directories found in the properties file." + RESET);
            return;
        }

        Scanner scanner = new Scanner(System.in);

        for (String directoryPath : directories) {
            File directory = new File(directoryPath);
            if (directory.exists() && directory.isDirectory()) {
                // Simulate scanning the D drive with a progress bar
                simulateDriveScanning(directoryPath);

                // Collect subfolders to delete (including deep subfolders)
                List<File> foldersToDelete = new ArrayList<>();
                collectFoldersToDelete(directory, foldersToDelete);

                if (!foldersToDelete.isEmpty()) {
                    System.out.println(
                            BLUE + "The following folders contain .log and .xml files larger than 2MB:" + RESET);
                    for (File folder : foldersToDelete) {
                        System.out.println(folder.getAbsolutePath());
                    }

                    // Ask user confirmation before deleting
                    System.out.print(YELLOW + "Do you want to delete these folders? (yes/no): " + RESET);
                    String userInput = scanner.nextLine();

                    if ("yes".equalsIgnoreCase(userInput)) {
                        // Delete subfolders with delay(Is more fun and increases engagement!)
                        for (File folder : foldersToDelete) {
                            deleteFolderWithAnimation(folder);
                        }

                        System.out.println("**************************************************");
                        System.out.println("* Service server just got a little more cleaner! *");
                        System.out.println("**************************************************");
                    } else {
                        System.out.println(GREEN + "No folders were deleted." + RESET);
                    }
                } else {
                    System.out.println(BLUE + "No folders with .log or .xml files larger than 2MB found in: "
                            + directoryPath + RESET);
                }
            } else {
                System.out.println(RED + "Directory does not exist or is not a directory: " + directoryPath + RESET);
            }
        }

        // Prompt user to press any key to exit
        System.out.println(YELLOW + "Press Enter to exit..." + RESET);
        try {
            System.in.read();
        } catch (IOException e) {
            System.err.println(RED + "Error reading input: " + e.getMessage() + RESET);
        }
    }

    private static List<String> loadDirectoriesFromProperties(String propertiesFilePath) {
        List<String> directories = new ArrayList<>();
        try (FileInputStream input = new FileInputStream(propertiesFilePath)) {
            Properties prop = new Properties();
            prop.load(input);
            String dirs = prop.getProperty("directories");
            if (dirs != null) {
                for (String dir : dirs.split(",")) {
                    directories.add(dir.trim());
                }
            }
        } catch (IOException e) {
            System.err.println(RED + "Error reading properties file: " + e.getMessage() + RESET);
        }
        return directories;
    }

    // Picks up the folder which contains the file mentioned in the directory from
    // the config
    private static void collectFoldersToDelete(File directory, List<File> foldersToDelete) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            boolean containsLargeFiles = false;

            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        // Recursively collect from subdirectories
                        collectFoldersToDelete(file, foldersToDelete);
                    } else if ((file.getName().matches("(?i).*\\.log.*") || file.getName().matches("(?i).*\\.xml.*"))
                            && file.length() > 2 * 1024 * 1024 && !isModifiedTodayOrYesterday(file)) {
                        containsLargeFiles = true; // Mark the folder if it contains large files
                    }
                }
            }

            // Only add the folder to the list if it contains large files
            if (containsLargeFiles) {
                foldersToDelete.add(directory);
            }
        }
    }

    private static boolean isModifiedTodayOrYesterday(File file) {
        Calendar calendar = Calendar.getInstance();

        // Current Date
        Date today = calendar.getTime();

        // Yesterday's Date
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        Date yesterday = calendar.getTime();

        // Get file's last modified date
        Date fileDate = new Date(file.lastModified());

        // Check if the file was modified today or yesterday
        return isSameDay(today, fileDate) || isSameDay(yesterday, fileDate);
    }

    private static boolean isSameDay(Date date1, Date date2) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(date1);

        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date2);

        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR)
                && cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
    }

    /**
     * Deletes a folder and its contents, with a delay to simulate processing.
     * This method deletes the folder if it contains the large log/xml files.
     */
    private static void deleteFolderWithAnimation(File folder) {
        if (folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteFolderWithAnimation(file); // Recursively delete contents
                }
            }
        }

        simulateDeletionAnimation(folder);

        if (!folder.delete()) {
            System.err.println(RED + "Failed to delete: " + folder.getAbsolutePath() + RESET);
        } else {
            System.out.println(GREEN + "Deleted: " + folder.getAbsolutePath() + RESET);
        }
    }

    // Delete Pause
    private static void simulateDeletionAnimation(File folder) {
        System.out.print(BLUE + "Deleting " + folder.getName() + " ");
        try {
            for (int i = 0; i < 3; i++) {
                Thread.sleep(50); // 50ms delay
                System.out.print(".");
            }
            System.out.println(RESET);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Function to simulate drive scanning with a progress bar
    private static void simulateDriveScanning(String directoryPath) {
        System.out.println(BLUE + "Scanning directory: " + directoryPath + RESET);

        // Simulate the progress bar with a loop
        int totalProgress = 50;
        for (int i = 0; i <= totalProgress; i++) {
            // Print progress bar
            System.out.print("\r[");
            for (int j = 0; j < totalProgress; j++) {
                if (j < i) {
                    System.out.print("=");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.print("] " + (i * 100 / totalProgress) + "%");

            // Slow down to simulate work being done
            try {
                Thread.sleep(50); // 50ms delay to simulate scanning
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println();
        System.out.println(GREEN + "Drive scan completed for: " + directoryPath + RESET);
    }
}
