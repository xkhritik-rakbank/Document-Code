CREATE TABLE Cause_of_Death (
    DESCPFX	VARCHAR(512),
    DESCTABL	VARCHAR(512),
    DESCITEM	VARCHAR(512),
    SHORTDESC	VARCHAR(512),
    LONGDESC	VARCHAR(512)
);

INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('HE', 'T5548', '', '', 'Cause of Death');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'ACCD', 'ACCD', 'Accident');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'ACDR', 'ACDR', 'Accident Drowning');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'ACVE', 'ACVE', 'Acute Viral Encephalitis');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'AFAL', 'AFAL', 'Accidental Fall');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'APCT', 'APCT', 'Appendicitis');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'ASSP', 'ASSP', 'Abscess & Sepsis');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'BACC', 'BACC', 'Accident (Blast)');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'BCAC', 'BCAC', 'Building Collapse');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'BDCR', 'BDCR', 'Blood Cancer');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'BDIF', 'BDIF', 'Blood Infection');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'BRCR', 'BRCR', 'Brain Cancer');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'BRHG', 'BRHG', 'Brain Haemorrhage');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'BSAR', 'BSAR', 'Post LRLT Biliary Stricture');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CDWV', 'CDWV', 'Cold wave');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CEVA', 'CEVA', 'Cerebro Vascular Accident');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CHPN', 'CHPN', 'Chest Pain');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CLBM', 'CLBM', 'Carcinoma of Left Bukal Mucosa');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CLVR', 'CLVR', 'Cirrhosis of Liver');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CNCR', 'CNCR', 'Cancer');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'COVD', 'Covd', 'Covid-19');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CRAD', 'CRAD', 'Coronary Artery Disease');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CRAT', 'CRAT', 'Cardio Respiratory Arrest');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CRFL', 'CRFL', 'Cardio Respiratory Failure');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CRTH', 'CRTH', 'Cerebral thrombosis');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'CVAC', 'CVAC', 'Cardio Vascular Accident');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'DBML', 'DBML', 'Diabetes Mellitus');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'EPLP', 'EPLP', 'Epilepsy');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'EXGR', 'EXGR', 'Ex Gratia');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'FACD', 'FACD', 'Fire Accident');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'FEVR', 'FEVR', 'Fever');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'GNST', 'GNST', 'Gunshot');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'HIV', 'HIV', 'HIV');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'HLSM', 'HLSM', 'Hailstorm');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'HMRG', 'HMRG', 'Haemorrhage');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'HPEP', 'HPEP', 'Hepatic Encephalitis');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'HRAT', 'HRAT', 'Heart Attack');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'HTSK', 'HTSK', 'Heat Stroke');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'HYPT', 'HYPT', 'Hypertension');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'IALF', 'IALF', 'ATT Induced Acute Liver');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'ILLN', 'ILLN', 'Illness');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'INBD', 'INBD', 'Intracranial Bleed');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'INIF', 'INIF', 'Intestinal Infection');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'JAUN', 'JAUN', 'Jaundice');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'KAFL', 'KAFL', 'Karnataka Flood');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'KDCR', 'KDCR', 'Cancer - Kidney');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'KLFL', 'KLFL', 'Kerela floods');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'LHTN', 'LHTN', 'Lightening');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'LMLK', 'LMLK', 'Acute Lymphoblastic Leukemia');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'LNCR', 'LNCR', 'Cancer - Lung');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'MLRA', 'MLRA', 'Malaria');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'MNRD', 'MNRD', 'Motor Neuron Disease');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'MODF', 'MODF', 'Multiorgan dysfunction');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'MOGF', 'MOGF', 'Multi Organ Failure');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'MRDA', 'MRDA', 'Murder');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'MYOC', '', 'Myocardial Infarction');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'NACC', 'NACC', 'Non Accidental Death');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'NTGV', 'NTGV', 'Not given');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'NTRL', 'NTRL', 'Natural');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'OVCR', 'OVCR', 'Cancer Ovary');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'PCAR', 'PCAR', 'Pulmonary Cardiac Arrest');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'PMTB', 'PMTB', 'Pulmonary Tuberculosis');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'POIS', 'POIS', 'Poisoning/Accident');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'PRSK', 'PRSK', 'Paralytic Stroke');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'RABS', 'RABS', 'Rabbies');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'RECC', 'RECC', 'Renal Cell Carcinoma');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'RNFL', 'RNFL', 'Renal Failure');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'RTAC', 'RTAC', 'Road Traffic Acdnt');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'RVDS', 'RVDS', 'Retroviral Disease');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'SDDT', 'SDDT', 'Sudden Death');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'SKBT', 'SKBT', 'Snake Bite');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'SSMF', 'SSMF', 'Severe Sepsis-Multiorgan failr');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'SSRF', 'SSRF', 'Septic Shock/Renal failure');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'STPN', 'STPN', 'Stomach pain');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'STRK', 'STRK', 'Stroke');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'SUCI', '', 'Suicide Death');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'TACD', 'TACD', 'Train Accident');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'THDR', 'THDR', 'Thundering');
INSERT INTO Cause_of_Death (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'T5548', 'VMLM', 'VMLM', 'Vomitting and loose motions');



CREATE TABLE Nominee_Relationship (
    LONGDESC	VARCHAR(512)
);

INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Nominee relationship');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Aunt');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Brother-in-Law');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('BR');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Cousin');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Daughter');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Daughter-In-Law');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Father');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Father-in-Law');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Friend');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Grand Daughter');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('GrandFather');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('GrandMother');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Grandson');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Husband');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Mother-in-Law');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Mother');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Nephew');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Niece');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Sister');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Sister-in-Law');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Son');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Trust');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Uncle');
INSERT INTO Nominee_Relationship (LONGDESC) VALUES ('Wife');



CREATE TABLE Critical_Illness (
    DESCPFX	VARCHAR(512),
    DESCTABL	VARCHAR(512),
    DESCITEM	VARCHAR(512),
    SHORTDESC	VARCHAR(512),
    LONGDESC	VARCHAR(512)
);

INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('HE', 'TZB87', '', '', 'Critical Illness');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'ALZH', 'ALZH', 'Alzheimer\'s Disease');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'APLA', 'APLA', 'Aplastic Anaemia');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'ASYN', 'ASYN', 'Apallic Syndrome');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'BACM', 'BACM', 'Bacterial Meningitis');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'BLND', 'BLND', 'Blindness');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'BSUR', 'BSUR', 'Brain Surgery');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'BTUM', 'BTUM', 'Benign Brain Tumor');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'CABG', 'CABG', 'Open Chest CABG');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'CARS', 'CARS', 'Carotid Artery Surgery');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'CHRP', 'CHRP', 'Chronic Recurrent Pancreatitis');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'CILS', 'CILS', 'Critical Illness');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'CLUG', 'CLUG', 'Chronic Lung Disease');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'CNCR', 'CNCR', 'Cancer of Specified Severity');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'COMA', 'COMA', 'Coma of Specified Severity');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'CRDO', 'CRDO', 'Cardiomyopathy');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'DBPL', 'DBPL', 'Disoln of nerve of Brach Plexs');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'DEAF', 'DEAF', 'Deafness');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'ELIV', 'ELIV', 'End Stage Liver Disease');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'ENCE', 'ENCE', 'Encephalitis');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'FVHP', 'FVHP', 'Fulminant Viral Hepatitis');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'HATK', 'HATK', 'Frst Hrt Atk of specfd severty');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'HSUR', 'HSUR', 'Opn Hrt Repl/Repr of Hrt Valve');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'KDNF', 'KDNF', 'Kdny Failure Req Reg Dialysis');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'LIND', 'LIND', 'Loss of Independent Existence');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'LLMB', 'LLMB', 'Loss of Limbs');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'LSCH', 'LSCH', 'Loss of Speech');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'MBUR', 'MBUR', 'Major Burns');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'MCKD', 'MCKD', 'Medulry Cystic Kidney Disease');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'MHET', 'MHET', 'Major Head Trauma');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'MNUR', 'MNUR', 'Mtr Nurn Dis with Perman Sympt');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'MORT', 'MORT', 'Mjr Org/Bone Marrow Transplant');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'MSCL', 'MSCL', 'Multi Scls with Persistn Sympt');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'MUSD', 'MUSD', 'Muscular Dystrophy');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'PARA', 'PARA', 'Permanent Paralysis of Limbs');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'PHYT', 'PHYT', 'Primary Pulmonary Hypertension');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'PRKD', 'PRKD', 'Parkinson\'s Disease');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'PRSS', 'PRSS', 'Progressive Systemic Sclerosis');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'SLLN', 'SLLN', 'SLE with Lupus Nephritis');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'STRK', 'STRK', 'Strk result in Permnt Symptoms');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'SURA', 'SURA', 'Surgery to Aorta');
INSERT INTO Critical_Illness (DESCPFX, DESCTABL, DESCITEM, SHORTDESC, LONGDESC) VALUES ('IT', 'TZB87', 'ULCL', 'ULCL', 'Ulcerative Colitis');




CREATE TABLE Nature_Of_Accident (
    Nature of Accident	VARCHAR(512)
);

INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Accident');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Accident Drowning');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Accidental Fall');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Accident (Blast)');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Building Collapse');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Fire Accident');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Gunshot');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Murder');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Poisoning/Accident');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Road Traffic Acdnt');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Snake Bite');
INSERT INTO Nature_Of_Accident (Nature of Accident) VALUES ('Train Accident');




CREATE TABLE NG_Master_Policy (
    PolicyNo	INT,
    Client ID	INT,
    Application No	VARCHAR(512),
    Salutation	VARCHAR(512),
    FirstName	VARCHAR(512),
    MiddleName	VARCHAR(512),
    LastName	VARCHAR(512),
    DOB	VARCHAR(512),
    Type	VARCHAR(512),
    MemberID	VARCHAR(512),
    Group_Company_Name	VARCHAR(512)
);

INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000001', '9000001', 'A000001', 'Mr', 'Lal', '', 'Singh', '12-Jan-73', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000002', '9000002', 'A000002', 'Mr', 'Abdul', '', 'Ahmed', '12-Jul-84', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000003', '9000003', 'A000003', 'Mr', 'Ram', 'Singh', 'Purohit', '1-Feb-89', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000004', '9000004', 'A000004', 'Ms', 'Amita', 'Rani', 'Khanna', '6-Aug-78', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000005', '9000005', 'A000005', 'Ms', 'Sukhpreet', '', 'Singh', '4-Sep-98', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000006', '9000006', 'A000006', 'Ms', 'Madhuri', '', 'Bhatia', '12-Dec-78', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000007', '9000007', 'A000007', 'Mr', 'Piyush', '', 'Khanna', '12-Dec-78', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000008', '9000001', 'A000008', 'Mr', 'Lal', '', 'Singh', '12-Jan-73', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000009', '9000002', 'A000009', 'Mr', 'Abdul', '', 'Ahmed', '12-Jul-84', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000010', '9000008', 'A000010', 'Mr', 'Subhodh', '', 'Agarwal', '1-Feb-89', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000011', '9000009', 'A000011', 'Mr', 'Bipin', '', 'Sharma', '6-Aug-78', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000012', '9000010', 'A000012', 'Mr', 'Ravi', '', 'Lal', '4-Sep-98', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('10000013', '9000011', 'A000013', 'Mr', 'Krishna', '', 'Sharma', '1-Feb-89', 'Individual', '', '');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000001', 'AX0000001', 'X000001', 'Mr', 'Deepansh', '', 'Makkar', '12-Apr-73', 'Group', 'NG000001', 'Newgen Software Tech Ltd');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000001', 'AX0000001', 'X000001', 'Ms', 'Shreya', '', 'Sachan', '3-Feb-74', 'Group', 'NG000002', 'Newgen Software Tech Ltd');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000001', 'AX0000001', 'X000001', 'Mr', 'Manish', 'Singh', 'Sengar', '18-Sep-83', 'Group', 'NG000003', 'Newgen Software Tech Ltd');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000001', 'AX0000001', 'X000001', 'Ms', 'Princi', '', 'Chak', '21-Oct-71', 'Group', 'NG000004', 'Newgen Software Tech Ltd');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000001', 'AX0000001', 'X000001', 'Mr', 'Rahul', '', 'Kumar', '12-Dec-78', 'Group', 'NG000005', 'Newgen Software Tech Ltd');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000001', 'AX0000001', 'X000001', 'Mr', 'Abhas', '', 'Pathak', '12-Dec-78', 'Group', 'NG000006', 'Newgen Software Tech Ltd');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000001', 'AX0000001', 'X000001', 'Mr', 'Shiva', '', 'Verma', '12-Jan-73', 'Group', 'NG000007', 'Newgen Software Tech Ltd');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000002', 'AX0000002', 'X000002', 'Mr', 'Sai', 'Karthik', 'S', '12-Jul-84', 'Group', 'WG00001', 'Wipro');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000002', 'AX0000002', 'X000002', 'Mr', 'Pratishtha ', '', 'Madeshia', '1-Feb-89', 'Group', 'WG00002', 'Wipro');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000002', 'AX0000002', 'X000002', 'Ms', 'Princy ', '', 'Bhasin', '1-Feb-89', 'Group', 'WG00003', 'Wipro');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000002', 'AX0000002', 'X000002', 'Mr', 'Sameer ', '', 'Kumar', '12-Apr-73', 'Group', 'WG00004', 'Wipro');
INSERT INTO NG_Master_Policy (PolicyNo, Client ID, Application No, Salutation, FirstName, MiddleName, LastName, DOB, Type, MemberID, Group_Company_Name) VALUES ('X0000002', 'AX0000002', 'X000002', 'Mr', 'Pawan', '', 'Gupta', '3-Feb-74', 'Group', 'WG00005', 'Wipro');



CREATE TABLE  NG_Policy_Claims (
    PolicyNo	VARCHAR(512),
    NotificationID	VARCHAR(512),
    ClaimID	VARCHAR(512),
    ClaimType	VARCHAR(512),
    Status	VARCHAR(512),
    ApprovedAmount	INT,
    IntimationDate	VARCHAR(512)
);

INSERT INTO  NG_Policy_Claims (PolicyNo, NotificationID, ClaimID, ClaimType, Status, ApprovedAmount, IntimationDate) VALUES ('10000001', 'NT0001', 'CL01011', 'Accidental Disability', 'CLOSED', '10000', '1-Apr-20');
INSERT INTO  NG_Policy_Claims (PolicyNo, NotificationID, ClaimID, ClaimType, Status, ApprovedAmount, IntimationDate) VALUES ('X0000001', 'NT0002', 'CL01012', 'Critical Illness', 'CLOSED', '50000', '31-Dec-22');
