ALTER TRIGGER [dbo].[FAS_CUSTOM_ALERT_GEN_TRIGGER] ON [dbo].[RAK_FAS_ALERT_HOST_CUST_TABLE]



AFTER  INSERT 



AS







BEGIN







DECLARE







    @ASBT_BANK_ID      CHAR(9),



    @ASBT_ALERT_ID     CHAR(10),



    @ASBT_CORP_ID      CHAR(64),



    @ASBT_USER_ID       CHAR(32),



    @ASBT_CUST_HOST_ID CHAR(4),



    @ASBT_CUST_DC_ID   CHAR(9),



    @ASBT_APP_TYPE        CHAR(3),



    @ASBT_UNIQUE_ID     CHAR(64),    



    @MESSAGE                      VARCHAR(4000),



    @DATA_EXIST                   CHAR(1),



       @SRNUMBER        CHAR(30),



       @AMT        CHAR(30),



       @STATUS        CHAR(30),



       @MSG        CHAR(20),



       @CARDNUM      CHAR(20),



	   @CRN			 CHAR(3),



	   @FRACID		CHAR(24),



	   @BENEFICIARY		CHAR(100),



	    @TLNUM		CHAR(100),



		@COMPNAME		CHAR(100),



		@CUSTNAME      CHAR(100),



		@ACCTYPE		CHAR(100),



		@BRANCHNAME		CHAR(100),



		@BRANCHTIME		CHAR(100),



		@BRANCHDAY      CHAR(100),



		@SRNAME			CHAR(100),



    @NEW_ALERT_ID           CHAR(10),



    @NEW_BANK_ID             CHAR(9),



       @NEW_ALERT_TYPE     CHAR(9),



    @NEW_IDENTIFIER1       CHAR(64),



    @NEW_IDENTIFIER2       CHAR(250),



    @NEW_UNIQUE_ID       CHAR(64),



       @SUB_STATUS       CHAR(64),



    @NEW_OUTPUT_PARAMS CHAR(250),



    @NEW_CIF_ID                   CHAR(64),



	@SRDATE			CHAR(100),



	@SRBROPENTIME	CHAR(100),



	@SRBRCLOSETIME  CHAR(100),



	@SRFIRSTDOW		CHAR(100),



	@SRLASTDOW		CHAR(100),



	@SRMODE			CHAR(100),



	@SRSTATUS		CHAR(100),



	@SRTENOR		CHAR(100),



	@SRPROCESSFEE	CHAR(100),



	@ALERT_PROCESS_STATUS                    CHAR(64);



    



    PRINT 'NONFIN_CUST START';



       



    SET @DATA_EXIST = 'N';



       SET @SUB_STATUS = 'N';







    SELECT @NEW_ALERT_ID = ALERT_ID, @NEW_BANK_ID=BANK_ID,@NEW_ALERT_TYPE=ALERT_TYPE,@NEW_IDENTIFIER1=IDENTIFIER1,@NEW_IDENTIFIER2=OUTPUT_PARAMS,@NEW_UNIQUE_ID=UNIQUE_ID,@NEW_OUTPUT_PARAMS=OUTPUT_PARAMS,@NEW_CIF_ID=CIF_ID,@ALERT_PROCESS_STATUS=ALERT_PROCESS_STATUS FROM INSERTED;







IF (@NEW_ALERT_ID = 'BPMSTPRQST' OR @NEW_ALERT_ID = 'BPMNSTPINT' OR @NEW_ALERT_ID = 'BPMFULREDM' OR @NEW_ALERT_ID = 'BPMPARTAPR' OR @NEW_ALERT_ID = 'BPMFULFORT' OR @NEW_ALERT_ID = 'BPMNSTPREJ' OR @NEW_ALERT_ID = 'BPMTATSLAB' OR @NEW_ALERT_ID = 'BPMCARDBLK'


OR @NEW_ALERT_ID = 'BPMBTRINIT' OR @NEW_ALERT_ID = 'BPMCCCINIT' OR @NEW_ALERT_ID = 'BPMCCCPROC' OR @NEW_ALERT_ID = 'BPMACCTCLO' OR @NEW_ALERT_ID = 'BPMOUTTTIN' OR @NEW_ALERT_ID = 'BPMCALLFAL' OR @NEW_ALERT_ID = 'BPMTLURQST' OR @NEW_ALERT_ID = 'BPMTLRQFL'


OR @NEW_ALERT_ID = 'BPMTLRQSC' OR @NEW_ALERT_ID = 'BPM_CIFUPD' OR @NEW_ALERT_ID = 'BPM_CIFDOC' OR @NEW_ALERT_ID = 'BPM_CIFREJ' OR @NEW_ALERT_ID = 'BPM_CNCREJ' OR @NEW_ALERT_ID = 'BPM_CNCSUC' OR @NEW_ALERT_ID = 'BPM_CNCACT' OR @NEW_ALERT_ID = 'BPM_CNCREM'


OR @NEW_ALERT_ID = 'BPM_SRPEN' OR @NEW_ALERT_ID = 'BPM_SRDOC' OR @NEW_ALERT_ID = 'BPM_SRAPR' OR @NEW_ALERT_ID = 'BPM_SRARDC' OR @NEW_ALERT_ID = 'BPM_SRREJ' OR @NEW_ALERT_ID = 'BPM_SRFAPR' OR @NEW_ALERT_ID = 'BPM_SRAPRC' OR @NEW_ALERT_ID = 'BPM_SRAPRB' 


OR @NEW_ALERT_ID = 'BPM_SRBCLC' OR @NEW_ALERT_ID = 'BPM_SRBDLV' OR @NEW_ALERT_ID = 'BPM_SRBPRC' OR @NEW_ALERT_ID = 'BPM_SRBCDL' OR @NEW_ALERT_ID = 'BPM_SRBCEX' OR @NEW_ALERT_ID = 'BPM_SRMSCN' OR @NEW_ALERT_ID = 'BPM_SRMSCP' OR @NEW_ALERT_ID = 'BPM_SRINVN'
 

OR @NEW_ALERT_ID = 'BPM_SRINVY' OR @NEW_ALERT_ID = 'BPM_SRINVA' OR @NEW_ALERT_ID = 'BPM_SRINVC' OR @NEW_ALERT_ID = 'BPM_SRINVD' OR @NEW_ALERT_ID = 'BPM_SRINVS' OR @NEW_ALERT_ID = 'BPM_SRLUPT' OR @NEW_ALERT_ID = 'BPMFATAPR' OR @NEW_ALERT_ID = 'BPMFATREJ') 


 



BEGIN



     



       PRINT 'BPM ALERTS:BEGIN';



--       Declare tmpCur3 Cursor For SELECT  ASBT.BANK_ID, ASBT.ALERT_ID, ASBT.CORP_ID, ASBT.USER_ID, 

--

--                            ASBT.CUST_HOST_ID, ASBT.CUST_DC_ID, ASBT.APP_TYPE, ASBT.UNIQUE_ID

--

--                    FROM ASBT

--

--                    WHERE ASBT.ALERT_ID  = @NEW_ALERT_ID AND

--

--                          ASBT.STRING1   = @NEW_BANK_ID A

--

--                          ASBT.STRING2   = @NEW_IDENTIFIER1



--       OPEN tmpCur3



       



--   Fetch Next from tmpCur3 into @ASBT_BANK_ID,@ASBT_ALERT_ID,@ASBT_CORP_ID,@ASBT_USER_ID,@ASBT_CUST_HOST_ID,@ASBT_CUST_DC_ID,@ASBT_APP_TYPE,@ASBT_UNIQUE_ID 



  --      WHILE(@@fetch_status= 0 )



              begin



                   



                  IF (@NEW_ALERT_ID = 'BPMSTPRQST') 



                           BEGIN



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @AMT  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @STATUS =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @MSG =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE         =LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@AMT))+'^T'+LTRIM(RTRIM(@STATUS))+'^T'+LTRIM(RTRIM(@MSG))+'^T';



                           END



						   



						   else if (@NEW_ALERT_ID = 'BPM_SRLUPT') 



                           BEGIN



                                  SET @CUSTNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@CUSTNAME))+'^T';



                           END   



				else if (@NEW_ALERT_ID = 'BPMFATAPR') 



                           BEGIN



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T';



                           END 



				else if (@NEW_ALERT_ID = 'BPMFATREJ') 



                           BEGIN



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T';



                           END 			



						   



            else if (@NEW_ALERT_ID = 'BPMNSTPINT') 



                           BEGIN



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @CARDNUM  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @AMT =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE=LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@CARDNUM))+'^T'+LTRIM(RTRIM(@AMT))+'^T';



                           END 



                      else if (@NEW_ALERT_ID = 'BPMFULREDM') 



                           BEGIN



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @AMT  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @STATUS =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @MSG =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE         =LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@AMT))+'^T'+LTRIM(RTRIM(@STATUS))+'^T'+LTRIM(RTRIM(@MSG))+'^T';



                           END



                      else if (@NEW_ALERT_ID = 'BPMPARTAPR') 



                           BEGIN



                                  



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @AMT  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @MSG =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE         =LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@AMT))+'^T'+LTRIM(RTRIM(@MSG))+'^T';



                           END   



                           else if (@NEW_ALERT_ID = 'BPMFULFORT') 



                           BEGIN



                                  



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @AMT =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE         =LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@AMT))+'^T';



                           END   



                           else if (@NEW_ALERT_ID = 'BPMNSTPREJ') 



                           BEGIN



                                  



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @AMT  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @STATUS =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE         =LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@AMT))+'^T'+LTRIM(RTRIM(@STATUS))+'^T';



                           END



                           else if (@NEW_ALERT_ID = 'BPMCARDBLK') 



                 BEGIN



                                  



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @MSG =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE         =LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@MSG))+'^T';



                           END



                           else if (@NEW_ALERT_ID = 'BPMTATSLAB') 



                           BEGIN



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @CARDNUM  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @AMT =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE         =LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@CARDNUM))+'^T'+LTRIM(RTRIM(@AMT))+'^T';



                           END  



							else if (@NEW_ALERT_ID = 'BPMBTRINIT' OR @NEW_ALERT_ID = 'BPMCCCINIT' OR @NEW_ALERT_ID = 'BPM_SRMSCN' OR @NEW_ALERT_ID = 'BPM_SRMSCP') 



                           BEGIN



                                  SET @AMT =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1))



								  



								  SET @CARDNUM  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE =LTRIM(RTRIM(@AMT))+'^T'+LTRIM(RTRIM(@CARDNUM))+'^T';



                           END   



						   else if (@NEW_ALERT_ID = 'BPMCCCPROC') 



                           BEGIN



                                  SET @AMT =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1))



								  



								  SET @STATUS =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1))



								  



								  SET @CARDNUM  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE         =LTRIM(RTRIM(@AMT))+'^T'+LTRIM(RTRIM(@STATUS))+'^T'+LTRIM(RTRIM(@CARDNUM))+'^T';



                           END  



						else if (@NEW_ALERT_ID = 'BPMACCTCLO') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1))



								  



								  SET @STATUS =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@STATUS))+'^T';



                           END



						else if (@NEW_ALERT_ID = 'BPMOUTTTIN') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @CRN =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @AMT =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @FRACID =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @BENEFICIARY =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@CRN))+'^T'+LTRIM(RTRIM(@AMT))+'^T'+LTRIM(RTRIM(@FRACID))+'^T'+LTRIM(RTRIM(@BENEFICIARY))+'^T';



                           END



			else if (@NEW_ALERT_ID = 'BPMCALLFAL') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @BENEFICIARY =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @CRN =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @AMT =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



                                  SET @FRACID =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@BENEFICIARY))+'^T'+LTRIM(RTRIM(@CRN))+'^T'+LTRIM(RTRIM(@AMT))+'^T'+LTRIM(RTRIM(@FRACID))+'^T';



                           END 



		else if (@NEW_ALERT_ID = 'BPMTLURQST') 



                           BEGIN



                                  SET @TLNUM =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @COMPNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@TLNUM))+'^T'+LTRIM(RTRIM(@COMPNAME))+'^T';



                           END



		else if (@NEW_ALERT_ID = 'BPMTLRQFL') 



                           BEGIN



                                  SET @TLNUM =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@TLNUM))+'^T';


                           END



		else if (@NEW_ALERT_ID = 'BPMTLRQSC') 



                           BEGIN



                                  SET @TLNUM =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@TLNUM))+'^T';



                           END  



		else if (@NEW_ALERT_ID = 'BPM_CIFUPD' OR @NEW_ALERT_ID = 'BPM_SRINVN' OR @NEW_ALERT_ID = 'BPM_SRINVA' OR @NEW_ALERT_ID = 'BPM_SRINVC' OR @NEW_ALERT_ID = 'BPM_SRINVD') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T';



                           END   



		else if (@NEW_ALERT_ID = 'BPM_CIFDOC') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T';



                           END   



		else if (@NEW_ALERT_ID = 'BPM_CIFREJ') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T';



                           END 



		else if (@NEW_ALERT_ID = 'BPM_CNCREJ') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T';



                           END 



	else if (@NEW_ALERT_ID = 'BPM_CNCSUC') 



                           BEGIN



                                  SET @ACCTYPE =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @BRANCHNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								    SET @BRANCHTIME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @CRN =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @AMT =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



	  



                                  SET @MESSAGE = LTRIM(RTRIM(@ACCTYPE))+'^T'+LTRIM(RTRIM(@BRANCHNAME))+'^T'+LTRIM(RTRIM(@BRANCHTIME))+'^T'+LTRIM(RTRIM(@CRN))+'^T'+LTRIM(RTRIM(@AMT))+'^T';



								  



                           END 



	else if (@NEW_ALERT_ID = 'BPM_CNCACT') 



                           BEGIN



                                  SET @FRACID =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



	  



                                  SET @MESSAGE = LTRIM(RTRIM(@FRACID))+'^T';



								  



                           END 	



		else if (@NEW_ALERT_ID = 'BPM_CNCREM') 



                           BEGIN



								  



								  SET @BRANCHNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								    SET @BRANCHTIME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @BRANCHDAY =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @CRN =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @AMT =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



	  



                                  SET @MESSAGE = LTRIM(RTRIM(@BRANCHNAME))+'^T'+LTRIM(RTRIM(@BRANCHTIME))+'^T'+LTRIM(RTRIM(@BRANCHDAY))+'^T'++LTRIM(RTRIM(@CRN))+'^T'+LTRIM(RTRIM(@AMT))+'^T';



								  



                           END 



	else if (@NEW_ALERT_ID = 'BPM_SRPEN' OR @NEW_ALERT_ID = 'BPM_SRDOC' OR @NEW_ALERT_ID = 'BPM_SRFAPR' OR @NEW_ALERT_ID = 'BPM_SRARDC' OR @NEW_ALERT_ID = 'BPM_SRREJ' OR @NEW_ALERT_ID = 'BPM_SRAPRC' OR @NEW_ALERT_ID = 'BPM_SRBDLV') 



                           BEGIN



								  	



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  	



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  								  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@SRNAME))+'^T';



								  



                           END 



	else if (@NEW_ALERT_ID = 'BPM_SRAPR') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRDATE=substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



	  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@SRNAME))+'^T'+LTRIM(RTRIM(@SRDATE))+'^T';



								  



                           END



else if (@NEW_ALERT_ID = 'BPM_SRAPRB' OR @NEW_ALERT_ID = 'BPM_SRBPRC') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @BRANCHNAME=substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



	  



                     SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@SRNAME))+'^T'+LTRIM(RTRIM(@BRANCHNAME))+'^T';



								  



                           END	



    else if(@NEW_ALERT_ID = 'BPM_SRBCLC')	



							BEGIN



								  SET @SRNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @BRANCHNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRDATE =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRBROPENTIME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







								  SET @SRBRCLOSETIME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







								  SET @SRFIRSTDOW =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







								  SET @SRLASTDOW =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  	



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNAME))+'^T'+LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@BRANCHNAME))+'^T'+LTRIM(RTRIM(@SRDATE))+'^T'+LTRIM(RTRIM(@SRBROPENTIME))+'^T'+LTRIM(RTRIM(@SRBRCLOSETIME))+'^T'+LTRIM(RTRIM(@SRFIRSTDOW))


+'^T'+LTRIM(RTRIM(@SRLASTDOW))+'^T';







							END



	else if (@NEW_ALERT_ID = 'BPM_SRBCDL') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRMODE=substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



	  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@SRNAME))+'^T'+LTRIM(RTRIM(@SRMODE))+'^T';



								  



                           END



	else if (@NEW_ALERT_ID = 'BPM_SRBCEX') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRNAME =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRSTATUS=substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



	  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@SRNAME))+'^T'+LTRIM(RTRIM(@SRSTATUS))+'^T';



								  



                           END



	else if (@NEW_ALERT_ID = 'BPM_SRINVS') 



                           BEGIN



                                  SET @SRNUMBER =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @CRN =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @AMT =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



                                  SET @SRTENOR =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



								  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));



								  



								  SET @SRPROCESSFEE =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



								  



                                  SET @MESSAGE = LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@CRN))+'^T'+LTRIM(RTRIM(@AMT))+'^T'+LTRIM(RTRIM(@SRTENOR))+'^T'+LTRIM(RTRIM(@SRPROCESSFEE))+'^T';



                           END	



			else if (@NEW_ALERT_ID = 'BPM_SRINVY') 



                           BEGIN



                                  



                                  SET @SRNUMBER  =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  SET @NEW_OUTPUT_PARAMS=substring(@NEW_OUTPUT_PARAMS, charindex('|',@NEW_OUTPUT_PARAMS)+1, (LEN(@NEW_OUTPUT_PARAMS)-1));







                                  SET @SRDATE =substring(@NEW_OUTPUT_PARAMS, 1, charindex('|',@NEW_OUTPUT_PARAMS)-1);



                                  



                                  SET @MESSAGE         =LTRIM(RTRIM(@SRNUMBER))+'^T'+LTRIM(RTRIM(@SRDATE))+'^T';



                           END						   



                     print(@MESSAGE)



        PRINT 'READY TO INSERT INTO REALTIME_PUBLISH_TABLE';    







IF(@NEW_ALERT_ID = 'BPMSTPRQST' OR @NEW_ALERT_ID = 'BPMNSTPINT' OR @NEW_ALERT_ID = 'BPMFULREDM' OR @NEW_ALERT_ID = 'BPMPARTAPR' OR @NEW_ALERT_ID = 'BPMFULFORT' OR @NEW_ALERT_ID = 'BPMNSTPREJ' OR @NEW_ALERT_ID = 'BPMCARDBLK' OR @NEW_ALERT_ID = 'BPMTATSLAB'


 OR @NEW_ALERT_ID = 'BPMBTRINIT' OR @NEW_ALERT_ID = 'BPMCCCINIT' OR @NEW_ALERT_ID = 'BPMCCCPROC' OR @NEW_ALERT_ID = 'BPMACCTCLO' OR @NEW_ALERT_ID = 'BPMOUTTTIN' OR @NEW_ALERT_ID = 'BPMCALLFAL' OR @NEW_ALERT_ID = 'BPMTLRQFL' OR @NEW_ALERT_ID = 'BPMTLRQSC' 


OR @NEW_ALERT_ID = 'BPMTLURQST' OR @NEW_ALERT_ID = 'BPM_CIFUPD' OR @NEW_ALERT_ID = 'BPM_CIFDOC' OR @NEW_ALERT_ID = 'BPM_CIFREJ' OR @NEW_ALERT_ID = 'BPM_CNCREJ' OR @NEW_ALERT_ID = 'BPM_CNCSUC' OR @NEW_ALERT_ID = 'BPM_CNCACT' OR @NEW_ALERT_ID = 'BPM_CNCREM'


 OR @NEW_ALERT_ID = 'BPM_SRPEN' OR @NEW_ALERT_ID = 'BPM_SRDOC' OR @NEW_ALERT_ID = 'BPM_SRAPR' OR @NEW_ALERT_ID = 'BPM_SRARDC' OR @NEW_ALERT_ID = 'BPM_SRREJ' OR @NEW_ALERT_ID = 'BPM_SRFAPR' OR @NEW_ALERT_ID = 'BPM_SRAPRC' OR @NEW_ALERT_ID = 'BPM_SRAPRB' OR


 @NEW_ALERT_ID = 'BPM_SRBCLC' OR @NEW_ALERT_ID = 'BPM_SRBDLV' OR @NEW_ALERT_ID = 'BPM_SRBPRC' OR @NEW_ALERT_ID = 'BPM_SRBCDL' OR @NEW_ALERT_ID = 'BPM_SRBCEX' OR @NEW_ALERT_ID = 'BPM_SRMSCN' OR @NEW_ALERT_ID = 'BPM_SRMSCP' OR @NEW_ALERT_ID = 'BPM_SRINVN' 


OR @NEW_ALERT_ID = 'BPM_SRINVY' OR @NEW_ALERT_ID = 'BPM_SRINVA' OR @NEW_ALERT_ID = 'BPM_SRINVC' OR @NEW_ALERT_ID = 'BPM_SRINVD' OR @NEW_ALERT_ID = 'BPM_SRINVS' OR @NEW_ALERT_ID = 'BPM_SRLUPT' OR @NEW_ALERT_ID = 'BPMFATAPR' OR @NEW_ALERT_ID = 'BPMFATREJ')




BEGIN



       INSERT INTO REALTIME_PUBLISH_TABLE



                    (



                    DB_TS, BANK_ID, ALERT_ID, CORP_ID, USER_ID, CUST_HOST_ID, CUST_DC_ID, APP_TYPE,



                    UNIQUE_ID, OUTPUT_PARAMS, R_MOD_ID, R_MOD_TIME, R_CRE_ID, R_CRE_TIME



                    )



                  VALUES



                    (



                    1, @NEW_BANK_ID, @NEW_ALERT_ID, @NEW_CIF_ID, @NEW_CIF_ID, 'CRM', 'CRM', '1',



                    @NEW_UNIQUE_ID, @MESSAGE, 'REALTIME', getdate(), 'REALTIME', getdate()



                    );



END



  PRINT( ' Before Setting Data Exist value '  )



                   set @DATA_EXIST = 'Y';



  PRINT( ' Before Fetching Next Set'  )				   



--                     Fetch Next from tmpCur3 into @ASBT_BANK_ID,@ASBT_ALERT_ID,@ASBT_CORP_ID,@ASBT_USER_ID,@ASBT_CUST_HOST_ID,@ASBT_CUST_DC_ID,@ASBT_APP_TYPE,@ASBT_UNIQUE_ID 



        END



--        CLOSE tmpCur3;



--        DEALLOCATE tmpCur3;



    END



-- CPP ALERTS END











       PRINT( ' @DATA_EXIST = ' + @DATA_EXIST )



       IF (@DATA_EXIST = 'Y') 



       BEGIN



              IF(@NEW_ALERT_TYPE = 'B')



              BEGIN



                                         



                     SET @SUB_STATUS = 'X';     --status for Batch alerts will be maintained as X, if subscription check is success.           



              END



              ELSE



              BEGIN 



                     



                     SET @SUB_STATUS = 'P'; --customer subscription check is success, so update the host cust table with status, Processed:                    



              END 



				INSERT INTO RAK_FAS_CUSTOM_PROCESS_TABLE



	          (



	            BANK_ID,



	            ALERT_TYPE,



	            ALERT_ID,



	            CIF_ID,



	            IDENTIFIER1,



	            IDENTIFIER2,



	            UNIQUE_ID,



				STATUS



	          )



	        VALUES



	          (



	            LTRIM(RTRIM(@NEW_BANK_ID)),



	            LTRIM(RTRIM(@NEW_ALERT_TYPE)),



	            LTRIM(RTRIM(@NEW_ALERT_ID)),



	            LTRIM(RTRIM(@NEW_CIF_ID)),



	            LTRIM(RTRIM(@NEW_IDENTIFIER1)),



	            LTRIM(RTRIM(@NEW_IDENTIFIER2)),



	            LTRIM(RTRIM(@NEW_UNIQUE_ID)),



		    LTRIM(RTRIM(@SUB_STATUS))



	          );



       END



ELSE



BEGIN



SET @SUB_STATUS= 'R'; --customer subscription check is not success, so update the host cust table with status, Read: R



 INSERT INTO RAK_FAS_CUSTOM_PROCESS_TABLE



          (



            BANK_ID,



            ALERT_TYPE,



            ALERT_ID,



            CIF_ID,



            IDENTIFIER1,



            IDENTIFIER2,



            UNIQUE_ID,



            STATUS



          )



        VALUES



          (



            LTRIM(RTRIM(@NEW_BANK_ID)),



            LTRIM(RTRIM(@NEW_ALERT_TYPE)),



            LTRIM(RTRIM(@NEW_ALERT_ID)),



            LTRIM(RTRIM(@NEW_CIF_ID)),



            LTRIM(RTRIM(@NEW_IDENTIFIER1)),



            LTRIM(RTRIM(@NEW_IDENTIFIER2)),



            LTRIM(RTRIM(@NEW_UNIQUE_ID)),



            LTRIM(RTRIM(@SUB_STATUS))



          );



       



    print('NONFIN_CUST GEN END');



END







END

