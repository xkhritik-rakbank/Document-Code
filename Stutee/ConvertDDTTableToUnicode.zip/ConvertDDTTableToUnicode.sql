/******************************************************************************************************
			NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group			: Eworkstyle
Product / Project	: Java Transaction Server	
Module			: Backend
File Name		: ConvertDDTTableToUnicode.sql
Author			: Shikhar Prawesh
Date written		: 08/03/2008
Description		: Converts DDT table to Unicode
---------------------------------------------------------------------------
		CHANGE HISTORY
---------------------------------------------------------------------------
 Date		Change By		Change Description (Bug No. If Any)

----------------------------------------------------------------------------
 Function Name 	: ConvertDDTTableToUnicode.sql
 Date written	: 08/03/2008
 Author		: Shikhar Prawesh
 Input parameter	:
	Table Name			Name of DDT Table.
	ConstraintStr			Constraint string
	TabColumnScript			Column list
	InsColumnScript			Insert List
	SelColumnScript 		Select List
	Status				Status
 Output parameter	:
 Return value(Result set) :Return Status
*******************************************************************************************************/
--DROP PROCEDURE ConvertDDTTableToUnicode
--GO
CREATE PROCEDURE ConvertDDTTableToUnicode(
	@TableName		varchar(128),
	@ConstraintStr		varchar(8000),
	@TabColumnScript	varchar(8000),
	@InsColumnScript	varchar(8000),
	@SelColumnScript	varchar(8000),
	@DDTStepNo		int,
	@Status			INT OUT
)
AS
	
	SET NOCOUNT ON
	SELECT	@Status = -1

	SELECT	@TableName		= LTRIM(RTRIM(@TableName))
	SELECT	@ConstraintStr		= LTRIM(RTRIM(@ConstraintStr))
	SELECT	@TabColumnScript	= LTRIM(RTRIM(@TabColumnScript))
	SELECT	@InsColumnScript	= LTRIM(RTRIM(@InsColumnScript))
	SELECT	@SelColumnScript	= LTRIM(RTRIM(@SelColumnScript))

	DECLARE	@NewTableName		varchar(128)
	DECLARE	@FKConstraintTable	varchar(128)
	DECLARE @QueryStr		varchar(8000)
	DECLARE @FK_NAME 		varchar(255)
	DECLARE @FK_TableName 		varchar(255)
	DECLARE @FK_Column_Name		varchar(255)
	DECLARE @PrimaryKeyTemp		varchar(128)
	DECLARE @UniqueKeyTemp		varchar(128)
	DECLARE	@PKUQTableName		nvarchar(128)
	DECLARE	@LastIndexTableName	varchar(128)

	DECLARE @LastObjectIndex 	int
	DECLARE @StartObjectIndex	int
	DECLARE	@BatchCount		int
	DECLARE @EndObjectIndex		int
	DECLARE @NumRowFetched		int
	DECLARE	@MaxObjectIndex		int
	DECLARE	@MaxNewObjectIndex	int
	DECLARE @UniCodeCursorQuery	NVARCHAR(4000)
	DECLARE @ParamDef		NVARCHAR(500)

	DECLARE	@Position		int
	DECLARE	@ConstraintName		varchar(50)
	DECLARE	@ConstraintNameTemp	varchar(50)
	DECLARE @LoopCount		int
	DECLARE @ObjectType		char(1)
	DECLARE	@index_name		varchar(256)
	DECLARE	@indkey			varchar(2126)
	DECLARE	@str			varchar(2126)


	SELECT 	@BatchCount = 100000

	SELECT	@NewTableName		= @TableName + '_NewTab'
	SELECT	@FKConstraintTable	= @TableName + 'Constraint'
	SELECT	@LastIndexTableName	= 'LAST' + @TableName + 'INDEX' + 'TABLE'

	IF NOT EXISTS(
		SELECT 1 FROM INFORMATION_SCHEMA.TABLES
		WHERE TABLE_NAME = @NewTableName
	)
	BEGIN
		BEGIN TRANSACTION TranUniUp

		IF @ConstraintStr IS NOT NULL
		BEGIN
			SELECT	@Position = CHARINDEX(',', @ConstraintStr)
			WHILE	@Position > 1
			BEGIN
				SELECT	@ConstraintName = SUBSTRING(@ConstraintStr, 1, @Position - 1)
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					ROLLBACK TRANSACTION TranUniUp
					RETURN
				END

				SELECT	@ConstraintStr = SUBSTRING(@ConstraintStr, @Position + 1, 8000)
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					ROLLBACK TRANSACTION TranUniUp
					RETURN
				END

				SELECT	@ConstraintNameTemp = @ConstraintName + '_OLD'
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					ROLLBACK TRANSACTION TranUniUp
					RETURN
				END

				EXEC sp_rename @ConstraintName, @ConstraintNameTemp
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					ROLLBACK TRANSACTION TranUniUp
					RETURN
				END
				SELECT	@Position = CHARINDEX(',', @ConstraintStr)
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					ROLLBACK TRANSACTION TranUniUp
					RETURN
				END
			END
		END		

		SELECT @QueryStr = 'CREATE TABLE  ' + @LastIndexTableName + ' (FoldDocFlag char(1), LastFetchedIndex int)'
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		EXECUTE (@QueryStr)
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		
		SELECT @QueryStr = ' CREATE TABLE ' + @NewTableName + ' ( ' + @TabColumnScript + ' ) '
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		EXECUTE (@QueryStr)
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END

		--Added by mili for creating indexex
		
		CREATE TABLE #indfol(index_name varchar(256), indexdesc varchar(256), indkey varchar(2126))
		INSERT INTO #indfol exec sp_helpindex @TableName
		INSERT INTO DDTIndexList SELECT @TableName, index_name, indexdesc,  indkey
		FROM #indfol
		WHERE CHARINDEX('UNIQUE', indexdesc) = 0

		DECLARE cur1 CURSOR
		FOR
			SELECT  IndexName,Indkey 
			FROM DDTIndexList
			WHERE TabName=@TableName
		OPEN cur1

		FETCH NEXT FROM cur1 INTO @index_name,@indkey
		WHILE @@Fetch_Status = 0
		BEGIN
			SELECT @str='CREATE NONCLUSTERED INDEX'+ ' '+ @index_name + ' '+'ON'+' '+ @NewTableName + '(' + @indkey + ')'
			EXECUTE (@str)
		        FETCH NEXT FROM cur1 INTO @index_name,@indkey
		END
 
		CLOSE cur1
		DEALLOCATE cur1

		DROP TABLE #indfol
		
		COMMIT TRANSACTION TranUniUp
	END


	IF EXISTS(
		SELECT 1 FROM INFORMATION_SCHEMA.TABLES
		WHERE TABLE_NAME = @NewTableName
	)
	BEGIN
		SELECT @LoopCount = 1
		WHILE @LoopCount < 3
		BEGIN
			IF  @LoopCount	= 1
				SELECT @ObjectType = 'D'
			ELSE IF  @LoopCount = 2
				SELECT @ObjectType = 'F'

			SELECT 	@UniCodeCursorQuery = N'SELECT	TOP 1 @MaxObjectIndex = ' + 'FoldDocIndex' +  ' FROM ' + @TableName + ' WITH (NOLOCK) WHERE FoldDocFlag = ''' +  @ObjectType + ''' ORDER BY ' + 'FoldDocIndex' + ' DESC '
			SELECT @Status = @@ERROR
			IF @Status <> 0
			BEGIN
				RETURN
			END

			SELECT @ParamDef = N'@MaxObjectIndex ' + 'int' + N' OUTPUT'
			EXEC SP_EXECUTESQL @UniCodeCursorQuery, @ParamDef, @MaxObjectIndex OUTPUT
			SELECT @Status = @@ERROR
			IF @Status <> 0
			BEGIN
				RETURN
			END
			SELECT @MaxObjectIndex = ISNULL(@MaxObjectIndex, 0)

			SELECT 	@UniCodeCursorQuery = N'SELECT TOP 1 @MaxNewObjectIndex = ' + 'FoldDocIndex' + ' FROM ' + @NewTableName + ' WITH (NOLOCK) WHERE FoldDocFlag = ''' +  @ObjectType + ''' ORDER BY ' + 'FoldDocIndex' + ' DESC'
			SELECT @ParamDef = N'@MaxNewObjectIndex ' + 'int' + N' OUTPUT'
			EXEC SP_EXECUTESQL @UniCodeCursorQuery, @ParamDef, @MaxNewObjectIndex OUTPUT		
			SELECT @Status = @@ERROR
			IF @Status <> 0
			BEGIN
				RETURN
			END
			SELECT @MaxNewObjectIndex = ISNULL(@MaxNewObjectIndex, 0)

			SELECT @QueryStr = ' INSERT INTO ' + @LastIndexTableName + ' VALUES (''' + @ObjectType + ''', ' + CONVERT(varchar(8000), @MaxNewObjectIndex) + ' ) '
			SELECT @Status = @@ERROR
			IF @Status <> 0
			BEGIN
				ROLLBACK TRANSACTION TranUniUp
				RETURN
			END
			EXECUTE (@QueryStr)
			SELECT @Status = @@ERROR
			IF @Status <> 0
			BEGIN
				ROLLBACK TRANSACTION TranUniUp
				RETURN
			END

			--UPDATE PDBUpdateStatus SET Status = 'Starting Inserting for FoldDocFlag = ''' + @ObjectType + ''' from ' + 'FoldDocIndex' + ' after ' + CONVERT(varchar(10), (@MaxNewObjectIndex)) + ' : Maximum ' + 'FoldDocIndex' + ' To Insert ' + CONVERT(varchar(10), (@MaxObjectIndex)) , EndDate = GETDATE() WHERE StepNumber = @DDTStepNo
			IF @MaxNewObjectIndex < @MaxObjectIndex
			BEGIN
				SELECT 	@NumRowFetched	= 1 
	
				SELECT 	@UniCodeCursorQuery = N'SELECT @LastObjectIndex = LastFetchedIndex FROM ' + @LastIndexTableName
				SELECT @ParamDef = N'@LastObjectIndex ' + 'int' + N' OUTPUT'
				EXEC SP_EXECUTESQL @UniCodeCursorQuery, @ParamDef, @LastObjectIndex OUTPUT		
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					RETURN
				END
				SELECT  @StartObjectIndex = @LastObjectIndex + 1
	
				WHILE 	(@NumRowFetched > 0 OR  @EndObjectIndex < @MaxObjectIndex )
				BEGIN
					SELECT @EndObjectIndex = @StartObjectIndex + @BatchCount - 1
				
					SELECT @UniCodeCursorQuery = N''
					SELECT @UniCodeCursorQuery = RTRIM(@UniCodeCursorQuery) + 
						N' INSERT INTO ' + @NewTableName + ' ( ' + @InsColumnScript + ' ) ' + 
						N' SELECT ' + @SelColumnScript + ' ' +
						N' FROM ' + @TableName + ' WITH (NOLOCK) ' + 
						N' WHERE ' + 'FoldDocIndex' + ' BETWEEN @StartObjectIndex AND @EndObjectIndex ' +
						N' AND FoldDocFlag = ''' + @ObjectType + N'''' +
						N' ORDER BY ' + 'FoldDocIndex' + ' ' +
						N' SELECT @Status = @@ERROR ,' +
						N' @NumRowFetched = @@ROWCOUNT '
					
					SELECT @Status = @@ERROR
					IF @Status <> 0
					BEGIN
						RETURN
					END

					BEGIN TRANSACTION TranUniUp
					SELECT @Status = -50000
					SELECT @ParamDef = N'@StartObjectIndex ' + N'int' + ' , @EndObjectIndex  ' + N'int' + ' , @Status INT OUTPUT, @NumRowFetched INT OUTPUT'
					EXEC SP_EXECUTESQL @UniCodeCursorQuery, @ParamDef, @StartObjectIndex, @EndObjectIndex, @Status OUTPUT, @NumRowFetched OUTPUT
					--SELECT @Status = @@ERROR
					SELECT @Status = ISNULL(@Status,-50000)
					IF @Status <> 0
					BEGIN
						ROLLBACK TRANSACTION TranUniUp
						RETURN
					END
				
					SELECT 	@UniCodeCursorQuery = 
						N'UPDATE ' + @LastIndexTableName + ' SET ' + 'LastFetchedIndex' + ' =  @EndObjectIndex '
					SELECT @ParamDef = N'@EndObjectIndex ' + N'int'
					EXEC SP_EXECUTESQL @UniCodeCursorQuery, @ParamDef, @EndObjectIndex
					SELECT @Status = @@ERROR
					IF @Status <> 0
					BEGIN
						ROLLBACK TRANSACTION TranUniUp
						RETURN
					END

					--UPDATE PDBUpdateStatus SET Status = 'Inserted  for FoldDocFlag = ''' + @ObjectType + ''' FoldDocIndex' + ' upto ' + CONVERT(varchar(10), (@EndObjectIndex)) + ' : Maximum ' + 'FoldDocIndex' + ' To Insert ' + CONVERT(varchar(10), (@MaxObjectIndex)) , EndDate = GETDATE() WHERE StepNumber = @DDTStepNo
					SELECT @Status = @@ERROR
					IF @Status <> 0
					BEGIN
						ROLLBACK TRANSACTION TranUniUp
						RETURN
					END
					COMMIT TRANSACTION TranUniUp
					SELECT @StartObjectIndex = @EndObjectIndex + 1
				END
			END
			SELECT @LoopCount = @LoopCount + 1
		END
	END

	BEGIN TRANSACTION TranUniUp
	SELECT @QueryStr = ' DROP TABLE ' + @TableName
	SELECT @Status = @@ERROR
	IF @Status <> 0
	BEGIN
		ROLLBACK TRANSACTION TranUniUp
		RETURN
	END
	EXECUTE (@QueryStr)
	SELECT @Status = @@ERROR
	IF @Status <> 0
	BEGIN
		ROLLBACK TRANSACTION TranUniUp
		RETURN
	END

	EXEC sp_rename @NewTableName, @TableName
	SELECT @Status = @@ERROR
	IF @Status <> 0
	BEGIN
		ROLLBACK TRANSACTION TranUniUp
		RETURN
	END

	SELECT @QueryStr = ' DROP TABLE ' + @LastIndexTableName
	SELECT @Status = @@ERROR
	IF @Status <> 0
	BEGIN
		ROLLBACK TRANSACTION TranUniUp
		RETURN
	END

	EXECUTE (@QueryStr)
	SELECT @Status = @@ERROR
	IF @Status <> 0
	BEGIN
		ROLLBACK TRANSACTION TranUniUp
		RETURN
	END

	

	SELECT @Status = 0

	COMMIT TRANSACTION TranUniUp
