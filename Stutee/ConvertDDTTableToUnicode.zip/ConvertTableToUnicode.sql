/******************************************************************************************************
			NEWGEN SOFTWARE TECHNOLOGIES LIMITED
Group			: Eworkstyle
Product / Project	: Java Transaction Server	
Module			: Backend
File Name		: ConvertTableToUnicode.sql
Author			: Shikhar Prawesh
Date written		: 08/03/2008
Description		: Converts DDT table to Unicode
---------------------------------------------------------------------------
		CHANGE HISTORY
---------------------------------------------------------------------------
 Date		Change By		Change Description (Bug No. If Any)
 27/11/2008	Pranay Tiwari		Changes in datatypes of variables to support larger userindex(Mantis ID : 10267)
----------------------------------------------------------------------------
 Function Name 	: ConvertTableToUnicode.sql
 Date written	: 08/03/2008
 Author		: Shikhar Prawesh
 Input parameter	:
	TableName		Name of Table.	
	ColumnName		Name of column
	DataType		Column data type
	PrimaryKey		Primary key if any
	UniqueKey		Unique key if any
	KeyColumnName		Key column Name
	KeyColumnType		Key column type
	TabColumnScript		Column Names List
	InsColumnScript		Insert List
	SelColumnScript		Select List
	IdentityFlag		Flag
	StepNo			Step Number
	Status			Result status
 Output parameter	:
 Return value(Result set) :Return Status

*******************************************************************************************************/
/*	sp_help PDBUserAddressList
	sp_help PDBUserAddressList_NewTab
	sp_help LASTPDBUserAddressListINDEXTABLE
	SELECT * FROM LASTPDBUserAddressListINDEXTABLE

DECLARE	@TableName		varchar(128)
DECLARE @ColumnName		nvarchar(128)
DECLARE @DataType		nvarchar(128)
DECLARE @PrimaryKey		varchar(128)
DECLARE @UniqueKey		varchar(128)
DECLARE @KeyColumnName		varchar(128)
DECLARE @KeyColumnType		varchar(128)
DECLARE @TabColumnScript	varchar(8000)
DECLARE @InsColumnScript	varchar(8000)
DECLARE @SelColumnScript	varchar(8000)
DECLARE @IdentityFlag		char(1)

SELECT	@TableName		= 'PDBUserAddressList'
SELECT	@ColumnName		= 'ListName'
SELECT	@DataType		= 'NVARCHAR'
SELECT	@PrimaryKey		= 'pk_AddressIndex'
SELECT	@UniqueKey		= 'UK_List'
SELECT	@KeyColumnName		= 'ListIndex'
SELECT	@KeyColumnType		= 'int'
SELECT	@TabColumnScript	= '
	ListIndex	int IDENTITY(1,1) Constraint pk_AddressIndex PRIMARY KEY,
	ListName	nvarchar(255),
	Owner		int,
        CONSTRAINT UK_List UNIQUE (ListName, Owner)
'
	
SELECT	@InsColumnScript	= 'ListIndex, ListName, Owner'
SELECT	@SelColumnScript	= 'ListIndex, RTRIM(ListName) ListName, Owner'
SELECT	@IdentityFlag		= 'Y'

EXEC ConvertTableToUnicode
	@TableName,
	@ColumnName,
	@DataType,
	@PrimaryKey,
	@UniqueKey,
	@KeyColumnName,
	@KeyColumnType,
	@TabColumnScript,
	@InsColumnScript,
	@SelColumnScript,
	@IdentityFlag

*/
--DROP PROCEDURE ConvertTableToUnicode
--GO
CREATE PROCEDURE ConvertTableToUnicode(
	@TableName		varchar(128),
	@ColumnName		nvarchar(128),
	@DataType		nvarchar(128),
	@PrimaryKey		varchar(128) = NULL,
	@UniqueKey		varchar(128) = NULL,
	@KeyColumnName		varchar(128),
	@KeyColumnType		varchar(128),
	@TabColumnScript	varchar(8000),
	@InsColumnScript	varchar(8000),
	@SelColumnScript	varchar(8000) ,
	@IdentityFlag		char(1) = NULL,
	@StepNo			int,
	@Status			INT OUT
)
AS
	SET NOCOUNT ON
	SELECT	@Status = -1

/*
SELECT	@TableName		= 'PDBUserAddressList'
SELECT	@ColumnName		= 'ListName'
SELECT	@DataType		= 'NVARCHAR'
SELECT	@PrimaryKey		= 'pk_AddressIndex'
SELECT	@UniqueKey		= 'UK_List'
SELECT	@KeyColumnName		= 'ListIndex'
SELECT	@KeyColumnType		= 'int'
SELECT	@TabColumnScript	= '
	ListIndex	int IDENTITY(1,1) Constraint pk_AddressIndex PRIMARY KEY,
	ListName	nvarchar(255),
	Owner		int,
        CONSTRAINT UK_List UNIQUE (ListName, Owner)
'
	
SELECT	@InsColumnScript	= 'ListIndex, ListName, Owner'
SELECT	@SelColumnScript	= 'ListIndex, RTRIM(ListName) ListName, Owner'
SELECT	@IdentityFlag		= 'Y'
*/

SELECT	@TableName		= LTRIM(RTRIM(@TableName))
SELECT	@ColumnName		= LTRIM(RTRIM(@ColumnName))
SELECT	@DataType		= LTRIM(RTRIM(@DataType))
SELECT	@PrimaryKey		= LTRIM(RTRIM(@PrimaryKey))
SELECT	@UniqueKey		= LTRIM(RTRIM(@UniqueKey))
SELECT	@KeyColumnName		= LTRIM(RTRIM(@KeyColumnName))
SELECT	@KeyColumnType		= LTRIM(RTRIM(@KeyColumnType))
SELECT	@TabColumnScript	= LTRIM(RTRIM(@TabColumnScript))
SELECT	@InsColumnScript	= LTRIM(RTRIM(@InsColumnScript))
SELECT	@SelColumnScript	= LTRIM(RTRIM(@SelColumnScript))

SELECT	@IdentityFlag		= ISNULL(@IdentityFlag, 'N')

DECLARE	@NewTableName		varchar(128)
DECLARE	@FKConstraintTable	varchar(128)
DECLARE @QueryStr		varchar(8000)
DECLARE @FK_NAME 		varchar(255)
DECLARE @FK_TableName 		varchar(255)
DECLARE @FK_Column_Name		varchar(255)
DECLARE @PrimaryKeyTemp		varchar(128)
DECLARE @UniqueKeyTemp		varchar(128)
DECLARE	@PKUQTableName		nvarchar(128)
DECLARE	@LastIndexTableName	varchar(128)

DECLARE @LastObjectIndex 	int
DECLARE @StartObjectIndex	int
DECLARE	@BatchCount		int
DECLARE @EndObjectIndex		int
DECLARE @NumRowFetched		int
DECLARE	@MaxObjectIndex		int
DECLARE	@MaxNewObjectIndex	int
DECLARE @UniCodeCursorQuery	NVARCHAR(4000)
DECLARE @ParamDef		NVARCHAR(500)

DECLARE @CK_NAME 		varchar(255)
DECLARE @CK_TableName 		varchar(255)
DECLARE @CK_Column_Name		varchar(255)
DECLARE @DF_NAME 		varchar(255)
DECLARE @DF_TableName 		varchar(255)
DECLARE @DF_Column_Name		varchar(255)

If @KeyColumnType = 'int'
	SELECT 	@BatchCount = 100000
Else
	SELECT 	@BatchCount = 10000	
SELECT	@NewTableName		= @TableName + '_NewTab'
SELECT	@FKConstraintTable	= @TableName + 'Constraint'
SELECT	@LastIndexTableName	= 'LAST' + @TableName + 'INDEX' + 'TABLE'

IF NOT EXISTS(
	SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
	WHERE 	TABLE_NAME	= @TableName
	AND COLUMN_NAME		= @ColumnName
	AND DATA_TYPE		= @DataType
)
BEGIN
	IF NOT EXISTS(
		SELECT 1 FROM INFORMATION_SCHEMA.TABLES
		WHERE TABLE_NAME = @NewTableName
	)
	BEGIN
		BEGIN TRANSACTION TranUniUp
		SELECT @QueryStr = ' DECLARE ConstCur CURSOR FOR  SELECT OBJECT_NAME(constid) FK_Name, OBJECT_NAME(fkeyid) FK_TableName, column_name FK_Column_Name from sysreferences a, INFORMATION_SCHEMA.Constraint_Column_Usage b where rkeyid = OBJECT_ID(''' + @TableName + ''') and OBJECT_NAME(constid) = constraint_Name'
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		EXECUTE (@QueryStr)
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END

		OPEN ConstCur
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		FETCH NEXT FROM ConstCur INTO @FK_NAME, @FK_TableName, @FK_Column_Name
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @QueryStr = ' ALTER TABLE ' + @FK_TableName + ' DROP CONSTRAINT ' + @FK_NAME
			EXECUTE (@QueryStr)
			SELECT @Status = @@ERROR
			IF @Status <> 0
			BEGIN
				ROLLBACK TRANSACTION TranUniUp
				RETURN
			END
			FETCH NEXT FROM ConstCur INTO @FK_NAME, @FK_TableName, @FK_Column_Name
		END
		CLOSE ConstCur
		DEALLOCATE ConstCur
		SELECT @QueryStr = ' DECLARE ConstCur1 CURSOR FOR SELECT name , table_name , column_name  FROM sys.check_constraints a, INFORMATION_SCHEMA.Constraint_Column_Usage b WHERE 
		table_name = ''' + @TableName + ''' AND name = constraint_Name'
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		EXECUTE (@QueryStr)
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END

		OPEN ConstCur1
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		FETCH NEXT FROM ConstCur1 INTO @CK_NAME, @CK_TableName, @CK_Column_Name
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @QueryStr = ' ALTER TABLE ' + @CK_TableName + ' DROP CONSTRAINT ' + @CK_NAME
			EXECUTE (@QueryStr)
			SELECT @Status = @@ERROR
			IF @Status <> 0
			BEGIN
				ROLLBACK TRANSACTION TranUniUp
				RETURN
			END
			FETCH NEXT FROM ConstCur1 INTO @CK_NAME, @CK_TableName, @CK_Column_Name
		END
		CLOSE ConstCur1
		DEALLOCATE ConstCur1
		
		SELECT @QueryStr = ' DECLARE ConstCur2 CURSOR FOR SELECT default_constraints.name, tables.name , all_columns.name FROM 
					sys.all_columns INNER JOIN sys.tables ON all_columns.object_id = tables.object_id INNER JOIN sys.schemas
					ON tables.schema_id = schemas.schema_id INNER JOIN sys.default_constraints ON all_columns.default_object_id = default_constraints.object_id WHERE tables.name = ''' + @TableName + '''';
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		EXECUTE (@QueryStr)
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END

		OPEN ConstCur2
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		FETCH NEXT FROM ConstCur2 INTO @DF_NAME, @DF_TableName, @DF_Column_Name
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @QueryStr = ' ALTER TABLE ' + @DF_TableName + ' DROP CONSTRAINT ' + @DF_NAME
			EXECUTE (@QueryStr)
			SELECT @Status = @@ERROR
			IF @Status <> 0
			BEGIN
				ROLLBACK TRANSACTION TranUniUp
				RETURN
			END
			FETCH NEXT FROM ConstCur2 INTO @DF_NAME, @DF_TableName, @DF_Column_Name
		END
		CLOSE ConstCur2
		DEALLOCATE ConstCur2

		IF @PrimaryKey IS NOT NULL
		BEGIN
			SELECT @PrimaryKey = LTRIM(RTRIM(@PrimaryKey))
			SELECT @PrimaryKeyTemp = @PrimaryKey + '_OLD'

			IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE WHERE CONSTRAINT_NAME = @PrimaryKey)
			BEGIN
				IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE WHERE CONSTRAINT_NAME = @PrimaryKeyTemp)
				BEGIN
					SELECT	@PKUQTableName = TABLE_NAME FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE WHERE CONSTRAINT_NAME = @PrimaryKeyTemp
					SELECT 	@QueryStr = ' ALTER TABLE ' + @PKUQTableName + ' DROP CONSTRAINT ' + @PrimaryKeyTemp
					EXECUTE (@QueryStr)
					SELECT @Status = @@ERROR
					IF @Status <> 0
					BEGIN
						ROLLBACK TRANSACTION TranUniUp
						RETURN
					END
				END
				EXEC sp_rename @PrimaryKey, @PrimaryKeyTemp
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					ROLLBACK TRANSACTION TranUniUp
					RETURN
				END
			END
		END		

		IF @UniqueKey IS NOT NULL
		BEGIN
			SELECT @UniqueKey = LTRIM(RTRIM(@UniqueKey))
			SELECT @UniqueKeyTemp = @UniqueKey + '_OLD'

			IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE WHERE CONSTRAINT_NAME = @UniqueKey)
			BEGIN
				IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE WHERE CONSTRAINT_NAME = @UniqueKeyTemp)
				BEGIN
					SELECT	@PKUQTableName = TABLE_NAME FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE WHERE CONSTRAINT_NAME = @UniqueKeyTemp
					SELECT 	@QueryStr = ' ALTER TABLE ' + @PKUQTableName + ' DROP CONSTRAINT ' + @UniqueKeyTemp
					EXECUTE (@QueryStr)
					SELECT @Status = @@ERROR
					IF @Status <> 0
					BEGIN
						ROLLBACK TRANSACTION TranUniUp
						RETURN
					END
				END
				EXEC sp_rename @UniqueKey, @UniqueKeyTemp
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					ROLLBACK TRANSACTION TranUniUp
					RETURN
				END
			END
		END
		SELECT @QueryStr = 'CREATE TABLE  ' + @LastIndexTableName + ' ( LastFetchedIndex ' + @KeyColumnType + ' ) '
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		EXECUTE (@QueryStr)
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		
		SELECT @QueryStr = ' INSERT INTO ' + @LastIndexTableName + ' VALUES (-1) '
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		EXECUTE (@QueryStr)
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END

		SELECT @QueryStr = ' CREATE TABLE ' + @NewTableName + ' ( ' + @TabColumnScript + ' ) '
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END
		EXECUTE (@QueryStr)
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			ROLLBACK TRANSACTION TranUniUp
			RETURN
		END

		COMMIT TRANSACTION TranUniUp
	END
END
IF NOT EXISTS(
	SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
	WHERE 	TABLE_NAME	= @TableName
	AND COLUMN_NAME		= @ColumnName
	AND DATA_TYPE		= @DataType
)
BEGIN
	IF EXISTS(
		SELECT 1 FROM INFORMATION_SCHEMA.TABLES
		WHERE TABLE_NAME = @NewTableName
	)
	BEGIN
		SELECT 	@UniCodeCursorQuery = N'SELECT	TOP 1 @MaxObjectIndex = ' + @KeyColumnName +  ' FROM ' + @TableName + ' WITH (NOLOCK) ORDER BY ' + @KeyColumnName + ' DESC '
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			RETURN
		END

		SELECT @ParamDef = N'@MaxObjectIndex ' + @KeyColumnType + N' OUTPUT'
		EXEC SP_EXECUTESQL @UniCodeCursorQuery, @ParamDef, @MaxObjectIndex OUTPUT
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			RETURN
		END
		SELECT @MaxObjectIndex = ISNULL(@MaxObjectIndex, 0)

		SELECT 	@UniCodeCursorQuery = N'SELECT TOP 1 @MaxNewObjectIndex = ' + @KeyColumnName + ' FROM ' + @NewTableName + ' WITH (NOLOCK) ORDER BY ' + @KeyColumnName + ' DESC'
		SELECT @ParamDef = N'@MaxNewObjectIndex ' + @KeyColumnType + N' OUTPUT'
		EXEC SP_EXECUTESQL @UniCodeCursorQuery, @ParamDef, @MaxNewObjectIndex OUTPUT		
		SELECT @Status = @@ERROR
		IF @Status <> 0
		BEGIN
			RETURN
		END
		SELECT @MaxNewObjectIndex = ISNULL(@MaxNewObjectIndex, 0)

		UPDATE PDBUpdateStatus SET Status = 'Starting Inserting from ' + @KeyColumnName + ' after ' + CONVERT(varchar(10), (@MaxNewObjectIndex)) + ' : Maximum ' + @KeyColumnName + ' To Insert ' + CONVERT(varchar(10), (@MaxObjectIndex)) , EndDate = GETDATE() WHERE StepNumber = @StepNo
		
		IF @MaxNewObjectIndex < @MaxObjectIndex
		BEGIN
			SELECT 	@NumRowFetched	= 1 
	
			SELECT 	@UniCodeCursorQuery = N'SELECT @LastObjectIndex = LastFetchedIndex FROM ' + @LastIndexTableName
			SELECT @ParamDef = N'@LastObjectIndex ' + @KeyColumnType + N' OUTPUT'
			EXEC SP_EXECUTESQL @UniCodeCursorQuery, @ParamDef, @LastObjectIndex OUTPUT		
			SELECT @Status = @@ERROR
			IF @Status <> 0
			BEGIN
				RETURN
			END
			SELECT  @StartObjectIndex = @LastObjectIndex + 1
	
			WHILE 	(@NumRowFetched > 0 OR  @EndObjectIndex < @MaxObjectIndex )
			BEGIN
				SELECT @EndObjectIndex = @StartObjectIndex + @BatchCount - 1
				
				SELECT @UniCodeCursorQuery = N''
				IF @IdentityFlag = 'Y'
				BEGIN
					SELECT @UniCodeCursorQuery = RTRIM(@UniCodeCursorQuery) + 
						N' SET IDENTITY_INSERT ' + @NewTableName + ' ON '
					SELECT @Status = @@ERROR
					IF @Status <> 0
					BEGIN
						RETURN
					END
				END
				SELECT @UniCodeCursorQuery = RTRIM(@UniCodeCursorQuery) + 
					N' INSERT INTO ' + @NewTableName + ' ( ' + @InsColumnScript + ' ) ' + 
					N' SELECT ' + @SelColumnScript + ' ' +
					N' FROM ' + @TableName + ' WITH (NOLOCK) ' + 
					N' WHERE ' + @KeyColumnName + ' BETWEEN @StartObjectIndex AND @EndObjectIndex ' +
					N' ORDER BY ' + @KeyColumnName + ' ' +
					N' SELECT @Status = @@ERROR ,' +
					N' @NumRowFetched = @@ROWCOUNT '
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					RETURN
				END
				IF @IdentityFlag = 'Y'
				BEGIN
					SELECT @UniCodeCursorQuery = RTRIM(@UniCodeCursorQuery) + 
						N' SET IDENTITY_INSERT ' + @NewTableName + ' OFF '
					SELECT @Status = @@ERROR
					IF @Status <> 0
					BEGIN
						RETURN
					END
				END

				BEGIN TRANSACTION TranUniUp
				SELECT @Status = -50000
				SELECT @ParamDef = N'@StartObjectIndex ' + @KeyColumnType + ' , @EndObjectIndex  ' + @KeyColumnType + ' , @Status INT OUTPUT, @NumRowFetched INT OUTPUT'
				EXEC SP_EXECUTESQL @UniCodeCursorQuery, @ParamDef, @StartObjectIndex, @EndObjectIndex, @Status OUTPUT, @NumRowFetched OUTPUT
--				SELECT @Status = @@ERROR
				SELECT @Status = ISNULL(@Status,-50000)
				IF @Status <> 0
				BEGIN
					ROLLBACK TRANSACTION TranUniUp
					RETURN
				END
				
				SELECT 	@UniCodeCursorQuery = 
					N'UPDATE ' + @LastIndexTableName + ' SET ' + 'LastFetchedIndex' + ' =  @EndObjectIndex '
				SELECT @ParamDef = N'@EndObjectIndex ' + @KeyColumnType
				EXEC SP_EXECUTESQL @UniCodeCursorQuery, @ParamDef, @EndObjectIndex
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					ROLLBACK TRANSACTION TranUniUp
					RETURN
				END

				UPDATE PDBUpdateStatus SET Status = 'Inserted ' + @KeyColumnName + ' upto ' + CONVERT(varchar(10), (@EndObjectIndex)) + ' : Maximum ' + @KeyColumnName + ' To Insert ' + CONVERT(varchar(10), (@MaxObjectIndex)) , EndDate = GETDATE() WHERE StepNumber = @StepNo
				SELECT @Status = @@ERROR
				IF @Status <> 0
				BEGIN
					ROLLBACK TRANSACTION TranUniUp
					RETURN
				END

				COMMIT TRANSACTION TranUniUp
				SELECT @StartObjectIndex = @EndObjectIndex + 1
			END
		END
	END
END

IF NOT EXISTS(
	SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
	WHERE 	TABLE_NAME	= @TableName
	AND COLUMN_NAME		= @ColumnName
	AND DATA_TYPE		= @DataType
)
BEGIN
	BEGIN TRANSACTION TranUniUp

	SELECT @QueryStr = ' DROP TABLE ' + @TableName
	SELECT @Status = @@ERROR
	IF @Status <> 0
	BEGIN
		ROLLBACK TRANSACTION TranUniUp
		RETURN
	END

	EXECUTE (@QueryStr)
	SELECT @Status = @@ERROR
	IF @Status <> 0
	BEGIN
		ROLLBACK TRANSACTION TranUniUp
		RETURN
	END

	EXEC sp_rename @NewTableName, @TableName
	SELECT @Status = @@ERROR
	IF @Status <> 0
	BEGIN
		ROLLBACK TRANSACTION TranUniUp
		RETURN
	END

	SELECT @QueryStr = ' DROP TABLE ' + @LastIndexTableName
	SELECT @Status = @@ERROR
	IF @Status <> 0
	BEGIN
		ROLLBACK TRANSACTION TranUniUp
		RETURN
	END

	EXECUTE (@QueryStr)
	SELECT @Status = @@ERROR
	IF @Status <> 0
	BEGIN
		ROLLBACK TRANSACTION TranUniUp
		RETURN
	END
	SELECT @Status = 0
	COMMIT TRANSACTION TranUniUp
END

