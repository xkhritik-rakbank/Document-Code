/*__________________________________________________________________________________;
	NEWGEN SOFTWARE TECHNOLOGIES LIMITED;
	Group                       : Genesis;
	Product / Project           : IBPS;
	Module                      : IBPS Server;
	File Name                   : SetAndMigrateMetaData.sql (MSSQL)
	Author                      : Kahkeshan
	Date written (DD/MM/YYYY)   : 21 MAY 2014
	Description                 : Stored Procedure to set values to start MetaDataMigration Execution
	____________________________________________________________________________________;
	CHANGE HISTORY;
	____________________________________________________________________________________;
	Date        Change By        Change Description (Bug No. (IF Any))
	____________________________________________________________________________________*/	

If Exists (Select * FROM SysObjects  WITH (NOLOCK)  Where xType = 'P' and name = 'SetAndMigrateMetaData')
Begin
	Execute('DROP PROCEDURE SetAndMigrateMetaData')
	Print 'Procedure SetAndMigrateMetaData already exists, hence older one dropped ..... '
End

GO

Create Procedure SetAndMigrateMetaData
(
	@v_sourceCabinet      		VARCHAR(256),
	@v_targetCabinet      		VARCHAR(256),
	@v_isDBLink			  		VARCHAR(1),
	@sourceMachineIp      		VARCHAR(256),
	@v_migrateAllData 	  		VARCHAR(1),	
	@v_copyForceFully	  		VARCHAR(1),
	@v_overRideCabinetData		VARCHAR(1),
	@v_DeleteFromSrc			VARCHAR(1),    /* Required for MoveDocDb whether Data has to be deleted from source or not */
	@v_moveTaskData        		VARCHAR(2)
)

AS
	
BEGIN

	SET NOCOUNT ON
	
	Declare @tableVariableMap 		AS Process_Variant_Type
	Declare @dblinkString 			NVARCHAR(256)
	Declare @Id 					INT
	Declare @PVId 					INT
	Declare @v_executionLogId 		INT
	Declare @v_remarks 				VARCHAR(Max)
	Declare @tableVarRemarks		VARCHAR(4000)
	DECLARE @DBStatus	 			INT
	
	Select @tableVarRemarks = ''
	IF(@v_isDBLink = 'Y' )
	BEGIN
		SELECT @dblinkString = '[' + @sourceMachineIp + '].'+ @v_sourcecabinet +'.dbo' 
	END
	ELSE
	BEGIN
		SELECT @dblinkString = @v_sourcecabinet + '.'
	END
	
		
	------------------------------Call SynchCabinets---------------------------------------------------------
	--EXEC SynchCabinets @v_sourceCabinet,@v_targetCabinet,@dblinkString,@DBStatus OUT
	--IF (@DBStatus <> 0)
	--Begin
		-- Print 'Error in caliing Synch Cabinets'
		 --Return
	--End
	
	--Populate our SourceIDMap variable (dummy select statement for now).
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (17,0)	--	CSR_MR
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (18,0)	--	CSR_CCC
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (19,0)	--	CSR_CCB
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (20,0)	--	CSR_OCC
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (21,0)	--	CSR_RR
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (22,0)	--	CSR_BT
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (23,0)	--	DSR_ODC
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (24,0)	--	DSR_DCB
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (25,0)	--	DSR_MR
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (26,0)	--	GSR_LCOL
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (27,0)	--	DA
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (28,0)	--	TF
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (29,0)	--	SRM
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (30,0)	--	AO
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (31,0)	--	BAIS
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (32,0)	--	SRB
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (33,0)	--	EPP
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (35,0)	--	RBL
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (36,0)	--	TL
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (37,0)	--	CU
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (38,0)	--	SRO
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (39,0)	--	TT
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (40,0)	--	TWC
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (41,0)	--	CAC
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (42,0)	--	OECD
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (43,0)	--	RAO
	Insert into @tableVariableMap(ProcessDefid,ProcessVariantID) values (44,0)	--	RMT

	--Print out contents of collection
	Declare NewCursor  CURSOR FAST_FORWARD FOR Select ProcessDefId,ProcessVariantID From @tableVariableMap
	Open NewCursor
	FETCH NEXT FROM NewCursor INTO @Id , @PVId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		PRINT 'ProcessDefId'
		PRINT  @Id
		PRINT 'ProcessVariantID'
		PRINT  @PVId
		SELECT @tableVarRemarks = @tableVarRemarks +  'PId--'+ CONVERT(NVARCHAR(10),@Id) + 'PVId--' + CONVERT(NVARCHAR(10),@PVId)
		FETCH NEXT FROM NewCursor INTO  @Id , @PVId

	END
	Close NewCursor
	
	Insert into getnerateLogId DEFAULT VALUES
	SELECT @v_executionLogId =  max(id) from  getnerateLogId
	SELECT @v_remarks = 'MetaData Execution Begins with following parameters --> v_sourceCabinet : ' + @v_sourceCabinet + ' , v_targetCabinet : ' + @v_targetCabinet + ' , v_isDBLink : ' + @v_isDBLink  + ' , sourceMachineIp : '+ @sourceMachineIp + ' , v_migrateAllData : ' + @v_migrateAllData + ' , v_copyForceFully : ' + @v_copyForceFully + '  , v_overRideCabinetData : ' + @v_overRideCabinetData + ' ,  tableVariable : ' + @tableVarRemarks + ' ,  dblinkString : ' + @dblinkString
	Insert into WFMigrationLogTable values (@v_executionLogId,getdate(),@v_remarks)
	
	EXEC WFMigrateMetaData @v_sourceCabinet , @v_targetCabinet , @dblinkString , @tableVariableMap , @v_migrateAllData ,@v_copyForceFully , @v_overRideCabinetData,@v_DeleteFromSrc,@v_executionLogId,@v_moveTaskData
	

END
