

var bNewSubmitRespHook = true;

function NewSubmit(item,containerId,callbackfuncname) {
    sub(item,containerId,callbackfuncname);
    return false;
}


function sub(item,containerId,callbackfuncname) {
    var xmlReq = null;
    var file = item.form.action;
    var time=new Date();
    var tempurl;
    
    if(file.indexOf("?")>0) {
        tempurl=file + "&time="+ time.getTime();    
    }
    else {
        tempurl=file + "?time="+ time.getTime();                
    }
    
    file=tempurl;
    
    var str = getFormValues(item,"validate");
    xmlReq = getXML(file,str,containerId,callbackfuncname);
}  

var doc = null ; 
function getXML(file,str,containerId,callbackfuncname) {
    var time=new Date();
    //var indid = randomString();
    if (typeof window.ActiveXObject != 'undefined' ) { 
        doc = new ActiveXObject("Microsoft.XMLHTTP"); 
        doc.onreadystatechange = displayState; 
    } 
    else { 
        doc = new XMLHttpRequest(); 
        doc.onload = displayState; 
    } 
    createIndicator('NewSubmitInd');
    try {
        doc.open( "POST", file, true); 
        doc.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); 
        doc.send(str); 
    }
    catch(e) {
        //		alert("from getxml==");
    }
    return doc; 
    
    function displayState() {
        var outputxml=null;
        
        if (doc.readyState!=null && doc.readyState==4) {
            if (doc.status==200) {
                
                try {                    
                    outputxml=doc.responseText;
                    //alert("displayState");
                    //To check whether the page is errorpage or not.
                    //If it is errorpage remove the logo and ok button(ie. only add the content of div to the innerhtml)
                    //For BUG ID:205
                    var error = "PM_ERROR_PAGE_12345_DIV";
                    if(outputxml.indexOf(error)>0) {

                     try{
                        var errorMsg=outputxml.substring(outputxml.indexOf(error) + error.length,outputxml.length);
                       errorMsg=errorMsg.substring(errorMsg.indexOf(">")+1,errorMsg.indexOf("</Div>"));
                        if(errorMsg.length>0)
                            generateErrorAjaxCalls(errorMsg);
                        else
                            generateErrorAjaxCalls(SESSION_TIMEDOUT);

                    }catch(ex) {
                        generateErrorAjaxCalls(SESSION_TIMEDOUT);
                    } 
                    }
                    else {
                        try {
                            //alert(outputxml)
                            document.getElementById(containerId).innerHTML=outputxml;
                            try
                            {
                             if(bNewSubmitRespHook)
                                    newsubmitreshook(doc);
                            }
                            catch(e){}
                            doc=null;
                        }
                        catch(ee) {
                            
                            window.opener.document.getElementById(containerId).innerHTML=outputxml;
                            window.opener.focus();
                            doc=null;
                        } 
                    }
                }
                catch (e) {
                    //alert("Exception "+e.toString());
                    try {
                        document.getElementById(containerId).innerText=outputxml ;	
                    }
                    catch(eee) {
                        window.opener.document.getElementById(containerId).innerText=outputxml;	
                        window.opener.focus();
                    }
                }
                
            }
            else if(doc.status==598) 
            {			  
                    window.location = "../application/errorpage.faces";
            }
             else if(doc.status==310)
            {
                window.location= "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";    
            }
            else {
                //alert(doc.responseText);
                customAlert(ERROR_FETCHING_DATA);
            }
            removeIndicator('NewSubmitInd');
            try{
                var callbackfunction = "";
                if(callbackfuncname != undefined && callbackfuncname.length>0)
                    callbackfunction = callbackfuncname;

                else if((document.getElementById("callbackfunction").value).length>0) {
                    callbackfunction =encode_ParamValue(document.getElementById("callbackfunction").value);
                }
                //alert("Inside Eval callbackfunction=="+callbackfunction);
                if(callbackfunction.length>0)
                    parseJSON(callbackfunction);
                
            }
            catch(e){
                
            }
            
        }	  
    }
}

function getFormValues(item,valFunc) { 
    var str = ""; 
    var valueArr = null; 
    var val = ""; 
    var cmd = ""; 
    var fobj = item.form;
    var formid=fobj.id;	
    for(var i = 0;i < fobj.elements.length;i++) { 
        //alert('Type of elt: '+fobj.elements[i].type+" name:  "+fobj.elements[i].name);
        
        switch(fobj.elements[i].type) { 
            case "hidden":
                
                var stateName = "com.sun.faces.VIEW";
                if(fobj.elements[i].name== stateName) {
                    
                    var stateValue = null;
                    var params = "";
                    
                    stateValue = fobj.elements[i].value;
                    var encodedValue = encodeURI(stateValue);
                    var re = new RegExp("\\+", "g");
                    var encodedPlusValue = encodedValue.replace(re, "\%2B");
                    params = stateName + "=" + encodedPlusValue + "&";
                    
                    str += params;
                }
                else {	
                    str += encode_utf8(fobj.elements[i].name) +  "=" + encode_utf8(fobj.elements[i].value) + "&";
                }
                break;
            case "textarea":
            case "text": 
            case "password":
                str += encode_utf8(fobj.elements[i].name) +  "=" + encode_utf8(fobj.elements[i].value) + "&"; 
                break; 
                
            case "select-one":
                try{
                str += encode_utf8(fobj.elements[i].name) + "=" + encode_utf8(fobj.elements[i].options[fobj.elements[i].selectedIndex].value) + "&"; 
                    }catch(ex){}
                break;
            case "select-multiple":
                formElement=fobj.elements[i];
                len=document.getElementById(fobj.elements[i].name).length;
                for(var x=0; x < len; x++) {
                    if(formElement[x].selected == true)
                        str += encode_utf8(fobj.elements[i].name) + "=" + formElement[x].value + "&"; 
                }
                break;
                
            case "checkbox":
                if(fobj.elements[i].checked) {
                    str += encode_utf8(fobj.elements[i].name) + "=" +(fobj.elements[i].value) + "&"; 
                }
                break;
            case "radio":	
                if(fobj.elements[i].checked) {
                    str += encode_utf8(fobj.elements[i].name) + "=" +(fobj.elements[i].value) + "&"; 
                }
                break;
                
                
        }
    }
    
    if(item.name == undefined) {
        //alert('item name undefined');
    }
    else {
        //alert(item.name);
        if(item.type=="image") {                                       
            str+=encode_utf8(item.name+'.x') + "="+encode_utf8(item.value)+"&";
            str+=encode_utf8(item.name+'.y') + "="+encode_utf8(item.value)+"&";
        }
        else {                    
            if(item.value.length==0) {
                //alert('in length eq 0');
                str+=encode_utf8(item.name) + "="+encode_utf8('act')+"&";    
            }
            else {
                //alert('in else case');
                str+=encode_utf8(item.name) + "="+encode_utf8(item.value)+"&";
            }
        }
    }
    str = str.substr(0,(str.length - 1));
    return str;
}



/*************************function returns xmlHttp object***********************************/
function createXMLHttpRequest() {
    //try {return new ActiveXObject("Msxml2.XMLHTTP");} catch (e) {}
    try {return new ActiveXObject("Microsoft.XMLHTTP");} catch (e) {}
    try {return new XMLHttpRequest();} catch(e) {}
    return null;
}



/*************************function for making ajax call***********************************/
function getActionUrlFromURL(sURL)
{
    var ibeginingIndex=sURL.indexOf("?");
    if (ibeginingIndex == -1)
        return sURL;
    else
        return sURL.substring(0,ibeginingIndex);
 }

function makeAjaxCallWrapper(url, target,indicatorid,onloadfunction) {
    
    var trui= getActionUrlFromURL(url);
    var servletUrl = "/webdesktop/secuidsv?T-URI="+trui;
    (typeof WD_SID != 'undefined' && WD_SID != null) && (servletUrl += "&WD_SID=" + WD_SID);
            
    var xhReq = createXMLHttpRequest();
    //createIndicator(indicatorid);
    xhReq.open("POST", servletUrl, true);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhReq.onreadystatechange = onResponse;
    var params = servletUrl.substring("?");
    xhReq.send(params);
   // xhReq.send();
    
    function onResponse() {        
        try {
            
            var wd_rid;
            
            if (xhReq.readyState==4) { 
                if (xhReq.status==200) {

                    wd_rid = xhReq.getResponseHeader("WD_RID");
                    if (url.indexOf("?") > 0) {
                        url = url + "&WD_RID=" + wd_rid;
                    } else {
                        url = url + "?WD_RID=" +wd_rid;
                    }
                   
                } 
                 makeAjaxCall(url,target,indicatorid,onloadfunction);
            }
            
        } catch(e) {
            alert(ERROR_FETCHING_DATA);
        }
    }
}



function makeAjaxCall(url,target,indicatorid,onloadfunction) {
    //var url=appendUrlSessionAjax(url);
    
    if(url.indexOf("?")>0) {
        url=url + "&sid="+ Math.random();
    }
    else {
        url=url + "?sid="+ Math.random();
    }
    var xhReq = createXMLHttpRequest();
    CreateIndicator(indicatorid);
    xhReq.open("GET", url, true);
    xhReq.onreadystatechange = onResponse;
    xhReq.send(null);
    
    
    function onResponse() {        
        try {
            if (xhReq.readyState==4) { 
                if (xhReq.status==200) {   
                    var returnxml=xhReq.responseText;//alert(returnxml);
                    var error = "PM_ERROR_PAGE_12345_DIV";
                    if(returnxml.indexOf(error)>0) {
                        
                     try{
                        var errorMsg=returnxml.substring(returnxml.indexOf(error) + error.length,returnxml.length);
                       errorMsg=errorMsg.substring(errorMsg.indexOf(">")+1,errorMsg.indexOf("</Div>"));
                        if(errorMsg.length>0)
                            generateErrorAjaxCalls(errorMsg);
                        else
                            generateErrorAjaxCalls(SESSION_TIMEDOUT);

                    }catch(ex) {
                        generateErrorAjaxCalls(SESSION_TIMEDOUT);
                    } 
                    }
                    else {
                        removeAllChildNodes(document.getElementById(target));
                        document.getElementById(target).innerHTML=returnxml;
                        if(onloadfunction.length>0) {
                            try {
                                parseJSON(onloadfunction);
                            }
                            catch(e){
                            }
                        }
                    }
                    
                
                } else if (xhReq.status == 310)
                {
                    window.location = "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";
                } else if (xhReq.status == 250) {
                    window.location = "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";
                }
                else if(xhReq.status==598) {			  
                    window.location = "../application/errorpage.faces";
                }
                else if(xhReq.status==12029) {			  
                    customAlert(ERROR_SERVER); 
                }
                else {                    
                    document.getElementById(target).innerHTML="";
                    if(xhReq.status!=0)
                        customAlert(ERROR_FETCHING_DATA);
                }
                removeIndicator(indicatorid);
            }
        }
        catch(e) {
            customAlert(ERROR_FETCHING_DATA);
        }
    }
}
var GlobalSessionVal="";
function appendUrlSessionAjax(url) {
    var cookieFlag = 'Y';
   
    if(cookie)
        cookieFlag = 'Y';
    else
        cookieFlag = 'N';

   
            
    if(cookieFlag == 'N' && GlobalSessionVal!="" )
    {
	    if(url.indexOf('?') != '-1')
            url = url.substring(0,url.indexOf('?'))+GlobalSessionVal+url.substring(url.indexOf('?'));
        else
            url = url + GlobalSessionVal;
    }
    
    return url;
    
}

function generateErrorAjaxCalls(ErrorMsg) {
    //DisplayErrorMsgPopUp(ErrorMsg);
    customAlert(ErrorMsg);
}

/*function removeAllChildNodes(node) {
    if (node && node.hasChildNodes && node.removeChild) {
        while (node.hasChildNodes()) {
            node.removeChild(node.firstChild);
        }
    }
} // removeAllChildNodes()*/


function removeAllChildNodes(node) {
    try{
        if (node && node.hasChildNodes && node.removeChild) {
            while (node.hasChildNodes()) {
                if(node.firstChild.hasChildNodes()){                
                    while(node.firstChild.hasChildNodes())
                        removeAllChildNodes(node.firstChild);
                }    
                else
                    node.removeChild(node.firstChild);
            }
        }
    }catch(e) {}
}


function handleEnter(e,id) {       
    var browser=navigator.appName;
    if(browser=="Netscape") {
        
        if(e.which == 13) {       
            
            try {
                document.getElementById(id).focus();
            }
            catch(e){
            }
            
        }
    }
    
    else {      
        e=window.event;
        if(e.keyCode == 13) {
            try {
                document.getElementById(id).focus();
            }
            catch(e){
            }
        }
        
    }
}

/*----------------------------------------------------------------------------------------------------
//Function Name   : createIndicator
//Date Written (DD/MM/YYYY) : 31/08/2007
//Input Parameters  :
//Output Parameters  :
//Description   : Creates a  images that acts as an indicator during an ajax call
----------------------------------------------------------------------------------------------------
             
----------------------------------------------------------------------------------------------------*/

function createIndicator(indicatorFrameId) {
    
    var ParentDocWidth = document.body.clientWidth;
    var ParentDocHeight = document.body.clientHeight;
    var ImgTop=ParentDocHeight/2-10;
    var ImgLeft=ParentDocWidth/2-25;
    
    try {
        
        if(document.getElementById(indicatorFrameId) != null)
            return;
        img = document.createElement("IMG");   
        img.setAttribute("src", "../webtop/images/progress.gif");
        img.setAttribute("name", indicatorFrameId);
        img.setAttribute("id", indicatorFrameId);
        img.style.left = ImgLeft+"px";
        img.style.top = ImgTop+"px";
        img.style.position="absolute";
        img.style.visibility="visible";        
        document.body.appendChild(img);
        
    }
    catch(ex) {
        //alert("exception= "+ex);
    }
    document.body.style.cursor='wait';
}

/*----------------------------------------------------------------------------------------------------
//Function Name   : removeIndicator
//Date Written (DD/MM/YYYY) : 31/08/2007
//Input Parameters  :
//Output Parameters  :
//Description   : Removes the image of indicator from the page after the ajax call
----------------------------------------------------------------------------------------------------
 
----------------------------------------------------------------------------------------------------*/

function removeIndicator(indicatorFrameId) {
    try {

        var img = document.getElementById(indicatorFrameId);
        document.body.removeChild(img);
    }
    catch(ex) {
        
    }
    document.body.style.cursor='auto';
}

function randomString() {
    var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
    var string_length = 8;
    var randomstring = '';
    for (var i=0; i<string_length; i++) {
        var rnum = Math.floor(Math.random() * chars.length);
        randomstring += chars.substring(rnum,rnum+1);
    }
    return randomstring;
}
function StyleLink(ref)
{   //alert(ref.value);
    ref.style.textDecoration='underline';
    ref.style.color='#B50000';
}

function StyleNormal(ref)
{//alert("stylenor");
    ref.style.textDecoration='none';
    ref.style.color='#003EA8';
    
}
