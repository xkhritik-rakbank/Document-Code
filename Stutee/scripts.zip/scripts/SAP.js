
function SAPClick()
{
    return true;
}

function openSAPWin(sapDefId) {
    
    var url='/webdesktop/components/workitem/view/SAP.app';
    var  pid=document.forms['wdesk']['wdesk:pid'].value;
    var  wid=document.forms['wdesk']['wdesk:wid'].value;
    var  taskid=document.forms['wdesk']['wdesk:taskid'].value;
    var requestString=encode_utf8("pid")+"="+pid+"&"+encode_utf8("wid")+"="+wid+"&taskid="+taskid+"&"+"sapDefId="+sapDefId+"&height="+winH;
    url = url+'?'+requestString;
    url = appendUrlSession(url);
    if(compositeSAPView=='Y'){          //Bug 64845
        openNewWindow(url, 'SAP', 'resizable=yes,scrollbars=yes,status=yes,width='+window1W+',height='+window1H+',left='+window1Y+',top='+window1X+',visibility=show',true,"Ext1","Ext2","Ext3","Ext4","");
    } else{
        var win = link_popup(url, sapDefId, 'resizable=yes,scrollbars=yes,status=yes,width='+window1W+',height='+window1H+',left='+window1Y+',top='+window1X+',visibility=show',windowList,false);
    }
    
}
function clickDone(sapDefName,sapCompName) {
    sapDefNameFinal=sapDefName;
    //sapDefNameFinal=sapCompName;
    var username=document.getElementById('username'+sapDefName).value;
    var pd=document.getElementById('password'+sapDefName).value;
    if(username=='' || pd==''){
        customAlert(MANDATORY_FIELD);
        return false;
    }
   var bf = new Blowfish('DES');
    username = bf.encryptx(username,'6432630498745557832');
    pd = bf.encryptx(pd,'6432630498745557832');
     
    var comboLoader = ContentLoaderWrapper('/webdesktop/ajaxsap.app?username='+encode_utf8(username)+'&passwd='+encode_utf8(pd)+'&'+encode_utf8("pid")+"="+pid+"&"+encode_utf8("wid")+"="+wid+"&taskid="+taskid+"&sapDefId="+sapDefName+"&WD_SID="+WD_SID,sapHandler,null,"POST","");
    return false;
}

function sapHandler() {
    /*if(this.req.responseText=='Failure')
    {
        document.getElementById('globalMessage'+sapDefNameFinal).innerHTML=ALERT_INVALID_LOGIN_INFO;
        document.getElementById('saperror').style.display="block";
    }
    else{
        document.getElementById('sapviewer'+sapDefNameFinal).style.display="inline";
        document.getElementById('credentialGrid'+sapDefNameFinal).style.visibility="hidden";
        document.getElementById('sapviewer'+sapDefNameFinal).src=this.req.responseText;
        document.getElementById('globalMessage'+sapDefNameFinal).innerHTML="";
        document.getElementById('saperror').style.display="none";
    }*/
    
    if(this.req.getResponseHeader("CallStatus") == 'failure')
    {
        var errorMessage = this.req.getResponseHeader("ErrorMessage");
        if(typeof errorMessage != 'undefined' && errorMessage!=""){
            alert(errorMessage);
            return false;
        } else {
            alert(ALERT_INVALID_LOGIN_INFO);
            return false;
        }
       // document.getElementById('saperror').style.display="block";
    } else{
        document.getElementById('sapviewer'+sapDefNameFinal).style.display="inline";
        document.getElementById('credentialGrid'+sapDefNameFinal).style.visibility="hidden";
        document.getElementById('sapviewer'+sapDefNameFinal).src = this.req.getResponseHeader("SAPUrl");
        document.getElementById('globalMessage'+sapDefNameFinal).innerHTML="";
        document.getElementById('saperror').style.display="none";
    }    
}

function handleEnter(e, sapDefName, sapCompName)
{
    var browser = navigator.appName;
    if (browser == "Netscape")
    {
        if (e.which == 13)
        {   
            cancelBubble(e);
            clickDone(sapDefName,sapCompName);
            return false;
        }
    }
    else
    {
        e = window.event;
        if (e.keyCode == 13)
        {
           cancelBubble(e);
           clickDone(sapDefName,sapCompName);
           return false;
        }
    }
}

function handleEnter(e, sapDefName, sapCompName)
{
    var browser = navigator.appName;
    if (browser == "Netscape")
    {
        if (e.which == 13)
        {   
            cancelBubble(e);
            clickDone(sapDefName,sapCompName);
            return false;
        }
    }
    else
    {
        e = window.event;
        if (e.keyCode == 13)
        {
           cancelBubble(e);
           clickDone(sapDefName,sapCompName);
           return false;
        }
    }
}