
var WD_SID;
var RefreshLink=null;
var UniqueUserId;
function RefreshAdminOption()
{   
    if(RefreshLink !=null)
    {
        ClickAnotherLink(RefreshLink,'cmdBtn');
    }
}

function Refreshmodifyprocstatus()
{
    try
    {
        clickLink('modifyprocessstate:cmdlink_go');
    }catch(e){}
}
function queueManagement()
{
    var Url="/webdesktop/components/queue/queuemgmt.app?Action=1&mode=1&Opt=1&WD_SID="+WD_SID;
    makeAjaxCallWrapper(Url,"ResultContainer","resultind","");
}

function processManagement()
{
    var Url="../processmgmt/modifyprocstatus.app?Action=1&Opt=2&WD_SID="+WD_SID;
    makeAjaxCallWrapper(Url,"ResultContainer","resultind","");
   
}
function queueProcessAuthorization()
{
    var Url="../authorization/queueprocessauth.app?Action=1&Opt=12&WD_SID="+WD_SID;
    makeAjaxCallWrapper(Url,"ResultContainer","resultind","");
   
}
function manageProcess(ref)
{
    var formID=ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var processID="";
    var processName="";
    try
    {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;
        var processIDId;
        var processNameId;
    
        for (var iCount=0;iCount < rowCount ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":procId";
            processNameId=tableID+":" + iCount +":procName";
            try
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    processID=document.getElementById(processIDId).value;
                    processName=document.getElementById(processNameId).value;
                }

            }
            catch(e)
            {
            //alert("Error in=="+iCount);
            }
        }
    }
    catch(e)
    {
    //alert("Error in=="+iCount);
    }
    if(noOfSelectedRows>1)
    {
        customAlert(INVALID_SELECTION_MULTIPLE);
        return false;
    }  
        
    var Url="../processmgmt/processmanagement.faces";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("Opt",encode_ParamValue("2")));
    listParam.push(new Array("procName",encode_ParamValue(processName)));
    listParam.push(new Array("procId",encode_ParamValue(processID)));

    var win = openNewWindow(Url,"processmanagement"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function purgeCriteria(ref)
{
    var formID="modifyprocessstate"; //ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var processID="";
    var processName="";
    try
    {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;
        for (var iCount=0;iCount < rowCount ;iCount++)
        {
            if(document.getElementById(tableID+":" + iCount +chkboxName).checked)
            {
                processID=document.getElementById(tableID+":" + iCount +":procId").value;
                processName=document.getElementById(tableID+":" + iCount +":procName").value;
                break;
            }
        }
    }catch(e)
    {
        //alert("Error in=="+iCount);
    }
   var Url="/webdesktop/components/process/purgecriteria.app";
    Url = appendUrlSession(Url);
   var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H+30;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);


    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("Opt",encode_ParamValue("2")));
    listParam.push(new Array("processdefid",encode_ParamValue(processID)));
    listParam.push(new Array("procName",encode_ParamValue(processName)));
    //listParam.push(new Array("version",encode_ParamValue(Version)));
    var win = openNewWindow(Url,"purgecriteria",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
    // window.location.href=Url;
}
function openwsdetails(ref)
{
    var formID="modifyprocessstate"; //ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;    
    var processIDId;
    var processNameId;
    var processID="";
    var processName="";
    try
    {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;
        for (var iCount=0;iCount < rowCount ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":procId";
            processNameId=tableID+":" + iCount +":procName";
            try 
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    processID=document.getElementById(processIDId).value;
                    processName=document.getElementById(processNameId).value;
                }

            }
            catch(e)
            {
                    //alert("Error in=="+iCount);
            }
        }
    }
    catch(e)
    {
            //alert("Error in=="+iCount);
    }
    if(noOfSelectedRows>1)
    {
       customAlert(INVALID_SELECTION_MULTIPLE);
       return false;
    }  
       //alert("fff") ;
   var Url="/webdesktop/components/process/wsdetails.app?newPage=true&Opt=4"+"&procName="+encode_utf8(processName)+"&procId="+encode_utf8(processID);
  // alert(Url);
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H+10;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var win = window.open(Url,"wsdetails"+UniqueUserId,'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
    
    try{
        win.focus();
    } catch(e){}
}

function openTaskPreferences(ref){
    var formID="modifyprocessstate"; //ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;    
    var processIDId;
    var processNameId;
    var processID="";
    var processName="";
    try
    {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;
        for (var iCount=0;iCount < rowCount ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":procId";
            processNameId=tableID+":" + iCount +":procName";
            try 
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    processID=document.getElementById(processIDId).value;
                    processName=document.getElementById(processNameId).value;
                }

            }
            catch(e)
            {
                    //alert("Error in=="+iCount);
            }
        }
    }
    catch(e)
    {
            //alert("Error in=="+iCount);
    }
    if(noOfSelectedRows>1)
    {
       customAlert(INVALID_SELECTION_MULTIPLE);
       return false;
    }
     var Url="/webdesktop/components/process/taskpreferences.app?newPage=true&Opt=4"+"&procName="+encode_utf8(processName)+"&procId="+encode_utf8(processID);
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H+10;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var win = window.open(Url,"taskPreferences"+UniqueUserId,'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft);
    try
    {
        addWindows(win);
    }
    catch(e)
    {
        
    }
    try{
        win.focus();
    } catch(e)
    {
        
    }
}

function openModifyActivity(ref){
    var formID="modifyprocessstate"; //ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;    
    var processIDId;
    var processNameId;
    var processID="";
    var processName="";
    try
    {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;
        for (var iCount=0;iCount < rowCount ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":procId";
            processNameId=tableID+":" + iCount +":procName";
            try 
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    processID=document.getElementById(processIDId).value;
                    processName=document.getElementById(processNameId).value;
                }

            }
            catch(e)
            {
                    //alert("Error in=="+iCount);
            }
        }
    }
    catch(e)
    {
            //alert("Error in=="+iCount);
    }
    if(noOfSelectedRows>1)
    {
       customAlert(INVALID_SELECTION_MULTIPLE);
       return false;
    }
     var Url="/webdesktop/components/process/activityMgmt.app";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H+10;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;
    var listParam=new Array();
    listParam.push(new Array("procName",encode_ParamValue(processName)));
    listParam.push(new Array("procId",encode_ParamValue(processID)));
    var win = openNewWindow(Url,'modifyActivity',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    //var win = window.open(Url,"modifyActivity"+UniqueUserId,'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft);
    try
    {
        addWindows(win);
    }
    catch(e)
    {
        
    }
    try{
        win.focus();
    } catch(e)
    {
        
    }
}

function openSuspendedWorkitem(ref){
     var Url="/webdesktop/components/process/resumeSuspendedWorkitem.app";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H+10;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;
    var win = openNewWindow(Url,'modifyActivity',wFeatures, true,"Ext1","Ext2","Ext3","Ext4","listParam");
    //var win = window.open(Url,"modifyActivity"+UniqueUserId,'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft);
    try
    {
        addWindows(win);
    }
    catch(e)
    {
        
    }
    try{
        win.focus();
    } catch(e)
    {
        
    }
}

function defineturnaroundtime(ref)
{
    var formID="modifyprocessstate";//ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var processIDId;
    var processID="";
    var processNameId;
    var processName="";
    var turnAroundTimeId;
    var turnAroundTime="";
    var processCalFlagId;
    var processCalFlag="";

    try
    {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;

        for (var iCount=0;iCount < rowCount ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":procId";
            processNameId=tableID+":" + iCount +":procName";
            turnAroundTimeId=tableID+":" + iCount +":procTat";
            processCalFlagId=tableID+":" + iCount +":procCalFlag";

            try
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    processID=document.getElementById(processIDId).value;

                    processName=document.getElementById(processNameId).value;
                    turnAroundTime=document.getElementById(turnAroundTimeId).value;
                    processCalFlag=document.getElementById(processCalFlagId).value;


                }

            }
            catch(e)
            {
                //alert("Error in=="+iCount);
            }
        }
    }
    catch(e)
    {
        //alert("Error in=="+iCount);
    }
    if(noOfSelectedRows>1)
    {
        customAlert(INVALID_SELECTION_MULTIPLE);
        return false;
    }
    var Url="/webdesktop/components/process/processturnaroundtime.app";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H-15;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("procName",encode_ParamValue(processName)));
    listParam.push(new Array("procId",encode_ParamValue(processID)));
    listParam.push(new Array("tat",encode_ParamValue(turnAroundTime)));
    listParam.push(new Array("calFlag",encode_ParamValue(processCalFlag)));

    var win = openNewWindow(Url,'defineturnaroundtime',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function dynamicConstants(ref)
{
    var formID="modifyprocessstate";//ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var processIDId;
    var processNameId;
    var processID="";
    var processName="";
    try
    {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;
        for (var iCount=0;iCount < rowCount ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":procId";
            processNameId=tableID+":" + iCount +":procName";
            try
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    processID=document.getElementById(processIDId).value;
                    processName=document.getElementById(processNameId).value;
                }

            }
            catch(e)
            {
                //alert("Error in=="+iCount);
            }
        }
    }
    catch(e)
    {
        //alert("Error in=="+iCount);
    }
    if(noOfSelectedRows>1)
    {
        customAlert(INVALID_SELECTION_MULTIPLE);
        return false;
    }
    
    var Url="/webdesktop/components/process/dynamicConstantsmgmt.app?newPage=true&Opt=4&procName="+encode_utf8(processName)+"&procId="+processID;
    Url = appendUrlSession(Url);
    //window.parent.createPopUpIFrameWrapper("dynamicconstant",Url,400,600);

    /*var ref=document.getElementById('modifyprocessstate:cmdDynamicConstants');
    var posLeft = findAbsPosX(ref);
    var posTop = findAbsPosY(ref);
      
    window.parent.popupIFrameOpenerWrapper(this,'dynamicconstant' ,Url,520,400, posLeft, posTop, false, true, false, true);*/
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("newPage",encode_ParamValue("true")));
    listParam.push(new Array("Opt",encode_ParamValue("4")));
    listParam.push(new Array("procName",encode_utf8(processName)));
    listParam.push(new Array("procId",encode_ParamValue(processID)));

    var win = openNewWindow(Url,"dynamicConstants",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);

    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function disabledAliasCheck(){ 
    //document.getElementById("aliaslistDiv").style.height = (window.screen.height - 640);
    for(j=0;j<5;j++){
        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar").disabled=true;   
        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar1").disabled=true;
    }
    
}

function checkOtherRule(ref){  
    if(ref.checked==true){ 
        document.getElementById("frmProcVarMapping:OtherRlueButton").disabled=false;
    }else{
        var radioIndex;  
        if(isCompatibleForRadioCheck())
            radioIndex=1;
        else
            radioIndex=0;
        document.getElementsByName("frmProcVarMapping:otherRadioCI")[radioIndex].checked="true";
        document.getElementById("frmProcVarMapping:otherBgcolortxtbox").style.backgroundColor="#FFFFFF";
        document.getElementById("frmProcVarMapping:otherImage").src="/webdesktop/resources/aliasimages/transparent.gif";
        document.getElementById("frmProcVarMapping:otherHidbgcolortxtbox").value=""; 
        document.getElementById("frmProcVarMapping:OtherRlueButton").disabled=true;
    }
}

function userPrefefences()
{
    var Url="../usermgmt/userpreferences.app?Action=1&Opt=5&WD_SID="+WD_SID;
    makeAjaxCallWrapper(Url,"ResultContainer","resultinduserpref","");
}

function changePassword()
{
    var Url= getActionUrlFromURL(changePasswordUrl);
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=windowH;
    var WindowWidth=windowW;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);    
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;
    var listParam = getInputParamListFromURL(changePasswordUrl);
    var win = openNewWindow(Url,"changepass"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try {
        addWindows(win);
    }
    catch(e)
    {}
}

function auditLogConfiguration()
{
    var Url="../auditlog/auditlogconfig.app?Action=1&Opt=7&WD_SID="+WD_SID;
    makeAjaxCallWrapper(Url,"ResultContainer","auditlogresultind","");
}


function changeWorkingTime()
{
    var Url="../calendar/changeworkingtime.app?Action=5&Opt=10&WD_SID="+WD_SID;
    makeAjaxCallWrapper(Url,"ResultContainer","calendermain","");
}

function SelectTabAlC(iTabIndex)
{
    try
    {
        document.getElementById("auditconfig11:SelTab").value=iTabIndex;
    }
    catch(e){}
    ClickAnotherLink('','cmdbutton_go');
}

function cabinetManagement()
{
    //BUG 557 //BUG 557 RE
        
    sContextPath = sContextPath.substring(sContextPath.lastIndexOf("/"));
        
    var url=sContextPath+'/application/odadmin.faces';
        
    url=appendUrlSessionAjax(url);
       
    var wFeatures = 'resizable=1,scrollbars=1,status=yes,width='+window1W+',height='+window1H+',left='+window1Y+',top='+window1X;
    var listParam=new Array();
    win = openNewWindow(url,'ODadmin'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
	
    addWindows(win);
}

function documentManagement()
{
    //BUG 558 //BUG 558 RE
    sContextPath = sContextPath.substring(sContextPath.lastIndexOf("/"));
       
    var url=sContextPath+'/application/odweb.faces';
       
    url=appendUrlSessionAjax(url);

    var wFeatures = 'resizable=1,scrollbars=1,status=yes,width='+window1W+',height='+window1H+',left='+window1Y+',top='+window1X;
    var listParam=new Array();

    win = openNewWindow(url,'ODweb'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    addWindows(win);
}

function newQueue(ref)
{
    RefreshLink=ref;
    var QueueID="123";
    
    var Url="/webdesktop/components/queue/queuemgmt.app";
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window6H+90;
    var WindowWidth=window6W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2) - 15;
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;
    
    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("Mode",encode_ParamValue("1")));
    listParam.push(new Array("showTab",encode_ParamValue("1")));
    listParam.push(new Array("QueueID",encode_ParamValue(QueueID)));
    var win = openNewWindow(Url,"newqueue"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function validateAliasList(ref, objId){
    //var objCombo = document.getElementById("frmProcVarMapping:opVar");
    var variableType=document.getElementById("frmProcVarMapping:selectedVarType").value;
    //var variableType=objCombo.value;
    var strValue="";
    var strValue1="";
    if(variableType!="8"){
        var compareValue="";
        var compareValue1="";
        for(j=0;j<5;j++){
            compareValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value;
            compareValue1=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value;
               
            if(variableType!=10){
                if(validateAllTypeData(compareValue,variableType))
                {

                }
                else
                {
                    customAlert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").focus();
                    return false;
                }
            }
            if(variableType!=10){
                if(validateAllTypeData(compareValue1,variableType))
                {

                }
                else
                {
                    customAlert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").focus();
                    return false;
                }
            }

        }
    }
    else{
        for(var j=0;j<5;j++){
            strValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").value;
            strValue1=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").value;
            if(strValue){
                if(validateAllTypeData(strValue,'3'))
                {

                }
                else
                {
                    customAlert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").focus();
                    return false;
                }
            }

            if(strValue1){
                if(validateAllTypeData(strValue1,'3'))
                {

                }
                else
                {
                    customAlert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").focus();
                    return false;
                }
            }
        }
    }
    selectOnechkBoxClick(ref);
    if(ref.checked){
        //If Alias is selected then show rule
        clickLink(objId);
    }
    callOnUnchecked(ref);
    return true;
}

function validateAliasListOnNew(){
   // var objCombo = document.getElementById("frmProcVarMapping:opVar");
    //var variableType=objCombo.value;
    var variableType=document.getElementById("frmProcVarMapping:selectedVarType").value;
    var strValue="";
    var strValue1="";
    if(variableType!="8"){
        var compareValue="";
        var compareValue1="";
        for(j=0;j<5;j++){
            compareValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value;
            compareValue1=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value;
            if(variableType!=10){
                if(validateAllTypeData(compareValue,variableType))
                {

                }
                else
                {
                    
                    customAlert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").focus();
                    return false;
                }
            } 
            if(variableType!=10){
                if(validateAllTypeData(compareValue1,variableType))
                {

                }
                else
                {
                    
                    customAlert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").focus();
                    return false;
                }
            }

        }
    }
    else{
        var ruleSelected;
        for(j=0;j<5;j++){
            strValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").value;
            strValue1=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").value;
            ruleSelected = document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").checked;
            if(strValue){
                if(validateAllTypeData(strValue,'3'))
                {
                     if(ruleSelected && trimByRegularEx(strValue) != "") {
                        if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").value) == "") {
                            customAlert(VALUE_IS_NOT_VALID);
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").focus();
                            return false;
                        }
                        if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").value) == "") {
                            customAlert(VALUE_IS_NOT_VALID);
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").focus();
                            return false;
                        }
                    }
                }
                else
                {
                    customAlert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").focus();
                    return false;
                }
            }

            if(strValue1){
                if(validateAllTypeData(strValue1,'3'))
                {
                    if(ruleSelected && trimByRegularEx(strValue1) != "") {
                        if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").value) == "") {
                            customAlert(VALUE_IS_NOT_VALID);
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").focus();
                            return false;
                        }
                        if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").value) == "") {
                            customAlert(VALUE_IS_NOT_VALID);
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").focus();
                            return false;
                        }
                        if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").value) == "") {
                            customAlert(VALUE_IS_NOT_VALID);
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").focus();
                            return false;
                        }
                    }
                }
                else
                {
                    customAlert(VALUE_IS_NOT_VALID); 
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").focus();
                    return false;
                }
            }
        }
    }
    return true;
}

function callOnUnchecked(ref){
    if(!ref.checked)
    {
        clickLink('frmProcVarMapping:cmdHideRule');
       
    }
}
function checkAliasRule(ref){
    var strId=ref.id;
    strId=strId.substring(0,strId.lastIndexOf(":")+1);
    var variableType=document.getElementById("frmProcVarMapping:selectedVarType").value;
 //   var objCombo = document.getElementById("frmProcVarMapping:opVar");
    if(ref.checked==true){
        document.getElementById(strId+"rlueButton").disabled=false;
    }else{
        var radioIndex;  
        if(isCompatibleForRadioCheck())
            radioIndex=1;
        else
            radioIndex=0;
        if(variableType!="8"){
            document.getElementById(strId+"ruleValue").value="";
            document.getElementById(strId+"relOperator").selectedIndex=0;
            document.getElementById(strId+"relOperator1").selectedIndex=0;
            document.getElementById(strId+"assignOperator").selectedIndex=0;
            document.getElementById(strId+"assignOperator1").selectedIndex=0;
            document.getElementById(strId+"logicalOperator").selectedIndex=0;
            document.getElementById(strId+"ruleValue1").value="";
        }
        else
        {
            document.getElementById(strId+"relOperator").selectedIndex=0;
            document.getElementById(strId+"relOperator1").selectedIndex=0;
            document.getElementById(strId+"assignOperator").selectedIndex=0;
            document.getElementById(strId+"assignOperator1").selectedIndex=0;
            document.getElementById(strId+"logicalOperator").selectedIndex=0;
            document.getElementById(strId+"ruleTempVar").value="";
            document.getElementById(strId+"ruleTempVar1").value="";
            document.getElementById(strId+"ruleTempVarType").value="";
            document.getElementById(strId+"ruleTempVarType1").value="";
        }
        document.getElementsByName(strId+"radioCI")[radioIndex].checked="true";
        document.getElementById(strId+"bgcolortxtbox").style.backgroundColor="#FFFFFF";
        document.getElementById(strId+"selImage").src="/webdesktop/resources/aliasimages/transparent.gif";
        document.getElementById(strId+"hidbgcolortxtbox").value=""; 
        document.getElementById(strId+"rlueButton").disabled=true;
    }
}

function delQueue()
{
    var QueueID="-1";
    var iCount=0;
    try
    {
        for(iCount=0;;iCount++)
        {
            var ctrlName= "QueueListForm:queueLists:" + iCount +":chkBoxQueue";
            if((document.getElementById(ctrlName)).checked==true)
            {
                ctrlName="QueueListForm:queueLists:" + iCount +":queueID";
                QueueID=(document.getElementById(ctrlName)).value;
                ctrlName="QueueListForm:queueLists:" + iCount +":queueType";
                if(document.getElementById(ctrlName).value=="I" || document.getElementById(ctrlName).value=="Q" || document.getElementById(ctrlName).value=="E" || document.getElementById(ctrlName).value=="H")
                {
                    customAlert(QUEUE_CAN_NOT_BE_DELETED);
                    document.getElementById("QueueListForm:hidQueueId").value="";
                    return false;
                }
                else
                {
                    document.getElementById("QueueListForm:hidQueueId").value=QueueID;
                    return true;                    
                }
            }
        }
    }
    catch(ex)
    {
        customAlert(NO_QUEUE_SELECTED);
        document.getElementById("QueueListForm:hidQueueId").value="";
        return false;
    }
    return false;
}

function delQueueConfirm()
{
   try
    {
        var toclickid='QueueListForm:btnConfirmDelete';
        clickLink(toclickid);
    }
    catch(e)
    {
    }
}

function getCalendar()
{
    var ProcessID="-1";
    var ProcessName="";
    var WorkstepID="-1";
    var WorkstepName="";
    var iCount=0;
    var Url="/webdesktop/components/calender/calendardisplay.app";
    Url = appendUrlSession(Url);    
    var listParam=new Array();
    var strSelectedTab=document.getElementById("changeworkingtime:SelTab").value;
    if(strSelectedTab=="processTab")
    {
        try
        {
            for(iCount=0;;iCount++)
            {
                var ctrlName= "changeworkingtime:process:" + iCount +":chkBoxProcess";
                if((document.getElementById(ctrlName)).checked==true)
                {
                   //changeworkingtime:process:0:processName
                    ctrlName="changeworkingtime:process:" + iCount +":processId";
                    ProcessID=(document.getElementById(ctrlName)).value;
                    ctrlName="changeworkingtime:process:" + iCount +":processName";
                    ProcessName=(document.getElementById(ctrlName)).value;
                    break;
                }
            }
        }
        catch(ex)
        {
            fieldValidator(null, NO_PROCESS_SELECTED, "absolute", true);
            //alert(NO_PROCESS_SELECTED);
            return;
        }

        listParam.push(new Array("Action",encode_ParamValue("1")));
        listParam.push(new Array("Launch",encode_ParamValue("1")));
        listParam.push(new Array("ProcessID",encode_ParamValue(ProcessID)));
        listParam.push(new Array("ProcessName",encode_ParamValue(ProcessName)));
        listParam.push(new Array("ListType",encode_ParamValue("B")));
    }
    else
    {
        try
        {
            ProcessID=(document.getElementById("changeworkingtime:hidSelectedProcessId")).value;
            ProcessName=(document.getElementById("changeworkingtime:hidSelectedProcessName")).value;
            if(ProcessID=="")
            {
                fieldValidator("changeworkingtime:txtProcessName", NO_PROCESS_SELECTED, "absolute", true);
                //alert(NO_PROCESS_SELECTED);
                return;
            }
        }
        catch(ex) {}
        try
        {
            for(iCount=0;;iCount++)
            {
               
                ctrlName= "changeworkingtime:activityInfo:" + iCount +":chkBox";
                if((document.getElementById(ctrlName)).checked==true)
                {
                    ctrlName="changeworkingtime:activityInfo:" + iCount +":actvityId";
                    WorkstepID=(document.getElementById(ctrlName)).value;
                    ctrlName="changeworkingtime:activityInfo:" + iCount +":acticityName";
                    WorkstepName=(document.getElementById(ctrlName)).value;
                    break;
                }
            }
        }
        catch(ex)
        {
            fieldValidator(null, NO_ACTIVITY_SELECTED, "absolute", true);
            //alert(NO_ACTIVITY_SELECTED);
            return;
        }
    
        listParam.push(new Array("Action",encode_ParamValue("2")));
        listParam.push(new Array("Launch",encode_ParamValue("1")));
        listParam.push(new Array("ProcessID",encode_ParamValue(ProcessID)));
        listParam.push(new Array("ProcessName",encode_ParamValue(ProcessName)));
        listParam.push(new Array("ListType",encode_ParamValue("B")));
        listParam.push(new Array("WorkstepID",encode_ParamValue(WorkstepID)));
        listParam.push(new Array("WorkstepName",encode_ParamValue(WorkstepName)));
    }
    var ScreenWidth=screen.width;
    var WindowHeight=window1H-20;
    var WindowWidth=window1W-100;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;
    var win = openNewWindow(Url,"getcalendar",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function updateQueue(ref)
{
    RefreshLink=ref;
    var QueueID="-1";
    var iCount=0;
    var pendingActions="";
    var queueName = "";
    var rightString=""
    try
    {
        for(iCount=0;;iCount++)
        {
            var ctrlName= "QueueListForm:queueLists:" + iCount +":chkBoxQueue";
            var ctrlName2 ="QueueListForm:queueLists:" + iCount +":queueType";
            
            if((document.getElementById(ctrlName)).checked==true)
            {
                rightString=document.getElementById("QueueListForm:queueLists:" + iCount +":hidUserRightString").value;
                if(document.getElementById(ctrlName2).value=="I")
                {
                
                }
                ctrlName="QueueListForm:queueLists:" + iCount +":queueID";
                QueueID=(document.getElementById(ctrlName)).value;                
                queueName = document.getElementById("QueueListForm:queueLists:" + iCount +":queueName").value                
                  try
                  {
                  pendingActions=document.getElementById("QueueListForm:queueLists:"+ iCount +":PendingActions").value;
                  }
                  catch(ex)
                  {}
                   
                break;
            }
        }
    }
    catch(ex)
    {
        customAlert(NO_QUEUE_SELECTED);
        return;
    }   
    var Url="/webdesktop/components/queue/queuemgmt.app";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window6H+90;
    var WindowWidth=window6W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2) - 15;
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;
    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("Mode",encode_ParamValue("2")));
    listParam.push(new Array("showTab",encode_ParamValue("1")));
    listParam.push(new Array("QueueID",encode_ParamValue(QueueID)));
    listParam.push(new Array("QueueName",encode_utf8(queueName)));
    listParam.push(new Array("PendingActions",encode_ParamValue(pendingActions)));
    listParam.push(new Array("RightString",encode_ParamValue(rightString)));
        
    var win = openNewWindow(Url,"changequeue"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}
//this,#{queue.m_bShowQProperty},#{queue.m_bShowQUserProp},#{queue.m_bShowQActivityProp},#{queue.m_bShowQDelete}
function selectOnechkBoxClick(nodeChkBox,showQProperty,showQUserProp,showQActivityProp,showQDelete)
{
    var iCount;
    var index = nodeChkBox.id.lastIndexOf(':');
    var arr=nodeChkBox.id.split(":");
    var iArrLength = arr.length ;
    var strName="";
    for (var count=0; count < arr.length-2 ; count++ )
    {
        if(count==0)
            strName = arr[count] ;
        else
        {
            strName=strName + ":" + arr[count] ;
        }
    }
    var btnUpdate=document.getElementById("QueueListForm:BtnUpdate");
    var btndisUpdate=document.getElementById("QueueListForm:BtndisUpdate");
    var btnDelete=document.getElementById("QueueListForm:BtnDelete");
    var btndisDelete=document.getElementById("QueueListForm:BtndisDelete");
    
    
    
    var btnMoreUpdate=document.getElementById("QueueListForm:panel:BtnMoreUpdate");
    var btnMoredisUpdate=document.getElementById("QueueListForm:panel:BtnMoredisUpdate");
        
    var btnMoreDelete=document.getElementById("QueueListForm:panel:BtnMoreDelte");
    var btnMoreDisDelete=document.getElementById("QueueListForm:panel:BtnMoredisDelete");
    
    var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length;
    if(nodeChkBox.checked == true)
    {
        for(iCount = 0; iCount < rowCount;iCount++)
        {

            if(iCount != arr[iArrLength-2])
            {
                var el=document.getElementById(strName+":"+iCount +":"+arr[iArrLength-1]);
                if(el!=undefined) //Ref BugId-61913
                el.checked=false;
            }
        }
        
        if(showQProperty=="false" && showQUserProp=="false" && showQActivityProp=="false"){
            if(btnUpdate!=null && btnUpdate!=undefined){
                btnUpdate.style.display="none";
                btndisUpdate.style.display="inline";
            }
           
        }else{
            if(btnUpdate!=null && btnUpdate!=undefined){
                btnUpdate.style.display="inline";
                btndisUpdate.style.display="none"; 
            }
            
        }
        if(showQDelete=="false"){
            if(btnDelete!=null && btnDelete!=undefined){
                btnDelete.style.display="none";
                btndisDelete.style.display="inline";
            }
            
        }else{
            if(btnDelete!=null && btnDelete!=undefined){
                btnDelete.style.display="inline";
                btndisDelete.style.display="none";
            }
           
        }
        
               
        if(btnMoreUpdate!=null){
            if(showQProperty=="false" && showQUserProp=="false" && showQActivityProp=="false"){
                btnMoreUpdate.style.display="none";
                btnMoredisUpdate.style.display="inline";
            }else{
                btnMoreUpdate.style.display="inline";
                btnMoredisUpdate.style.display="none";
            }
        }
        
        if(btnMoreDelete!=null){
            if(showQDelete=="false"){
                btnMoreDelete.style.display="none";
                btnMoreDisDelete.style.display="inline";
            }else{
                btnMoreDelete.style.display="inline";
                btnMoreDisDelete.style.display="none";
            }
            
        }
    }else{
        if(btnUpdate!=null && btnUpdate!=undefined && btndisUpdate!=null && btndisUpdate!=undefined){
             btnUpdate.style.display="none";
        btndisUpdate.style.display="inline";
        }
       
        if(btnDelete!=null && btnDelete!=undefined && btndisDelete!=null && btndisDelete!=undefined){
            btnDelete.style.display="none";
        btndisDelete.style.display="inline"; 
        }

       
           
        if(btnMoreUpdate!=null){
            btnMoreUpdate.style.display="none";
            btnMoredisUpdate.style.display="inline";
        }
        if(btnMoreDelete!=null){
            btnMoreDelete.style.display="none";
            btnMoreDisDelete.style.display="inline";
        }
    }
}

function quciksearch()
{
    var Url="../search/quickSearch.app?Action=1&Opt=11&WD_SID="+WD_SID;
    makeAjaxCallWrapper(Url,"ResultContainer","quicksearchresult","refreshQSVList()");
           
}


function appendTagAndValue(tagName,tagValue)
{
    var tagAndValue="";
    if(tagValue != "")
        tagAndValue = "<" + tagName + ">" + tagValue + "</" + tagName + ">";
    return tagAndValue;
}
            
function appendTagOnly(tagName,flag)
{
    var Tag="";
    if(flag==true)
        Tag="<" + tagName + ">";
    else if(flag==false)
        Tag="</" + tagName + ">";
    return Tag;
}
             
function changeProcessState()
{
    var item=document.getElementById("modifyProcState:btnCnfChangeState");
    var formID=item.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var selectedProcessXML="";
    try
    {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;
        var processIDId;
        var processStateId;
        for (var iCount=0;iCount < rowCount ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":procId";
            processStateId=tableID+":" + iCount +":procState";
            try
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    var processID=document.getElementById(processIDId).value;
                    var processState=document.getElementById(processStateId).value;
                    if(noOfSelectedRows==1)
                    {
                        selectedProcessXML=appendTagOnly(PROCESSLIST,true);
                    }
                    selectedProcessXML += appendTagOnly(PROCESSINFO,true);
                    selectedProcessXML += appendTagAndValue(ID,processID);
                    selectedProcessXML += appendTagAndValue(STATE,processState)
                    selectedProcessXML += appendTagOnly(PROCESSINFO,false);
                }

            }
            catch(e)
            {
                //alert("Error in=="+iCount);
            }
        }
    }
    catch(e)
    {
        //alert("Error in=="+iCount);
    }
    if(noOfSelectedRows>0)
    {
        selectedProcessXML += appendTagOnly(PROCESSLIST,false);
        document.getElementById(formID+":hid_ProcessListXML").value=selectedProcessXML;
        NewSubmit(item);
    }
    else
    {
        document.getElementById(formID+":hid_ProcessListXML").value="";
        //   alert(INVALID_SELECTION_MORE);   //Bug Id 7191
        return false;
    }
    return false;
}
/**************************************************change password*********************************/

function chkPassword()
{
    var txtOldP=document.getElementById("ChangePassword:txtOldPassword");
    var txtP=document.getElementById("ChangePassword:txtPassword");
    var txtConP=document.getElementById("ChangePassword:txtConfirmPassword");

    if(Trim(txtOldP.value)=="")
    {
        customAlert(EMPTY_PASSWORD_NOT_ALLOWED);
        txtOldP.focus();
        return false;
    }
    if(Trim(txtP.value)=="")
    {
        customAlert(EMPTY_PASSWORD_NOT_ALLOWED);
        txtP.focus();
        return false;
    }
    if(Trim(txtConP.value)=="")
    {
        customAlert(EMPTY_PASSWORD_NOT_ALLOWED);
        txtConP.focus();
        return false;
    }
    if(txtOldP.value!="")
    {
        if(((Trim(txtOldP.value)) != txtOldP.value) && (txtOldP.value.length != 0))
        {
            customAlert(NO_SPACE_IN_PASSWORD);
            txtOldP.select();
            txtOldP.focus();
            return false;
        }
    }
    if(txtP.value!="" ||txtConP.value!="")
    {
        /*  if((Trim(txtP.value)).indexOf('#') != -1 || (Trim(txtP.value)).indexOf(',') != -1 || (Trim(txtP.value)).indexOf('<') != -1 || (Trim(txtP.value)).indexOf('>') != -1)
            {
                alert(NO_SYMBOL_CHAR_IN_PASSWORD);
                txtP.focus();
                return false;
            }
            if((Trim(txtConP.value)).indexOf('#') != -1 || (Trim(txtConP.value)).indexOf(',') != -1 || (Trim(txtConP.value)).indexOf('<') != -1 || (Trim(txtConP.value)).indexOf('>') != -1)
            {
                alert(NO_SYMBOL_CHAR_IN_PASSWORD);
                txtConP.focus();
                return false;
            }
            */
        if( ((Trim(txtP.value)) != txtP.value) && (txtP.value.length != 0))
        {
            customAlert(NO_SPACE_IN_PASSWORD);
            txtP.select();
            txtP.focus();
            return false;
        }
        if( ((Trim(txtConP.value)) != txtConP.value) && (txtConP.value.length != 0))
        {
            customAlert(NO_SPACE_IN_PASSWORD);
            txtConP.select();
            txtConP.focus();
            return false;
        }
        else if (ConformPassword(Trim(txtP.value),Trim(txtConP.value)) == '1')
        {
            customAlert(NO_MATCH_PASSWD_CONFIRMPASSWD);
            txtConP.select();
            txtConP.focus();
            return false;
        }
    }
    return true;
}

function ConformPassword(var1,var2)
{
    if (var1.toLowerCase() != var2.toLowerCase())
        return 1;
    else
        return 0;
}

/***********************************************************************************************/            

/****************************************************Process variable mapping********************/

function checkData()
{
    //set the selected var name

    var varName = document.getElementById("frmProcVarMapping:selectedVarName").value;
    var variableType=document.getElementById("frmProcVarMapping:selectedVarType").value;
    document.getElementById("frmProcVarMapping:selectedVarName").value = Trim(varName);
    document.getElementById("frmProcVarMapping:hidChkDisplay").value = document.getElementById("frmProcVarMapping:chkDisplay").checked;
    document.getElementById("frmProcVarMapping:hidChkSorting").value = document.getElementById("frmProcVarMapping:chkSorting").checked;
    document.getElementById("frmProcVarMapping:hidChkSearching").value = document.getElementById("frmProcVarMapping:chkSearching").checked;
    /*var objCombo = document.getElementById("frmProcVarMapping:opVar");

    var selIndex = document.getElementById("frmProcVarMapping:opVar").selectedIndex;
    var varName = document.getElementById("frmProcVarMapping:opVar").options[selIndex].text;
    document.getElementById("frmProcVarMapping:selectedVarName").value = Trim(varName);*/
                
    //check if queue name is selected or not
                
    if(document.getElementById("frmProcVarMapping:hidQueueId").value == "-1" && document.getElementById("frmProcVarMapping:hidQueueName").value == "")
    {
        fieldValidator("frmProcVarMapping:txtQueueName", NO_QUEUE_SELECTED, "absolute", true);
        //alert(NO_QUEUE_SELECTED);
        return false;
    }

    if(varName=="")
    {
        fieldValidator("frmProcVarMapping:txtVariableName", NO_VARIABLE_SELECTED, "absolute", true);
        //alert("No Variable is Selected");
        return false;
    }
    //check for blank name and other conditions
                
    var aliasBox = document.getElementById("frmProcVarMapping:txtAliasName");
    if(aliasBox.value == "")
    {
        fieldValidator("frmProcVarMapping:txtAliasName", ALIAS_NO_SPECIFY_VALUE, "absolute", true);
        //alert(ALIAS_NO_SPECIFY_VALUE);
        //aliasBox.focus();
        return false;
    }
    else
    {
        //check for invalid characters in name
                    
        var tempVal = isInvalid(aliasBox.value);
        if (tempVal =='3')
        {
            fieldValidator("frmProcVarMapping:txtAliasName", ALIAS_NO_SYMBOL_CHAR, "absolute", true);
            //alert(ALIAS_NO_SYMBOL_CHAR);
            //aliasBox.focus();
            return false;
        }
        else if (tempVal=='1')
        {
            fieldValidator("frmProcVarMapping:txtAliasName", ALIAS_NO_SPACE_CHAR, "absolute", true);
            //alert(ALIAS_NO_SPACE_CHAR);
           // aliasBox.focus();
            return false;
        }
                    
        //check for numeric value in name
                    
        if(!isNaN(Trim(aliasBox.value)))
        {
            fieldValidator("frmProcVarMapping:txtAliasName", ALIAS_NO_NUMERICNAME, "absolute", true);
            //alert(ALIAS_NO_NUMERICNAME);
            //aliasBox.focus();
            return false;
        }
        else if(!isNaN(Trim(aliasBox.value).substring(0,1)))
        {
            fieldValidator("frmProcVarMapping:txtAliasName", ALIAS_NO_START_NUMERIC_CHAR, "absolute", true);
            //alert(ALIAS_NO_START_NUMERIC_CHAR);
            //aliasBox.focus();
            return false;
        }
                    
        //Check that alias name must not be same as system variable names bug id-3582

        try
        {
                var sysVarList = document.getElementById("frmProcVarMapping:hidSysVarList").value;
                    if (sysVarList != '') {
                    sysVarList = JSON.parse(sysVarList);
                        var sysVarValue = sysVarList[Trim(aliasBox.value).toUpperCase()];
                        if (sysVarValue != undefined && sysVarValue == 'Y') {
                            fieldValidator("frmProcVarMapping:txtAliasName", ALIAS_NAME_NOT_AS_SYSTEM_VARIABLE_NAME, "absolute", true);
                            return false;
                }
            }
        }
        catch(e)
        {
        }

        //check for same alias name
        var rowCount = 0;
        try
        {
            rowCount = document.getElementById("frmProcVarMapping:dtVarList").tBodies[0].rows.length;
        }catch(ex)
        {
            rowCount =0;
        }
        if(rowCount > 0)
        {
                        
            for(var iCount = 0 ; iCount < rowCount ; iCount++)
            {
                            
                if(Trim(document.getElementById("frmProcVarMapping:dtVarList:"+iCount+":aliasname").innerHTML).toUpperCase() == Trim(aliasBox.value).toUpperCase())
                {
                    fieldValidator("frmProcVarMapping:txtAliasName", ALIAS_NAME_ALREADY_EXIST, "absolute", true);
                    //alert(ALIAS_NAME_ALREADY_EXIST);
                    if(aliasBox.disabled == false)
                        aliasBox.focus();
                    return false;
                }
                //check if alias exsit for the variable
                if(Trim(document.getElementById("frmProcVarMapping:dtVarList:"+iCount+":varname").innerHTML).toUpperCase() == Trim(varName).toUpperCase())
                {
                    fieldValidator("frmProcVarMapping:txtAliasName", ALIAS_EXIST_FOR_VARIABLE, "absolute", true);
                    //alert(ALIAS_EXIST_FOR_VARIABLE);
                    //aliasBox.focus();
                    return false;
                }
            }
        }
 
    }
    //var variableType=objCombo.value;
    if(typeof document.getElementById("frmProcVarMapping:rulelist")!='undefined' && document.getElementById("frmProcVarMapping:rulelist")!=null){
    if(variableType!="8"){
        var compareValue="";
        var compareValue1="";
        for(j=0;j<5;j++){
            compareValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value;
            compareValue1=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value;
            if(variableType!=10){
                if(validateAllTypeData(compareValue,variableType))
                {
                                  
                }
                else
                {
                    customAlert(VALUE_IS_NOT_VALID);
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").focus();
                    return false;
                }
            }
            if(variableType!=10){
                if(validateAllTypeData(compareValue1,variableType))
                {
                                  
                }
                else
                {
                    customAlert(VALUE_IS_NOT_VALID);
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").focus();
                    return false;
                }
            }
                        
        }
    }
    //Bug 58796 starts
    if(variableType == "8") {
                    var ruleTempVar = "";
                    var ruleTempVar1 = "";
                    var ruleSelected;
                    for(j = 0; j < 5; j++) {
                        ruleSelected = document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").checked;
                        if(ruleSelected) {
                            ruleTempVar = document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").value;
                            ruleTempVar1 = document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").value;
                            if(validateAllTypeData(ruleTempVar, "3")) {
                                if(trimByRegularEx(ruleTempVar) != "") {
                                    if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").value) == "") {
                                        customAlert(VALUE_IS_NOT_VALID);
                                        document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").focus();
                                        return false;
                                    }
                                    if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").value) == "") {
                                        customAlert(VALUE_IS_NOT_VALID);
                                        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").focus();
                                        return false;
                                    }
                                }
                            } else {
                                customAlert(VALUE_IS_NOT_VALID);
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").select();
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").focus();
                                return false;
                            }
                            if(validateAllTypeData(ruleTempVar1, "3")) {
                                if(trimByRegularEx(ruleTempVar1) != "") {
                                    if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").value) == "") {
                                        customAlert(VALUE_IS_NOT_VALID);
                                        document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").focus();
                                        return false;
                                    }
                                    if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").value) == "") {
                                        customAlert(VALUE_IS_NOT_VALID);
                                        document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").focus();
                                        return false;
                                    }
                                    if(trimByRegularEx(document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").value) == "") {
                                        customAlert(VALUE_IS_NOT_VALID);
                                        document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").focus();
                                        return false;
                                    }
                                }
                            } else {
                                customAlert(VALUE_IS_NOT_VALID);
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").select();
                                document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").focus();
                                return false;
                            }
                        }
                    }
                }//Bug 58796 ends
            }
    return true;
}
            
function Verify(ctrl)
{
    var rowCount =0;
    try
    {
        rowCount = document.getElementById("frmProcVarMapping:dtVarList").tBodies[0].rows.length;
    }catch(ex)
    {
        rowCount = 0;
    }
    var flag = false;
    var iCount = 0 ;
    if(rowCount > 0)
    {
                        
        for(iCount = 0 ; iCount < rowCount ; iCount++)
        {
            if(document.getElementById("frmProcVarMapping:dtVarList:"+iCount+":chkUser").checked == true)
            {
                flag =true;
                break;
            }
        }
    }

    if(flag == true)
    {
        document.getElementById("frmProcVarMapping:selectedRow").value = iCount;
    }
    else
    {
        fieldValidator(null, MSG_SELECT_AN_ALIAS, "absolute", true);
        //alert(MSG_SELECT_AN_ALIAS);
        return false;
    }
    if((ctrl == 'UP') && (iCount == 0))
        return false;
    if((ctrl == 'DOWN') && (iCount ==(rowCount-1)))
        return false;
                    
    return true;
}

function callbackfunction(data){
    var scrollDiv= document.getElementById("contentDiv");
    if(data.status=='begin'){
        scrollTopVal=scrollDiv.scrollTop;
        setPopupMask();
        CreateIndicator("ProcVarMapping");
    }
    if(data.status=="success"){
         scrollDiv.scrollTop=scrollTopVal;
         checkBoxSelect();
         hideShowRuleList();
         hidePopupMask();
         RemoveIndicator("ProcVarMapping");
    }
       
}


function checkBoxSelect()
{
    //document.getElementById("aliaslistDiv").style.height = (window.screen.height - 640);
    var selectedVarType= document.getElementById("frmProcVarMapping:selectedVarType").value;
    var selectedVarName= document.getElementById("frmProcVarMapping:selectedVarName").value;
    //alert(selectedVarType);
    if(typeof document.getElementById("frmProcVarMapping:rulelist")!='undefined' && document.getElementById("frmProcVarMapping:rulelist")!=null){
    if(selectedVarType==""){
        var radioIndex;
        if(isCompatibleForRadioCheck())
            radioIndex=1;
        else
            radioIndex=0;
        for(j=0;j<5;j++){
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar").value="";
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value="";
            document.getElementsByName("frmProcVarMapping:rulelist:"+j+":radioCI")[radioIndex].checked="true";
            document.getElementById("frmProcVarMapping:rulelist:"+j+":bgcolortxtbox").style.backgroundColor="#FFFFFF";
            document.getElementById("frmProcVarMapping:rulelist:"+j+":selImage").src="/webdesktop/resources/aliasimages/transparent.gif";
            document.getElementById("frmProcVarMapping:rulelist:"+j+":hidbgcolortxtbox").value="";
            document.getElementById("frmProcVarMapping:rulelist:"+j+":rlueButton").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").checked=false;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar1").value="";
        }
    }
    if(document.getElementById("frmProcVarMapping:selectedVarName")){
        var strSelectedText=document.getElementById("frmProcVarMapping:selectedVarName").value;
        document.getElementById("frmProcVarMapping:txtVariableName").value=strSelectedText;
        if(strSelectedText!=""){
            operatorCombo(document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator"));
            operatorCombo(document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1"));
            for(j=1;j<5;j++)
            {
                operatorCombo(document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator"));
                operatorCombo(document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1"));
            }
            if(selectedVarType=='8'){
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue").value=REPORT_TODAY;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").value=REPORT_TODAY;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").disabled=true;
                        for(j=1;j<5;j++){
                            //document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value=REPORT_TODAY;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value=REPORT_TODAY;
                        }
                    }
                    else if(selectedVarType=='10'){
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").disabled=false;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").disabled=false;
                        //document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").disabled=true;
                        //document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":chkAliasRule").disabled=false;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").disabled=true; //Bug 58796
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").disabled=true;
                        for(j=1;j<5;j++){
//                            document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator").disabled=true;
//                            document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=false;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").disabled=true;//Bug 58796
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").disabled=true;
                        }
                    }
                    else{
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").disabled=true;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":chkAliasRule").disabled=false;
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").disabled=true;//Bug 58796
                        document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").disabled=true;
                        for(j=1;j<5;j++){
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=false;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").disabled=true;
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").disabled=true;//Bug 58796
                            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").disabled=true;
                        }
                    }
                    //document.getElementById("frmProcVarMapping:opVar").disabled=true;
                    document.getElementById("frmProcVarMapping:txtVariableName").disabled=true;
                    document.getElementById("frmProcVarMapping:txtAliasName").disabled=true;
                    if(document.getElementById("frmProcVarMapping:hidQueueType").value=='G'){
                        document.getElementById("frmProcVarMapping:cmdNewGlobal").style.display="block";
                        document.getElementById("frmProcVarMapping:cmdAddGlobal").style.display="none";
                    } else {
                        document.getElementById("frmProcVarMapping:cmdNew").style.display="block"; //Bug 69233
                        document.getElementById("frmProcVarMapping:cmdAdd").style.display="none";
                    }
                }
            
        }
        for(i=0;i<5;i++){
            document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar").readOnly=true;
            document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar1").readOnly=true;
             document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar").title=selectedVarName;
            document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar1").title=selectedVarName;
            document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar").className = "wdinputtextstyledisabled";
            document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar1").className="wdinputtextstyledisabled";
        }
    }
    var rowCount =0;
    try
    {
        rowCount = document.getElementById("frmProcVarMapping:dtVarList").tBodies[0].rows.length;
    }catch(ex)
    {
        rowCount =0;
    }
    var selRow = document.getElementById("frmProcVarMapping:selectedRow").value;
                
    if(rowCount > 0)
    {
        if(selRow > -1)
        {
            document.getElementById("frmProcVarMapping:dtVarList:"+selRow+":chkUser").checked = true;
        }
    }
    if(document.getElementById("frmProcVarMapping:hidQueueId").value=="0"){
        document.getElementById("frmProcVarMapping:pgProcessName").style.display="inline-table";
    }
    else{
        document.getElementById("frmProcVarMapping:pgProcessName").style.display="none";
        document.getElementById("frmProcVarMapping:hidProcessName").value="";
        document.getElementById("frmProcVarMapping:hidProcessId").value="-1";
    }
}

function hideShowRuleList() {
    var selectedQType = document.getElementById("frmProcVarMapping:hidQueueType").value;
    if(selectedQType!="" && selectedQType=="G"){
        document.getElementById("frmProcVarMapping:rulelist").style.display="none";
        document.getElementById("frmProcVarMapping:ruledeflabel").style.display="none";
        document.getElementById("otheroptionsdiv").style.display="none";
        document.getElementById("frmProcVarMapping:cmdAddModifyGlobal").style.display="";
    }
}
function submitForm()
{
    ClickAnotherLink('','cmdlink_Go');
}

function procVarQSelect()
{
    try{

     if(window.parent.document.getElementById("frmProcVarMapping:hidProcessName")){
        window.parent.document.getElementById("frmProcVarMapping:hidProcessName").value="";
        window.parent.document.getElementById("frmProcVarMapping:hidProcessName").value="";
        window.parent.document.getElementById("frmProcVarMapping:hidProcessId").value="-1";
    }
    if(window.parent.document.getElementById("frmProcVarMapping:rulelist"))
    {
        for(j=0;j<5;j++){
             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").value="";
             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue").value="";
             window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value="";
              window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").selectedIndex=0;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").selectedIndex=0;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator").selectedIndex=0;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1").selectedIndex=0;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=false;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").selectedIndex=0;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").selectedIndex=0;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").value="";
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").value="";
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").selectedIndex=0;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").selectedIndex=0;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").value="";
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").value="";
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleVar1").value="";
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar1").value="";
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").selectedIndex=0;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":logicalOperator").selectedIndex=0;
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").value="";//Bug 58796
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").value="";
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").value="";
                 window.parent.document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").value="";
        }
    }

    }catch(ex)
    {}
    submitForm();
}



function checkQueue()
{
    if(document.getElementById("frmProcVarMapping:hidQueueId").value == "-1" && document.getElementById("frmProcVarMapping:hidQueueName").value == "")
    {
        customAlert(NO_QUEUE_SELECTED);
        return false;
    }

    //var objCombo = document.getElementById("frmProcVarMapping:opVar");
    //var variableType=objCombo.value;
    var variableType=document.getElementById("frmProcVarMapping:selectedVarType").value;
    if(variableType!="8"){
        var compareValue="";
        if(typeof document.getElementById("frmProcVarMapping:rulelist")!='undefined' && document.getElementById("frmProcVarMapping:rulelist")!=null){
        for(j=0;j<5;j++){
            compareValue=document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value;
            if(variableType!=10){
                if(validateAllTypeData(compareValue,variableType))
                {
                                  
                }
                else
                {
                    customAlert(VALUE_IS_NOT_VALID);
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").select();
                    document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").focus();
                    return false;
                }
            }
                        
        }
        }
    }
    return true;
}
            
function setProcVarMapping()
{
    try
    {
        clickLink('frmProcVarMapping:btnSetMapping');
    }catch(e){}
    return false;
}
            
function setAuditLogConfig()
{
    try
    {
        clickLink('auditconfig11:btnSetConfig');
    }catch(e){}
    return false;
}
            
function saveQuickSearchVars()
{
    try
    {
        clickLink('quicksearch:btnSaveQSV');
    }catch(e){}
    return false;
}            
                   
/*********************************************for Calender*********************************************************/

function SelectTabCalender(iTabIndex)
{
    try
    {
        document.getElementById("changeworkingtime:SelTab").value=iTabIndex;
    }
    catch(e){
    }

    if(iTabIndex==1)
    {
        document.getElementById("changeworkingtime:hidProcessName").value="";
        document.getElementById("changeworkingtime:hidProcessId").value="";
        clickLink('changeworkingtime:cmdlink_GoProcess');
    }
    if(iTabIndex==2)
    {
        var ProcessID="-1";
        var ProcessName="";
        var iCount=0;
        try
        {
            for(iCount=0;;iCount++)
            {
                var ctrlName= "changeworkingtime:sv1:processlist:" + iCount +":chkBoxProcess";
                if((document.getElementById(ctrlName)).checked==true)
                {
                    ctrlName="changeworkingtime:sv1:processlist:" + iCount +":processId";
                    ProcessID=(document.getElementById(ctrlName)).value;
                    ctrlName="changeworkingtime:sv1:processlist:" + iCount +":processName";
                    ProcessName=(document.getElementById(ctrlName)).value;
                    document.getElementById("changeworkingtime:hidProcessId").value=ProcessID;
                    document.getElementById("changeworkingtime:hidProcessName").value=ProcessName;
                    clickLink('changeworkingtime:cmdlink_Go');
                    break;
                }
            }
        }

        catch(ex)
        {
            clickLink('changeworkingtime:cmdlink_TempForRefresh');
        }
    }
}

function getWorkstepforprocess()
{
    clickLink('changeworkingtime:cmdlink_Go');
}
        
function getWorkstepforfilter()
{
    if((Trim(document.getElementById("changeworkingtime:hidProcessId").value)).length>0)
    {
        clickLink('changeworkingtime:cmdlink_Go');
    }
}
/*********************************************for Calender end*********************************************************/            
/*********************************************for AUDITlOG CONFIGURATION*********************************************************/  
function submit()
{
    ClickAnotherLink('','cmdlink_Go');
}
            
            
function chkSelected(listType)
{
                    
					
    var len;
    var name;
    var id;
    var selValue="";
    if(listType == TS_ENABLEITEM)
    {
        //selValue=document.getElementById("auditconfig11:availableItems").value;
							
        len=document.getElementById("auditconfig11:availableItems").length;
        for(i=0;i<len;i++)
        {

            if(document.getElementById("auditconfig11:availableItems").options[i].selected)
            {
									
                name=document.getElementById("auditconfig11:availableItems").options[i].text;
                id=document.getElementById("auditconfig11:availableItems").options[i].value;
                if(i==len-1)
                    selValue+=name;
                else
                    selValue+=name+",";
                           
            }
        }

    }
    else if(listType == TS_DISABLEITEM)
    {
        //selValue=document.getElementById("auditconfig11:selectedItems").value;
        len=document.getElementById("auditconfig11:selectedItems").length;
        for(i=0;i<len;i++)
        {

            if(document.getElementById("auditconfig11:selectedItems").options[i].selected)
            {

                name=document.getElementById("auditconfig11:selectedItems").options[i].text;
                id=document.getElementById("auditconfig11:selectedItems").options[i].value;
                if(i==len-1)
                    selValue+=name;
                else
                    selValue+=name+",";

            }
        }
                            
    }
    if(selValue =="")
    {
        customAlert(SELECT_AN_ITEM_FROM_THE_LIST);
        return false;
    }
    else
    {
        document.getElementById("selectedValue").value = selValue;
							
        return true;

    }
}
        
function chkSelectedattribute(listType)
{
                   
    var selValue="";
    var len;
    var name;
    var id;
    var selValue="";
    if(listType == TS_ENABLEATTRIBUTE)
    {
        len=document.getElementById("auditconfig11:disableItems2").length;
        for(i=0;i<len;i++)
        {

            if(document.getElementById("auditconfig11:disableItems2").options[i].selected)
            {

                name=document.getElementById("auditconfig11:disableItems2").options[i].text;
                id=document.getElementById("auditconfig11:disableItems2").options[i].value;
                if(i==len-1)
                    selValue+=name;
                else
                    selValue+=name+",";
            //selValue=document.getElementById("auditconfig11:disableItems2").value;
            }
        }
    }
    else if(listType == TS_DISABLATTRIBUTE)
    {
        //selValue=document.getElementById("auditconfig11:selectedItems2").value;
        len=document.getElementById("auditconfig11:selectedItems2").length;
        for(i=0;i<len;i++)
        {

            if(document.getElementById("auditconfig11:selectedItems2").options[i].selected)
            {

                name=document.getElementById("auditconfig11:selectedItems2").options[i].text;
                id=document.getElementById("auditconfig11:selectedItems2").options[i].value;
                if(i==len-1)
                    selValue+=name;
                else
                    selValue+=name+",";

            }
        }
    }
                    
    if(selValue =="")
    {
        customAlert(SELECT_AN_ITEM_FROM_THE_LIST);
        return false;
    }
    else
    {
        document.getElementById("selectedAttribute").value = selValue;
        return true;
    }
}
	
function handleEnter(e)
{       
    var browser=navigator.appName;
    if(browser=="Netscape")
    {

        if(e.which == 13)
        {

            try
            {
                document.getElementById('auditconfig11:cmdRef').focus();
            }
            catch(e){
            }

        }
    }

    else
    {
        e=window.event;
        if(e.keyCode == 13)
        {
            try
            {
                document.getElementById('auditconfig11:cmdRef').focus();
            }
            catch(e){
            }
        }

    }
}
function newfunc()
{
			
//document.forms["auditconfig11"].submit();
}        

function submitforquicksearch()
            {
              
               EnableDisableProcVarListButton("quicksearchmgmt");
               document.getElementById("quicksearchmgmt:txtProcessVarName").value = "";
               document.getElementById("quicksearchmgmt:hidProcVarName").value = "";
               
            }
            function ShowProcVarList(ref,hidProcessName,hidProcessId,txtProcessVarName,hidProcVartype,hidProcVarName)
                        {
                            
                        var formid=ref.form.id;
                        var procID= document.getElementById(formid+":"+hidProcessId).value;
                        var procName= document.getElementById(formid+":"+hidProcessName).value;
                        ShowPickList(ref,'WFProcVariablelist',txtProcessVarName,hidProcVartype,hidProcVarName,'0','-1','0','',procID,procName);

                   }

            function ShowVariableList(ref,hidProcessName,hidProcessId,txtProcessVarName,hidProcVartype,hidProcVarName,Extra,Extra1,Extra2,hidProcVarID,showLocalizedName)
            {
                        var formid=ref.form.id;                        
                        var procID="";
                        var procName="";
                        if(hidProcessId!=undefined && hidProcessId!="")
                            procID= document.getElementById(formid+":"+hidProcessId).value;

                        if(hidProcessName!=undefined && hidProcessName!=""){
                            procName = document.getElementById(formid+":"+hidProcessName).value;                            
                        }                        
                        
                        //" " special character allowed.
                        /*if(formid == "QueueMgmtForm"){
                            procName = procName.substring(0, procName.indexOf(" ", 0));
                        }*/
                
                        // spliting process name from version process string
                        procName = procName.split('_V')[0];
                        
                        procName= encode_utf8(procName);   
                        
                        //alert(procName)
                        //  ShowPickList(ref,'VariableList',txtProcessVarName,hidProcVartype,hidProcVarName,'window','0','-1','0','',procID,procName);
                    //    function ShowPickList(reference,type,nameCtrl,iDCtrl,hidNameCtrl,flag,NoneType,NoneID,ReturnNoneText,FunctionName,Extra1,Extra2,Extra3,Extra4,Extra5,parentFlag,EmailIdCntrl,OpenedFor)
                        ShowVariablePickList(ref,txtProcessVarName,hidProcVartype,encode_utf8(hidProcVarName),procID,procName,Extra2,Extra,Extra1,hidProcVarID,showLocalizedName);
            }

            function EnableDisableProcVarListButton(formId)
            {
                if(document.getElementById(formId+":hidProcessId").value > 0 )
                {
                    document.getElementById(formId+":cmdPicklist_ProcessVar").disabled=false;
                }
                else
                {
                    document.getElementById(formId+":cmdPicklist_ProcessVar").disabled=true;
                 }
            }       
           
    function removeqsv(ref)
    {

    var formId=ref.form.id;
    tableID=formId+":"+"qsearch";
    chkboxName=":chkBoxQsv";
    var chkBoxID=tableID+":";
    var jCount=0;
    rowCount=document.getElementById(tableID).tBodies[0].rows.length ;
     for (var iCount=0;iCount < rowCount ;iCount++)
    {
       currentChkBoxID=chkBoxID + iCount +chkboxName ;
            try 
            {
                    if(document.getElementById(currentChkBoxID).checked)
                    {
                        jCount++;
                        document.getElementById("quicksearch:hiddeletedindex").value=iCount	
                        break;	
                     }

               }
            catch(e)
            {
                    //alert("Error in=="+iCount);
            }
            
    }

    if(jCount==0)
            {
                customAlert(SELECT_VARIABLE_TOREMOVE);
                return false;
            }
            return true;
    }
    function checkAdd(ref)
    {
      var txtVal=document.getElementById("quicksearch:txtProcessVarName").value;
      var txtaliasVal=document.getElementById("quicksearch:txtProcessVaraliasName").value;
     if(Trim(txtVal).length==0)
	  {
		customAlert(SELECT_PROC_VAR);
		return false;
	  }
      if(Trim(txtaliasVal).length==0)
      {
        customAlert(ALIAS_NO_SPECIFY_VALUE);
		return false;
      }
    try 
        {
     rowCount=document.getElementById("quicksearch:qsearch").tBodies[0].rows.length ;
	 
     for (var iCount=0;iCount < rowCount ;iCount++)
    {
           var aliasTxtID="quicksearch:qsearch:"+iCount+":txtqsvalias";
		   
            try 
            {
                    if(Trim(document.getElementById(aliasTxtID).innerHTML)==Trim(txtaliasVal))
                    {
                        customAlert(ALIAS_NAME_ALREADY_EXIST);
                        return false;
                     }

               }
            catch(e)
            {
                    //alert("Error in=="+iCount);
            }
    }    
}
catch(e)
            {
}
      return true;
    }
	


function setUserPreferences(ref)
{
    var batchSize="";
    batchSize=document.getElementById("UserPref:BatchSize").value;

    if(isNaN(batchSize) || IsFloatVal(batchSize))
    {
        document.getElementById("UserPref:BatchSize").select();
        customAlert(VALID_INTEGER);
    }
    else
        NewSubmit(ref);

    return false;
} 

function EnableDisButtonProcessMgmt(ref)
{
       
    var formID=ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var EnableChangeStateButton="";
    var PendingActions="";
    
    //Right Based Enable Disable
    var enableDefineTAT=true;
    var enableDefineCons=true;
    var enableWebService=true;
    var enablePurgeCriteria=true;
    //Right Based Enable Disable
    
    
    //"hidChangeProcState"
    //"hidDefineTAT" 
    //"hidDefineCons" 
    //"hidWebService"
    
    
    
    
    try
    {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;

        for (var iCount=0;iCount < rowCount ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":procId";
            processNameId=tableID+":" + iCount +":procName";
            var PendingActionsID=tableID+":" + iCount +":hidPendingActions";
            try 
            {
                if(document.getElementById(currentChkBoxID).checked)
                {  
                    noOfSelectedRows++;
                    PendingActions=document.getElementById(PendingActionsID).value
                    if(PendingActions.length>0 && PendingActions!="null" && PendingActions=="21")
                    {
                       EnableChangeStateButton="0" 
                    }
                    else if(EnableChangeStateButton!="0")
                    {
                        EnableChangeStateButton="1";
                    }
                    enableDefineTAT=document.getElementById(tableID+":"+iCount+":hidDefineTAT").value;
                    enableDefineCons=document.getElementById(tableID+":"+iCount+":hidDefineCons").value;
                    enableWebService=document.getElementById(tableID+":"+iCount+":hidWebService").value;
                    enablePurgeCriteria=document.getElementById(tableID+":"+iCount+":hidPurgeCriteria").value;                 
                 }

             }
            catch(e){}
        }
        var cmddefineTAT=document.getElementById(formID+":cmdDefineturnaroundtime");
        var disCmddefineTAT=document.getElementById(formID+":disCmdDefineturnaroundtime");
        var cmddynamicConstants=document.getElementById(formID+":cmdDynamicConstants");
        var disCmddynamicConstants=document.getElementById(formID+":disCmdDynamicConstants");
        var cmdWeb=document.getElementById(formID+":cmdWeb");
        var disCmdWeb=document.getElementById(formID+":disCmdWeb");
        var cmdPurgeCriteria=document.getElementById(formID+":cmdPurgeCriteria");
        var disCmdPurgeCriteria=document.getElementById(formID+":disCmdPurgeCriteria");
        var cmdPrcConfTab=document.getElementById(formID+":cmdPrcConfTab");
        var disCmdPrcConfTab=document.getElementById(formID+":disCmdPrcConfTab");
        var cmdTaskPrefTab=document.getElementById(formID+":cmdTaskPrefTab");//Bug 74636
        var disCmdTaskPrefTab=document.getElementById(formID+":disCmdTaskPrefTab");//Bug 74636

        var cmddefineTATMore=document.getElementById(formID+":panel:cmdDefine");
        var disCmddefineTATMore=document.getElementById(formID+":panel:disCmdDefine");
        var cmddynamicConstantsMore=document.getElementById(formID+":panel:cmdDynamic");
        var disCmddynamicConstantsMore=document.getElementById(formID+":panel:disCmdDynamic");
        var cmdWebServicesMore=document.getElementById(formID+":panel:cmdWebServices");
        var disCmdWebServicesMore=document.getElementById(formID+":panel:disCmdWebServices");
        var cmdPurgeCriteriaMore=document.getElementById(formID+":panel:cmdPurgeCriteria");
        var disCmdPurgeCriteriaMore=document.getElementById(formID+":panel:disCmdPurgeCriteria");
        var cmdPrcConf=document.getElementById(formID+":panel:cmdPrcConf");
        var disCmdPrcConf=document.getElementById(formID+":panel:disCmdPrcConf");
        var cmdTaskPrefMore=document.getElementById(formID+":panel:cmdTaskPref");
        var disCmdTaskPrefMore=document.getElementById(formID+":panel:disCmdTaskPref");
        
        var cmdModifyActivity=document.getElementById(formID+":panel:cmdModifyActivity");
        var disCmdModifyActivity=document.getElementById(formID+":panel:disCmdModifyActivity");
        var cmdModifyActivityTab=document.getElementById(formID+":cmdModifyActivityTab");
        var disCmdModifyActivityTab=document.getElementById(formID+":disCmdModifyActivityTab");
        
        if(noOfSelectedRows == 1)
        {   
            if(cmddefineTAT!=null){
                if(enableDefineTAT=="true"){
                    cmddefineTAT.style.display="inline";
                    disCmddefineTAT.style.display="none";
                }else if(enableDefineTAT=="false"){
                    cmddefineTAT.style.display="none";
                    disCmddefineTAT.style.display="inline";
                }
                
            }
            if(cmddynamicConstants!=null){
                if(enableDefineCons=="true"){
                    cmddynamicConstants.style.display="inline";
                    disCmddynamicConstants.style.display="none";
                }else if(enableDefineCons=="false"){
                    cmddynamicConstants.style.display="none";
                    disCmddynamicConstants.style.display="inline";
                }
                
            }
            if(cmdWeb!=null){
                if(enableWebService=="true"){
                    cmdWeb.style.display="inline";
                    disCmdWeb.style.display="none";
                }else if(enableWebService=="false"){
                    cmdWeb.style.display="none";
                    disCmdWeb.style.display="inline";
                }
                
            }
            if(cmdPurgeCriteria!=null){
                if(enablePurgeCriteria=="true"){
                    cmdPurgeCriteria.style.display="inline";
                    disCmdPurgeCriteria.style.display="none";
                }else if(enablePurgeCriteria=="false"){
                    cmdPurgeCriteria.style.display="none";
                    disCmdPurgeCriteria.style.display="inline";
                }
                
            }
            // For enabling and disabling in the more options div
            if(cmddefineTATMore!=null){
                if(enableDefineTAT=="true"){
                    cmddefineTATMore.style.display="inline";
                    disCmddefineTATMore.style.display="none";
                }else if(enableDefineTAT=="false"){
                    cmddefineTAT.style.display="none";
                    disCmddefineTAT.style.display="inline";
                }
            }
            if(cmddynamicConstantsMore!=null){
                if(enableDefineCons=="true"){
                    cmddynamicConstantsMore.style.display="inline";
                    disCmddynamicConstantsMore.style.display="none";
                }else if(enableDefineCons=="false"){
                    cmddynamicConstantsMore.style.display="none";
                    disCmddynamicConstantsMore.style.display="inline";
                }
            }
            if(cmdWebServicesMore!=null){
                if(enableWebService=="true"){
                    cmdWebServicesMore.style.display="inline";
                    disCmdWebServicesMore.style.display="none";
                }else if(enableWebService=="false"){
                    cmdWebServicesMore.style.display="none";
                    disCmdWebServicesMore.style.display="inline";
                }
            }
            if(cmdTaskPrefMore!=null){
                cmdTaskPrefMore.style.display="inline";
                disCmdTaskPrefMore.style.display="none";
            }
            if(cmdTaskPrefTab!=null){//Bug 74636 Start
                cmdTaskPrefTab.style.display="inline";
                disCmdTaskPrefTab.style.display="none";
            }//Bug 74636 End
            if(cmdPurgeCriteriaMore!=null){
                if(enablePurgeCriteria=="true"){
                    cmdPurgeCriteriaMore.style.display="inline";
                    disCmdPurgeCriteriaMore.style.display="none";
                }else if(enableWebService=="false"){
                    cmdPurgeCriteriaMore.style.display="none";
                    disCmdPurgeCriteriaMore.style.display="inline";
                }
            }
                        
            if(cmdPrcConfTab!=null){                
                cmdPrcConfTab.style.display="inline";
                disCmdPrcConfTab.style.display="none";                             
            }
            
            if(cmdPrcConf!=null){                
                cmdPrcConf.style.display="inline";
                disCmdPrcConf.style.display="none";                             
            }
            
            if(cmdModifyActivityTab!=null){                
                cmdModifyActivityTab.style.display="inline";
                disCmdModifyActivityTab.style.display="none";                             
            }
            
            if(cmdModifyActivity!=null){                
                cmdModifyActivity.style.display="inline";
                disCmdModifyActivity.style.display="none";                             
            }
        }
        else
        {
            if(cmddefineTAT!=null){
                disCmddefineTAT.style.display="inline";
                cmddefineTAT.style.display="none";
            }if(cmddynamicConstants!=null){
                disCmddynamicConstants.style.display="inline";
                cmddynamicConstants.style.display="none";
            }
            if(cmdWeb!=null){
                disCmdWeb.style.display="inline";
                cmdWeb.style.display="none";
            }
            if(cmdPurgeCriteria!=null){
                 disCmdPurgeCriteria.style.display="inline";
                cmdPurgeCriteria.style.display="none";
            }
            // For enabling and disabling in the more options div
            if(cmddefineTATMore!=null){
                disCmddefineTATMore.style.display="inline";
                cmddefineTATMore.style.display="none";
            }if(cmddynamicConstantsMore!=null){
                disCmddynamicConstantsMore.style.display="inline";
                cmddynamicConstantsMore.style.display="none";
            }
            if(cmdWebServicesMore!=null){
                disCmdWebServicesMore.style.display="inline";
                cmdWebServicesMore.style.display="none";
            }
            if(cmdTaskPrefMore!=null){
                disCmdTaskPrefMore.style.display="inline";
                cmdTaskPrefMore.style.display="none";
            }
            if(cmdTaskPrefTab!=null){//Bug 74636 Start
                cmdTaskPrefTab.style.display="none";
                disCmdTaskPrefTab.style.display="inline";
            }//Bug 74636 End
            if(cmdPurgeCriteriaMore!=null){
                 disCmdPurgeCriteriaMore.style.display="inline";
                 cmdPurgeCriteriaMore.style.display="none";
            }
            if(cmdModifyActivityTab!=null){                
                cmdModifyActivityTab.style.display="none";
                disCmdModifyActivityTab.style.display="inline";                             
            }
            
            if(cmdModifyActivity!=null){                
                cmdModifyActivity.style.display="none";
                disCmdModifyActivity.style.display="inline";                    
            }
            
            
            if(noOfSelectedRows>1){
                if(cmdPrcConf!=null){
                     disCmdPrcConf.style.display="inline";
                     cmdPrcConf.style.display="none";
                }

                if(cmdPrcConfTab!=null){
                     disCmdPrcConfTab.style.display="inline";
                     cmdPrcConfTab.style.display="none";
                }
            }
        }
    }
        catch(e){
        }  
}

function CommentDiv(ref,Callback,Validate,hidCommentId,thisObj,Title, width, height,hidRevokeId){
    Title = (typeof Title == 'undefined')? '': Title;
    width = (typeof width == 'undefined')? 260: width;
    height = (typeof height == 'undefined')? 165: height;
    hidRevokeId = (typeof hidRevokeId == 'undefined')? '': hidRevokeId;
    
    var bOpenWindow=true;
    if(Validate.length>0)
    {   
        bOpenWindow=parseJSON(Validate + '();');
        
    }
    if(bOpenWindow)
    {   
        var sURL="/webdesktop/components/process/wdcomment.app?Title="+Title;
        sURL=sURL+"&Callback="+Callback+"&Validate="+Validate+"&CommentWindow="+hidCommentId+"&hidRevokeId="+hidRevokeId;
        sURL = sURL + "&WD_SID="+WD_SID+"&Width="+width+"&Height="+height;
        sURL=appendUrlSession(sURL);
        var posLeft = findAbsPosX(ref);
        var posTop = findAbsPosY(ref);
        /*
        try{
            if(document.getElementById("scrollTL") != null) {
                posTop  -= document.getElementById("scrollTL").scrollTop;
                posLeft -= document.getElementById("scrollTL").scrollLeft;
            } else if(document.getElementById("scroll") != null){
                posTop  -= document.getElementById("scroll").scrollTop;
                posLeft -= document.getElementById("scroll").scrollLeft;
            }
        }catch(e){}
        */
        window.parent.popupIFrameOpenerWrapper(this, "CommentWindow",sURL, width, height, posLeft,posTop, false, false, false, true);
    }
    return false;
}

function CommentDivPVM(ref,Callback,Validate,hidCommentId){

    var bOpenWindow=true;
    if(Validate.length>0)
    {
        bOpenWindow=parseJSON(Validate + '();');

    }
    if(bOpenWindow)
    {
        var sURL="/webdesktop/components/process/wdcomment.app?";
        sURL=sURL+"Callback="+Callback+"&Validate="+Validate+"&CommentWindow="+hidCommentId;
        sURL = sURL + "&WD_SID="+WD_SID;
        sURL=appendUrlSession(sURL);
        var posLeft = findAbsPosX(ref)+18;
        var posTop = 108;

        window.parent.popupIFrameOpenerWrapper(this, "CommentWindow",sURL, 240, 160, posLeft,posTop, false, false, false, true);
        //createPopUpIFrameWrapper('CommentWindow',sURL,'160','400');
    }
    return false;

}


function validatePage(Callback,finalWindow,containerDiv,hidCommentId){
    var comments= window.document.getElementById('txtcomment').value;
    
    if(comments !=''){
        window.document.getElementById(hidCommentId).value=comments;
        finalWindow.document.body.removeChild(containerDiv);
        clickLink(Callback);
    }
}

function removeElement(finalWindow,containerDiv){
             finalWindow.document.body.removeChild(containerDiv);
    }

function closeIFrameAndRefreshParent()
{
    try
    {
        if(bClose)
        {
            window.opener.Refreshmodifyprocstatus();
            removeIFrame("processturnaroundtime");
        }
    }
    catch(ex){}
}

function AlphanumericCheck(textToCheck)
{
    for(var j=0;j < textToCheck.length; j++)
    {
        var alphaa = textToCheck.charAt(j);
        var code = alphaa.charCodeAt(0);
        if(code > 47 && code < 58)
        {
        }
        else
        {
            return false;
        }
    }
    return true;
}
function isInvalid(ch)
{
	if (ch.indexOf(" ") != -1)
		return '1';
	else if (ch.indexOf("'") == -1 && ch.indexOf("\\") == -1 && ch.indexOf(":") == -1 && ch.indexOf("?") == -1 && ch.indexOf("*") == -1 && ch.indexOf("/") == -1 && ch.indexOf('\"') == -1 && ch.indexOf(">") == -1 && ch.indexOf("<") == -1 && ch.indexOf("|") == -1 && ch.indexOf("&") == -1)
		return '2';
	else
		return '3';
}

function isInvalid(ch)
{
 /*if (ch.indexOf(" ") != -1)
  return '1';
 else */
        if (ch.indexOf("'") == -1 && ch.indexOf("\\") == -1 && ch.indexOf(":") == -1 && ch.indexOf("?") == -1 && ch.indexOf("*") == -1 && ch.indexOf("/") == -1 && ch.indexOf('\"') == -1 && ch.indexOf(">") == -1 && ch.indexOf("<") == -1 && ch.indexOf("|") == -1 && ch.indexOf("&") == -1)
  return '2';
 else
  return '3';
} 

function validateAllTypeData(val,strType){
   if(trimByRegularEx(val)=="")
         return 1;
   if(isNaN(val))
        {
            return 0;
        }
   if(strType=="3")
    {
       if(IsNumericVal(val))
       {
           if(val<-32768 || val>32767)
        {
            return 0;
        }
       }
       else{
           return 0;
       }
   }else if(strType=="4")
    {
       if(IsNumericVal(val))
       {
          if(val<-2147483648 || val>2147483648)
        {
            return 0;
        }

       }
       else{
           return 0;
       }
    }else if(strType=="6"){
        if(val<1.4E-45 || val>3.4028235E38)
        {
            return 0;
        }
   }

   return 1;
}
function setIndex(ref)
{
    var refId = ref.id;
    var arr=refId.split(":");
    var iArrLength = arr.length;
    var selIndex = arr[iArrLength-2];
    //alert(document.getElementById("frmdynamicconstant:blankp:bp:dclist:"+selIndex+":changeFlag"));
    document.getElementById("frmdynamicconstant:dclist:"+selIndex+":changeFlag").value = true;

}
function checkDataforDConstants()
{
    //check if there are elements in the table or table exist
    
    var rowCount = 0;
    try
    {
        rowCount = document.getElementById("frmdynamicconstant:dclist").tBodies[0].rows.length;
    }catch(ex)
    {
        rowCount =0;
        
    }
    if(rowCount <= 0)
    {
        return false;
    }
    else
    {
        //validate all the input elements in the table
        var validationStatus = 0;
        var inputTextVal="";
        var inputTextElt="";
        for (iCount = 0 ; iCount< (rowCount-1) ; iCount++)
        {
            inputTextElt = document.getElementById("frmdynamicconstant:dclist:"+iCount+":cvalue");
            inputTextVal = inputTextElt.value;
            validationStatus = TextValidate(inputTextVal);
            if(validationStatus != 1)
            {
                customAlert(INVALID_CONSTANT_VALUE);
                inputTextElt.select();
                return false;
            }

        }
    }

    return true;
}

function TextValidate(text)
{
	var i=0;
	var len = text.length;
	var val=text;
	if(val == "")
	{
		return 1;
	}
	if ( len > 255)
	{
		return (-2);
	}
	while(i != len)
	{
		chr = val.charAt(i);
		chrAscii =val.charCodeAt(i);
		if(chr == "'" || chr == '|' || chr == '"')
		{
			return (-3);
		}
		i++;
	}
	return 1;
}

function selectOnechkBox(nodeChkBox)
{
     var iCount;
     var index = nodeChkBox.id.lastIndexOf(':');
     var arr=nodeChkBox.id.split(":");
     var iArrLength = arr.length ;
     var strName="";
     for (var count=0; count < arr.length-2 ; count++ )
     {
         if(count==0)
            strName = arr[count] ;
         else
         {
            strName=strName + ":" + arr[count] ;
         }
     }
     var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length;
     if(nodeChkBox.checked == true)
     {
         for(iCount = 0; iCount < rowCount;iCount++)
         {

            if(iCount != arr[iArrLength-2])
             {
                var el=document.getElementById(strName+":"+iCount +":"+arr[iArrLength-1]);
                el.checked=false;
             }
         }		
     }
}

function openPrcConf(ref){
    var formID="modifyprocessstate"; //ref.form.id;
    var tableID=formID+":"+"dtprocess";
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;    
    var processIDId;
    var processNameId;
    var processID="";
    var processName="";
    
    try {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;
        for (var iCount=0;iCount < rowCount ;iCount++) {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":procId";
            processNameId=tableID+":" + iCount +":procName";
            try {
                if(document.getElementById(currentChkBoxID).checked) {
                    noOfSelectedRows++;
                    processID=document.getElementById(processIDId).value;
                    processName=document.getElementById(processNameId).value;
                }
            }
            catch(e) {}
        }
    } catch(e){}
    
    if(noOfSelectedRows>1){
        customAlert(INVALID_SELECTION_MULTIPLE);
        return false;
    }  
        
    var Url="/webdesktop/components/process/prcconf.app?newPage=true&Opt=5"+"&procName="+encode_utf8(processName)+"&procId="+encode_utf8(processID);
    
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=440;
    var WindowWidth=780;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var win = window.open(Url,"prcconf"+UniqueUserId,'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft);
    
    try {
        addWindows(win);
    } catch(e) {}
    
    try{
        win.focus();
    } catch(e){}
}