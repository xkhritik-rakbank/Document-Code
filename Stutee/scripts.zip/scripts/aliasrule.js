

function dataTableSelectOneRadio(radio) { 
        var id = radio.name.substring(radio.name.lastIndexOf(':')); 
         try
            {
            window.parent.document.getElementById(TargetHidId).value=radio.value;  
            }catch(e){}
            try
            { 
            window.parent.document.getElementById(TargetDispId).src="/webdesktop/resources/aliasimages/"+radio.value;
            }catch(e){} 
      
        var el = radio.form.elements; 
           
        for (var i = 0; i < el.length; i++) { 
                el[i].checked = false; 
        } 
        radio.checked = true;
        removeIFrame(CurrentPickListId);
        
        if(afterSetColor){
            afterSetColor();
        }
       //document.getElementById('cab_form:hiddenVar').value=radio.value;
    }
function setInputValue(){
    var radioIndex;  
    if(isCompatibleForRadioCheck())
     radioIndex=1;
    else
     radioIndex=0;
 if(typeof document.getElementById("frmProcVarMapping:rulelist")!='undefined' && document.getElementById("frmProcVarMapping:rulelist")!=null){
    for(j=0;j<5;j++){
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar").value=""; 
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value="";
     
     document.getElementsByName("frmProcVarMapping:rulelist:"+j+":radioCI")[radioIndex].checked="true";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":bgcolortxtbox").style.backgroundColor="#FFFFFF";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":selImage").src="/webdesktop/resources/aliasimages/transparent.gif";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":hidbgcolortxtbox").value="";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":rlueButton").disabled=true;
     document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").checked=false;
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").disabled=false;
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleVar1").value="";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value="";
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").value="";// Bug 58796
     document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").value="";
     
   }
    document.getElementsByName("frmProcVarMapping:otherRadioCI")[radioIndex].checked="true";
    document.getElementById("frmProcVarMapping:otherBgcolortxtbox").style.backgroundColor="#FFFFFF";
    document.getElementById("frmProcVarMapping:otherImage").src="/webdesktop/resources/aliasimages/transparent.gif";
    document.getElementById("frmProcVarMapping:otherHidbgcolortxtbox").value=""; 
    document.getElementById("frmProcVarMapping:OtherRlueButton").disabled=true;
   document.getElementById("frmProcVarMapping:chkOtherRule").checked=false;
   var selectedVarName= document.getElementById("frmProcVarMapping:selectedVarName").value;
   var selectedVarType= document.getElementById("frmProcVarMapping:selectedVarType").value;
    /*** PRM_8.0_060 Provision to change color if variable value is not blank****/
   operatorCombo(document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator"));
   operatorCombo(document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1"));
    /*** PRM_8.0_060 req Provision to change color if variable value is not blank****/
   
   for(j=1;j<5;j++){
       if(selectedVarType=='8'){
         operatorCombo(document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator"));
         operatorCombo(document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1"));
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue").value=REPORT_TODAY;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").value=REPORT_TODAY;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").value=REPORT_TODAY;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").value=REPORT_TODAY;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").disabled=false;// Bug 58796
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").disabled=false;
       }
       else if(selectedVarType=='10'){
         /*** PRM_8.0_060 commented req Provision to change color if variable value is not blank****/
         
         //document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").disabled=true;
         //document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").disabled=true;
         //document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator").disabled=true;

          /*** PRM_8.0_060 commented req Provision to change color if variable value is not blank****/
         document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").selectedIndex=0;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").selectedIndex=0;

         document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").disabled=false;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").disabled=true;// Bug 58796
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").disabled=true;
         document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").disabled=true;
       }
        else{ 
            document.getElementById("frmProcVarMapping:rulelist:"+j+":chkAliasRule").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":assignOperator1").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":assignOperator1").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVar1").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVar1").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":relOperator1").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":relOperator1").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleValue1").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleValue1").disabled=false;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType").disabled=true;// Bug 58796
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+0+":ruleTempVarType1").disabled=true;
            document.getElementById("frmProcVarMapping:rulelist:"+j+":ruleTempVarType1").disabled=true;
       }
     }
    
  //  var strSelectedText=objCombo.options[objCombo.options.selectedIndex].text;
   if(selectedVarName.indexOf("VAR_")==-1){
     
    }
    //if(selectedVarName==""){
        for(i=0;i<5;i++)
        {
          //document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar").value= objCombo.options[objCombo.options.selectedIndex].text;
          //document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar1").value= objCombo.options[objCombo.options.selectedIndex].text;
          document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar").value= selectedVarName;
          document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar1").value= selectedVarName;
          document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar").title= selectedVarName;
          document.getElementById("frmProcVarMapping:rulelist:"+i+":ruleVar1").title=selectedVarName;
    //    }
   }
}
    try {
            var oldSysVarList = JSON.parse(document.getElementById("frmProcVarMapping:hidOldSysVarList").value);
            var enableStatus = oldSysVarList[selectedVarName.toUpperCase()];
            document.getElementById("frmProcVarMapping:chkSorting").checked = false;
            document.getElementById("frmProcVarMapping:chkSearching").checked = false;
            if (enableStatus == 'Y' || enableStatus == undefined) {
                document.getElementById("frmProcVarMapping:chkSorting").disabled = false;
                document.getElementById("frmProcVarMapping:chkSearching").disabled = false;
            } else {
                document.getElementById("frmProcVarMapping:chkSorting").disabled = true;
                document.getElementById("frmProcVarMapping:chkSearching").disabled = true;
            }
        } catch (e) {
        }
}
function changeCIRadio(ref){  
    var strId=ref.name;
    strId=strId.substring(0,strId.lastIndexOf(":")+1);  
    var colorGrid=strId+"bgcolortxtbox";
    var imageGrid=strId+"selImageGrid";
    document.getElementById(colorGrid).style.backgroundColor="#FFFFFF";
    document.getElementById(strId+"selImage").src="/webdesktop/resources/aliasimages/transparent.gif";
    document.getElementById(strId+"hidbgcolortxtbox").value="";
   if(ref.value==1){
      // alert(document.getElementById(colorGrid).style.display);
     document.getElementById(imageGrid).style.display="none";
     document.getElementById(colorGrid).style.display="block";  
  }
else{
    //alert(document.getElementById(imageGrid).style.display);
     document.getElementById(colorGrid).style.display="none";
     document.getElementById(imageGrid).style.display="block";
}
}
function changeOtherCIRadio(ref){   
    var colorGrid="frmProcVarMapping:otherBgcolortxtbox";
    var imageGrid="frmProcVarMapping:otherImageGrid";
    document.getElementById("frmProcVarMapping:otherBgcolortxtbox").style.backgroundColor="#FFFFFF";
    document.getElementById("frmProcVarMapping:otherImage").src="/webdesktop/resources/aliasimages/transparent.gif";
    document.getElementById("frmProcVarMapping:otherHidbgcolortxtbox").value=""; 
   if(ref.value==1){
     document.getElementById(imageGrid).style.display="none";
     document.getElementById(colorGrid).style.display="block";  
    }
    else{
     document.getElementById(colorGrid).style.display="none";
     document.getElementById(imageGrid).style.display="block";
    }
}
function trimByRegularEx(value) {
   var temp = value;
   var obj = /^(\s*)([\W\w]*)(\b\s*$)/;
   if (obj.test(temp)) { temp = temp.replace(obj, '$2'); }
   obj = / +/g;
   temp = temp.replace(obj, " ");
   if (temp == " ") { temp = ""; }
   return temp;
}


 /***PRM_8.0_060 req for Provision to change color if variable value is not blank****/
function operatorCombo(operator){
    var selectedVarType= document.getElementById("frmProcVarMapping:selectedVarType").value;
    if(selectedVarType=="10" && operator.options.length==6){
    for(var i=0;i<4;i++)
    {
         operator.options[2]=null;
    }
    }else if(selectedVarType!="10" && operator.options.length==2){
        var option = new Option("<=","2");
        operator.options.add(option,operator.options.length);
        var option = new Option("<","1");
        operator.options.add(option,operator.options.length);
        var option = new Option(">","5");
        operator.options.add(option,operator.options.length);
        var option = new Option(">=","6");
        operator.options.add(option,operator.options.length);
    }

}
function uncheckSearchNSort(ref) {
    if (!ref.checked) {
        document.getElementById("frmProcVarMapping:chkSorting").checked = false;
        document.getElementById("frmProcVarMapping:chkSearching").checked = false;
    }
}
 /***PRM_8.0_060 req for Provision to change color if variable value is not blank****/