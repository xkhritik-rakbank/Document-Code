

function WFSave(bShowMessages)
{
    bShowWFSaveMessageFlag = true;
    
    if (bShowMessages != undefined && !bShowMessages)
    {
        bShowWFSaveMessageFlag = false;
    }
    
    if (wiproperty.locked != 'Y')
        if (windowProperty.winloc == 'M')
            mainSave();
        else
            (windowProperty.winloc == 'N') ? window.opener.mainSave() : window.opener.opener.mainSave();
    
    bShowWFSaveMessageFlag = true;
}

function WFDone()
{
    if(wiproperty.locked != 'Y') 

    {
        if(wiproperty.operationOption== 'done')
            if(windowProperty.winloc=='M') 
                done(); 
            else (windowProperty.winloc=='N')?window.opener.done():window.opener.opener.done();
        else if(wiproperty.operationOption== 'introduction')
            if(windowProperty.winloc=='M') introduceWI(); else (windowProperty.winloc==N)?window.opener.introduceWI():window.opener.opener.introduceWI();
        else if(wiproperty.operationOption == 'audit')                     
            if(windowProperty.winloc=='M') introduceWI(); else (windowProperty.winloc==N)?window.opener.introduceWI():window.opener.opener.introduceWI(); 
    }
}

function ZoneGotFocus(X1,Y1,X2,Y2,zone)
{    
    //Bugzilla – Bug 55971 Highlighter in case of datepicker is very dark as compare to others.
    ZoneLostFocus();
    if(!isZoningRequired())
        return false;
             
    var dtWin ='';
    if(windowProperty.winloc=='M')
        dtWin=getWindowHandler(windowList,'tableGrid'); 
    else
        dtWin=(windowProperty.winloc=='N')?getWindowHandler(window.opener.windowList,'tableGrid'):getWindowHandler(window.opener.opener.windowList,'tableGrid');
    var frm=null,app=null;
    if(typeof dtWin !='undefined'){
        if(dtWin.isOpAll == 'N' && dtWin.document.IVApplet){
            app=dtWin.document.IVApplet; 
        } else if(dtWin.isOpAll == 'Y' && dtWin.opall_toolkit){
            app=dtWin.opall_toolkit;
        }
    } else {
        return;
    }
                
    if((typeof app == 'undefined') || (app == null)){
        return;
    }
 
    var nX1,nX2,nY1,nY2;
    strZoneCoordinatesFromDPI='N';//Bug 90600
    if(strZoneCoordinatesFromDPI=='N') {
        nX1 = X1;
        nX2 = X2;
        nY1 = Y1;
        nY2 = Y2;
    }
    else {
        nX1 = (X1*app.getImageXDpi())/96;
        nX2 = (X2*app.getImageXDpi())/96;
        nY1 = (Y1*app.getImageYDpi())/96;
        nY2 = (Y2*app.getImageYDpi())/96;
    }
             
    var NumberOfPages = parseInt(dtWin.document.getElementById('wdesk:noOfpages').value);
    var ZoneName = zone;
    var currentPage = app.getCurrentPage();
    var PageNumber = ZoneName.substring(0, ZoneName.indexOf('_'));
    if(PageNumber == '') PageNumber = app.getCurrentPage();
    PageNumber=parseInt(PageNumber);
    if (NumberOfPages >= PageNumber){ 
        if(dtWin.isOpAll == 'N' && dtWin.document.IVApplet){                
            if(typeof confirmAnnotationSave!="undefined" && confirmAnnotationSave=="Y"){
                if(app.getCurrentPage()!=PageNumber)
                    app.showPage(PageNumber); 
            }else
                app.showPage(PageNumber); 
 
            var extractstatus = app.DrawExtractZone(parseInt(wiproperty.ZoneType),nX1,nY1,nX2,nY2,parseInt(wiproperty.ZoneColor),3,false); 
            var displaystatus = app.SetRectDisplayPosition(nX1, nY1, nX2, nY2, 1, 0, 0, 0, 0);
        } else if(dtWin.isOpAll == 'Y'){
            if (currentPage != PageNumber){
                app.showPage(PageNumber, function(arr){
                            
                     var nX1,nX2,nY1,nY2;
                    if(strZoneCoordinatesFromDPI=='N') {
                        nX1 = arr[1];
                        nX2 = arr[3];
                        nY1 = arr[2];
                        nY2 = arr[4];
                    }
                    else {
                        nX1 = (arr[1]*app.getImageXDpi())/96;
                        nX2 = (arr[3]*app.getImageXDpi())/96;
                        nY1 = (arr[2]*app.getImageYDpi())/96;
                        nY2 = (arr[4]*app.getImageYDpi())/96; 
                    }

                    setTimeout(function(){
                        extractstatus = app.DrawExtractZone(arr[0],nX1,nY1,nX2,nY2,arr[5],arr[6],arr[7]);
                    },50);  
                }, [parseInt(wiproperty.ZoneType),X1,Y1,X2,Y2,parseInt(wiproperty.ZoneColor),3,false, false, '', PageNumber]);
            } else {
                var extractstatus = app.DrawExtractZone(parseInt(wiproperty.ZoneType),nX1,nY1,nX2,nY2,parseInt(wiproperty.ZoneColor),3,false,false,null,PageNumber);
            }
        }
        var window_workdesk="";
        if(windowProperty.winloc == 'M')
            window_workdesk = window;
        else if(windowProperty.winloc == 'T')
            window_workdesk = window.opener.opener;
        else
            window_workdesk = window.opener;
        if(window_workdesk.SharingMode)
            window_workdesk.broadcastZoningEvent(X1, Y1, X2, Y2, zone, windowProperty, windowList);
        return true;
    } 
    else
        return false;
}
         
function ZoneGotFocusCollaboration(X1,Y1,X2,Y2,zone)
{     
    if(!isZoningRequired())
        return false;
    var dtWin ='';
    if(windowProperty.winloc=='M')
        dtWin=getWindowHandler(windowList,'tableGrid'); 
    else
        dtWin=(windowProperty.winloc=='N')?getWindowHandler(window.opener.windowList,'tableGrid'):getWindowHandler(window.opener.opener.windowList,'tableGrid');
    var frm=null,app=null;
                
    if(typeof dtWin !='undefined'){
        if(dtWin.isOpAll == 'N' && dtWin.document.IVApplet){
            app=dtWin.document.IVApplet; 
        } else if(dtWin.isOpAll == 'Y' && dtWin.opall_toolkit){
            app=dtWin.opall_toolkit;
        }
    } else {
        return;
    }
		
    if((typeof app == 'undefined') || (app == null)){
        return;
    }

    var nX1 = (X1*app.getImageXDpi())/96;
    var nX2 = (X2*app.getImageXDpi())/96;
    var nY1 = (Y1*app.getImageYDpi())/96;
    var nY2 = (Y2*app.getImageYDpi())/96;
    nX1 = nX1 * (39.37007874 / 40);
    nX2 = nX2 * (39.37007874 / 40);
    nY1 = nY1 * (39.37007874 / 40);
    nY2 = nY2 * (39.37007874 / 40);
             
    var NumberOfPages = parseInt(dtWin.document.getElementById('wdesk:noOfpages').value);
    var ZoneName = zone;
    var PageNumber = ZoneName.substring(0, ZoneName.indexOf('_'));
    if(PageNumber == '') PageNumber = app.getCurrentPage();
    PageNumber=parseInt(PageNumber);
    if (NumberOfPages >= PageNumber){ 
        if(dtWin.isOpAll == 'N' && dtWin.document.IVApplet){				
            if(typeof confirmAnnotationSave!="undefined" && confirmAnnotationSave=="Y"){
                if(app.getCurrentPage()!=PageNumber)
                    app.showPage(PageNumber); 
            }else
                app.showPage(PageNumber); 

            var extractstatus = app.DrawExtractZone(parseInt(wiproperty.ZoneType),nX1,nY1,nX2,nY2,parseInt(wiproperty.ZoneColor),3,false); 
            var displaystatus = app.SetRectDisplayPosition(nX1, nY1, nX2, nY2, 1, 0, 0, 0, 0);
        } else if(dtWin.isOpAll == 'Y'){
            var extractstatus = app.DrawExtractZone(parseInt(wiproperty.ZoneType),nX1,nY1,nX2,nY2,parseInt(wiproperty.ZoneColor),3,false,false,null,PageNumber);
        }
        return true;
    } 
    else
        return false;
}
	
function ZoneLostFocus()
{             
    var dtWin ='';
    if((typeof window.parent.bDefaultNGForm == 'undefined') || ((typeof window.parent.bDefaultNGForm != 'undefined') && window.parent.bDefaultNGForm)){
        if(windowProperty.winloc=='M')
            dtWin=getWindowHandler(windowList,'tableGrid'); 
        else
            dtWin=(windowProperty.winloc=='N')?getWindowHandler(window.opener.windowList,'tableGrid'):getWindowHandler(window.opener.opener.windowList,'tableGrid');
    } else {                    
        if(window.parent.windowProperty.winloc=='M')
            dtWin=window.parent.getWindowHandler(window.parent.windowList,'tableGrid'); 
        else
            dtWin=(window.parent.windowProperty.winloc=='N')?window.parent.getWindowHandler(window.parent.windowList,'tableGrid'):window.parent.getWindowHandler(window.opener.opener.windowList,'tableGrid');                    
    }
                
    var frm=null,app=null;
		
    if(typeof dtWin !='undefined'){
        if(dtWin.isOpAll == 'N' && dtWin.document.IVApplet){
            app=dtWin.document.IVApplet; 
        } else if(dtWin.isOpAll == 'Y' && dtWin.opall_toolkit){
            app=dtWin.opall_toolkit;
        }
    } else {
        return;
    }
		
    if((typeof app == 'undefined') || (app == null)){
        return;
    }
                
    if(dtWin){
        if(dtWin.isOpAll == 'Y' && dtWin.opall_toolkit)
        {
            // For deleteExtractZone(0) use deleteAllZone() in case of OpallViewer and for non-zero zoneid use deleteExtractZone(n)
            var deletestatus =  app.deleteAllZone();
        }
        else
        {
            var deletestatus =  app.deleteExtractZone(0);
        }
                    
    }
}
    
function WFClose(){
    closeWorkdesk();
}
        
function Print()
{
    var argv = Print.arguments;
    var argLength = Print.arguments.length;
    if(argv[0] != null && argLength == 1)
    {
        var status = document.pa.printDocument(argv[0],1,1);
    }
    if(argv[1] !=null && argLength == 2)
    {
        var status = document.pa.printDocument(argv[0],argv[1],1,1);
    }
    if(argv[0]!= null & argLength == 3 )
    {
        var status = document.pa.printDocument(argv[0],argv[1],argv[2]);
    }
    if(argv[0]!= null & argLength == 4 )
    {
        var status = document.pa.printDocument(argv[0],argv[1],argv[2],argv[3]);
    }
}