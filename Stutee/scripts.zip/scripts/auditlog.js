/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
function printAuditLogPage()
{
     
    var ScreenWidth = screen.width;
    var ScreenHeight = screen.height;
                
    var window1H = 500;
    var WindowHeight=window1H;
    var WindowWidth=window1W + 10;
    var WindowLeft=parseInt(ScreenWidth /2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var WindowHeight=window1H;
    var WindowWidth=window1W + 200;
    var selectedTab = document.getElementById("auditlog:hidSelectedTab").value;
    var selectedOperation = document.getElementById("auditlog:selectedOperation");
        
    var popup = window.open('','AuditLog','resizable=yes,scrollbars=yes,status=yes,width='+WindowWidth+',height='+WindowHeight+',left='+WindowLeft+',top='+WindowTop);
    popup.document.write("<html dir="+HTML_DIR+"><head><title>"+titleAuditLog);
    popup.document.write("</title>");
    //css
    popup.document.write("<link href='/webdesktop/javax.faces.resource/stylesheet.css.app?ln="+Path+"/css'"+" rel='stylesheet' type='text/css'>");
    popup.document.write("<link href='"+themeStyleSheet+"'"+" rel='stylesheet' type='text/css'>");
    popup.document.write("</head><body class='bodywhite'>");
    popup.document.write("<Table align ='center'  width='100%' ><TR><TD class=wdwidth100center style='text-align:center'>");
    popup.document.write("<span id='Heading1' class='wdlabelstyleblackbold'>");
    popup.document.write(titleAuditLog);
    popup.document.write("</span>");
    popup.document.write("</TD><TD class='wdwidth20right'>");
    popup.document.write("&nbsp");
    popup.document.write("</TD></TR></TABLE>");
    popup.document.write("<br/>");
    popup.document.write("<Table align ='center' border='0' cellpadding='0' cellspacing='0' width='100%'><TR><TD class='wdwidth20 wdlabelstyleblackbold'>");
    if(selectedTab=='queuesTab')
    {
        popup.document.write(document.getElementById("auditlog:lblQueueName").innerHTML+" : ");
              
        popup.document.write("</TD><TD class='wdwidth80 wdlabelstyleblack'>");
        popup.document.write(encode_ParamValue(document.getElementById("auditlog:queueName").value)+"");
        popup.document.write("</TD></TR></TABLE>");
    }
    else if(selectedTab == 'processesTab')
    {
        popup.document.write(document.getElementById("auditlog:lblProcessName").innerHTML+" : ");
        popup.document.write("</TD><TD class='wdwidth80 wdlabelstyleblack'>");
        popup.document.write(encode_ParamValue(document.getElementById("auditlog:processName").value)+"");
        popup.document.write("</TD></TR></TABLE>");
    }
    else if(selectedTab == 'userTab')
    {
        popup.document.write(document.getElementById("auditlog:lblUserName").innerHTML+" : ");
        popup.document.write("</TD><TD class='wdwidth80 wdlabelstyleblack'>");
        popup.document.write(encode_ParamValue(document.getElementById("auditlog:userName").value)+"");
        popup.document.write("</TD></TR></TABLE>");
    }
    else if(selectedTab == 'cabinetTab')
    {
        popup.document.write(document.getElementById("auditlog:lblCabinetName").innerHTML+" : ");
        popup.document.write("</TD><TD class='wdwidth80 wdlabelstyleblack'>");
        popup.document.write(encode_ParamValue(document.getElementById("auditlog:cabUserName").value)+"");
        popup.document.write("</TD></TR></TABLE>");
    }
      else if(selectedTab == 'rightsMgmtTab')
    {
        popup.document.write(document.getElementById("auditlog:lblRMUserName").innerHTML+" : ");
        popup.document.write("</TD><TD class='wdwidth80 wdlabelstyleblack'>");
        popup.document.write(encode_ParamValue(document.getElementById("auditlog:rmsUserName").value)+"");
        popup.document.write("</TD></TR></TABLE>");
    }
    popup.document.write("<Table align ='center' border='0' cellpadding='0' cellspacing='0' width='100%'><TR><TD class='wdwidth20 wdlabelstyleblackbold'>");
    popup.document.write(document.getElementById("auditlog:lblFromDateRange").innerHTML+" : ");
    popup.document.write("</TD><TD class='wdwidth80 wdlabelstyleblack'>");
    popup.document.write(encode_ParamValue(document.getElementById("auditlog:fromDay").value)+"/"+encode_ParamValue(document.getElementById("auditlog:fromMonth").value)+"/"+encode_ParamValue(document.getElementById("auditlog:fromYear").value));
    popup.document.write("</TD></TR><TR><TD class='wdwidth20 wdlabelstyleblackbold'>");
    popup.document.write(document.getElementById("auditlog:lblToDateRange").innerHTML+" : ");
    popup.document.write("</TD><TD class='wdwidth80 wdlabelstyleblack'>");
    popup.document.write(encode_ParamValue(document.getElementById("auditlog:toDay").value)+"/"+encode_ParamValue(document.getElementById("auditlog:toMonth").value)+"/"+encode_ParamValue(document.getElementById("auditlog:toYear").value));
    popup.document.write("</TD></TR></TABLE>");
    popup.document.write("<Table align ='center' border='0' cellpadding='0' cellspacing='0' width='100%'><TR><TD class='wdwidth20 wdlabelstyleblackbold'>");
    popup.document.write(document.getElementById("auditlog:lblOperation").innerHTML+" : ");
    popup.document.write("</TD><TD class='wdwidth80 wdlabelstyleblack'>");
    popup.document.write(encode_ParamValue(selectedOperation.options[selectedOperation.selectedIndex].text)+"");
    popup.document.write("</TD></TR></TABLE>");
    popup.document.write("<br/>");
    //popup.document.write("<label value='hii' style='background-image:url(/webdesktop/resources/images/tab.png)'>");
    //popup.document.write("<img src='/webdesktop/resources/images/check.gif'>");
    popup.document.write("<Table align='center' border='0' cellpadding='0' cellspacing='0' width='100%'><TR><TD class='wdwidth1'></TD><TD class='wdwidth94'>");
    popup.document.write("<div id='historyData' >");
    popup.document.write(document.getElementById("auditlog:historyLog").innerHTML);
    popup.document.write("</TD><TD class='wdwidth5'></TD></TR></TABLE>");

          
    popup.document.write("</body></html>");
    popup.document.close();
    popup.print();
    popup.close();
}

function displayMoreOptions(ref){
    if(document.getElementById('MoreDiv').style.display == 'none'){
        positionmenuOptions(ref.id,'MoreDiv');
        document.getElementById('MoreDiv').style.display = 'inline';
    }
    else{
        document.getElementById('MoreDiv').style.display = 'none';
        positionmenuOptions(ref.id,'MoreDiv');
    }
}
function positionmenuOptions(ref,divId){
    var tempCtrlname=document.getElementById(ref);
    var posLeft = findPosX(tempCtrlname);
    var posTop = findPosY(tempCtrlname);
    var subMenuObj=document.getElementById(divId);
    var absoluteleft = absolutetop = 0;
    if (tempCtrlname.offsetParent)
    {
        absoluteleft = tempCtrlname.offsetLeft;
        absolutetop = tempCtrlname.offsetTop;
    }
    if(divId=="MoreDiv" ){
        if(absoluteleft+posLeft-80<0)
        {
            subMenuObj.style.left=posLeft + "px";
        }
        else
        {
            subMenuObj.style.left=absoluteleft+posLeft-50 + "px";
        }
        
        
        subMenuObj.style.top=absolutetop+posTop+15 + "px";
    }else{
        subMenuObj.style.left=absoluteleft+posLeft+25 + "px";
        subMenuObj.style.top=absolutetop+posTop+15 + "px";
    }

}
function removeMoreOptions()
{
    if(document.getElementById('MoreDiv').style.display == 'inline')
        document.getElementById('MoreDiv').style.display = 'none';
}