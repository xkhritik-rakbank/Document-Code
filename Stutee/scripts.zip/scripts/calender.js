

    function selectradio(iselected)
    {
        if(iselected==1)
        {
                document.forms["calendar"]["calendar:radio1"].checked=true;
                document.forms["calendar"]["calendar:radio2"].checked=false;
                document.forms["calendar"]["calendar:radio3"].checked=false;
                document.getElementById("calendar:hidworkingmode").value='1';
                copyDefHourRange();
        }

       else if(iselected==2)
        {
                document.forms["calendar"]["calendar:radio2"].checked=true;
                document.forms["calendar"]["calendar:radio1"].checked=false;
                document.forms["calendar"]["calendar:radio3"].checked=false;
                document.getElementById("calendar:hidworkingmode").value='2';
        }
        else if(iselected==3)
        {
                document.forms["calendar"]["calendar:radio3"].checked=true;
                document.forms["calendar"]["calendar:radio1"].checked=false;
                document.forms["calendar"]["calendar:radio2"].checked=false;
                document.getElementById("calendar:hidworkingmode").value='3';
        }
        else
        {
                document.forms["calendar"]["calendar:radio3"].checked=false;
                document.forms["calendar"]["calendar:radio1"].checked=false;
                document.forms["calendar"]["calendar:radio2"].checked=false;
                document.getElementById("calendar:hidworkingmode").value='-1';

        }

    }

    function setradonload()
    {
        //setstyleArray();
        if(strSuccess=='success')
            {
            
            self.close();
            }
        else
        {
                    try
                    {
                    if(document.getElementById("calendar:hidworkingmode").value=='1')
                    {
                        selectradio(1);
                    }

                   else if(document.getElementById("calendar:hidworkingmode").value=='2')
                    {
                            selectradio(2);
                    }

                     else if(document.getElementById("calendar:hidworkingmode").value=='3')
                    {
                            selectradio(3);
                    }
                    else if(document.getElementById("calendar:hidworkingmode").value=='-1')
                        {
                            selectradio(0);
                            if(!defaultcal)
                                {
                                document.forms["calendar"]["calendar:radio3"].disabled=false;
                                document.forms["calendar"]["calendar:radio1"].disabled=false;
                                document.forms["calendar"]["calendar:radio2"].disabled=false;
                                }
                        }
                    else
                    {
                            selectradio(0);
                            document.forms["calendar"]["calendar:radio3"].disabled=true;
                            document.forms["calendar"]["calendar:radio1"].disabled=true;
                            document.forms["calendar"]["calendar:radio2"].disabled=true;

                    }
                    if(document.getElementById("calendar:hidSelected_week").value!='0')
                        {
                            document.forms["calendar"]["calendar:radio2"].disabled=true;
                        }

                    }
                    catch(e){}
               if(strSuccess=='newCreated')
               {
                customAlert(NEW_CALENDAR_CREATED_SUCCESSFULLY);
               }
        }

    }

    function selectedDate(idate)
    {
            document.getElementById("calendar:hidselected_date").value=idate;
            document.getElementById("calendar:hidSelected_week").value='0';
            if(validatehourrange())
            {
                clickLink('calendar:updateChangesInBean');
            }

    }

    function selectedWeek(iweek)
    {
            document.getElementById("calendar:hidselected_date").value='0';
            document.getElementById("calendar:hidSelected_week").value=iweek;
            if(validatehourrange())
            {
                clickLink('calendar:updateChangesInBean');
            }
    }


    function validatehourrange()
    {
      var tableID="calendar:hourdef";
      for(icount=0;icount<5;icount++)
      {
      var StartTimeBoxID=tableID+":"+icount+":starttime";
      var EndTimeBoxID=tableID+":"+icount+":endtime";
      var StartTimeBoxValue=Trim(document.getElementById(StartTimeBoxID).value);
      var EndTimeBoxValue=Trim(document.getElementById(EndTimeBoxID).value);
      var PrevEndTimeValue;

      if(StartTimeBoxValue!="")
        {
            if(!AlphanumericCheck(StartTimeBoxValue))
                    {
                        customAlert(NOT_CORRECT_TIME);
                        document.getElementById(StartTimeBoxID).focus();
                        document.getElementById(StartTimeBoxID).select();
                        return false;
                     }
                    if(!reformattime(StartTimeBoxID,StartTimeBoxValue))
                        {
                            customAlert(NOT_CORRECT_TIME);
                            return false;
                        }

                        var firstpart=StartTimeBoxValue.substr(0,2);
                        var secondpart=StartTimeBoxValue.substr(2,2);

                    if((firstpart-0)>24)
                        {
                            customAlert(NOT_CORRECT_TIME);
                            document.getElementById(StartTimeBoxID).focus();
                            document.getElementById(StartTimeBoxID).select();
                            return false;
                        }
                    if((secondpart-0)>59)
                        {
                            customAlert(NOT_CORRECT_TIME);
                            document.getElementById(StartTimeBoxID).focus();
                            document.getElementById(StartTimeBoxID).select();
                            return false;
                        }
                        if((firstpart-0)==24)
                        {
                            if((secondpart-0)>0)
                            {
                                customAlert(NOT_CORRECT_TIME);
                                document.getElementById(StartTimeBoxID).focus();
                                document.getElementById(StartTimeBoxID).select();
                                return false;
                            }
                        }

                    if(EndTimeBoxValue=="")
                    {
                            customAlert(SPECIFY_TO_TIME);
                            document.getElementById(EndTimeBoxID).focus();
                            document.getElementById(EndTimeBoxID).select();
                            return false;
                    }
        }

        if(EndTimeBoxValue!="")
            {
                    if(!AlphanumericCheck(EndTimeBoxValue))
                    {
                        customAlert(NOT_CORRECT_TIME);
                        document.getElementById(EndTimeBoxID).focus();
                        document.getElementById(EndTimeBoxID).select();
                        return false;
                     }

                    if(!reformattime(EndTimeBoxID,EndTimeBoxValue))
                        {
                        customAlert(NOT_CORRECT_TIME);
                        return false;
                        }

                        var firstpart=EndTimeBoxValue.substr(0,2);
                        var secondpart=EndTimeBoxValue.substr(2,2);

                    if((firstpart-0)>24)
                        {
                            customAlert(NOT_CORRECT_TIME);
                            document.getElementById(EndTimeBoxID).focus();
                            document.getElementById(EndTimeBoxID).select();
                            return false;
                        }
                    if((secondpart-0)>59)
                        {
                            customAlert(NOT_CORRECT_TIME);
                            document.getElementById(EndTimeBoxID).focus();
                            document.getElementById(EndTimeBoxID).select();
                            return false;
                        }

                        if((firstpart-0)==24)
                        {
                            if((secondpart-0)>0)
                            {
                                customAlert(NOT_CORRECT_TIME);
                                document.getElementById(EndTimeBoxID).focus();
                                document.getElementById(EndTimeBoxID).select();
                                return false;
                            }
                        }

                    if(StartTimeBoxValue=="")
                        {
                            customAlert(SPECIFY_FROM_TIME);
                            document.getElementById(StartTimeBoxID).focus();
                            document.getElementById(StartTimeBoxID).select();
                            return false;
                        }
            }

                    var StartTimeBoxValuemod=Trim(document.getElementById(StartTimeBoxID).value);
                    var EndTimeBoxValuemod=Trim(document.getElementById(EndTimeBoxID).value);


                    if((EndTimeBoxValuemod-0)<=(StartTimeBoxValuemod-0) &&(StartTimeBoxValuemod.length !=0)&&(EndTimeBoxValuemod.length !=0) )
                        {

                            customAlert(TO_TIME_GREATER_THAN_FROM_TIME);
                            document.getElementById(EndTimeBoxID).focus();
                            document.getElementById(EndTimeBoxID).select();
                            return false;
                        }
      }
      
      /*
      if(!checkDefHourRange())
          {
              alert(DEFAULT_TIME_RANGE_NOT_SPECIFIED);
              return false;
          }
      
      
        */
       return true;
    }
    
    function validatedefaulthourrange()
    {
            if( validatehourrange() && checkDefHourRange())
            {
                return true;
            }
            else
            {
                return false;
            }
    }
    
    

    function AlphanumericCheck(textToCheck)
    {
        for(var j=0;j < textToCheck.length; j++)
         {
            var alphaa = textToCheck.charAt(j);
             var code = alphaa.charCodeAt(0);
             if(code > 47 && code < 58)
                {
                }
             else
                {
                     return false;
                 }
          }
        return true;
     }


     function reformattime(timeid,timevalue)
        {
            var timelength=timevalue.length;
            if(timelength!=4)
            {
                if(timelength>4)
                {
                    document.getElementById(timeid).focus();
                    document.getElementById(timeid).select();
                    return false;
                }
                else if((timelength)<4)
                    {
                        if((timelength)==1)
                        {
                            timevalue='0'+timevalue+'00';
                        }
                        if((timelength)==2)
                        {
                            timevalue=timevalue+'00';
                        }
                        if((timelength)==3)
                        {
                            timevalue=timevalue+'0';
                        }

                     document.getElementById(timeid).value=timevalue;
                     return true;
                    }
             }
             else
             {
                return true;
             }

        }


        function next()
        {
            if(validatehourrange())
            {
                clickLink('calendar:nextmonth');
            }
        }


        function previous()
        {
            if(validatehourrange())
            {
                clickLink('calendar:previousmonth');
            }
        }

        function getSelectedCal()
        {
            var index=document.getElementById("selectitems:cmbcalendar").selectedIndex;
            var calid=document.getElementById("selectitems:cmbcalendar").options[index].value;
            document.getElementById("calendar:hidSelectedCalValue").value=calid;
            document.getElementById("calendar:hidselectedoption").value=calid;
            clickLink('calendar:hidselectedcal');
        }

        function clearHourDef()
        {
            var tableID="calendar:hourdef";
            for(icount=0;icount<5;icount++)
            {
                var StartTimeBoxID=tableID+":"+icount+":starttime";
                var EndTimeBoxID=tableID+":"+icount+":endtime";
                document.getElementById(StartTimeBoxID).value = "";
                document.getElementById(EndTimeBoxID).value = "";
            }
        }

        function copyDefHourRange()
        {
              var tableID="calendar:hourdef";
              var defhourtableID="calendar:defhourdef";
              for(icount=0;icount<5;icount++)
              {
                  var StartTimeBoxID=tableID+":"+icount+":starttime";
                  var EndTimeBoxID=tableID+":"+icount+":endtime";
                  var defStartTimeBoxID=defhourtableID+":"+icount+":defstarttime";
                  var defEndTimeBoxID=defhourtableID+":"+icount+":defendtime";
                  document.getElementById(StartTimeBoxID).value = document.getElementById(defStartTimeBoxID).value;
                  document.getElementById(EndTimeBoxID).value = document.getElementById(defEndTimeBoxID).value;
              }
        }

    var mySelectHandler22 = function(type,args,obj){
        var selected = args[0];
        var selDate = this.toDate(selected[0]);
        var strDateFormat="dd/MM/yyyy";
        if(document.getElementById('newAction:blankpanel:bp:hidDateFormat')!=null)
            strDateFormat=document.getElementById('newAction:blankpanel:bp:hidDateFormat').value;
        if(document.getElementById('audittrailform:dateformat')!=null)
            strDateFormat=document.getElementById('audittrailform:dateformat').value;
        if(document.getElementById('businessRuleMapping:blankpanel:bp:hidDateformat')!=null)
            strDateFormat=document.getElementById('businessRuleMapping:blankpanel:bp:hidDateformat').value;
        if(document.getElementById('exttableform_Test:hidDateformat')!=null)
            strDateFormat=document.getElementById('exttableform_Test:hidDateformat').value;
        if(document.getElementById('exttableform:hidDateformat')!=null)
            strDateFormat=document.getElementById('exttableform:hidDateformat').value;
        if(document.getElementById('queuevariable:hidDateformat')!=null)
            strDateFormat=document.getElementById('queuevariable:hidDateformat').value;
        if(document.getElementById('scanActionForm:hidDateformat')!=null)
            strDateFormat=document.getElementById('scanActionForm:hidDateformat').value;
        if(document.getElementById('setTriggerForm:hidDateformat')!=null)
            strDateFormat=document.getElementById('setTriggerForm:hidDateformat').value;
        if(document.getElementById('hidDateformat')!=null)
            strDateFormat=document.getElementById('hidDateformat').value;
        if(document.getElementById('form1:blankpanel:bp:hidDateFormat')!=null)
            strDateFormat=document.getElementById('form1:blankpanel:bp:hidDateFormat').value;
        if(document.getElementById('taskPreCondiotion:hidDateformat')!=null)
            strDateFormat=document.getElementById('taskPreCondiotion:hidDateformat').value;
        if(document.getElementById('propertyView:bpanel:gpanel:hidDateformat')!=null)
            strDateFormat=document.getElementById('propertyView:bpanel:gpanel:hidDateformat').value;
        if(document.getElementById('editGlobalTemplate:hidDateformat')!=null)
            strDateFormat=document.getElementById('editGlobalTemplate:hidDateformat').value;
        if(document.getElementById('propertyView:bpanel:gpanel:hidDateformats')!=null)
            strDateFormat=document.getElementById('propertyView:bpanel:gpanel:hidDateformats').value;
        if(document.getElementById('ruledef:hidDateformat')!=null)
            strDateFormat=document.getElementById('ruledef:hidDateformat').value;
        if(document.getElementById('ccwTriggerForm:hidDateformat')!=null)
            strDateFormat=document.getElementById('ccwTriggerForm:hidDateformat').value;
        if(document.getElementById('taskCondOpr:hidDateformat')!=null)
            strDateFormat=document.getElementById('taskCondOpr:hidDateformat').value;
        if(document.getElementById('taskRuleDef:blankpanel:bp:hidDateformat')!=null)
            strDateFormat=document.getElementById('taskRuleDef:blankpanel:bp:hidDateformat').value;
        var strDBDate=convertYahooToDbDate(selDate);
        var strLocalDate=DBToLocal(strDBDate,strDateFormat,false);
        strLocalDate= Trim(strLocalDate);
        var Elm=document.getElementById(calFromTextBox);

        try{
            document.getElementById(calFromTextBox).focus();
        }catch(e){}
        if(obj.varType=='combo'){
            Elm.options[Elm.options.selectedIndex].text=strLocalDate;
            Elm.options[Elm.options.selectedIndex].value=strLocalDate;
            Elm.title=strLocalDate;
        }
        else{
            document.getElementById(calFromTextBox).value=strLocalDate;
            if(calHidTextBox){
                if(document.getElementById(calHidTextBox))
                document.getElementById(calHidTextBox).value=strLocalDate;
            }
        }
        try{
            document.getElementById(calFromTextBox).blur();
        }catch(e){}
        obj.hide();
    }
    function openCalenderThis(ref,Option,TextBoxId,varType,position,hidVarId){    
        var optId = ref.id;
        var index = optId.lastIndexOf(":");
        var subId = optId.substring(0,index);
        var bShortDate=true;
        calFromTextBox=TextBoxId;
        calHidTextBox=hidVarId;
        var cal=null;
        cal = openCalender(varType,cal,bShortDate,'',position,mySelectHandler22);
    }
    function checkDefHourRange()
        {
              var tableID="calendar:hourdef";
              var defhourtableID="calendar:defhourdef";
              var bDefHourRange = false;
              for(icount=0;icount<5;icount++)
              {   
                  var StartTimeBoxID=tableID+":"+icount+":starttime";
                  var EndTimeBoxID=tableID+":"+icount+":endtime";
                  var vStUTime = document.getElementById(StartTimeBoxID).value;
                  var vEndUTime = document.getElementById(EndTimeBoxID).value;
                  var defStartTimeBoxID=defhourtableID+":"+icount+":defstarttime";
                  var defEndTimeBoxID=defhourtableID+":"+icount+":defendtime";
                  var vStBoxVal = document.getElementById(defStartTimeBoxID).value;
                  var vEndBoxVal = document.getElementById(defEndTimeBoxID).value;
                  
                  var hidWorkingMode = document.getElementById("calendar:hidworkingmode").value;
                  
                  if(hidWorkingMode == '1')
                      {
                      if(vStUTime.length>0 || vEndUTime.length>0)
                      {
                          bDefHourRange = true;
                          break;
                      }
                      }
                      else
                      {
                      if(vStBoxVal.length>0 || vEndBoxVal.length>0)
                      {
                          bDefHourRange = true;
                          break;
                      }
                      }
              }
              
              if(!bDefHourRange)
              {
                   customAlert(DEFAULT_TIME_RANGE_NOT_SPECIFIED);
              }    
              return bDefHourRange;
          
        }    

    function newCalendarOkClick()
    {
        if(ValidateCalendarName() && validateCalenderComments())
        {
                /*try{
                 window.parent.document.getElementById("calendar:hidcalName").value=document.getElementById("newcalendar:blankpanel:bluepanel:calendarName").value;
                }catch(ex){}

                try{
                 window.parent.document.getElementById("calendar:hidNewCalType").value=document.getElementById("newcalendar:blankpanel:bluepanel:hidNewCalType").value;
                  }catch(ex){}

                try{
                 window.parent.document.getElementById("calendar:cmbcalendar").value=document.getElementById("newcalendar:blankpanel:bluepanel:ListExtCal").value;
                  }catch(ex){}

                 try{
                 window.parent.document.getElementById("calendar:hidActionComments").value=document.getElementById("newcalendar:blankpanel:bluepanel:calendarComments").value;
                  }catch(ex){}

                try{
                 window.parent.clickLink("calendar:cmdlink_RefreshCal");
                  }catch(ex){}

                 removeIFrame(CurrentPickListId);
             }*/
            try{
                var comment=document.getElementById("newcalendar:calendarComments").value;
                if(Trim(comment).length > 255) {                    
                    notifierAbs('notifier', ALERT_EXCEEDING_REMINDER_COMMENT_LENGTH, "absolute", true);                    
                    return false;
                }
                
                clickLink("newcalendar:cmdlink_RefreshCal");
            }catch(ex){}
         return false;
    }
}

        function validateCalenderComments()
        {
           
           var comments = Trim(document.getElementById("newcalendar:calendarComments").value);
             if(comments=="")
            {
                fieldValidator("newcalendar:calendarComments", COMMENTS_MADATORY, "absolute", true);
                //alert(COMMENTS_MADATORY);
                //document.getElementById("newcalendar:calendarComments").focus();
                return false;
             }
             return true;
        }

    function ValidateCalendarName()
    {
        var name = Trim(document.getElementById("newcalendar:calendarName").value);
        if(name=="")
        {
            fieldValidator("newcalendar:calendarName", CALENDAR_NAME_CANNOT_BE_BLANK, "absolute", true);
            //alert(CALENDAR_NAME_CANNOT_BE_BLANK);
            //document.getElementById("newcalendar:calendarName").focus();
            return false;
         }
         else
         {
            var list=window.parent.document.getElementById("calendar:cmbcalendar");
            if(list!=undefined)
            {
                var i;
                for(i=0; i< list.options.length; ++i)
                {
                    if(name==list.options[i].text)
                    break;
                }
                if(i < list.options.length)
                {
                    fieldValidator("newcalendar:calendarName", CALENDAR_WITH_SAME_NAME_ALREADY_EXISTS, "absolute", true);
                    //alert(CALENDAR_WITH_SAME_NAME_ALREADY_EXISTS);
                    //document.getElementById("newcalendar:calendarName").select();
                    return false;
                }
            }
         }
        return true;
    }
    function calenderTypeRadioOnClick(option)
    {
       if(option=='1')
       {
           //newcalendar:blankpanel:bluepanel:radioNewBaseCal:0 newcalendar:blankpanel:bluepanel:radioCopyCal:0
        document.forms[0].elements["newcalendar:radioCopyCal"].checked=false;
        document.getElementById("newcalendar:ListExtCal").disabled=true;
        document.getElementById("newcalendar:hidNewCalType").value="newBaseCal";
       }
       else
       {
        document.forms[0].elements["newcalendar:radioNewBaseCal"].checked=false;
        document.getElementById("newcalendar:ListExtCal").disabled=false;
        document.getElementById("newcalendar:hidNewCalType").value="copyCal";
       }

    }
    function NewCalOnLoadInit()
    {
        var openCalendar=encode_ParamValue(document.getElementById("newcalendar:hidCloseOnSuccess").value);
        if(openCalendar=="newCreated"){
            var procId=encode_ParamValue(document.getElementById("newcalendar:hidProcessID").value);
            var ExtFunc=encode_ParamValue(document.getElementById("newcalendar:hidExtFunc").value);
            var calenderName =encode_ParamValue(document.getElementById("newcalendar:calendarName").value);
           var CalTypeObj = document.getElementsByName("newcalendar:calType");

            var calenderType = "";
          var radioCalTypeLength = CalTypeObj.length;
             for(var iLoop = 0; iLoop < radioCalTypeLength ; iLoop++)
              {
                  if(CalTypeObj[iLoop].checked == true)
                    {
                        calenderType = CalTypeObj[iLoop].value;
                        break;
                    }
              }

              var calId = "-1";
              if(document.getElementById("newcalendar:hidAddedCalenderId") != null)
                calId =  encode_ParamValue(document.getElementById("newcalendar:hidAddedCalenderId").value);
            var associatedProcDefId = -1;
            if(calenderType == "G")
                associatedProcDefId = 0; // global calender
            else
               associatedProcDefId = procId; // local calender
            if(Trim(ExtFunc)!=""){
                var hidAddedCalId=encode_ParamValue(document.getElementById("newcalendar:hidAddedCalenderId").value);
              // window.opener.parseJSON(ExtFunc);
               parseJSON("window.opener."+ExtFunc+"('"+procId+"','"+hidAddedCalId+"','"+calenderName+"','"+associatedProcDefId+"')");
            }

         //  openCalendarDisplay(procId);
           openCalendarDisplay(procId,calId);
            return "";
        }
        var list =document.getElementById("newcalendar:ListExtCal");
        if(list.options.length>0)
        {
            list.options[0].selected=true;
        }
        document.forms[0].elements["newcalendar:radioNewBaseCal"].checked=true;
        calenderTypeRadioOnClick('1');
    }

   // function openCalendarDisplay(procId){
    function openCalendarDisplay(procId,calId){

        var Url = "/webdesktop/components/calender/calendardisplay.app";
       /* var wFeatures = 'status=yes,resizable=no,scrollbars=yes,width=350,height=600,left='+windowY+',top='+windowX;
        var listParam=new Array();
        listParam.push(new Array("Launch",encode_ParamValue("1")));
        listParam.push(new Array("ProcessID",encode_ParamValue(procId)));
        listParam.push(new Array("CalId",encode_ParamValue(calId)));
        if(procId==""){
            listParam.push(new Array("ListType",encode_ParamValue("G")));
        }else{
            listParam.push(new Array("ListType",encode_ParamValue("B")));
        }*/
        var RID = getRequestToken(Url);
        var lType = (procId=="")?encode_ParamValue("G"):encode_ParamValue("B");
        Url+="?WD_SID="+WD_SID+"&WD_RID="+RID+"&Launch="+encode_ParamValue("1")+"&ProcessID="+encode_ParamValue(procId)+"&CalId="+encode_ParamValue(calId)+"&ListType="+lType;
//        win = openNewWindow(Url,"_self",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
        window.location.href=Url;
        
    }

    /*function openNewCalendar1(strProcId,strProcName,listType)
    {
        var Url = "/webdesktop/components/calender/newcalendar.app?WD_SID="+WD_SID+"&Launch=1&ProcessID=48&ListType=B";


        Url = appendUrlSession(Url);
        var listParam=new Array();
        listParam.push(new Array("Action",encode_ParamValue("1")));
        listParam.push(new Array("Launch",encode_ParamValue("1")));
        listParam.push(new Array("ProcessID",encode_ParamValue("48")));
        listParam.push(new Array("ProcessName",encode_ParamValue(ProcessName)));
        listParam.push(new Array("ListType",encode_ParamValue("B")));




        createPopUpIFrameWrapper('newcalendar',Url,'270','400');
    }*/

    function openNewCalendar(){
        var Url = "/webdesktop/login/loginapp.app";
        var wFeatures = 'status=yes,resizable=no,scrollbars=yes,width=500,height=500,left='+windowY+',top='+windowX;
        var listParam=new Array();
        listParam.push(new Array("Action",encode_ParamValue("1")));
        listParam.push(new Array("Launch",encode_ParamValue("1")));
        listParam.push(new Array("ProcessID",encode_ParamValue("48")));
        listParam.push(new Array("ListType",encode_ParamValue("L")));
        listParam.push(new Array("CalledFrom",encode_ParamValue("EXT")));
        listParam.push(new Array("Option",encode_ParamValue("NewCalendar")));

        var win = openNewWindow(Url,'NewCal',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    }

    function SaveCalChanges()
    {
        try
        {
            clickLink('calendar:btnSaveCalChanges');
        }catch(e){}
        return false;
    }

function CalendarStyleLink(ref)
{
    
    ref.style.textDecoration='underline';
    ref.style.color='green';
    ref.style.cursor='pointer';
}

function CalendarStyleCurrentNormal(ref)
{
    ref.style.textDecoration='none';
    ref.style.color='black';
}

function CalendarStyleNormal(ref)
{
   
    ref.style.textDecoration='none';
    ref.style.color='black';


}
function CalendarStylePartialWorking(ref)
{
    ref.style.textDecoration='underline';
    ref.style.color='black';

}
function CalendarStylePartialWorkingCurrent(ref)
{
    ref.style.textDecoration='underline';
    ref.style.color='black';

}

function CalendarStyleWeekLink(ref)
{
    ref.style.cursor='pointer';
}

/*function setPicklistFocus()
{
    try
    {
        parent.document.getElementById(CurrentPickListId).focus();
    }
    catch(e){}
}*/