
var leftMargin = 5;
var rightMargin = 5;
var middleDivWidth = 6;
var actWidth = 150;
var branchTop = 65;
var actHeight = 30;
var actBranchHeight = 35;
var actTextColor = 'black';
var taskBranchHeight = 20;
var taskHeight = 15;
var taskWidth = 100;
var taskOffset = 20;
var taskPadding = 5;
var startHeight = 40;
var startWidth = 90;
var fontSize = 12;
var fontFamily = 'Arial';
var hoverDiv;
var sample;
var isRTL= false;
/*
 * Plot the case
 **/
function plotCase(obj)
{
    var side = "R";
    sample = obj;
    hoverDiv = $("#hoverDiv");
    var caseDiv = $("#caseDiv");
    caseDiv.empty();
    caseDiv.css({
        overflow: 'Auto',
        fontFamily: fontFamily,
        fontSize: fontSize
    });

    var caseOverFlowDiv = $('<div id="caseOverFlowDiv"></div>');
    caseDiv.append(caseOverFlowDiv);
    var caseHeight = caseDiv.height();
    var caseWidth = caseDiv.width();
    var x = caseDiv.position();
    if(pageDirection == 'rtl')
        isRTL = true;
    if(typeof window.parent.isMobileDevice != 'undefined' && window.parent.isMobileDevice()) {
        var ref = window.parent.document.getElementById('ProgressDiv');
        if(ref){
            caseHeight = ref.parentNode.clientHeight-40;
            caseWidth = ref.parentNode.clientWidth;
            cfPanel=false;
        }
    }
    var divWidth = ((caseWidth - middleDivWidth - 1) / 2) - leftMargin - rightMargin;
    var leftDiv = $('<div id="leftDiv"></div>');
    var middleDiv = $('<div id="middleDiv" class="middleDiv" style="z-index:0;top: 20px; width:' + middleDivWidth + 'px;"></img></div>');
    var rightDiv = $('<div id="righttDiv"></div>');

    caseOverFlowDiv.append(leftDiv);
    caseOverFlowDiv.append(middleDiv);
    caseOverFlowDiv.append(rightDiv);

    var branchObj;
    var arrBranchObjs = new Array();
    var branchHeight = branchTop;
    var panelSide = 'R';
    for (i = 0; i < sample.length; i++)
    {
        //Plot activities left right alternatively starting with value in side variable
        var parentDiv;
        if (side === "L")
        {
            side = "R";
            parentDiv = rightDiv;
        }
        else
        {
            side = "L";
            parentDiv = leftDiv;
        }
        if(panelSide=='R' && cfPanel){
            side = "R";
            parentDiv = rightDiv;  
        } else if(panelSide=='L' && cfPanel){
            side = "L";
            parentDiv = leftDiv;
        }

        if (sample[i].type === '32')
        {
            branchObj = plotCaseActivity(sample[i], parentDiv, side, branchHeight);
        }
        else
        {
            
            branchObj = plotActivity(sample[i], parentDiv, side, branchHeight);
        }

        //Add branch height to give top margin for the next activity to be plotted
        //NOTE: Case activity has variable height, so it can't be constant
        branchHeight += branchObj.height();
        //LeftDiv and Right div require width to be calculated dynamically as per the width of case activity ploteed
        //Width can not be constant
        var tmpWidth = branchObj.width();
        if (tmpWidth > divWidth)
        {
            divWidth = tmpWidth;
        }
        arrBranchObjs.push(branchObj);
    }
    //IF the CaseDiv is bigger than the height of the plotted Case Visualization the readjust the branch height
    if (branchHeight < caseHeight)
    {
        branchHeight = caseHeight;
    }
    if(cfPanel){
//        $('#middleDiv').css({
//            height: '100%'
//        });
               middleDiv.height(branchHeight - 25);

    } else{
        middleDiv.height(branchHeight - 25);
    }
    
    //By giving width and height CaseOverflowDiv will now be able to be scrolled inside CaseDiv
    caseOverFlowDiv.css({
        width: ((divWidth) * 2) + middleDivWidth + 10 + 'px',
        position: 'relative',
        height: branchHeight + 'px'
    });
    if(cfPanel){
        caseOverFlowDiv.css({
            width: '100%',
            height: '100%'
        });
    }

    //Give dynamically calculated width and height to left, middle and right divs within CaseOverflowDiv
    leftDiv.css({
        width: (divWidth) + 'px',
        left: leftMargin + 'px',
        marginRight: rightMargin + 'px',
        //height: caseHeight + 'px',
        'float': 'left',
        position: 'absolute',
        textAlign: '-webkit-right'
    });
    
    if(cfPanel){
        middleDiv.css({
            //height: caseHeight + 'px',
            left: '24px',
            position: 'relative',
            textAlign: 'center'
        });
    } else {
        middleDiv.css({
            //height: caseHeight + 'px',
            left: (divWidth + leftMargin + rightMargin) + 'px',
            position: 'absolute',
            textAlign: 'center'
        });
    }
    rightDiv.css({        
        width: divWidth + 'px',
        position: 'absolute',
        textAlign: '-webkit-left'
    });
    if(cfPanel) {
        rightDiv.css({
            top:'50px',
            'float': 'left',
            left: '26px'
        }); 
    } else{
        rightDiv.css({
            'float': 'right',
            left: (divWidth + (leftMargin * 2) + rightMargin + middleDivWidth) + 'px'
        }); 
    }
    if(cfPanel){
        rightDiv.width($(window).width()-55);
    } 
    //Create ellipse background for Start 
    var stw = (cfPanel)?(startWidth / 2):((startWidth / 2)+50);
    var startSVG = $('<svg height="' + startHeight + '" width="' + ((startWidth)+10) + '">' +
        '<rect width="' + stw + '" height="' + ((startHeight / 2) - 1) +
        '" style="fill:#ffffff;stroke:#424242;stroke-width:1" />'+CVMSG_BROWSER_DOES_NOT_SUPPORT_INLINE_SVG+'</svg>');
    var startDiv = $('<div></div>');
    middleDiv.append(startDiv);
    startDiv.css({
        position: 'absolute',
        left: (cfPanel)?(-((startWidth - middleDivWidth) / 4 - 2)):(-(startWidth - middleDivWidth) / 2) + 'px',
//        left: -((startWidth - middleDivWidth) / 2) + 'px',
        height: startHeight + 'px',
        top: '-5px',
        width: startWidth + 'px',
        zIndex: 1
    });
    var startTextDiv = $('<div class="start">'+CV_START+'</div>');
    middleDiv.append(startTextDiv);
    startTextDiv.css({
        left: -((startWidth - middleDivWidth) / 2) + 'px',
        height: startHeight + 'px',
        top: '-15px',
        lineHeight: startHeight + 'px',
        width: startWidth + 'px'
    });
    startDiv.append(startSVG);
    prettyPrint();
    
    $('#menuBarDiv').css({
        left: caseWidth - 30 + 'px',
        top: '0px',
        display: 'block'
    });
}

/* Stacking of elements in Activity branch is as below
 * branchDiv
 * tempActDiv 
 * [actSpan + actOtherInfoSpan]
 **/
function plotActivity(actObj, parentDiv, side, top)
{
    if(actObj.status === "future")
    {
        return plotFutureActivity(actObj, parentDiv, side, top);
    }
    
    var branchDiv = $('<div class="branch"></div>');
    if(cfPanel){
        branchDiv.css({
            lineHeight: actBranchHeight + 'px',
            position: 'relative',
            left: '0px',
            whiteSpace: 'normal'
        });
    } else {
        branchDiv.css({
            top: top + 'px',
            height: actBranchHeight + 'px',
            lineHeight: actBranchHeight + 'px'
        });
    }
    
    var actOtherInfoSpan = $('<span class="actOtherInfo"></span>').css({
        lineHeight: actBranchHeight + 'px'
    });
    var actHoverData;
    if(actObj.endDate === "")
    {
        actHoverData= '<div>' + actObj.name + '</div><div>' + actObj.startDate + '</div><div>' + actObj.user + '</div>';
    }
    else
    {
        actHoverData = '<div>' + actObj.name + '</div><div>' + actObj.startDate + " - " + actObj.endDate + '</div><div>' + actObj.user + '</div>';
    }
    var actSpan = $('<span onmouseover="event_mouseover(event, \'' + actHoverData + '\');" onmouseout="event_mouseout();" onmousemove="event_mousemove(event);" class="act">' + actObj.name + '</span>');
    if(cfPanel){
        actSpan.css({
            top: ((actBranchHeight - actHeight) / 2) + 'px',
            lineHeight: actHeight-6 + 'px',
            height: actHeight + 'px',
            width: actWidth - 20 + 'px',
            'position': 'relative',
            'display': 'inline-block',
            textAlign : 'center'
        });
    } else {
        actSpan.css({
            top: ((actBranchHeight - actHeight) / 2) + 'px',
            lineHeight: actHeight-6 + 'px',
            height: actHeight + 'px',
            width: actWidth - 20 + 'px'
        });
    }
    var tempActDiv = $('<div></div>');
    if(cfPanel){
        tempActDiv.css({
            textAlign: "left",
            whiteSpace: "normal"
        });
    } else {
        tempActDiv.css({
            height: actBranchHeight + 'px'
        });
    }

    parentDiv.append(branchDiv);
    branchDiv.append(tempActDiv);
    var colorObj = getColorObj(actObj.status, 'A');
    var svgPoints;
    if (side === 'L')
    {
        branchDiv.css({
            right: '0px'
        });
        tempActDiv.append(actOtherInfoSpan.css({
            right: actWidth + 'px'
        }));
        tempActDiv.append(actSpan.css({
            "border-color":colorObj.bk2,
            "border-weight":"3px",
            "border-style":"solid",
            right: '0px'
        }));
        //Case Background
        svgPoints = getActSVGPoints(0, 0, actHeight, actWidth, side);
        tempActDiv.append('<svg style="display:none;position:absolute; z-index: -1; right:0px; top:' + (actBranchHeight - actHeight) / 2 + 'px" height="' + actHeight + '" width="' + actWidth + '">' +
            '<linearGradient id="Gradient' + actObj.id + '"  x1="0%" y1="0%"' +
            'x2="0%" y2="100%"' +
            'spreadMethod="pad">' +
            '<stop style="stop-color:'+colorObj.bk1+'" class="stop1" offset="0%"/>' +
            '<stop style="stop-color:'+colorObj.bk2+'" class="stop2" offset="100%"/>' +
            '</linearGradient>' +
            '<polygon id="poly' + actObj.id + '" points="' + svgPoints + '" style="stroke:'+colorObj.border+';stroke-width:1;" />' +
            'Sorry, your browser does not support inline SVG.' +
            '   <style type="text/css"><![CDATA[' +
            '    #poly' + actObj.id + ' { fill: url(#Gradient' + actObj.id + '); }' +
            '   .stop1 {  }' +
            '  .stop2 {  }' +
            ']]></style>' +
            '</svg>');
    }
    else
    {
        branchDiv.css({
            left: '0px'
        });
        tempActDiv.append(actSpan.css({
            "border-color":colorObj.bk2,
            "border-weight":"3px",
            "border-style":"solid",
            left: '0px'
        }));
        if(cfPanel){
            actOtherInfoSpan.css({
                "display": "inline-block",
                "position": "relative"
            });
        } else {
            actOtherInfoSpan.css({
                left: actWidth + 'px'
            });
        }
        tempActDiv.append(actOtherInfoSpan);
        //Case Background
        svgPoints = getActSVGPoints(0, 0, actHeight, actWidth, side);
        tempActDiv.append('<svg style="display:none;position:absolute; z-index: -1; left:0px; top:' + (actBranchHeight - actHeight) / 2 + 'px" height="' + actHeight + '" width="' + actWidth + '">' +
            '<linearGradient id="Gradient' + actObj.id + '"  x1="0%" y1="0%"' +
            'x2="0%" y2="100%"' +
            'spreadMethod="pad">' +
            '<stop style="stop-color:'+colorObj.bk1+'" class="stop1" offset="0%"/>' +
            '<stop style="stop-color:'+colorObj.bk2+'" class="stop2" offset="100%"/>' +
            '</linearGradient>' +
            '<polygon id="poly' + actObj.id + '" points="' + svgPoints + '" style="stroke:'+colorObj.border+';stroke-width:1;" />' +
            'Sorry, your browser does not support inline SVG.' +
            '   <style type="text/css"><![CDATA[' +
            '    #poly' + actObj.id + ' { fill: url(#Gradient' + actObj.id + '); }' +
            '   .stop1 {  }' +
            '  .stop2 {  }' +
            ']]></style>' +
            '</svg>');
    }
    
    //Act Other Info needs special attention for arabic locale
    var actOtherInfoStrArr = new Array();
    if(actObj.status === "1")
    {
        //Initiated
        if(actObj.user === "")
        {
            if(pageDirection === 'rtl')
            {
                actOtherInfoStrArr.push(CV_STARTED_ON_);
                actOtherInfoStrArr.push(actObj.startDate); 
                createOtherInfoSpanForRTLLanguages(actOtherInfoSpan,actOtherInfoStrArr,side);
            }
            else
            {
                actOtherInfoSpan.html(CV_STARTED_ON_ + actObj.startDate);
            }
        }
        else{
            if(pageDirection === 'rtl')
            {
                actOtherInfoStrArr.push(CV_ASSIGNED_TO_);
                actOtherInfoStrArr.push(actObj.user); 
                actOtherInfoStrArr.push(CV__ON_); 
                actOtherInfoStrArr.push(actObj.startDate); 
                createOtherInfoSpanForRTLLanguages(actOtherInfoSpan,actOtherInfoStrArr,side);
            }
            else
            {
                actOtherInfoSpan.html(CV_ASSIGNED_TO_ + actObj.user + CV__ON_ + actObj.startDate);
            }
        }
    }
    else
    {
        //Completed
        if(actObj.user === "")
        {
            if(pageDirection === 'rtl')
            {
                actOtherInfoStrArr.push(CV_COMPLETED_ON_);
                actOtherInfoStrArr.push(actObj.endDate); 
                createOtherInfoSpanForRTLLanguages(actOtherInfoSpan,actOtherInfoStrArr,side);
            }
            else
            {
                actOtherInfoSpan.html(CV_COMPLETED_ON_ + actObj.endDate);
            }
        }    
    
        else{
            
            if(pageDirection === 'rtl')
            {
                actOtherInfoStrArr.push(CV_COMPLETED_BY_);
                actOtherInfoStrArr.push(actObj.user); 
                actOtherInfoStrArr.push(CV__ON_); 
                actOtherInfoStrArr.push(actObj.endDate); 
                createOtherInfoSpanForRTLLanguages(actOtherInfoSpan,actOtherInfoStrArr,side);
            }
            else
            {
                actOtherInfoSpan.html(CV_COMPLETED_BY_ + actObj.user + CV__ON_ + actObj.endDate);
            }
        }
    }
    
    //Add width of dynamically generated divs and assign it to the parent branch div so as to use it for the 
    // width of LeftDiv and RightDiv in CaseOverflowDiv
    if(cfPanel){
        tempActDiv.width($(window).width()-55);
        branchDiv.width($(window).width()-55);
    } else {
        tempActDiv.width(actSpan.width() + actOtherInfoSpan.width());
        branchDiv.width(tempActDiv.width()+30);
    }

    return branchDiv;
}

/* Stacking of elements in Case Activity branch is as below
 * branchDiv
 * tempActDiv 
 * [actSpan + actOtherInfoSpan]
 * tempTaskDiv 
 * [taskSpan + taskOtherInfoSpan]
 * ...
 **/
function plotCaseActivity(actObj, parentDiv, side, top)
{
    if(actObj.status === "future")
    {
        return plotFutureCaseActivity(actObj, parentDiv, side, top);
    }
    var branchDiv = $('<div class="branch"></div>');
    if(cfPanel){
        branchDiv.css({
            lineHeight: actBranchHeight + 'px',
            position: 'relative',
            left: '0px',
            whiteSpace: 'normal'
        });
    } else {
        branchDiv.css({
            top: top + 'px',
            height: actBranchHeight + 'px',
            lineHeight: actBranchHeight + 'px'
        });
    }

    
    var actOtherInfoSpan = $('<span class="actOtherInfo"></span>').css({
        lineHeight: actBranchHeight + 'px'
    });

    var actHoverData;
    if(actObj.endDate === "")
    {
        actHoverData= '<div>' + actObj.name + '</div><div>' + actObj.startDate + '</div><div>' + actObj.user + '</div>';
    }
    else
    {
        actHoverData= '<div>' + actObj.name + '</div><div>' + actObj.startDate + " - " + actObj.endDate + '</div><div>' + actObj.user + '</div>';
    }
    var actSpan = $('<span onmouseover="event_mouseover(event, \'' + actHoverData + '\');" onmouseout="event_mouseout();" onmousemove="event_mousemove(event);" class="caseAct">' + actObj.name + '</span>')
    if(cfPanel){
        actSpan.css({
            top: ((actBranchHeight - actHeight) / 2) + 'px',
            lineHeight: actHeight-6 + 'px',
            height: actHeight + 'px',
            width: actWidth - 20 + 'px',
            'position': 'relative',
            'display': 'inline-block',
            textAlign : 'center'
        });
    } else {
        actSpan.css({
        top: ((actBranchHeight - actHeight) / 2) + 'px',
        lineHeight: actHeight-6 + 'px',
        height: actHeight + 'px',
        width: actWidth - 20 + 'px'
    });
    }

    var tempActDiv = $('<div></div>')
    if(cfPanel){
        tempActDiv.css({
            textAlign: "left",
            whiteSpace: "normal"
        });
    } else {
        tempActDiv.css({
            height: actBranchHeight + 'px'
        });
    }


    parentDiv.append(branchDiv);
    branchDiv.append(tempActDiv);
    var colorObj = getColorObj(actObj.status, 'C');
    var svgPoints;
    if (side === 'L')
    {
        branchDiv.css({
            right: '0px'
        });
        
        if(cfPanel){
            actOtherInfoSpan.css({
                "display": "inline-block",
                "position": "relative"
            });
        } else {
            actOtherInfoSpan.css({
                right: actWidth + 'px'
            });
        }
        tempActDiv.append(actOtherInfoSpan);
        tempActDiv.append(actSpan.css({
            "border-color":colorObj.bk2,
            "border-weight":"3px",
            "border-style":"solid",
            right: '0px'
        }));
        //Case Background
        svgPoints = getCaseActSVGPoints(0, 0, actHeight, actWidth, side);
        tempActDiv.append('<svg style="display:none;position:absolute; z-index: -1; right:0px; top:' + (actBranchHeight - actHeight) / 2 + 'px" height="' + actHeight + '" width="' + actWidth + '">' +
            '<linearGradient id="Gradient' + actObj.id + '"  x1="0%" y1="0%"' +
            'x2="0%" y2="100%"' +
            'spreadMethod="pad">' +
            '<stop style="stop-color:'+colorObj.bk1+'" class="stop1" offset="0%"/>' +
            '<stop style="stop-color:'+colorObj.bk2+'" class="stop2" offset="100%"/>' +
            '</linearGradient>' +
            '<polygon id="poly' + actObj.id + '" points="' + svgPoints + '" style="stroke:'+colorObj.border+';stroke-width:1;" />' +
            'Sorry, your browser does not support inline SVG.' +
            '   <style type="text/css"><![CDATA[' +
            '    #poly' + actObj.id + ' { fill: url(#Gradient' + actObj.id + '); }' +
            '   .stop1 {  }' +
            '  .stop2 {  }' +
            ']]></style>' +
            '</svg>');
    }
    else
    {
        caseActivityLeft = 0;
        branchDiv.css({
            left: '0px'
        });
        tempActDiv.append(actSpan.css({
            "border-color":colorObj.bk2,
            "border-weight":"3px",
            "border-style":"solid",
            left: '0px'
        }));
        if(cfPanel){
            actOtherInfoSpan.css({
                "display": "inline-block",
                "position": "relative"
            });
        } else {
            actOtherInfoSpan.css({
                left: actWidth + 'px'
            });
        }

        tempActDiv.append(actOtherInfoSpan);
        //Case Background
        svgPoints = getCaseActSVGPoints(0, 0, actHeight, actWidth, side);
        tempActDiv.append('<svg style="display:none;position:absolute; z-index: -1; left:0px; top:' + (actBranchHeight - actHeight) / 2 + 'px" height="' + actHeight + '" width="' + actWidth + '">' +
            '<linearGradient id="Gradient' + actObj.id + '"  x1="0%" y1="0%"' +
            'x2="0%" y2="100%"' +
            'spreadMethod="pad">' +
            '<stop style="stop-color:'+colorObj.bk1+'" class="stop1" offset="0%"/>' +
            '<stop style="stop-color:'+colorObj.bk2+'" class="stop2" offset="100%"/>' +
            '</linearGradient>' +
            '<polygon id="poly' + actObj.id + '" points="' + svgPoints + '" style="stroke:'+colorObj.border+';stroke-width:1;" />' +
            'Sorry, your browser does not support inline SVG.' +
            '   <style type="text/css"><![CDATA[' +
            '    #poly' + actObj.id + ' { fill: url(#Gradient' + actObj.id + '); }' +
            '   .stop1 {  }' +
            '   .stop2 {  }' +
            ']]></style>' +
            '</svg>');
    }
    //Act Other Info needs special attention for arabic locale
    var actOtherInfoStrArr = new Array();
    if(actObj.status === "1")
    {
        if(actObj.user === "")
        {
            if(pageDirection === 'rtl')
            {
                actOtherInfoStrArr.push(CV_STARTED_ON_);
                actOtherInfoStrArr.push(actObj.startDate); 
                createOtherInfoSpanForRTLLanguages(actOtherInfoSpan,actOtherInfoStrArr,side);
            }
            else
            {
                actOtherInfoSpan.html(CV_STARTED_ON_ + actObj.startDate);
            }
        }
        else{
            if(pageDirection === 'rtl')
            {
                actOtherInfoStrArr.push(CV_ASSIGNED_TO_);
                actOtherInfoStrArr.push(actObj.user); 
                actOtherInfoStrArr.push(CV__ON_);
                actOtherInfoStrArr.push(actObj.startDate); 
                createOtherInfoSpanForRTLLanguages(actOtherInfoSpan,actOtherInfoStrArr,side);
            }
            else
            {
                actOtherInfoSpan.html(CV_ASSIGNED_TO_ + actObj.user + CV__ON_ + actObj.startDate);
            }
        }
    }
    else
    {
        if(actObj.user === "")
        {
            if(pageDirection === 'rtl')
            {
                actOtherInfoStrArr.push(CV_COMPLETED_ON_);
                actOtherInfoStrArr.push(actObj.endDate); 
                createOtherInfoSpanForRTLLanguages(actOtherInfoSpan,actOtherInfoStrArr,side);
            }
            else
            {
                actOtherInfoSpan.html(CV_COMPLETED_ON_ + actObj.endDate);
            }
        }
        else{
            if(pageDirection === 'rtl')
            {
                actOtherInfoStrArr.push(CV_COMPLETED_BY_);
                actOtherInfoStrArr.push(actObj.user); 
                actOtherInfoStrArr.push(CV__ON_);
                actOtherInfoStrArr.push(actObj.endDate); 
                createOtherInfoSpanForRTLLanguages(actOtherInfoSpan,actOtherInfoStrArr,side);
            }
            else
            {
                actOtherInfoSpan.html(CV_COMPLETED_BY_ + actObj.user + CV__ON_ + actObj.endDate);
            }
        }
    }
    //Add width of dynamically generated divs and assign it to the parent branch div so as to use it for the 
    // width of LeftDiv and RightDiv in CaseOverflowDiv
    if(cfPanel){
        tempActDiv.width($(window).width()-55);
    } else {
        tempActDiv.width(actSpan.width() + actOtherInfoSpan.width());
    }
    
    var tempTaskListDiv = $('<div></div>');
    branchDiv.append(tempTaskListDiv);
    if (side === 'L')
    {
        tempTaskListDiv.css({
            top: (actBranchHeight) + 'px',
            position: 'absolute',
            right: taskOffset + 'px'
        });
    }
    else
    {
        if(cfPanel){
            tempTaskListDiv.css({
                textAlign: "center",
                whiteSpace: "normal",
                left: taskOffset + 'px',
                position: 'absolute'
            });
        } else {
            tempTaskListDiv.css({
                top: (actBranchHeight) + 'px',
                position: 'absolute',
                left: taskOffset + 'px'
            });
        }
    }

    var tasks = actObj.tasks;
    var taskTop = 0;
    var ttop = 0;
    var tempTaskWidth = 0;
    for (var j = 0; j < tasks.length; j++)
    {
        taskTop += taskPadding;
        var tempTaskDiv = $('<div style="width: 100%"></div>');
        tempTaskListDiv.append(tempTaskDiv);
        var task = tasks[j];
        
        var taskOtherInfoSpan = $('<span class="taskOtherInfo"></span>')

        if(cfPanel){
            if(isRTL){
                taskOtherInfoSpan.css({
                lineHeight: (taskBranchHeight+10) + 'px',
                "display":"inline-block",
                "position":"relative",
                "vertical-align":"bottom"
            });
            }else{
            taskOtherInfoSpan.css({
                lineHeight: (taskBranchHeight+10) + 'px',
                "display":"inline-block",
                "position":"relative"
            }); 
            }
        } else {
            taskOtherInfoSpan.css({
                lineHeight: taskBranchHeight + 'px',
                height: taskBranchHeight + 'px'
            });
        }
        var taskHoverData;
        if(task.status === "-1")
        {
            taskHoverData= '<div>' + task.name + '</div><div>'+CV_READY+'</div>';    
        }
        else if(task.status === "702")
        {
            taskHoverData= '<div>' + task.name + '</div><div>' + task.startDate + " - "+ task.endDate + '</div><div>' + task.user + '</div>';
        }
        else if(task.status === "703")
        {
            taskHoverData= '<div>' + task.name + '</div><div>' + task.endDate + '('+CV_REVOKED_ON+')</div><div>' + task.user + '</div>';
        }
        else if(task.status === "708")
        {
            taskHoverData= '<div>' + task.name + '</div><div>' + task.endDate + '('+CV_DECLINED_ON+')</div><div>' + task.user + '</div>';
        }
        else if(task.status === "-11")
        {
            taskHoverData= '<div>' + task.name + '</div><div>'+CV_WAITING+'</div>';
        }
        else if(task.status === "-12")
        {
            taskHoverData= '<div>' + task.name + '</div><div>'+CV_READY+'</div>';
        }
        else
        {
            if(task.dueDate === "")
            {
                taskHoverData= '<div>' + task.name + '</div><div>' + task.startDate + '</div><div>' + task.user + '</div>';
            }else

            {
                taskHoverData= '<div>' + task.name + '</div><div>' + task.startDate + ' - ' + task.dueDate + '(' + CV_DUE_ON + ')</div><div>' + task.user + '</div>';
            }
        }
        
        var taskSpan = $('<span onmouseover="event_mouseover(event, \'' + taskHoverData + '\');" onmouseout="event_mouseout();" onmousemove="event_mousemove(event);"  class="task ' + getColorClass(task.status) + '">' + task.name + '</span>');

        if(cfPanel){
            taskSpan.css({
                //top: ((taskBranchHeight - taskHeight) / 2 + taskTop) + 'px',
                lineHeight: (taskHeight - (taskBranchHeight - taskHeight) / 2)+2.5 + 'px',
                height: taskHeight+5 + 'px',
                width: taskWidth + 'px',
                top: (taskBranchHeight - taskHeight) / 2 + 'px',
                "display":"inline-block",
                "position":"relative",
                textAlign:"center"
            });
        } else {
            taskSpan.css({
                //top: ((taskBranchHeight - taskHeight) / 2 + taskTop) + 'px',
                lineHeight: (taskHeight - (taskBranchHeight - taskHeight) / 2)+2.5 + 'px',
                height: taskHeight+5 + 'px',
                width: taskWidth + 'px',
                top: (taskBranchHeight - taskHeight) / 2 + 'px'
            });
        }

        if (side === 'L')
        {
            tempTaskDiv.css({
                right: '0px'
            });
            tempTaskDiv.append(taskOtherInfoSpan.css({
                right: taskWidth + 'px'
            }));
            tempTaskDiv.append(taskSpan.css({
                right: '0px'
            }));
        }
        else
        {
            tempTaskDiv.css({
                left: '0px'
            });
            tempTaskDiv.append(taskSpan.css({
                left: '0px'
            }));
            if(!cfPanel) {
                tempTaskDiv.append(taskOtherInfoSpan.css({
                    left: taskWidth + 'px'
                }));
            } else {
                if(isRTL){
                   tempTaskDiv.append(taskOtherInfoSpan.css({
                    left: '15px'
                })); 
                }else{
                tempTaskDiv.append(taskOtherInfoSpan.css({
                    left: '0px'
                }));
                }
            }
        }
        //Task Other Info needs special attention for arabic locale
        // Bug Id -61530    
        var taskOtherInfoStrArr = new Array();
        if(task.status === "-11")
        {
            taskOtherInfoSpan.html(CV_WAITING);
        }
        else if(task.status === "-12")
        {
            taskOtherInfoSpan.html(CV_READY);
        }
        else if(task.status === "701")
        {
            if(pageDirection === 'rtl')
            {
                taskOtherInfoStrArr.push(CV_ASSIGNED_TO_);
                taskOtherInfoStrArr.push(task.user);
                taskOtherInfoStrArr.push(CV__ON_);
                taskOtherInfoStrArr.push(task.startDate);
                createOtherInfoSpanForRTLLanguages(taskOtherInfoSpan,taskOtherInfoStrArr,side);
            }
            else
            {
                taskOtherInfoSpan.html(CV_ASSIGNED_TO_ + task.user + CV__ON_ + task.startDate);
            }
        }
        else if(task.status === "708")
        {
            if(pageDirection === 'rtl')
            {
                taskOtherInfoStrArr.push(CV_DECLINED_BY);
                taskOtherInfoStrArr.push(task.user);
                taskOtherInfoStrArr.push(CV__ON_);
                taskOtherInfoStrArr.push(task.startDate);
                createOtherInfoSpanForRTLLanguages(taskOtherInfoSpan,taskOtherInfoStrArr,side);
            }
            else
            {
                taskOtherInfoSpan.html(CV_DECLINED_BY + task.user + CV__ON_ + task.startDate);
            }
        }
        else
        {
            if(task.status === "703")
            {
                if(pageDirection === 'rtl')
                {
                    taskOtherInfoStrArr.push(CV_REVOKED_BY);
                    taskOtherInfoStrArr.push(task.user);
                    taskOtherInfoStrArr.push(CV__ON_);
                    taskOtherInfoStrArr.push(task.endDate);
                    createOtherInfoSpanForRTLLanguages(taskOtherInfoSpan,taskOtherInfoStrArr,side);
                }
                else
                {
                    taskOtherInfoSpan.html(CV_REVOKED_BY + task.user + CV__ON_ + task.endDate);
                }
            }
            else
            {
                if(pageDirection === 'rtl')
                {
                    taskOtherInfoStrArr.push(CV_COMPLETED_BY_);
                    taskOtherInfoStrArr.push(task.user);
                    taskOtherInfoStrArr.push(CV__ON_);
                    taskOtherInfoStrArr.push(task.endDate);
                    createOtherInfoSpanForRTLLanguages(taskOtherInfoSpan,taskOtherInfoStrArr,side);
                }
                else
                {
                    taskOtherInfoSpan.html(CV_COMPLETED_BY_ + task.user + CV__ON_ + task.endDate);
                }
            }
        }
        
            if(cfPanel){
                tempActDiv.width($(window).width()-55);
            } else {
                tempActDiv.width(actSpan.width() + actOtherInfoSpan.width());
            }
        if (tempTaskWidth < taskSpan.width() + taskOtherInfoSpan.width())
        {
            tempTaskWidth = taskSpan.width() + taskOtherInfoSpan.width();
        }
        tempTaskDiv.css({
            position: 'absolute',
            top: taskTop + 'px',
            height: taskBranchHeight + 'px',
            lineHeight: taskBranchHeight + 'px',
            width: (taskSpan.width() + taskOtherInfoSpan.width()) + 'px'
        });
        if(cfPanel){
           tempTaskDiv.css({
               textAlign:"left",
               position:"relative",
               width:($(window).width()-90) + 'px'
           }); 
        }
        taskTop += taskBranchHeight;
        ttop+=taskOtherInfoSpan.height()+tempTaskDiv.height();
    }
    if (tempTaskWidth < tempActDiv.width())
    {
        tempTaskWidth = tempActDiv.width()+50;
    }
   if(cfPanel){
        branchDiv.width($(window).width()-55);
    } else {
        branchDiv.width(tempTaskWidth);
    }
    if(cfPanel){
        branchDiv.height(ttop + actBranchHeight);
    } else {
        branchDiv.height(taskTop + actBranchHeight);
    }

    return branchDiv;
}

/*
 * branchDiv
 * tempActDiv
 * [actSpan + actOtherInfoSpan]
 */
function plotFutureActivity(actObj, parentDiv, side, top)
{
    
    var branchDiv = $('<div class="branch"></div>').css({
        top: top + 'px',
        height: actBranchHeight + 'px',
        lineHeight: actBranchHeight + 'px'
    });
    var actSpan = $('<span class="futureAct">' + actObj.name + '</span>').css({
        top: (((actBranchHeight - actHeight) / 2)+10) + 'px',
        lineHeight: actHeight-6 + 'px',
        height: actHeight + 'px',
        width: actWidth - 20 + 'px'
    });
    var tempActDiv = $('<div></div>').css({
        height: actBranchHeight + 'px'
    });

    parentDiv.append(branchDiv);
    branchDiv.append(tempActDiv);
    var svgPoints;
    if (side === 'L')
    {
        branchDiv.css({
            right: '0px'
        });
        tempActDiv.append(actSpan.css({
            "border-color":"gray",
            "border-width":"3px",
            "border-style":"dashed",
            right: '0px'
        }));
        //Case Background
        svgPoints = getActSVGPoints(0, 0, actHeight, actWidth, side);
        tempActDiv.append('<svg style="display:none;position:absolute; z-index: -1; right:0px; top:' + (actBranchHeight - actHeight) / 2 + 'px" height="' + actHeight + '" width="' + actWidth + '">' +
            '<linearGradient id="Gradient' + actObj.id + '"  x1="0%" y1="0%"' +
            'x2="0%" y2="100%"' +
            'spreadMethod="pad">' +
            '<stop style="stop-color:lightgrey" class="stop1" offset="0%"/>' +
            '<stop style="stop-color:lightgrey" class="stop2" offset="100%"/>' +
            '</linearGradient>' +
            '<polygon id="poly' + actObj.id + '" points="' + svgPoints + '" style="stroke:grey;stroke-width:1;stroke-dasharray: 5,5" />' +
            'Sorry, your browser does not support inline SVG.' +
            '   <style type="text/css"><![CDATA[' +
            '    #poly' + actObj.id + ' { fill: url(#Gradient' + actObj.id + '); }' +
            '   .stop1 {  }' +
            '  .stop2 {  }' +
            ']]></style>' +
            '</svg>');
    }
    else
    {
        branchDiv.css({
            left: '0px'
        });
        tempActDiv.append(actSpan.css({
            "border-color":"gray",
            "border-width":"3px",
            "border-style":"dashed",
            left: '0px'
        }));
        //Case Background
        svgPoints = getActSVGPoints(0, 0, actHeight, actWidth, side);
        tempActDiv.append('<svg style="display:none;position:absolute; z-index: -1; left:0px; top:' + (actBranchHeight - actHeight) / 2 + 'px" height="' + actHeight + '" width="' + actWidth + '">' +
            '<linearGradient id="Gradient' + actObj.id + '"  x1="0%" y1="0%"' +
            'x2="0%" y2="100%"' +
            'spreadMethod="pad">' +
            '<stop style="stop-color:lightgrey" class="stop1" offset="0%"/>' +
            '<stop style="stop-color:lightgrey" class="stop2" offset="100%"/>' +
            '</linearGradient>' +
            '<polygon id="poly' + actObj.id + '" points="' + svgPoints + '" style="stroke:grey;stroke-width:1;stroke-dasharray: 5,5" />' +
            'Sorry, your browser does not support inline SVG.' +
            '   <style type="text/css"><![CDATA[' +
            '    #poly' + actObj.id + ' { fill: url(#Gradient' + actObj.id + '); }' +
            '   .stop1 {  }' +
            '  .stop2 {  }' +
            ']]></style>' +
            '</svg>');
    }
    
    tempActDiv.width(actSpan.width());
    branchDiv.width(tempActDiv.width());
    return branchDiv;
}

/*
 * branchDiv
 * tempActDiv 
 * [actSpan + actOtherInfoSpan]
 */
function plotFutureCaseActivity(actObj, parentDiv, side, top)
{
    var branchDiv = $('<div class="branch"></div>').css({
        top: top + 'px',
        height: actBranchHeight + 'px',
        lineHeight: actBranchHeight + 'px'
    });
    var actSpan = $('<span class="futureAct">' + actObj.name + '</span>').css({
        top: ((actBranchHeight - actHeight) / 2) + 'px',
        lineHeight: actHeight-6 + 'px',
        height: actHeight + 'px',
        width: actWidth - 20 + 'px'
    });
    var tempActDiv = $('<div></div>').css({
        height: actBranchHeight + 'px'
    });

    parentDiv.append(branchDiv);
    branchDiv.append(tempActDiv);
    var svgPoints;
    if (side === 'L')
    {
        branchDiv.css({
            right: '0px'
        });
        tempActDiv.append(actSpan.css({
            "border-color":"gray",
            "border-width":"3px",
            "border-style":"dashed",
            right: '0px'
        }));
        //Case Background
        svgPoints = getCaseActSVGPoints(0, 0, actHeight, actWidth, side);
        tempActDiv.append('<svg style="display:none;position:absolute; z-index: -1; right:0px; top:' + (actBranchHeight - actHeight) / 2 + 'px" height="' + actHeight + '" width="' + actWidth + '">' +
            '<linearGradient id="Gradient' + actObj.id + '"  x1="0%" y1="0%"' +
            'x2="0%" y2="100%"' +
            'spreadMethod="pad">' +
            '<stop style="stop-color:lightgrey" class="stop1" offset="0%"/>' +
            '<stop style="stop-color:lightgrey" class="stop2" offset="100%"/>' +
            '</linearGradient>' +
            '<polygon id="poly' + actObj.id + '" points="' + svgPoints + '" style="stroke:grey;stroke-width:1;stroke-dasharray: 5,5" />' +
            'Sorry, your browser does not support inline SVG.' +
            '   <style type="text/css"><![CDATA[' +
            '    #poly' + actObj.id + ' { fill: url(#Gradient' + actObj.id + '); }' +
            '   .stop1 {  }' +
            '  .stop2 {  }' +
            ']]></style>' +
            '</svg>');
    }
    else
    {
        branchDiv.css({
            left: '0px'
        });
        tempActDiv.append(actSpan.css({
            "border-color":"gray",
            "border-width":"3px",
            "border-style":"dashed",
            left: '0px'
        }));
        //Case Background
        svgPoints = getCaseActSVGPoints(0, 0, actHeight, actWidth, side);
        tempActDiv.append('<svg style="display:none;position:absolute; z-index: -1; left:0px; top:' + (actBranchHeight - actHeight) / 2 + 'px" height="' + actHeight + '" width="' + actWidth + '">' +
            '<linearGradient id="Gradient' + actObj.id + '"  x1="0%" y1="0%"' +
            'x2="0%" y2="100%"' +
            'spreadMethod="pad">' +
            '<stop style="stop-color:lightgrey" class="stop1" offset="0%"/>' +
            '<stop style="stop-color:lightgrey" class="stop2" offset="100%"/>' +
            '</linearGradient>' +
            '<polygon id="poly' + actObj.id + '" points="' + svgPoints + '" style="stroke:grey;stroke-width:1;stroke-dasharray: 5,5" />' +
            'Sorry, your browser does not support inline SVG.' +
            '   <style type="text/css"><![CDATA[' +
            '    #poly' + actObj.id + ' { fill: url(#Gradient' + actObj.id + '); }' +
            '   .stop1 {  }' +
            '  .stop2 {  }' +
            ']]></style>' +
            '</svg>');
    }
    
    tempActDiv.width(actSpan.width());
    branchDiv.width(tempActDiv.width());
    return branchDiv;
}

/*
 * Get color coding for activity / case activity SVG graphics
 **/
function getColorObj(status, type)
{
    var colorObj;
    if(status === '4')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"#F7931E", 
                bk2:"#F7931E", 
                border:"#F7931E"
            };
        }
        else
        {
            colorObj = {
                bk1:"#F7931E", 
                bk2:"#F7931E", 
                border:"#F7931E"
            };
        }
    }
    else if (status === '-1')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"#009245", 
                bk2:"#009245", 
                border:"#009245"
            };
        }
        else
        {
            colorObj = {
                bk1:"#009245", 
                bk2:"#009245", 
                border:"#009245"
            };
        }
       
    }
    else if (status === '1' || status === '701')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"#29ABE2", 
                bk2:"#29ABE2", 
                border:"#29ABE2"
            };
        }
        else
        {
            colorObj = {
                bk1:"#29ABE2", 
                bk2:"#29ABE2", 
                border:"#29ABE2"
            };
        }
    }
    else if (status === '2' || status === '702')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"#0071BC", 
                bk2:"#0071BC", 
                border:"#0071BC"
            };
        }
        else
        {
            colorObj = {
                bk1:"#0071BC", 
                bk2:"#0071BC", 
                border:"#0071BC"
            };
        }
    }
    else if (status === '703')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"#662D91", 
                bk2:"#662D91", 
                border:"#662D91"
            };
        }
        else
        {
            colorObj = {
                bk1:"#662D91", 
                bk2:"#662D91", 
                border:"#662D91"
            };
        }
    }
    else if (status === '5')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"#662D91", 
                bk2:"#662D91", 
                border:"#662D91"
            };
        }
        else
        {
            colorObj = {
                bk1:"#662D91", 
                bk2:"#662D91", 
                border:"#662D91"
            };
        }
    }
    else
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"#F7931E", 
                bk2:"#F7931E", 
                border:"#F7931E"
            };
        }
        else
        {
            colorObj = {
                bk1:"#F7931E", 
                bk2:"#F7931E", 
                border:"#F7931E"
            };
        }
    }
    return colorObj;
}

/*function getColorObj(status, type)
{
    var colorObj;
    if(status === '4')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"white", 
                bk2:"#FFC38D", 
                border:"#F7931E"
            };
        }
        else
        {
            colorObj = {
                bk1:"#FFC38D", 
                bk2:"white", 
                border:"#F7931E"
            };
        }
    }
    else if (status === '-1')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"white", 
                bk2:"#00FF73", 
                border:"#009245"
            };
        }
        else
        {
            colorObj = {
                bk1:"#00FF73", 
                bk2:"white", 
                border:"#009245"
            };
        }
       
    }
    else if (status === '1' || status === '701')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"white", 
                bk2:"#55D3FF", 
                border:"#29ABE2"
            };
        }
        else
        {
            colorObj = {
                bk1:"#55D3FF", 
                bk2:"white", 
                border:"#29ABE2"
            };
        }
    }
    else if (status === '2' || status === '702')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"white", 
                bk2:"#03A5FF", 
                border:"#0071BC"
            };
        }
        else
        {
            colorObj = {
                bk1:"#03A5FF", 
                bk2:"white", 
                border:"#0071BC"
            };
        }
    }
    else if (status === '703')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"white", 
                bk2:"#A845FF", 
                border:"#662D91"
            };
        }
        else
        {
            colorObj = {
                bk1:"#A845FF", 
                bk2:"white", 
                border:"#662D91"
            };
        }
    }
    else if (status === '5')
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"white", 
                bk2:"#A8A8A8", 
                border:"#662D91"
            };
        }
        else
        {
            colorObj = {
                bk1:"#A8A8A8", 
                bk2:"white", 
                border:"#662D91"
            };
        }
    }
    else
    {
        if(type === 'C')
        {
            colorObj = {
                bk1:"white", 
                bk2:"#FFC38D", 
                border:"#F7931E"
            };
        }
        else
        {
            colorObj = {
                bk1:"#FFC38D", 
                bk2:"white", 
                border:"#F7931E"
            };
        }
    }
    return colorObj;
}*/

/*
 * Get color class for activities / tasks based on state
 **/
function getColorClass(status)
{
    if (status === '4')
    {
        return 'orangeGradient';
    }
    else if (status === '-1')
    {
        return 'greenGradient';
    }
    else if (status === '701' || status === '1')
    {
        return 'blueLightGradient';
    }
    else if (status === '702' || status === '2')
    {
        return 'blueDarkGradient';
    }
    else if (status === '703')
    {
        return 'violetGradient';
    }
     else if (status === '708')
    {
        return 'redGradient';
    }
    else if (status === '5')
    {
        return 'greyGradient';
    }
    else if (status === '-11') //waiting task
    {
        return 'redGradientDark';
    }
    else if (status === '-12') //ready task
    {
        return 'blueReady';
    }
    else
    {
        return 'orangeGradient';
    }
}

//Get Polygon SVG points for case activity
function getCaseActSVGPoints(left, top, height, width)
{
    height -= 2;
    width -= 2;
    left = left + 1;
    top = top + 1;
    var bottom = top + height;
    var right = left + width;
    var yMid = top + (height / 2);
    var xRMargin = right - (height / 2);
    var xLMargin = left + (height / 2);
    return left + "," + yMid + " " +
    xLMargin + "," + top + " " +
    xRMargin + "," + top + " " +
    right + "," + yMid + " " +
    xRMargin + "," + bottom + " " +
    xLMargin + "," + bottom + " ";
}

//Get Polygon SVG points for activity
function getActSVGPoints(left, top, height, width, side)
{
    height -= 2;
    width -= 2;
    left = left + 1;
    top = top + 1;
    var bottom;
    var right;
    var yMid;
    if (side === 'L')
    {
        bottom = top + height;
        right = left + width;
        yMid = top + (height / 2);
        var xRMargin = right - (height / 2);
        return left + "," + top + " " +
        xRMargin + "," + top + " " +
        right + "," + yMid + " " +
        xRMargin + "," + bottom + " " +
        left + "," + bottom + " ";
    }
    else
    {
        bottom = top + height;
        right = left + width;
        yMid = top + (height / 2);
        var xLMargin = left + (height / 2);
        return left + "," + yMid + " " +
        xLMargin + "," + top + " " +
        right + "," + top + " " +
        right + "," + bottom + " " +
        xLMargin + "," + bottom + " ";
    }
}

function showShapesLegendDiv()
{
    var legendDiv = $('#legendDiv');
    //legendDiv.html('');
    var legendPlaceHolderDiv = $('<div></div>');
    var initiatedDiv = $('<div style="position:relative;padding:' + taskPadding + 'px"><span class="blueLightGradient" style="float:left;height:'+taskHeight+'px;width:'+taskWidth+'px;"></span><div style="float:right">Initiated</div></div>');
    var completedDiv = $('<div style="position:relative;padding:' + taskPadding + 'px"><div class="blueDarkGradient" style="float:left;height:'+taskHeight+'px;width:'+taskWidth+'px;"></div><div style="float:right">Completed</div></div>');
    var revokedDiv = $('<div style="position:relative;padding:' + taskPadding + 'px"><div class="violetGradient" style="float:left;height:'+taskHeight+'px;width:'+taskWidth+'px;"></div><div style="float:right">Revoked</div></div>');
    var futureDiv = $('<div style="position:relative;padding:' + taskPadding + 'px"><div class="futureAct" style="float:left;height:'+taskHeight+'px;width:'+taskWidth+'px;"></div><div style="float:right">Future</div></div>');
 
    legendPlaceHolderDiv.append(initiatedDiv);
    legendPlaceHolderDiv.append(completedDiv);
    legendPlaceHolderDiv.append(revokedDiv);
    legendPlaceHolderDiv.append(futureDiv);
    legendDiv.append(legendPlaceHolderDiv);
    legendDiv.css({
        right: '20px',
        top: '5px',
        display: 'block',
        "float": 'right'
    });
}


function showLegendDiv()
{
    $('#legendDiv').toggleClass('show');
}

/*
 *Create absolute span stacking for RTL Languages
 **/
function createOtherInfoSpanForRTLLanguages(actOtherInfoSpan,actOtherInfoStrArr,side)
{
    var tmpSpan;
    var offset = 0;
    var i;
    if(side === 'L')
    {
        i=0;
        for(;i < actOtherInfoStrArr.length;i++)
        {
            tmpSpan = $('<span>' + actOtherInfoStrArr[i] + '</span>');
            actOtherInfoSpan.append(tmpSpan);
            tmpSpan.css({
                position: 'absolute',
                right: offset + 'px'
            });
            offset += tmpSpan.width();
        }
    }
    else
    {
        i = actOtherInfoStrArr.length - 1;
        for(;i >= 0;i--)
        {
            tmpSpan = $('<span>' + actOtherInfoStrArr[i] + '</span>');
            actOtherInfoSpan.append(tmpSpan);
            if(isRTL){
            tmpSpan.css({
                position: 'relative'
            });
            }else{
                tmpSpan.css({
                position: 'absolute',
                left: offset + 'px'
            });
            }
            offset += tmpSpan.width();
        }
    }
}

function cvRefresh()
{
   var str= window.location.href;
   var surl= window.location.pathname;
   var RID=getRequestToken(surl);
   var nextAmp;
    
    if(str.indexOf('WD_RID')>0)
                        {
                           nextAmp= str.indexOf('&',str.indexOf('WD_RID'));
                           if(nextAmp==-1)
                               nextAmp=str.length;
                           str=str.replace(str.substring(str.indexOf('WD_RID')-1,nextAmp),"");
                        }
                    str = str+"&WD_RID="+RID;
                    window.location.href=encode_ParamValue(str);
}
