
var typedMsg = "";// to prevent clearing the message from textarea when user receives a message of another user
var calledFromFedContent = false;
var roomId = '';

function doInit(){
    roomId = document.getElementById("chatfram:bp:iframeId").value;    
    
    fedContent('');
    document.getElementById('chatfram:bp:msgArea').focus();
}

function fedContent(data)
{   
    try{
        if(data == '' || (typeof data == 'undefined')){
            /*if(typeof window.parent.oldJsonData != 'undefined'){
                document.getElementById("chatfram:json").value =  window.parent.oldJsonData;
              }

              window.parent.oldJsonData = "";*/
            if(messageData.length>0){
                document.getElementById("chatfram:json").value =  messageData;
            }
        } else{           
            document.getElementById("chatfram:json").value =  data;
        }
        
        if(bChatMinimized){
            var chatIFrame = window.parent.document.getElementById("popupIFrame_"+roomId);
            var height = 300;
            
            chatIFrame.style.left = 10+"px";
            chatIFrame.style.top = (window.parent.document.documentElement.clientHeight-height-5)+'px';
            chatIFrame.style.height = height+'px';            
            bChatMinimized = false;
        }
        componentNotifier();
        clickLink("chatfram:updateMsg");        
    }catch(e){
        //alert(e.description)                    
    }
    calledFromFedContent = true;
}

function getFocus(data){
    if(data.status == "complete"){        
        typedMsg = document.getElementById("chatfram:bp:msgArea").value;
    }
    
    if( data.status == 'success' ){        
        try
        {
            window.focus();
        }
        catch(ex){}
        
        document.getElementById("chatfram:bp:msgArea").focus();
        if(calledFromFedContent){
            // if this method is called for receiver then it should not clear text area.
            document.getElementById("chatfram:bp:msgArea").value = typedMsg; 
        }                   
        typedMsg = "";
        
        var objDiv = document.getElementById("msgdiv");
        objDiv.scrollTop = objDiv.scrollHeight;
        
        calledFromFedContent = false;
    }
}            

function clickbut(e){
    try{
        evt = e || window.event;            
        if ( evt.keyCode == 13){
            var msgArea = document.getElementById("chatfram:bp:msgArea");
            var byUserName = document.getElementById("chatfram:bp:senderName").value;  
            var byUserIndex = document.getElementById("chatfram:bp:senderIndex").value;                
            
            var msg = msgArea.value;            
            
            msgArea.value = msg.replace(/(\r\n|\n|\r|\t)/gm,"");
            if(msgArea.value.length == 0 ) {
                return;
            }
            
            msgArea.value = "";
            
            var mes = {
                message: encode_utf8(msg), 
                by: byUserName, 
                byId : byUserIndex , 
                sendTime : getdate()
            };//Bug 75320            
            
            var Container = { 
                FromUserIndex : byUserIndex,
                FromUserName : byUserName,   
                Msg: mes,
                SaveConversation : "Y"
            };            
            
            document.getElementById("chatfram:json").value = JSON.stringify(Container);            
            clickLink("chatfram:updateMsg");
            
            window.parent.broadcastEvent(mes, "broadcastMessage");                        
        }
    }catch(ex){
    //alert(ex);
    }
} 

Number.prototype.padLeft = function(base,chr){
    var  len = (String(base || 10).length - String(this).length)+1;
    return len > 0? new Array(len).join(chr || '0')+this : this;
}

var MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']; //variable for returning month name 

function getdate(){    
    var d = new Date,
    dformat = [d.getDate().padLeft(),
    ( MONTH_NAMES[d.getMonth()])
    ].join('-')+
    ' ' +
    [d.getHours().padLeft(),
    d.getMinutes().padLeft(),
    d.getSeconds().padLeft()].join(':');

    return dformat;        
}

var NOTIFY_PROBE_TIME = 500;
var NOTIFY_REPEAT = 2
var NOTIFY_THRESHOLD = 2*NOTIFY_REPEAT;

function componentNotifier() {
    var headerBPId = null;    
    
    if((document.getElementById("chatfram:bp:bluepanel")!=null) && (document.getElementById("chatfram:bp:bluepanel").style.display!="none")) {
        headerBPId = "chatfram:bp:bluepanel";        
    }
    
    if(headerBPId == null){
        return;
    }

    setTimeout("blinkComponent(1)", NOTIFY_PROBE_TIME);    
}


function blinkComponent(notifyCtr){
    if(notifyCtr <= NOTIFY_THRESHOLD) {
        var contHeaderObj = null;
        if(notifyCtr%2 == 0){
            contHeaderObj = document.getElementsByClassName('headerTitle2')[0];
            removeCSS(contHeaderObj, 'headerTitle2');
            addCSS(contHeaderObj, 'headerTitle');               
        } else {                
            contHeaderObj = document.getElementsByClassName('headerTitle')[0];
            removeCSS(contHeaderObj, 'headerTitle');
            addCSS(contHeaderObj, 'headerTitle2');
        }

        if(notifyCtr < NOTIFY_THRESHOLD){
            notifyCtr++;
            setTimeout("blinkComponent("+notifyCtr+")",NOTIFY_PROBE_TIME);
        }        
    }     
}

function closeBp(){             
    try{        
        rootWindowRef.removeIFramePopup(roomId);               
    } catch(e){        
        window.parent.removeIFramePopup(roomId);        
    }
}

var bChatMinimized = false;
function minimizeBp(ref){    
    var chatIFrame = window.parent.document.getElementById("popupIFrame_"+roomId);
    var height = 300;
    
    if(bChatMinimized){   
        chatIFrame.style.left = 10+"px";
        chatIFrame.style.top = (window.parent.document.documentElement.clientHeight-height-5)+'px';
        chatIFrame.style.height = height+'px';        
        
        changeImage('min_icon.png', 'minimizehw.png', MINIMIZE);
        
        bChatMinimized = false
    } else{                   
        chatIFrame.style.height = '23px';
        chatIFrame.style.top = (window.parent.document.documentElement.clientHeight - 31)+"px";
        chatIFrame.style.left = 10+"px";        
        
        changeImage('max_icon.png', 'maximizehw.png', MAXIMIZE);    
        
        bChatMinimized = true;
    }
}               

function changeImage(onMouseOutImage, onMouseOverImage, title){    
    // Changes the maximize image to restore image    
    var maxImgId = document.getElementById("minimizeImg");
    if(maxImgId != null){
        if(title==MAXIMIZE)
            maxImgId.className="oap-icon-maximize oa-tool-margin-r";
        else
            maxImgId.className="oap-icon-minimize oa-tool-margin-r";
//        maxImgId.onmouseout = function (){onmouseoutEvent(this,onMouseOutImage);};
//        maxImgId.onmouseover = function (){onmouseoverEvent(this,onMouseOverImage);};
//        maxImgId.src = "/webdesktop/resources/images/"+onMouseOutImage;
        maxImgId.setAttribute("title", title);
    }
}
function readChatMessage(){
    try{
        var chatTitle = document.getElementById('chatfram:bp:framTitle').value;
        var byUserName = document.getElementById("chatfram:bp:senderName").value;
        var byUserIndex = document.getElementById("chatfram:bp:senderIndex").value;
        var chatMessage = {
            chatTitle: chatTitle,
            by: byUserName,
            byId : byUserIndex ,
            sendTime : getdate()
        };
         window.parent.readChatMsgEvent(chatMessage, "broadcastMessage");
    }catch(ex){
    //alert(ex);
    }
}