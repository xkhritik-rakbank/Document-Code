
var version;
var opr = '';
function getNewVersionNo()
{
    if (error == "true") {

    } else {
        if (version != null || version != 'null' || version != "") {
            pos = version.indexOf(".");
            if (pos != -1)
            {
                pref = version.substring(0, pos);
                suf = new Number(version.substring(pos + 1, pos + 2));
                // PR:2365 begin
                if (suf > 8)
                {
                    pre = new Number(pref);
                    pre = pre + 1;
                    suf = 0;
                } else
                {
                    pre = pref;
                    suf = suf + 1;
                }
                // PR:2365 end
                // version = pre + "."+suf + "0";
                version = pre + "." + suf;
            } else
                version = version + ".1";
        }
    }
    
    return version;
}

function init()
{
    document.getElementById('checkInForm:txtVersionComment').value = "";
    document.getElementById('checkInForm:DocId').value = DocId;
    document.getElementById('checkInForm:DocName').value = DocName;
    document.getElementById('checkInForm:ISIndex').value = ISIndex;
    document.getElementById('checkInForm:pid').value = pid;
    document.getElementById('checkInForm:wid').value = wid;
    document.getElementById('checkInForm:taskid').value = taskid;
    document.getElementById('checkInForm:UploadLimit').value = uploadLimit;
    document.getElementById('checkInForm:UploadLimitUnit').value = upLoadLimitUnit;
    document.getElementById('checkInForm:Version').value = version;    
}

function beforeChkin()
{
    var processname = window.opener.strprocessname;
    var activityname = window.opener.stractivityName;
    var username = window.opener.strUsername;
    var docType;
    var strPar = "(";
    if (DocName.lastIndexOf(strPar)!=-1)
        {
            var pos= DocName.lastIndexOf(strPar);
            docType = DocName.substring(0,pos);
        }
    else 
        docType = DocName;
    var strDataDefList;
    strDataDefList= customDataDefName(processname,activityname,username,docType);
    document.getElementById('checkInForm:DataDefList').value = strDataDefList;
    if(opr == 'C')
    {   
        var fileobj;
        if(googleIntegrated){
            if(document.getElementById('saveOptions1').checked){
                fileobj = document.getElementById('checkInForm:fileupload');
            }
            else{
                fileobj = document.getElementById('checkInForm:fileuploadDrive');
            }
        }
        else{
            fileobj = document.getElementById('checkInForm:fileupload');
        }
        if(Trim(fileobj.value) == ""){
                customAlert(SELECT_DOC_TO_UPLOAD);
                fileobj.focus();
                RemoveIndicator("application");
  //              hidePopupMask();
                return false;
        }
        else if(Trim(fileobj.value) != "")
        {
            if(document.getElementById("checkInForm:GDocMimeType")!=null&&(document.getElementById("checkInForm:GDocMimeType").value=="application/vnd.google-apps.document"
                ||document.getElementById("checkInForm:GDocMimeType").value=="application/vnd.google-apps.presentation"||document.getElementById("checkInForm:GDocMimeType").value=="application/vnd.google-apps.spreadsheet")){
                var FileExt;
                if(document.getElementById("checkInForm:GDocMimeType").value=="application/vnd.google-apps.document"){
                    FileExt="docx";
                }
                else if(document.getElementById("checkInForm:GDocMimeType").value=="application/vnd.google-apps.spreadsheet"){
                    FileExt="xlsx";
                }
                else{
                    FileExt="pptx";
                }
                if (!validateUploadDocType(FileExt ,docType))
                {
                    customAlert(INVALID_FILE_TYPE);
                    fileobj.focus();
                    RemoveIndicator("application");
                   // hidePopupMask();
                    return false;
                }
                else if (!valUploadDocRestriction(FileExt, UplCheck, fTypeJsonObj))
                {
                    customAlert(INVALID_FILE_TYPE);
                    fileobj.focus();
                    RemoveIndicator("application");
                    //hidePopupMask();
                    return false;
                } else if (!validateUploadFormFieldRestriction(fileName)) {
                    customAlert(DOCUMENT_NAME_DOES_NOT_MATCHES_FIELD_VALUE);
                    fileobj.focus();
                    return false;
                }
            }
            else{
                if (fileobj.value.indexOf('.') == -1)
                {
                    customAlert(SPECIFY_EXT_FOR_DOC);
                    fileobj.focus();
                    RemoveIndicator("application");
                   // hidePopupMask();
                    return false;
                }

                dotPos = fileobj.value.lastIndexOf('.');
                var FileExt = fileobj.value.substring(dotPos + 1, fileobj.value.length);
                var filePos;
                if (fileobj.value.indexOf("/") == -1) {
                    filePos = fileobj.value.lastIndexOf('\\');
                } else {
                    filePos = fileobj.value.lastIndexOf('/');
                }
                var fileName = fileobj.value.substring(filePos + 1, fileobj.value.length);
                if (FileExt == "")
                {
                    customAlert(SPECIFY_EXT_FOR_DOC);
                    fileobj.focus();
                    RemoveIndicator("application");
                  //  hidePopupMask();
                    return false;
                } else if (!validateUploadDocType(FileExt ,docType))//WCL_8.0_081
                {
                    customAlert(INVALID_FILE_TYPE);
                    fileobj.focus();
                    RemoveIndicator("application");
                   // hidePopupMask();
                    return false;
                } else if (!valUploadDocRestriction(FileExt, UplCheck, fTypeJsonObj))
                {
                    customAlert(INVALID_FILE_TYPE);
                    fileobj.focus();
                    RemoveIndicator("application");
                    //hidePopupMask();
                    return false;
                } 
            }
        }
        
        if(NGDocApplet == 'Y'){
            var tempMsg = '<APPLET code="com.newgen.docApplet.NGDocApplet.class" Name="docApplet" width="0" height="0" archive="'+sContextPath+'/webtop/applet/docApplet.jar" cabbase="'+sContextPath+'/webtop/applet/docApplet.cab"><param name = "filePath" value="'+fileobj.value+'"></APPLET>';
            document.getElementById("divApplet").innerHTML=encode_ParamValue(tempMsg);
            var FileSize = document.docApplet.returnSize();
            if(!checkFile(FileSize))
            {
                    var proceed = customAlert(CONFIRM_MAX_UPLOAD_LIMIT + uploadLimit + " MB" + CONFIRM_CURRENT_FILESIZE + (FileSize/1024/1024).toPrecision(4) + " MB");
                    RemoveIndicator("application");
                   // hidePopupMask();
                    return false;
            }		
        }
    }    
}

function ChkInClk(param)
{
    opr = param;return true;
}