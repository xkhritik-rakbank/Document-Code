
function cancel()
{
   window.top.opener.document.getElementById("wdesk:checkinDiv").style.display="inline";
   window.top.opener.document.getElementById("wdesk:checkoutDiv").style.display="none";      
}


function getShortDownloadName()
{   
    var name1="";
    if(orgName == "true")
        name1 = docName + "("+displayName+")";
    else    
        name1 = docName;
  
    if (name1.length >200)
	name1 = name1.substring(0,200)+"~1";
    ext = extension;
    
    /*if(orgName == "true")
        return name1;
    else*/
        return name1+"."+ext;
}


function downloadOnCheckout(link)
{    
    var docName = docInfoJSON.document[0].DocName;
    var fileName = docInfoJSON.document[0].FileName;
    fileName = fileName.substring(0, fileName.lastIndexOf("."));
    var docExt = docInfoJSON.document[0].DocExt;
    
    var url = sContextPath+"/servlet/getdocument";
    url = appendUrlSession(url);
    url=url+"&WD_RID="+getRequestToken('/webdesktop/servlet/getdocument');
    var listParam=new Array();
    listParam.push(new Array("ISIndex",encode_ParamValue(isIndex)));
    listParam.push(new Array("DocExt",encode_ParamValue(extension)));
    listParam.push(new Array("DocIndex",encode_ParamValue(docId)));
    listParam.push(new Array("PageNo",encode_ParamValue("1")));
    listParam.push(new Array("pid",encode_utf8(pid)));    //Bug 62239 
    listParam.push(new Array("wid",encode_utf8(wid)));    //Bug 62239 
    listParam.push(new Array("DownloadFlag",encode_ParamValue("Y")));
    
    if(typeof customDownloadedDocName != undefined) {
        var dldDispName = customDownloadedDocName(docName, fileName, docExt, pid, processName, activityName);
        if(typeof dldDispName != 'undefined' && dldDispName != "") {
            downloadDisplay = dldDispName;
            listParam.push(new Array("DocCustomName", "Y"));
        }
    }
    
    listParam.push(new Array("DocumentName",encode_ParamValue(downloadDisplay)));
    generatePostRequest(window,url,listParam);
    
    /*var url = "/webdesktop/servlet/getdocument?ISIndex="+encode_utf8(isIndex)+"&DocExt="+extension+"&DocIndex="+docId+"&PageNo=1&DownloadFlag=Y&DocumentName="+encode_utf8(downloadDisplay);    
    url = appendUrlSession(url);
    link.href = url;*/
}

