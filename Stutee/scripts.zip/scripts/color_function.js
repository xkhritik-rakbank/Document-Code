
var isFirefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
function openColorPicklist(targetDispId,targetHidId)
{
    var Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
    createPopUpIFrameWrapper('ColorPicklist',Url,225,225);
}

function openColorPicklistNew(ref,targetDispId,targetHidId)
{
    var Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
    
    var posLeft = findAbsPosX(ref);
    var posTop = findAbsPosY(ref);

    try{

        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){

    }
    
    if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 215, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 215, 224, posLeft, posTop, false, true, false, true);
        
    }
    
    
}

function openImagePicklist(targetDispId,targetHidId)
{
    var Url = "/webdesktop/components/process/imagepicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
    createPopUpIFrameWrapper('ImagePicklist',Url,200,150);
}


function openOtherColorPicklist(ref,targetDispId,targetHidId)
{
    var strId=ref.id;
    strId=strId.substring(0,strId.lastIndexOf(":")+1);
    var targetDispId;
    var targetHidId;
    var radioId=strId+"otherRadioCI";
    var radioIndex;
    var Url="";
    var posLeft = findAbsPosX(ref);
    var posTop = findAbsPosY(ref);

    try{

        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){

    }
    if(isCompatibleForRadioCheck())
        radioIndex=1;
    else
        radioIndex=0;
    if(document.getElementsByName(radioId)[radioIndex].checked==true){
        targetDispId=strId+"otherBgcolortxtbox";
        targetHidId=strId+"otherHidbgcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 215, 248, posLeft, posTop, false, true, false, true); //bug 76182
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 215, 224, posLeft, posTop, false, true, false, true); //bug 76182
    }
    }else{
        targetDispId=strId+"otherImage";
        targetHidId=strId+"otherHidbgcolortxtbox";
        Url = "/webdesktop/components/process/imagepicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ImagePicklist',Url,235,170);
        popupIFrameOpenerWrapper(this, 'ImagePicklist', Url, 170, 235, posLeft, posTop, false, true, false, true);
    }
}
function openColorPicklistForDatatable(ref,targetDispId,targetHidId,from)
{
    var strId=ref.id;
    strId=strId.substring(0,strId.lastIndexOf(":")+1);
    var targetDispId;
    var targetHidId;
    var radioId=strId+"radioCI";
    var radioIndex;
    var Url="";
    var posLeft = findAbsPosX(ref);
    var posTop = findAbsPosY(ref);

    try{

        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){
        
    }
    if(isCompatibleForRadioCheck())
        radioIndex=1;
    else
        radioIndex=0;
    var rdchkref=document.getElementsByName(radioId)[radioIndex];
    
    if(typeof from!='undefined' && from=='CRM_DONUT'){
         var scrollDiv=document.getElementById('flDiv');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"bgcolortxtbox";
        targetHidId=strId+"hidbgcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        //bug 76182 starts : Dated-21/02/2018
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }//bug 76182 ends
      return true;
    }
    
    if(typeof from!='undefined' && from=='CRM_BAR'){
        var scrollDiv=document.getElementById('flDiv');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"bgcolortxtbox";
        targetHidId=strId+"hidbgcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        //bug 76182 starts : Dated-21/02/2018
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }//bug 76182 ends
      return true;
    }
    
     if(typeof from!='undefined' && from=='CRMTILEBG'){
         var scrollDiv=document.getElementById('flDiv');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"tilebgcolortxtbox";
        targetHidId=strId+"hidTileBGColor";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        //bug 76182 starts : Dated-21/02/2018
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }//bug 76182 ends
      return true;
    }
    if(typeof from!='undefined' && from=='CRMTILEHD'){
         var scrollDiv=document.getElementById('frmcriteriamgmt:bp:tilesLeftContainer');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"headColorImg";
        targetHidId=strId+"hidHeadColor";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        //bug 76182 starts : Dated-21/02/2018
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }//bug 76182 ends
      return true;
    }
     if(typeof from!='undefined' && from=='CRMFLBG'){
         var scrollDiv=document.getElementById('flDiv');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"flbgcolortxtbox";
        targetHidId=strId+"hidFlBGColor";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        //bug 76182 starts : Dated-21/02/2018
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }//bug 76182 ends
      return true;
    }
     if(typeof from!='undefined' && from=='CRMTILHFC'){
         var scrollDiv=document.getElementById('flDiv');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"tilehfcbgcolortxtbox";
        targetHidId=strId+"hidTilehFColor";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        //bug 76182 starts : Dated-21/02/2018
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }//bug 76182 ends
      return true;
    }
    if(typeof from!='undefined' && from=='CRMCFC'){
        var scrollDiv=document.getElementById('flDiv');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"tilecountfcolortxtbox";
        targetHidId=strId+"hidtilecountfcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        //bug 76182 starts : Dated-21/02/2018
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }//bug 76182 ends
      return true;
    }
    if(typeof from!='undefined' && from=='CRMBDFC'){
        var scrollDiv=document.getElementById('flDiv');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"tilebdcolortxtbox";
        targetHidId=strId+"hidtilebdcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        //bug 76182 starts : Dated-21/02/2018
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }//bug 76182 ends
      return true;
    }
    
    if(typeof rdchkref !='undefined' && rdchkref.checked==true){
        targetDispId=strId+"bgcolortxtbox";
        targetHidId=strId+"hidbgcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        //bug 76182 starts : Dated-21/02/2018
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
    }//bug 76182 ends
    }else{
        targetDispId=strId+"selImage";
        targetHidId=strId+"hidbgcolortxtbox";
        Url = "/webdesktop/components/process/imagepicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ImagePicklist',Url,235,170);
        popupIFrameOpenerWrapper(this, 'ImagePicklist', Url, 170, 235, posLeft, posTop, false, true, false, true);
    // createIFrame('ImagePickList','200',Url,targetDispId,true,150);
    }
}

function PopulateColors()
{
    var colors = new Array("#000000","#000033","#000066","#000099","#0000CC","#0000FF","#330000","#330033","#330066","#330099","#3300CC",
        "#3300FF","#660000","#660033","#660066","#660099","#6600CC","#6600FF","#990000","#990033","#990066","#990099",
        "#9900CC","#9900FF","#CC0000","#CC0033","#CC0066","#CC0099","#CC00CC","#CC00FF","#FF0000","#FF0033","#FF0066",
        "#FF0099","#FF00CC","#FF00FF","#003300","#003333","#003366","#003399","#0033CC","#0033FF","#333300","#333333",
        "#333366","#333399","#3333CC","#3333FF","#663300","#663333","#663366","#663399","#6633CC","#6633FF","#993300",
        "#993333","#993366","#993399","#9933CC","#9933FF","#CC3300","#CC3333","#CC3366","#CC3399","#CC33CC","#CC33FF",
        "#FF3300","#FF3333","#FF3366","#FF3399","#FF33CC","#FF33FF","#006600","#006633","#006666","#006699","#0066CC",
        "#0066FF","#336600","#336633","#336666","#336699","#3366CC","#3366FF","#666600","#666633","#666666","#666699",
        "#6666CC","#6666FF","#996600","#996633","#996666","#996699","#9966CC","#9966FF","#CC6600","#CC6633","#CC6666",
        "#CC6699","#CC66CC","#CC66FF","#FF6600","#FF6633","#FF6666","#FF6699","#FF66CC","#FF66FF","#009900","#009933",
        "#009966","#009999","#0099CC","#0099FF","#339900","#339933","#339966","#339999","#3399CC","#3399FF","#669900",
        "#669933","#669966","#669999","#6699CC","#6699FF","#999900","#999933","#999966","#999999","#9999CC","#9999FF",
        "#CC9900","#CC9933","#CC9966","#CC9999","#CC99CC","#CC99FF","#FF9900","#FF9933","#FF9966","#FF9999","#FF99CC",
        "#FF99FF","#00CC00","#00CC33","#00CC66","#00CC99","#00CCCC","#00CCFF","#33CC00","#33CC33","#33CC66","#33CC99",
        "#33CCCC","#33CCFF","#66CC00","#66CC33","#66CC66","#66CC99","#66CCCC","#66CCFF","#99CC00","#99CC33","#99CC66",
        "#99CC99","#99CCCC","#99CCFF","#CCCC00","#CCCC33","#CCCC66","#CCCC99","#CCCCCC","#CCCCFF","#FFCC00","#FFCC33",
        "#FFCC66","#FFCC99","#FFCCCC","#FFCCFF","#00FF00","#00FF33","#00FF66","#00FF99","#00FFCC","#00FFFF","#33FF00",
        "#33FF33","#33FF66","#33FF99","#33FFCC","#33FFFF","#66FF00","#66FF33","#66FF66","#66FF99","#66FFCC","#66FFFF",
        "#99FF00","#99FF33","#99FF66","#99FF99","#99FFCC","#99FFFF","#CCFF00","#CCFF33","#CCFF66","#CCFF99","#CCFFCC",
        "#CCFFFF","#FFFF00","#FFFF33","#FFFF66","#FFFF99","#FFFFCC","#FFFFFF");
    var total = colors.length;
    var width = 18;
    //var cp_contents = "";
    var tableElem=document.createElement('table');
    var tbodyElem = document.createElement('tbody');
    tableElem.setAttribute("cellPadding", 0);
    tableElem.setAttribute("cellSpacing", 0);
    tableElem.setAttribute("border", 1);

    var use_highlight = (document.getElementById || document.all)?true:false;
    var tableRow=null;
    for (var i=0; i<total; i++) {
        if ((i % width) == 0) {
            tableRow=document.createElement('tr');
        }

        var tableCol=document.createElement('td');
        tableCol.style.backgroundColor=colors[i];

        var anchorEle=document.createElement("a");
        var selColor=colors[i];

        anchorEle.onmouseover=createHandlerMouseOver(selColor,use_highlight);

        anchorEle.onclick=createHandlerClick(selColor);

        anchorEle.style.textDecoration='none';
        anchorEle.innerHTML='&nbsp;&nbsp;&nbsp;';
        anchorEle.style.fontsize='9px';
        anchorEle.style.width='100%';
        anchorEle.href='#';

        tableCol.appendChild(anchorEle);
        tableRow.appendChild(tableCol);
        if ( ((i+1)>=total) || (((i+1) % width) == 0)) {
            tbodyElem.appendChild(tableRow);
        }
    }
    // If the browser supports dynamically changing TD cells, add the fancy stuff
    if(document.getElementById){
        var width1 = Math.floor(width/2);
        var width2 = width = width1;
        var tableRow=document.createElement('tr');
        tableRow.style.fontSize="14px";

        var tableCol=document.createElement('td');
        tableCol.setAttribute("colSpan", width1);
        tableCol.style.backgroundColor='#ffffff';
        tableCol.setAttribute('id', 'colorPickerSelectedColor');
        tableCol.onclick=function(){
            selectCustomColor();
        };

        tableCol.style.cursor='pointer';
        tableCol.innerHTML='&nbsp;';

        tableRow.appendChild(tableCol);

        tableCol=document.createElement('td');
        tableCol.setAttribute("colSpan", width2);
        tableCol.setAttribute('align', 'CENTER');
        tableCol.setAttribute('id', 'colorPickerSelectedColorValue1');
        tableCol.className='PMControlText';
        tableCol.innerHTML="<input type='text' style='width:60%;' ID='colorPickerSelectedColorValue' value='#FFFFFF' onkeyUp='changeColor(this);'/><input type='hidden' ID='hidcolorPickerSelectedColorValue' value='#FFFFFF' /><input type='button' style='width:40%' class='buttonstyle' ID='button' value='"+APPLY+"' onclick='selectCustomColor();'/>";
        tableRow.appendChild(tableCol);
        tbodyElem.appendChild(tableRow);
    }
    tableElem.appendChild(tbodyElem);
    document.getElementById("colorcontainer").appendChild(tableElem);
}

function createHandlerMouseOver( param,use_highlight) {
    return function() {
        if(use_highlight){
            ColorPicker_highlightColor( param,window.document);
        }
    }
}

function createHandlerClick( param ) {
    return function() {
        ColorPicker_pickColor(param);
        if(afterSetColor){
            afterSetColor();
        }
        return false;
    }
}

function changeColor(ref)
{
    var color=ref.value;
    if(fncIsValidcolor(color))
    {
        var thedoc = (arguments.length>1)?arguments[1]:window.document;
        var d = thedoc.getElementById("colorPickerSelectedColor");
        d.style.backgroundColor = color;
        d = thedoc.getElementById("hidcolorPickerSelectedColorValue");
        d.value = color;
    }
}
function ColorPicker_pickColor(color) {
    pickColor(color);
}

// This function runs when you move your mouse over a color block, if you have a newer browser
function ColorPicker_highlightColor(c)
{
    var thedoc = (arguments.length>1)?arguments[1]:window.document;
    var d = thedoc.getElementById("colorPickerSelectedColor");
    d.style.backgroundColor = c;
    d = thedoc.getElementById("colorPickerSelectedColorValue");
    d.value = c;
    d = thedoc.getElementById("hidcolorPickerSelectedColorValue");
    d.value = c;
}

function selectCustomColor()
{
    var thedoc = (arguments.length>1)?arguments[1]:window.document;
    var d = thedoc.getElementById("hidcolorPickerSelectedColorValue");
    try
    {
        var ColorCode=d.value;
        if(fncIsValidcolor(ColorCode))
        {
            pickColor(ColorCode);
        }else
        {
            d = thedoc.getElementById("colorPickerSelectedColorValue");
            d.select();
        }
        
        if(afterSetColor){
            afterSetColor();
        }
    }catch(e)
    {}
}

function fncIsValidcolor(hexcolor)
{
    var strPattern =/^#([0-9a-f]{6})$/i ;
    return strPattern.test(hexcolor);
}
function pickColor(color)
{try
    {
        window.parent.document.getElementById(TargetHidId).value=color;
    }catch(e){}
    try
    {
        window.parent.document.getElementById(TargetDispId).style.backgroundColor=color;
    }catch(e){}
    removeIFrame(CurrentPickListId);
}


          