/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function openDataPicklistInputWin(ref,TextBoxId,varType,hidTextBoxId,scrollContainer)
{
    var optId = ref.id;
    var index = optId.lastIndexOf(":");
    var subId = optId.substring(0,index);
    
    if(typeof fieldSubId != 'undefined')
    {
      fieldSubId= subId; 
    }
    
    var DataTextBoxId = subId +':'+TextBoxId;    
    var hidDataTextBoxId = subId +':'+hidTextBoxId;
    var scrollDivTop=0;
    var scrollDivLeft=0;
    if(scrollContainer){
             scrollDivTop = scrollContainer.scrollTop;
             scrollDivLeft= scrollContainer.scrollLeft;
     }
    if(varType=="9" || varType=="50")//date type variable
    {
        CurrentCalenderPicklistType=varType;
        var bShortDate=false;
        /*if(varType=="50")
            bShortDate=true;*/
        calFromTextBox=DataTextBoxId;
        hiddenCalFromTextBox = hidDataTextBoxId;
        //Bug 75725 Start
        cal = openCalender(document.getElementById(DataTextBoxId),cal,bShortDate,185);
        //Bug 75725 End
        //cal = openCalender(document.getElementById(DataTextBoxId),cal,bShortDate,155);
        
        var calObj =document.getElementById("calContainer");
        var obj = findPosition(ref);        
        var totalheight = obj.top+calObj.clientHeight+2;
        var totalwidth = obj.left+calObj.clientWidth+2;
        
        if((totalheight - scrollDivTop)> document.body.clientHeight){
            calObj.style.top = obj.top-(totalheight-document.body.clientHeight)-20+"px";
            
            if(obj.left-155< 0){
                calObj.style.left= obj.left+"px";
            }else{
                //calObj.style.left= obj.left-155+"px";
                
                if((totalwidth-scrollDivLeft) > document.body.clientWidth){
                    calObj.style.left = obj.left -(totalwidth-document.body.clientWidth)-10+"px";
                } else {
                    calObj.style.left= obj.left - scrollDivLeft +"px";
                }
            }
        }else{
            if(optId.indexOf("wdesk:tview")>-1){
                calObj.style.top= obj.top-80-scrollDivTop+"px";
            }else{
                calObj.style.top= obj.top-20-scrollDivTop+"px";
            }   
            if(optId.indexOf("wdesk:tview")>-1){
                calObj.style.left = obj.left - 500 + "px";
            }else if (obj.left < 250) {
                calObj.style.left = obj.left-80 + "px";
            }
            else {
                calObj.style.left = obj.left - 152 + "px";
            }
        }
        
        var top = calObj.style.top.split('p')[0]-0;
        if(top<0){
            calObj.style.top = "10px";
        }
        
        var left = calObj.style.left.split('p')[0]-0;
        if(left<0){
            calObj.style.left = "10px";
        }
        
    }
    return false;
}

function mySelectHandler(type,args,obj)
{
    var selected = args[0];
    var selDate = this.toDate(selected[0]);
    var lDateFormat="dd/MMM/yyyy";
    if(dateTimeFormat!=undefined)
    {
        lDateFormat=dateTimeFormat;
    }
    var strDBDate=convertYahooToDbDate(selDate);
    if(CurrentCalenderPicklistType=="9" || CurrentCalenderPicklistType=="50")
    {
        var strHours,strMinutes,strSeconds;
        if(document.getElementById("selectHour")!=null){
        var objHourSelectItem=document.getElementById("selectHour");
         strHours=objHourSelectItem.options[objHourSelectItem.selectedIndex].value;
        }
        else if(document.getElementById("selectHour")==null){
             strHours="00";
        }
        if(document.getElementById("selectMinute")!=null){
        var objMinuteSelectItem=document.getElementById("selectMinute");
         strMinutes=objMinuteSelectItem.options[objMinuteSelectItem.selectedIndex].value;
        }
        else if(document.getElementById("selectMinute")==null){
             strMinutes="00";
        }
        if(document.getElementById("selectSecond")!=null){
        var objSecondSelectItem=document.getElementById("selectSecond");
         strSeconds=objSecondSelectItem.options[objSecondSelectItem.selectedIndex].value;
       }
       else if(document.getElementById("selectSecond")==null){
             strSeconds="00";
        }
       strDBDate=strDBDate+" "+strHours+":"+strMinutes+":"+strSeconds;
    }
    
    var strLocalDate=DBToLocal(strDBDate,lDateFormat,false);
    var tempLocalDate = strLocalDate;
    
    if(tempLocalDate.length > 0){
        var dbDate = LocalToDB(tempLocalDate,lDateFormat);
        dbDate = dbDate.split(" ");
        if(dbDate.length > 0){        
            tempLocalDate = dbDate[0];
            if(dbDate.length > 1){
                tempLocalDate += "T"+dbDate[1];
            }
        }
    }
    
    var d1=new Date(tempLocalDate);
    var d2=new Date();
    if(typeof fieldSubId != 'undefined')
    {
        var dateJSON = calDateAndTimediff(d1,d2);
        if(dateJSON.DateModified){
            strDBDate=convertYahooToDbDate(dateJSON.Date);
            strLocalDate=DBToLocal(strDBDate,lDateFormat,false);
            strLocalDate += "00:00:00";
        }
    }
    
    strLocalDate= Trim(strLocalDate);
    
    var ref = document.getElementById(calFromTextBox);
    if(ref){
        ref.value=strLocalDate;
    }
    
    ref = document.getElementById(hiddenCalFromTextBox);
    if(ref){
        ref.value=strLocalDate;
    }
    
    obj.hide();
    
    /*var strLocalDate=DBToLocal(strDBDate,lDateFormat,false);
    strLocalDate= Trim(strLocalDate);
    document.getElementById(calFromTextBox).value=strLocalDate;
    document.getElementById(hiddenCalFromTextBox).value=strLocalDate;
    obj.hide();*/
}

function calDateAndTimediff(d1,d2)
{
    var dateModified = false;
    var date1_ms = d1.getTime();
    var date2_ms = d2.getTime();
    
    var d = new Date();
    if(date1_ms < date2_ms){
        // Set today midnight    
        d.setHours(24,0,0,0); 
        date1_ms = d.getTime();
        dateModified = true;
    }
    
    var difference_ms = date1_ms - date2_ms;
    //take out milliseconds
    difference_ms = difference_ms / 1000;
    difference_ms = difference_ms / 60;
    var days = Math.floor(difference_ms /(60*24) );
    var hours = Math.floor((difference_ms /60)%24);
    var minutes = Math.floor(difference_ms%60);
    
    if(document.getElementById(fieldSubId +':tatdays') != null){
        document.getElementById(fieldSubId +':tatdays').value=days;
    }
    if(document.getElementById(fieldSubId +':tathours') != null){
        document.getElementById(fieldSubId +':tathours').value=hours;
    }
    if(document.getElementById(fieldSubId +':tatminutes') != null){
        document.getElementById(fieldSubId +':tatminutes').value=minutes;
    }
    
    return {"DateModified": dateModified, "Date":d};
}

function openDatePicklistWithRender(ref,TextBoxId,varType,hidTextBoxId,maxDate,scrollContainer){
     cal=null;
    openDataPicklistInputWin(ref,TextBoxId,varType,hidTextBoxId,scrollContainer);
    cal.cfg.setProperty("mindate",new Date()); 
    
    if(maxDate.length > 0){
        var dbDate = LocalToDB(maxDate,dateTimeFormat);
        dbDate = dbDate.split(" ");
        if(dbDate.length > 0){        
            var maxdate = dbDate[0];
            if(dbDate.length > 1){
                maxdate += "T"+dbDate[1];
            }
            cal.cfg.setProperty("maxdate",new Date(maxdate)); 
        }
    }
    cal.render();
    //Bug 72057 Start
    if(!isCalDraggable){
        if(getElementsByClassName("title",document.getElementById("calContainer"))!=null){
            var temp=getElementsByClassName("title",document.getElementById("calContainer"));
            temp.style.cursor="default";
        }
    }
    //Bug 72057 End
    return false;
}

                      
 