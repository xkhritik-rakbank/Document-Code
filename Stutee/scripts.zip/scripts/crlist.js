/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var strMyQueueFlag = "Y";

function updateCriteria(ref)
{
  
    var CriteriaId="-1";
    var iCount=0;
    var pendingActions="";
    var criteriaName = "";
    
    try
    {
       CriteriaId=document.getElementById("criteriaListForm:hidcrId").value;
    }
    catch(ex)
    {
        alert("NO Criteria Selected");
        return;
    }   
    var Url="/webdesktop/components/criteria/criteriamgmt.app";
    Url = appendUrlSession(Url);
    
    WindowLeft=293;
    WindowTop=window.parent.document.documentElement.scrollTop+10;
   
    var WindowHeight=615;
    var WindowWidth=950;
    
    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("2")));
    listParam.push(new Array("showTab",encode_ParamValue("1")));
    listParam.push(new Array("crid",encode_ParamValue(CriteriaId)));
    Url=Url+'&Action='+encode_ParamValue("2")+'&showTab='+encode_ParamValue("1")+'&crid='+encode_ParamValue(CriteriaId)+'&Mode=1'+'&openMode=PM';
        
 //   var win = openNewWindow(Url,"updateCriteria",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
   window.parent.popupIFrameOpenerCriteriaWrapper(this, "Criteria", Url, WindowWidth, WindowHeight, WindowLeft, WindowTop, false, true, false, true, false);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function newCriteria(ref){
    url = '/webdesktop/components/criteria/criteriamgmt.app?Action=1';
    WindowLeft=293;
    WindowTop=window.parent.document.documentElement.scrollTop+10;
    
    var CriteriaId="";
    var WindowHeight=615;
    var WindowWidth=950;

    
    Url = '/webdesktop/components/criteria/criteriamgmt.app?Mode=0&Action=1&WD_SID='+WD_SID+'&openMode=PM';
       
        window.parent.popupIFrameOpenerCriteriaWrapper(this, "Criteria", Url, WindowWidth, WindowHeight, WindowLeft, WindowTop, false, true, false, true, false);
    
}



function updateOrderId(ref){
     var tableId = "frmcriteriamgmt:bp:"+"varmapList";
     var tbref=document.getElementById(tableId);
     for(var iCount=0;iCount < tbref.rows.length;iCount++){
        var hideOrderId= document.getElementById(tableId+":"+iCount+":"+"hidOrderId");
         var hidVarName= document.getElementById(tableId+":"+iCount+":"+"hidVarName");
       hideOrderId.value=iCount;
    }
}

function resizeCompWH(height,width,type,diffHeight){
    type = (typeof type == 'undefined')? '':type;
    diffHeight = (typeof diffHeight == 'undefined')? null:diffHeight;

   var scrollDivRef = document.getElementById('scrollQM');
     if(scrollDivRef && (diffHeight != null)){
        scrollDivRef.style.height = (parseInt(scrollDivRef.style.height)+diffHeight)+'px';
     } 

    if(width!=undefined && width!=""){
        document.getElementById('criteriaListForm:hidWidth').value=width;
        
        var tableHeaderFix = document.getElementsByClassName('table-header-fix');
        if(tableHeaderFix){
            tableHeaderFix = tableHeaderFix[0];
            if(tableHeaderFix){
                tableHeaderFix.style.width = width-20+'px';

                scrollDivRef = document.getElementById('scrollQM');
                scrollDivRef.style.width = width-20+'px';

                initTableHeaderFix();
            }
        }
    }
    
    if(height!=undefined && height!="")
        document.getElementById('criteriaListForm:hidHeight').value=height;
  // clickLink("criteriaListForm:lnkRefresh");
}

            
function compRefresh(insId){
    clickLink("criteriaListForm:lnkRefresh");
}


function eldlchk(nodeChkBox,bEnableModify,bEnabledelete)
{
    var iCount;
    var index = nodeChkBox.id.lastIndexOf(':');
    var arr=nodeChkBox.id.split(":");
    var iArrLength = arr.length ;
   var selCrId='';
    var btnUpdate=document.getElementById("criteriaListForm:BtnUpdate");
    var btndisUpdate=document.getElementById("criteriaListForm:BtndisUpdate");
    var btnDelete=document.getElementById("criteriaListForm:BtnDelete");
    var btndisDelete=document.getElementById("criteriaListForm:BtndisDelete");
    
    var chkcount=0;
    var strName="";
    for (var count=0; count < arr.length-2 ; count++ )
    {
        if(count==0)
            strName = arr[count] ;
        else
        {
            strName=strName + ":" + arr[count] ;
        }
    }
    
    var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length;
    if(nodeChkBox.checked == true)
    {
        for(iCount = 0; iCount < rowCount;iCount++)
        {

            if(iCount != arr[iArrLength-2])
            {
                var el=document.getElementById(strName+":"+iCount +":"+arr[iArrLength-1]);
                if(el!=undefined)
                    el.checked=false;
            }
        }
    }
        for(iCount = 0; iCount < rowCount;iCount++)
        {
            var el=document.getElementById("criteriaListForm:wDCriteriaLists"+":"+iCount +":"+"chkBoxCriteria");  
            var crid=document.getElementById("criteriaListForm:wDCriteriaLists"+":"+iCount +":"+"hidCriteriaID").value;
            if(typeof el!=undefined && el.checked==true){
                selCrId=crid;
               chkcount++;


                       if(chkcount>=2){
                break;
            }

            }

            
        }
        
        if(chkcount==0){
            
           if(btnUpdate!=null && btnUpdate!=undefined){
           
                btnUpdate.style.display="none";
                btndisUpdate.style.display="inline-block"; 
            }
            
            if(btnDelete!=null && btnDelete!=undefined){
           
                btnDelete.style.display="none";
                btndisDelete.style.display="inline-block"; 
            }


        }
        
        if(chkcount==1){
            if(bEnableModify=='true' && btnUpdate!=null && btnUpdate!=undefined){
           
                btnUpdate.style.display="inline-block";
                btndisUpdate.style.display="none"; 
            }else if(bEnableModify=='false' && btnUpdate!=null && btnUpdate!=undefined){
                 btnUpdate.style.display="none";
                btndisUpdate.style.display="inline-block"; 
            }
            if(bEnabledelete=='true' && btnDelete!=null && btnDelete!=undefined){
                btnDelete.style.display="inline-block";
                btndisDelete.style.display="none";
            }else if(bEnabledelete=='false' && btnDelete!=null && btnDelete!=undefined){
                btnDelete.style.display="none";
                btndisDelete.style.display="inline-block";
            }


        }
        if(chkcount>1){
             if(btnDelete!=null && btnDelete!=undefined){
                btnDelete.style.display="none";
                btndisDelete.style.display="inline-block";
            }
            if(btnUpdate!=null && btnUpdate!=undefined){
           
                btnUpdate.style.display="none";
                btndisUpdate.style.display="inline-block"; 
            }
           
 
        }
       document.getElementById("criteriaListForm:hidcrId").value= selCrId;
               
}

 function paintPieChartType() {
     var ref=document.getElementById("frmcriteriamgmt:bp:hidChartJson");
     var chartType=document.getElementById("frmcriteriamgmt:bp:dpcharttype").value;
     var chartDataType =document.getElementById("frmcriteriamgmt:bp:hidChartDataType").value;
     var pieDataType =document.getElementById("frmcriteriamgmt:bp:hidPieDataType").value;
//var chartDataType = "2";
    var chartJsonData=""
    if(typeof ref!=undefined){
        chartJsonData=ref.value;
        chartJsonData = JSON.parse(chartJsonData);
    }
    
                                
                chartJsonData.chart.events.dataPointSelection = function (event, chartContext, config) {
                    onChartClick(event,chartContext, config,chartJsonData);
                }
                
               /* if((chartType === "bar") || (chartType === "line") || (chartType === "area")){
                    
                        chartJsonData.tooltip.y.title.formatter = function(){
                            return '';
                        }
                }*/
                 if(chartType === "radialBar" || (chartType === "pie") || (chartType === "donut")){
                        
                        chartJsonData.legend.formatter = function(seriesName, opts) {
                            //alert(seriesName + ":  " + opts.w.globals.series[opts.seriesIndex]);
                            return seriesName + ":  " + opts.w.globals.series[opts.seriesIndex];
                        }
                        if(chartType === "pie"){
                            if(pieDataType === "1"){
                                chartJsonData.dataLabels.formatter = function(seriesName, opts){
                                    var labelName = opts.w.globals.labels[opts.seriesIndex]
                                    var labelVal = opts.w.globals.series[opts.seriesIndex]
                                    return [ labelName, labelVal];
                                }
                            }else if(pieDataType === "2"){
                                chartJsonData.dataLabels.formatter = function(seriesName, opts){
                                    var labelName = opts.w.globals.labels[opts.seriesIndex]
                                    var labelVal = ('' + ( + (Math.round(seriesName + 'e+1') + 'e-1')) + '%')
                                    return [ labelName, labelVal];
                                }
                            }else if(pieDataType === "3"){
                                    chartJsonData.dataLabels.formatter = function(seriesName, opts){
                                    var labelName = opts.w.globals.labels[opts.seriesIndex]
                                    if(pageDirection == 'rtl'){
                                        labelVal = (' (' + ( + (Math.round(seriesName + 'e+1') + 'e-1')) + '%) ' + opts.w.globals.series[opts.seriesIndex])
                                    } else{
                                        labelVal = (opts.w.globals.series[opts.seriesIndex] + ' (' + ( + (Math.round(seriesName + 'e+1') + 'e-1')) + '%)')
                                    }
                                    return [ labelName, labelVal];
                                }
                            }
                        }else{
                        if(chartDataType === "1"){
                                chartJsonData.dataLabels.formatter = function(seriesName, opts){
                                    return opts.w.globals.series[opts.seriesIndex];
                                }
                            }else if(chartDataType === "2"){
                                chartJsonData.dataLabels.formatter = function(seriesName, opts){
                                    return ('' + ( + (Math.round(seriesName + 'e+1') + 'e-1')) + '%');
                            }
                            } else if (chartDataType === "3"){
                            chartJsonData.dataLabels.formatter = function(seriesName, opts){
                            return (opts.w.globals.series[opts.seriesIndex] + ' (' + ( + (Math.round(seriesName + 'e+1') + 'e-1')) + '%)');
                            }
                            }
                            }
                            }
              chartJsonData.chart.width = '100%';
              chartJsonData.chart.height = '300px';
              if(chartJsonData.grid.padding)
                delete chartJsonData.grid.padding;
//            if(chartType === "radialBar" || (chartType === "pie") || (chartType === "donut")){
//                if(chartJsonData.plotOptions.pie.startAngle != undefined)
//                            chartJsonData.chart.height = window.innerHeight * 1.5 + 'px';
//                else
//                            chartJsonData.chart.height = window.innerHeight + 'px';
//            }else{
//                     chartJsonData.chart.height = window.innerHeight - 30 + 'px';
//             }
                
                var chart = new ApexCharts(document.querySelector("#chartContainerDiv"),
                                     chartJsonData);

                chart.render();
            
}

 function onChartClick(event,chartContext, config,chartJsonData)
            {            
            console.log(chartContext, config)
            //alert("config.seriesIndex:"+config.seriesIndex);
            
            //alert(config.dataPointIndex);
            
            console.log("Selected Data point index: "+config.dataPointIndex);
            
            
            var filterInfo = chartJsonData.filters[config.dataPointIndex];
            
            console.log(filterInfo);
            
            }

function fetchFilter(ref){
//    if(!validateFilter(true))
//      return false;
    var temp=ref.id.substring(0,ref.id.lastIndexOf(":"));
    var tableId=temp.substring(0,temp.lastIndexOf(":"));
    var fIndex=temp.substring(temp.lastIndexOf(":")+1);
    var tbref=document.getElementById(tableId);
    for(var i=0;i<tbref.rows.length;i++){
        
        if(fIndex==i){
             ref.parentNode.classList='wd-filter-sel';
             ref.parentNode.parentNode.parentNode.lastElementChild.firstElementChild.style.backgroundColor="#dff0fe";
        }else{
            tbref.rows[i].firstElementChild.lastElementChild.classList='';
            tbref.rows[i].lastElementChild.firstElementChild.style.backgroundColor="#F5F5F5";
        }
        
    }
    
  
    setRowsToRemove(ref,"frmcriteriamgmt:bp:hidFetchflIndex");
    clickLink('frmcriteriamgmt:bp:fetchFilter');
    
}

function handleFetchFilter(data){
    if(data.status=='success'){
       // ref.parentNode.parentNode.classList.add("wdSelected");
        var condref= document.getElementById('frmcriteriamgmt:bp:condtestlist');
        setJoingCond(condref,true);
    }
}

 function onmouseOver(ref)
            {
                ref.parentNode.parentNode.classList.add("wdSelected");
            }

            function onmouseOut(ref)
            {
                ref.parentNode.parentNode.classList.remove("wdSelected");
            }

function deletefl(ref){
        var scrollLeftVar=document.getElementById("frmcriteriamgmt:bp:wlscrollTop");
        scrollLeftVar.value=document.getElementById("frmcriteriamgmt:bp:leftcontainer").scrollTop;
        setPopupMask();
        document.getElementById('MessageDiv').style.display='inline';
        positioncenter(ref.id,'MessageDiv','CRMGMT');
}

function deleteCriteria(){
        setPopupMask();
        document.getElementById('MessageDiv').style.display='inline';
        positioncenter('criteriaListForm:BtnDelete','MessageDiv','CRLIST');
}

function positioncenter(refid,divid,from){
    var tempCtrlname=document.getElementById(refid);
    var posLeft = findPosX(tempCtrlname);
    var posTop = findPosY(tempCtrlname);
    var subMenuObj=document.getElementById(divid);
    var absoluteleft =0;
    var absolutetop = 0;
    if (tempCtrlname.offsetParent)
    {
        absoluteleft = tempCtrlname.offsetLeft;
        absolutetop = tempCtrlname.offsetTop;
    }
       if(from=='CRLIST'){
        if(pageDirection == 'rtl')
            subMenuObj.style.left=absoluteleft+posLeft+"px";
        else
            subMenuObj.style.left=absoluteleft+posLeft-260+"px";
        subMenuObj.style.top=absolutetop+posTop+15+"px";   
       }else if(from=='CRALERT'){
        subMenuObj.style.left=absoluteleft+posLeft-180+"px";
        subMenuObj.style.top=absolutetop+posTop+65+"px";   
       }else{
           subMenuObj.style.left=370+"px";
       subMenuObj.style.top=200+"px";
       }
        
//    var subMenuObj=document.getElementById(divid);
//     subMenuObj.style.left=window.innerWidth/2+"px";
//        subMenuObj.style.top=window.innerHeight/2;+"px";
}

function DeleteFilter(confirm){
    if(confirm=="yes"){
        
        clickLink("frmcriteriamgmt:bp:deleteFl");
    }else if(confirm=="no"){
        document.getElementById("MessageDiv").style.display="none";
    }
    hidePopupMask();
}

function DeleteCriteria(confirm){
    if(confirm=="yes"){
        
        clickLink("criteriaListForm:deletecr");
    }else if(confirm=="no"){
        document.getElementById("MessageDiv").style.display="none";
    }
    hidePopupMask();
}

function ChangeProcess(confirm){
    if(confirm=="yes"){
        var ref=document.getElementById('frmcriteriamgmt:bp:pidBtn'); 
        document.getElementById("MessageDiv2").style.display="none";
       ShowProcessList(ref, 'frmcriteriamgmt:bp:pidtext', 'frmcriteriamgmt:bp:hidPid', 'frmcriteriamgmt:bp:hidPName', '', '', 'getVarListProc', 'Y', 'CRM' , '', '', '', '', '', '', 'N', '', '', '');
    }else if(confirm=="no"){
        document.getElementById("MessageDiv2").style.display="none";
    }
    hidePopupMask();
}

function duplicatefl(){
    var scrollLeftVar=document.getElementById("frmcriteriamgmt:bp:wlscrollTop");
    scrollLeftVar.value=document.getElementById("frmcriteriamgmt:bp:leftcontainer").scrollTop;
//    if(!validateFilter(true))
//      return false;
    clickLink("frmcriteriamgmt:bp:duplicateFL");
}

function setJoingCond(ref,bUpdateCB){
    if(ref && typeof ref!='undefined' && (ref.value=='1' || ref.value=='2')){
        var iCount=0;
        var dtRef=document.getElementById("frmcriteriamgmt:bp:advFilterTable");
         for(iCount = 0; iCount < dtRef.rows.length-1;iCount++)
        {
            var el=document.getElementById("frmcriteriamgmt:bp:advFilterTable"+":"+iCount +":"+"advCmbJoin");

            if(iCount==0){
                if(ref.value=='1'){
                    el.style.visibility='visible';
                    el.disabled=true;
                    el.selectedIndex=0;;
                }
                else if(ref.value=='2'){
                    el.style.visibility='visible';
                    el.disabled=true;
                    el.selectedIndex=1;
                }
                
            }
            else if (iCount > 0) {
                if (ref.value == '1') {
                    el.selectedIndex = 0;
                }
                else if (ref.value == '2') {
                    el.selectedIndex = 1;
                }
                el.style.visibility = 'hidden';
            }
        }
    }
    
    else if(ref && typeof ref!='undefined' && (ref.value=='0') && !bUpdateCB){
            var iCount=0;
        var dtRef=document.getElementById("frmcriteriamgmt:bp:advFilterTable");
         for(iCount = 0; iCount < dtRef.rows.length-1;iCount++)
        {
            var el=document.getElementById("frmcriteriamgmt:bp:advFilterTable"+":"+iCount +":"+"advCmbJoin");
            
                el.style.visibility='visible';
                el.disabled=false;
                el.selectedIndex=document.getElementById("frmcriteriamgmt:bp:advFilterTable"+":"+0 +":"+"advCmbJoin").selectedIndex;
            
            
        } 
       if(ref.id=="frmcriteriamgmt:bp:condtestlist") 
       clickLink("frmcriteriamgmt:bp:enableOp");
    }
}
function updateCondSelection(ref){
    var conditionIndex;
    if(ref!=null){
        conditionIndex =ref.id.split(":")[2];
        
        if(conditionIndex=="advFilterTable"){
            var dpref=document.getElementById("frmcriteriamgmt:bp:condtestlist");
            if(dpref.selectedIndex!=0 && ref.selectedIndex==0){
              dpref.selectedIndex=1;    
            }
            else if(dpref.selectedIndex!=0 && ref.selectedIndex==1){
                dpref.selectedIndex=2;
            }
            
        }
    }
}

function changecolor(ref){
    var ccode=ref.value;
    var rid=ref.id.substring(0,ref.id.lastIndexOf(":"))+":bgcolortxtbox";
    if(document.getElementById(rid)!=null){
        document.getElementById(rid).style.backgroundColor=ccode;
    }
    //document.getElementById("frmcriteriamgmt:bp:advFilterTable"+":"+0 +":"+"advCmbJoin")
    //bgcolortxtbox frmcriteriamgmt:bp:dtcFilterTable:0:hidbgcolortxtbox1
    
}

function changetngcolor(ref){
    var ccode=ref.value;
    var rid=ref.id.substring(0,ref.id.lastIndexOf(":"))+":tilebgcolortxtbox";
    if(document.getElementById(rid)!=null){
        document.getElementById(rid).style.backgroundColor=ccode;
    }
    //document.getElementById("frmcriteriamgmt:bp:advFilterTable"+":"+0 +":"+"advCmbJoin")
    //bgcolortxtbox frmcriteriamgmt:bp:dtcFilterTable:0:hidbgcolortxtbox1
    
}

function changeWidgetView(ref){
    
    clickLink('frmcriteriamgmt:bp:changeChartView');
}

function setVarIndex(ref){
    var selIndex=ref.selectedIndex;
    var rid=ref.id.substring(0,ref.id.lastIndexOf(":"))+":hidSelectedVarIndex";
    var cdid=ref.id.substring(0,ref.id.lastIndexOf(":"))+":hidVarDType";
    document.getElementById(rid).value=selIndex;
    //document.getElementById(rid).value=selIndex;
    document.getElementById("frmcriteriamgmt:bp:hidSelectedVarId").value=selIndex;
    document.getElementById("frmcriteriamgmt:bp:hidSelConId").value=getIndexFromRef(ref);
    clickLink('frmcriteriamgmt:bp:setVarType');
}

function getIndexFromRef(ref){
    return ref.id.substring(ref.id.lastIndexOf(":")-1,ref.id.lastIndexOf(":"));
}

function addCondition(ref){
     clickLink("frmcriteriamgmt:bp:addConditioncmd");
}
function getVarListProc(){
     clickLink('frmcriteriamgmt:bp:updateQueueVar');
}
function getVarListQueue(){
     clickLink('frmcriteriamgmt:bp:getQueuevarList');
}

function attachRowEvent(ref) {
    var initclass = '';
    var rowref;
    // var tableId = "dt";
    var dt = document.getElementById("frmcriteriamgmt:bp:varmapList");
    var tbodyOld = null;
    sorter = jQuery(dt).rowSorter({
        onDragStart: function (tbody, row, index)
        {
            //alert('drag start');
            var srcid=event.srcElement.id;
            console.log(srcid);
            if(srcid!='moveDiv' && srcid!=""){
                return false;
            }
            tbodyOld = tbody.cloneNode(true);
            initclass = row.classList.value;
            //ref.style.cursor = "move";
            row.classList.add("draggable");
            rowref = row;
            rowShifted = true;
        },
        onDrop: function (tbody, row, new_index, old_index)
        {
            //  alert('on drop');
            var newrow = jQuery(tbodyOld.rows[new_index]);
            var oldrow = jQuery(tbodyOld.rows[old_index]);

            for (var i = 0; i < tbody.rows.length; i++){
                var value = tbody.rows[i].cells[1].innerText;
                mappingData.set(value, i);
            }
            row.classList.remove("draggable");
            // console.log(mappingData);
            //     ref.style.cursor = "pointer";
            return;
        }

    });
    if (rowShifted) {
        
        afterDragDrop(ref);
    }
   // rowref.classList.value = initclass;
}

function afterDragDrop() {
    var dt = document.getElementById("frmcriteriamgmt:bp:varmapList");
    for (var i = 1; i < dt.rows.length; i++) {
        if (dt.rows[i].classList.contains('draggable')) {
            dt.rows[i].classList.remove('draggable');

        }
    }
}

function hideOnDocumentClick(e) {
    var target = e ? e.target : event.srcElement;
    var refId = event.srcElement.id;
    var index = refId.lastIndexOf(":");
    var subId = refId.substring(index+1);
    var moreOptionsBtn = document.getElementById('frmcriteriamgmt:bp:moreOptionsBtn');
    var moreDiv = document.getElementById('MoreDiv');

    if (moreDiv.style.display=='inline' && (subId!='moreOptionsBtn' && subId!='selI')) {
        moreDiv.style.display = 'none';
    }
    // hide message
//    var skipObjects = [];
//    escapeDocClickEvt(e, skipObjects);
}

function paintTileView()
{
     var tileJsonData=JSON.parse(document.getElementById("frmcriteriamgmt:bp:hidTileJson").value);
     paintTile(tileJsonData);     
}
            
            
 function mapToObj(inputMap) {
    let obj = {};

    inputMap.forEach(function(value, key){
        obj[key] = value
    });

    return obj;
}

function saveMapping(){
mappingJson["VarriableMapping"] = mapToObj(mappingData);
        //alert(JSON.stringify(mappingJson));
        document.getElementById('frmcriteriamgmt:bp:hidMappingJson').value = JSON.stringify(mappingJson);
}

function handleFlSl(ref,bCallBack){
    var dt=document.getElementById('frmcriteriamgmt:bp:dtcFilterMap');
    var chkIndex=-1;
    var filterList='';
    var indexList='';
    if(bCallBack)
        chkIndex=document.getElementById('frmcriteriamgmt:bp:hidDummyIndexFl').value;
    else    
      chkIndex=ref.id.substring(ref.id.lastIndexOf("dtcFilterMap")+13,ref.id.lastIndexOf("flchk")-1);
   // var uid="frmcriteriamgmt:bp:dtcFilterMap:1:flchk:0";
    var uid=""
    if(dt!=null){
    for (var i = 0; i < dt.rows.length; i++) {
        uid="frmcriteriamgmt:bp:dtcFilterMap:";
        if (i == chkIndex) {
//           uid=uid+i+":flchk:0";
//           var uidref=document.getElementById(uid);
           var nameRef=uid+i+":flName";
           var uidName=document.getElementById(nameRef).innerText;
         
           if(ref.checked==true){
                filterList =  document.getElementById('frmcriteriamgmt:bp:hidMappedFl').value;
                filterList = filterList + "," + uidName;
                indexList =  document.getElementById('frmcriteriamgmt:bp:hidDummyIndexFl').value;
                indexList = indexList + "," + chkIndex;
           }else{
                filterList =  document.getElementById('frmcriteriamgmt:bp:hidMappedFl').value;
                filterList = filterList.substring(0,filterList.lastIndexOf(uidName)-1)+filterList.substring(filterList.lastIndexOf(uidName)+uidName.length,filterList.length);
//                indexList =  document.getElementById('frmcriteriamgmt:bp:hidDummyIndexFl').value;
//                indexList = indexList.substring(0,indexList.lastIndexOf(uidName)-1)+indexList.substring(indexList.lastIndexOf(uidName)+uidName.length,indexList.length);
//                
           }
        }
    }
        document.getElementById('frmcriteriamgmt:bp:hidMappedFl').value=filterList;
        document.getElementById('frmcriteriamgmt:bp:hidDummyIndexFl').value=indexList;
    }
}

 function paintWidget(outputType)
{
    if (outputType == '1')
    {
        paintPieChartType();
        var ref = document.getElementById('frmcriteriamgmt:bp:dpcharttype');
        renderPnl(ref);
    } else if (outputType == '2')
    {
        paintTileView();
    }
}

function dataTableSelectOneRadio(ref) { 
      //  var id = radio.name.substring(radio.name.lastIndexOf(':')); 
      var id=ref.src;
      var imgName=id.substring(id.lastIndexOf('/')+1);
         try
            {
            window.parent.document.getElementById(TargetHidId).value=imgName;  
            }catch(e){}
            try
            { 
            window.parent.document.getElementById(TargetDispId).src="/webdesktop/resources/tileimages/"+imgName;
            }catch(e){} 
      
//        var el = radio.form.elements; 
//           
//        for (var i = 0; i < el.length; i++) { 
//                el[i].checked = false; 
//        } 
//        radio.checked = true;
        removeIFrame(CurrentPickListId);
        
        if(afterSetColor){
            afterSetColor();
        }
       //document.getElementById('cab_form:hiddenVar').value=radio.value;
    }
    
    function openTilePicklist(ref,targetDispId,targetHidId)
{
    var strId=ref.id;
    strId=strId.substring(0,strId.lastIndexOf(":")+1);
    var targetDispId;
    var targetHidId;
    
    var radioIndex;
    var Url="";
    var posLeft = findPosX(ref);
    var posTop = findPosY(ref);

    try{

        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){

    }
    if(isCompatibleForRadioCheck())
        radioIndex=1;
    else
        radioIndex=0;
   
       // targetDispId=strId+"hidIconName";
        //targetHidId=strId+"hidIconName";
        Url = "/webdesktop/components/criteria/tilepicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ImagePicklist',Url,235,170);
        popupIFrameOpenerWrapper(this, 'TilePickList', Url, 170, 235, posLeft, posTop, false, true, false, true);
    
}
function renderPnl(ref) {
    var val = (ref)?ref.value:"";
    if(val=="bar") {
        document.getElementById('frmcriteriamgmt:bp:donutPnl').style.display="none"; 
        document.getElementById('frmcriteriamgmt:bp:barPnl').style.display="";
        document.getElementById('frmcriteriamgmt:bp:piePnl').style.display="none"; 
        chartType="bar";
    } else if(val=="donut") {
        document.getElementById('frmcriteriamgmt:bp:barPnl').style.display="none";
        document.getElementById('frmcriteriamgmt:bp:donutPnl').style.display="";
        document.getElementById('frmcriteriamgmt:bp:piePnl').style.display="none"; 
        chartType="donut";
    } else if(val=="pie") {
        document.getElementById('frmcriteriamgmt:bp:piePnl').style.display=""; 
        document.getElementById('frmcriteriamgmt:bp:donutPnl').style.display="none";
        document.getElementById('frmcriteriamgmt:bp:barPnl').style.display="none";
        chartType="pie";
    }
    if(val=="bar"){
        document.getElementById('frmcriteriamgmt:bp:halfChartPanel').style.display="none";
    }else{
        document.getElementById('frmcriteriamgmt:bp:halfChartPanel').style.display="";
//        if(val=="donut") {
//            document.getElementById('frmcriteriamgmt:bp:halfChartLabel').value = SEMI_DONUT;
//        }else{
//            document.getElementById('frmcriteriamgmt:bp:halfChartLabel').value = SEMI_PIE;
//        }
    }
}

 function openColorPicklistForDatatableWrapper(ref){
    if(chartType=="donut") 
       openColorPicklistForDatatable(ref,'frmcriteriamgmt:bp:bgcolortxtbox','frmcriteriamgmt:bp:hidbgcolortxtbox','CRM_DONUT');
   if(chartType=="pie") 
       openColorPicklistForDatatable(ref,'frmcriteriamgmt:bp:bgcolortxtbox','frmcriteriamgmt:bp:hidbgcolortxtbox','CRM_PIE');
   else if(chartType=="bar")
       openColorPicklistForDatatable(ref,'frmcriteriamgmt:bp:bgcolortxtbox','frmcriteriamgmt:bp:hidbgcolortxtbox','CRM_BAR');
     changecolor(ref);
 }

function showHideLegendsDonut()
{
    var valDonut = document.getElementById('frmcriteriamgmt:bp:showLegendsCheck');
    if (valDonut) {
        if (valDonut.checked)
        {
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:0').disabled = false;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:1').disabled = false;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:2').disabled = false;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:3').disabled = false;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:1').checked = true;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:0').checked = false;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:2').checked = false;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:3').checked = false;
        } else
        {
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:0').disabled = true;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:1').disabled = true;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:2').disabled = true;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:3').disabled = true;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:0').checked = false;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:1').checked = false;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:2').checked = false;
            document.getElementById('frmcriteriamgmt:bp:LegendsRadio:3').checked = false;
        }
    }
}

function showHideLegendsPie(){
    var valPie = document.getElementById('frmcriteriamgmt:bp:showLegendsPieCheck');
        if (valPie) {
            if (valPie.checked)
            {
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:0').disabled = false;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:1').disabled = false;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:2').disabled = false;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:3').disabled = false;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:1').checked = true;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:0').checked = false;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:2').checked = false;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:3').checked = false;
            } else
            {
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:0').disabled = true;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:1').disabled = true;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:2').disabled = true;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:3').disabled = true;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:0').checked = false;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:1').checked = false;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:2').checked = false;
                document.getElementById('frmcriteriamgmt:bp:LegendsPieRadio:3').checked = false;
            }
        }    
}

function showOptions(ref) {
    var moreDiv = document.getElementById('MoreDiv');
    var scrollDiv=document.getElementById('frmcriteriamgmt:bp:leftcontainer');
    if (moreDiv != null) {
        setRowsToRemove(ref, "frmcriteriamgmt:bp:hidFetchflIndex");
        if (moreDiv.style.display == 'none') {
            var posLeft = findPosX(ref);
            var posTop =findPosY(ref);
            var scrolltop=scrollDiv.scrollTop;
            try {
                posLeft -= document.getElementById("scroll").scrollLeft;
                posTop -= document.getElementById("scroll").scrollTop;
            } catch (e) {
            }
            if (posLeft < 60 || posLeft == 60)
            {
                if (posLeft - 20 < 0)
                    moreDiv.style.left = "0px";
                else
                    moreDiv.style.left = posLeft - 20 + "px";
                moreDiv.style.top = posTop + 8 + "px";
                moreDiv.style.display = 'inline';
            } else {
                if (posLeft - 114 < 0)
                    moreDiv.style.left = "0px";
                else
                            moreDiv.style.left = posLeft+13 + "px";
                        moreDiv.style.top = posTop + 8-scrolltop + "px";
                        moreDiv.style.display = 'inline'; }
                    }
                else{
            moreDiv.style.display = 'none';
        }
    }
}

function removeOptions()
{
    var moreDiv = document.getElementById('MoreDiv');
    if (moreDiv != null && moreDiv.style.display == 'inline') {
        moreDiv.style.display = 'none';
    }
}

function openColorPicklistForDatatable(ref,targetDispId,targetHidId,from)
{
    var strId=ref.id;
    strId=strId.substring(0,strId.lastIndexOf(":")+1);
    var targetDispId;
    var targetHidId;
    var radioId=strId+"radioCI";
    var radioIndex;
    var Url="";
    var posLeft = findPosX(ref);
    var posTop = findPosY(ref);

    if(isCompatibleForRadioCheck())
        radioIndex=1;
    else
        radioIndex=0;
    var rdchkref=document.getElementsByName(radioId)[radioIndex];
   
    if(typeof from!='undefined' && from=='CRM_DONUT'){
         var scrollDiv=document.getElementById('flDiv');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"bgcolortxtbox";
        targetHidId=strId+"hidbgcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }
      return true;
    }
    
     if(typeof from!='undefined' && from=='CRM_PIE'){
         var scrollDiv=document.getElementById('flDiv');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"bgcolortxtbox";
        targetHidId=strId+"hidbgcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }
      return true;
    }
    
    if(typeof from!='undefined' && from=='CRM_BAR'){
        var scrollDiv=document.getElementById('flDiv');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"bgcolortxtbox";
        targetHidId=strId+"hidbgcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
      
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }
      return true;
    }
    
     if(typeof from!='undefined' && from=='CRMTILEBG'){
         var scrollDiv=document.getElementById('frmcriteriamgmt:bp:tilesLeftContainer');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"tilebgcolortxtbox";
        targetHidId=strId+"hidTileBGColor";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }
      return true;
    }
    
      if(typeof from!='undefined' && from=='CRMTILEHD'){
         var scrollDiv=document.getElementById('frmcriteriamgmt:bp:tilesLeftContainer');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"headColorImg";
        targetHidId=strId+"hidHeadColor";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
    
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }
      return true;
    }
    
    
     if(typeof from!='undefined' && from=='CRMFLBG'){
         var scrollDiv=document.getElementById('frmcriteriamgmt:bp:tilesLeftContainer');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"flbgcolortxtbox";
        targetHidId=strId+"hidFlBGColor";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
       
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }
      return true;
    }
     if(typeof from!='undefined' && from=='CRMTILHFC'){
         var scrollDiv=document.getElementById('frmcriteriamgmt:bp:tilesLeftContainer');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"tilehfcbgcolortxtbox";
        targetHidId=strId+"hidTilehFColor";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
       
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }
      return true;
    }
    if(typeof from!='undefined' && from=='CRMCFC'){
        var scrollDiv=document.getElementById('frmcriteriamgmt:bp:tilesLeftContainer');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"tilecountfcolortxtbox";
        targetHidId=strId+"hidtilecountfcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
       
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }
      return true;
    }
    if(typeof from!='undefined' && from=='CRMBDFC'){
        var scrollDiv=document.getElementById('frmcriteriamgmt:bp:tilesLeftContainer');
          var scrolltop=scrollDiv.scrollTop;
          posTop-=scrolltop;
          targetDispId=strId+"tilebdcolortxtbox";
        targetHidId=strId+"hidtilebdcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
        
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
        
    }
      return true;
    }
    
    if(typeof rdchkref !='undefined' && rdchkref.checked==true){
        targetDispId=strId+"bgcolortxtbox";
        targetHidId=strId+"hidbgcolortxtbox";
        Url = "/webdesktop/generic/colorpicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ColorPicklist',Url,245,215);
     
        if(isFirefox){
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 248, posLeft, posTop, false, true, false, true);
    }
    else{
        popupIFrameOpenerWrapper(this, 'ColorPicklist', Url, 224, 224, posLeft, posTop, false, true, false, true);
    }
    }else{
        targetDispId=strId+"selImage";
        targetHidId=strId+"hidbgcolortxtbox";
        Url = "/webdesktop/components/process/imagepicklist.app?TargetDispId="+targetDispId+"&TargetHidId="+targetHidId+"&WD_SID="+WD_SID;
        //createPopUpIFrameWrapper('ImagePicklist',Url,235,170);
        popupIFrameOpenerWrapper(this, 'ImagePicklist', Url, 170, 235, posLeft, posTop, false, true, false, true);
    // createIFrame('ImagePickList','200',Url,targetDispId,true,150);
    }
}

function ConfirmProcessChange(){
        setPopupMask();
        document.getElementById('MessageDiv2').style.display='inline';
        positioncenter('frmcriteriamgmt:bp:pidBtn','MessageDiv2','CRALERT');
}
function ConfirmQueueChange(){
        setPopupMask();
        document.getElementById('MessageDiv3').style.display='inline';
        positioncenter('frmcriteriamgmt:bp:qidBtn','MessageDiv3','CRALERT');
}

function ShowProcessListWrapper(ref,nameCtrl,IdCtrl,hidNameCtrl,queuenamectrl,queueidctrl,funcName,AllProcessFlag,Extra2,Extra3,Extra4,Extra5,Extra6,Extra7,Extra8,showLocalizedName,hidOrigNameCtrl,hidDisplayName,searchBase){
    if(strMode!='undefined' && strMode=="0"){
        ShowProcessList(ref, 'frmcriteriamgmt:bp:pidtext', 'frmcriteriamgmt:bp:hidPid', 'frmcriteriamgmt:bp:hidPName', '', '', 'getVarListProc', 'Y', 'CRM' , '', '', '', '', '', '', 'N', '', '', '');
    }else{
        ConfirmProcessChange();
    }
}
function ShowQueueListWrapper(ref,nameCtrl,iDCtrl,hidNameCtrl,funcName,Extra1,ShowAllQueueFlag,Extra2,Extra3,ShowMyQueueFlag,showLocalizedName,hidOrigNameCtrl,typeCtrl,forglobalqueue,hidProcessDefId){
    
    if(strMode!='undefined' && strMode=="0"){
       ShowQueueList(ref, 'frmcriteriamgmt:bp:qidtext', 'frmcriteriamgmt:bp:hidQid', 'frmcriteriamgmt:bp:hidQName', 'getVarListQueue', 'CRM', 'Y', Extra2, '', strMyQueueFlag, 'N', '', '', '',hidProcessDefId,'frmcriteriamgmt:bp:hidQueueType');
    }else {
        ConfirmQueueChange();
    }
}

function ChangeQueue(confirm,hidProcessDefId){
    if(confirm=="yes"){
     var ref=document.getElementById('frmcriteriamgmt:bp:qidBtn'); 
      document.getElementById("MessageDiv3").style.display="none";
      ShowQueueList(ref, 'frmcriteriamgmt:bp:qidtext', 'frmcriteriamgmt:bp:hidQid', 'frmcriteriamgmt:bp:hidQName', 'getVarListQueue', 'CRM', 'Y', '', '', strMyQueueFlag, 'N', '', '', '',hidProcessDefId,'frmcriteriamgmt:bp:hidQueueType');
    }else if(confirm=="no"){
        document.getElementById("MessageDiv3").style.display="none";
    }
    hidePopupMask();
}
function HandleMode(data){
    if(data.status=="success"){
        strMode="0";
    }
}
function updateOperator(varref) {
    var ref=document.getElementById("frmcriteriamgmt:bp:condtestlist");
    if (ref && typeof ref != 'undefined' && (ref.value == '0')) {
        var iCount = 0;
        var dtRef = document.getElementById("frmcriteriamgmt:bp:advFilterTable");
        for (iCount = 0; iCount < dtRef.rows.length - 1; iCount++)
        {
            var el = document.getElementById("frmcriteriamgmt:bp:advFilterTable" + ":" + iCount + ":" + "advCmbJoin");

            el.style.visibility = 'visible';
            el.disabled = false;
            el.selectedIndex = document.getElementById("frmcriteriamgmt:bp:advFilterTable" + ":" + iCount + ":" + "advCmbJoin").selectedIndex;


        }

    }
}
function validateFilter(bFetchfl) {
    if (typeof bFetchfl == 'undefined')
        bFetchfl = false;
    var FlnmRef = document.getElementById("frmcriteriamgmt:bp:filterText");
    var currfl = document.getElementById("frmcriteriamgmt:bp:hidFetchflIndex");
    var dtRef = document.getElementById("frmcriteriamgmt:bp:filterList");
    if (FlnmRef!=null && FlnmRef.value == "") {
        fieldValidator("frmcriteriamgmt:bp:filterText", ALERT_NO_FILTER_NAME, "absolute", true);
        return false;
    }
    if (!bFetchfl) {
        //var flnTrim = FlnmRef.value.trim();
        for (iCount = 0; dtRef!=null && iCount < dtRef.rows.length; iCount++)
        {
            var el = document.getElementById("frmcriteriamgmt:bp:filterList" + ":" + iCount + ":" + "flName");
            if (FlnmRef != null && el != null && el.innerText == FlnmRef.value.trim() && iCount != currfl.value) {
                fieldValidator("frmcriteriamgmt:bp:filterText", FILTER_ALEADY_EXISTS, "absolute", true);
                //FlnmRef.value = "";
                return false;
            }

        }
    }

    return true;
}

function scrollUpdate(data)
{
    if(data.status=="success")
        {
         var scrollLeftVar=document.getElementById("frmcriteriamgmt:bp:wlscrollTop");
         document.getElementById("frmcriteriamgmt:bp:leftcontainer").scrollTop=scrollLeftVar.value;
        }
}
function tileNameChange(){
    if(document.getElementById("frmcriteriamgmt:bp:tileHeadNamechk").checked){   
        document.getElementById("frmcriteriamgmt:bp:Headfontlist").disabled = false;
        document.getElementById('frmcriteriamgmt:bp:hidHeadColor').disabled=false;
    }else{
        document.getElementById("frmcriteriamgmt:bp:Headfontlist").disabled = true;
        document.getElementById('frmcriteriamgmt:bp:hidHeadColor').disabled=true;
    }
}
function chartDataTypechange(ref){
    var chartType=document.getElementById("frmcriteriamgmt:bp:dpcharttype").value;
    if(chartType === "pie")
        document.getElementById("frmcriteriamgmt:bp:hidPieDataType").value = ref.value;
    else
        document.getElementById("frmcriteriamgmt:bp:hidChartDataType").value = ref.value;
}