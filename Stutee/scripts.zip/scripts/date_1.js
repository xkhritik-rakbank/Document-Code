

function isValidTime(tm,sep1,ampm)
{
    var sep=new String(sep1);
    if (sep.length!=1)
        return false;
    var ele=tm.split(sep);
    if (ele.length!=2)
        return false;
    var temp=ele[0];
    if (temp.charAt(0)=='0' && temp.length==2)
        temp=temp.charAt(1)
    var h=parseInt(temp);
    temp=ele[1];
    if (temp.charAt(0)=='0' && temp.length==2)
        temp=temp.charAt(1)
    var m=parseInt(temp);
    if (isNaN(h) || isNaN(m) || h<0 || m<0 || m>59)
        return false;
    if(ampm.toLowerCase()=="am" && h>11)
        return false;
    else if (ampm.toLowerCase()=="pm" && h>23)
        return false;
    return true;
}

function isValidDate(dt,sep1)
{
    var sep=new String(sep1);
    if (sep.length!=1)
        return false;
    var ele=dt.split(sep);
    if (ele.length!=3)
        return false;
    var d=ele[0], m=ele[1], y=ele[2];
    if ( isNaN(d) || isNaN(m) || isNaN(y))
        return false;
    if ( d<1 || d>31)
        return false;
    if ( m<1 || m>12)
        return false;
    if ( y<1900 || y>3000)
        return 2;
    if ((m==2 || m==4 || m==6 || m==9 || m==11) && d>30)
        return false;
    if (y%100 == 0)
        y = parseInt(y/100);
    if (y%4 != 0)
    {
        if (m==2 && d>28)
            return false;
    }
    return true
}

function compareDates(fromD,toD,sep1)
{
    var sep=new String(sep1);
    if (sep.length!=1)
        return false;

    var fEle=fromD.split(sep);
    if (fEle.length!=3)
        return false;

    var fD=fEle[0], fM=fEle[1], fY=fEle[2];
    if (isNaN(fD) || isNaN(fM) || isNaN(fY))
        return false;

    var tEle=toD.split(sep);
    if (tEle.length!=3)
        return false;

    var tD=tEle[0], tM=tEle[1], tY=tEle[2];
    if (isNaN(tD) || isNaN(tM) || isNaN(tY))
        return false;

    if (tY>fY)
        return true;
    else if ((tY==fY) && (tM>fM))
        return true;
    else if ((tY==fY) && (tM==fM) && (tD>=fD))
        return true;
    else
        return false;
}


function getSizeInKB(docSize)
{
    var strDocSize = docSize;
    var lSize = parseInt(strDocSize);
    if (lSize == 0)
        strDocSize = "0KB";
    else
    {
        var lTempSize = Math.ceil(lSize / 1024);
        strDocSize = lTempSize + " KB";
    }
    return strDocSize;
}

function replaceplus(Str)
{
    var	RetStr;
    var Pos	= FindPos(Str,"+");
    while(Pos != -1)
    {
        var RetStr	= Str.substring(0,Pos);
        Str	= Str.substring(Pos + 1,Str.length);
        Str=RetStr.concat(" ") + Str;
        Pos	= FindPos(Str,"+");
    }
    return Str;
}


function FindPos(Str,SearchStr)
{
    len = Str.length;
    var ii;
    for(ii=0; ii<len; ++ii)
    {
        if(Str.charAt(ii) == SearchStr)
            return ii;
    }
    return -1;
}

function TrimLeft(val)
{
    var len = val.length;
    if(len==1 && val == " ")
    {
        val = "";
        return val;
    }
    if(len != 0)
    {
        while(1)
        {
            if(val.charAt(0) != " ")
                return val;
            else
                val = val.substr(1);
        }
    }
    return val;
}

function TrimRight(val)
{
    var len = val.length;
    if(len==1 && val == " ")
    {
        val = "";
        return val;
    }
    if(len != 0)
    {
        while(1)
        {
            if(val.charAt(len - 1) != " ")
            {
                return val;
            }
            else
            {
                len -= 1;
                val = val.substr(0,len);
            }
        }
    }
    return val;
}

// function to get the short name of required size as specified by the user .
function getShortNameSize(Name,size)
{
    if (Name.length > size + 5)
    {
        Name1 = Name.substring(0, size) + "...&nbsp;<img align=absbottom border=0 src=\"/omniflow/images/arrow1.gif\" alt=\"" + Name + "\">";
        return Name1;
    }
    return Name;
}

function getShortName(Name)
{
    if (Name.length > 22)
    {
        Name1 = Name.substring(0, 17) + "...&nbsp;<img align=absbottom border=0 src=\"/omniflow/images/arrow1.gif\" alt=\"" + Name + "\">";
        return Name1;
    }
    return Name;
}

function getShortName1(Name)
{
    if (Name.length > 40)
    {
        Name1 = Name.substring(0, 38) + "...&nbsp;<img align=absbottom border=0 src=\"/omniflow/images/arrow1.gif\" alt='" + Name + "'>";
        return Name1;
    }
    return Name;
}


function ReplaceSpace(Str)
{
    var	RetStr;
    var Pos	= FindPos(Str," ");
    while(Pos != -1)
    {
        RetStr	= Str.substring(0,Pos);
        Str	= Str.substring(Pos + 1,Str.length);
        Str=RetStr.concat("+") + Str;
        Pos	= FindPos(Str," ");
    }
    return Str;
}


function getShortDownloadName(Name)
{
    if (Name.length > 20)
    {
        Name1 = Name.substring(0, 18) + "~1";
        return Name1;
    }
    return Name;
}

function getShortNameWithoutImage(Name)
{
    if (Name.length > 20)
    {
        Name1 = Name.substring(0, 18) + "...";
        return Name1;
    }
    return Name;
}

function getShortNameWithoutImage1(Name)
{
    if (Name.length > 16)
    {
        Name1 = Name.substring(0, 14) + "...";
        return Name1;
    }
    return Name;
}

function getProperDate(dateIn1)
{
    var dateOut;
    var dateIn = unescape(dateIn1);
    dateOut = dateIn.substring(8,10)+"-"+dateIn.substring(5,7)+"-"+dateIn.substring(0,4)+" "+dateIn.substring(11,dateIn.length-3);
    return dateOut;
}
function MakeUniqueNumber()
{
    var tm = new Date();
    var milisecs = Date.parse(tm.toGMTString());
    return milisecs;
}

function Trim(val)
{
    var len = val.length;
    if(len != 0)
    {
        while(1)
        {
            if(val.charAt(0) != " ")
                break;
            else
                val = val.substr(1);
        }
    }

    len = val.length;
    if(len != 0)
    {
        while(1)
        {
            if(val.charAt(len - 1) != " ")
                return val;
            else
            {
                len -= 1;
                val = val.substr(0,len);
            }
        }
    }
    return val;
}

function deletewindow()
{
    var ii;
    for(ii=0;ii<handle.length;ii++)
    {
        var v = handle[ii];
        if (typeof v != 'undefined' && v != null && !v.closed)
            v.close();
    }
}


function DBToLocal(sDbDate,sDateFormat,bUseTimeZone)
{	
    var UseTimeZoneFlag=true;
    if(UseTimeZoneFlag!= undefined)
        UseTimeZoneFlag=bUseTimeZone; 
    try
    {
        if(UseTimeZoneFlag)//use flag to check whethe to change time in calender
        {
            if(bEnableTimeZone == 'true')
            {
                var timeDiff = (iClientTimeDiff-0)-(iServerTimeDiff-0);
                sDbDate = addMinutesToDBDate(sDbDate,timeDiff);
            }
        }
    }
    catch(e)
    {}
    var sDateSeparator=DATESEPARATOR;
    
    if (sDateFormat.indexOf("-") > 0) {
            sDateSeparator = "-";
        } else if (sDateFormat.indexOf("/") > 0) {
            sDateSeparator = "/";
        }
    
    if(sDbDate=='')
        return ' ';
    var nBegIndex=sDbDate.indexOf("-");
    //Gets the value of the date from DB
    var strYear = sDbDate.substring(0,sDbDate.indexOf("-"));
    var strMonth = sDbDate.substring(nBegIndex+1,sDbDate.lastIndexOf("-"));
    var strDay;
    var strTime="";
    if (sDbDate.indexOf(" ")!=-1)
    {
        strDay = sDbDate.substring(sDbDate.lastIndexOf("-")+1,sDbDate.indexOf(" "));
        var strtimetemp=sDbDate.substring(sDbDate.indexOf(" ")+1,sDbDate.length);
        var index=strtimetemp.indexOf(":");
        var lastIndex=strtimetemp.lastIndexOf(":");

        if(index==lastIndex)
            strTime=strtimetemp;
        else
            strTime = sDbDate.substring(sDbDate.indexOf(" ")+1,sDbDate.lastIndexOf(":")+3);//gets the seconds as well

        if (strTime=="00:00:00")
            strTime="";
    }
    else
        strDay = sDbDate.substring(sDbDate.lastIndexOf("-")+1,sDbDate.length);

    var strtemp1="";
    var strtemp2="";
    var strtemp3="";
    var strResult="";
    var tempDay="";
    var tempMon="";

    // gets the characters from the set date format
    var strChar1=sDateFormat.substring(0,sDateFormat.indexOf(sDateSeparator));
    var strChar2=sDateFormat.substring(sDateFormat.indexOf(sDateSeparator)+1,sDateFormat.lastIndexOf(sDateSeparator));
    var strChar3=sDateFormat.substring(sDateFormat.lastIndexOf(sDateSeparator)+1,sDateFormat.length);

    strChar1=strChar1.toUpperCase();
    strChar2=strChar2.toUpperCase();
    strChar3=strChar3.toUpperCase();

    if ((strChar1=="D")||(strChar1=="DD"))
    {
        tempDay=parseInt(strDay,10);
        if ((strChar1=="D")&& (tempDay<10))
            strtemp1=strDay.substring(1,2); //getting the last value like 03 ->3
        else
            strtemp1=strDay;
    }
    else if((strChar1=="M")||(strChar1=="MM"))
    {
        tempMon=parseInt(strMonth,10);
        if ((strChar1=="M")&& (tempMon <10))
            strtemp1=strMonth.substring(1,2); //getting the last value like 03 ->3
        else
            strtemp1=strMonth;
    }
    else
    {
        if ((strChar1=="YY")||(strChar1=="YYYY"))
        {
            if (strChar1=="YY")
                strtemp1=strYear.substring(2,strYear.length);//getting the last two
            else
                strtemp1=strYear;
        }
    }

    if ((strChar2=="D")||(strChar2=="DD"))
    {
        tempDay=parseInt(strDay,10);
        if ((strChar2=="D")&& (tempDay <10))
            strtemp2=strDay.substring(1,2); //getting the last value like 03 ->3
        else
            strtemp2=strDay;
    }
    else if((strChar2=="MM")||(strChar2=="MMM"))
    {
        if (strChar2=="MMM")
        {
            switch(parseInt(strMonth,10))
            {
                case 1:
                    strtemp2=JAN;
                    break;
                case 2:
                    strtemp2=FEB;
                    break;
                case 3:
                    strtemp2=MAR;
                    break;
                case 4:
                    strtemp2=APR;
                    break;
                case 5:
                    strtemp2=MAY;
                    break;
                case 6:
                    strtemp2=JUN;
                    break;
                case 7:
                    strtemp2=JUL;
                    break;
                case 8:
                    strtemp2=AUG;
                    break;
                case 9:
                    strtemp2=SEP;
                    break;
                case 10:
                    strtemp2=OCT;
                    break;
                case 11:
                    strtemp2=NOV;
                    break;
                case 12:
                    strtemp2=DEC;
                    break;
            }
        }
        else
            strtemp2=strMonth;
    }


    if((strChar3=="D")||(strChar3=="DD"))
    {
        tempDay=parseInt(strDay,10);
        if ((strChar3=="D") && (tempDay < 10))
            strtemp3=strDay.substring(1,2); //getting the last value like 03 ->3
        else
            strtemp3=strDay;
    }
    else
    {
        if ((strChar3=="YY")||(strChar3=="YYYY"))
        {
            if (strChar3=="YY")
                strtemp3=strYear.substring(2,strYear.length);//getting the last two
            else
                strtemp3=strYear;
        }
    }
    if ((strtemp1=='')&&(strtemp2==''))
        return strtemp3+" "+strTime;
    else if ((strtemp3=='')&&(strtemp2==''))
        return strtemp1+" "+strTime;
    else if ((strtemp3=='')&&(strtemp1==''))
        return strtemp2+" "+strTime;
    else if (strtemp1=='')
        return strtemp2+sDateSeparator+strtemp3+" "+strTime;
    else if (strtemp2=='')
        return strtemp1+sDateSeparator+strtemp3+" "+strTime;
    else if (strtemp3=='')
        return strtemp1+sDateSeparator+strtemp2+" "+strTime;

    strResult=strtemp1+sDateSeparator+strtemp2+sDateSeparator+strtemp3+" "+strTime;
    return strResult;
}

function LocalToDB(sLocalDate,sDateFormat)
{
    if(Trim(sLocalDate)== '')
        return '';
    var sDateSeparator=DATESEPARATOR;
    
    if (sDateFormat.indexOf("-") > 0) {
            sDateSeparator = "-";
        } else if (sDateFormat.indexOf("/") > 0) {
            sDateSeparator = "/";
        }
    
    var nBegIndex=sLocalDate.indexOf(sDateSeparator);
    //Gets the value of the date from local
    var temp;
    var strtemp1 = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
    var strtemp2 = sLocalDate.substring(nBegIndex+1,sLocalDate.lastIndexOf(sDateSeparator));
    var strtemp3;
    var strTime;

    if (sLocalDate.indexOf(" ")!=-1)
    {
        strtemp3 = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.indexOf(" "));
        strTime = sLocalDate.substring(sLocalDate.indexOf(" "),sLocalDate.length);
    }
    else
    {
        strtemp3 = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
        strTime = "00:00:00";
    }

    var strResult="";
    var strYear = "";
    var strMonth = "";
    var strDay = "";

    // gets the characters from the set date format
    var strChar1=sDateFormat.substring(0,sDateFormat.indexOf(sDateSeparator));
    var strChar2=sDateFormat.substring(sDateFormat.indexOf(sDateSeparator)+1,sDateFormat.lastIndexOf(sDateSeparator));
    var strChar3=sDateFormat.substring(sDateFormat.lastIndexOf(sDateSeparator)+1,sDateFormat.length);

    strChar1=strChar1.toUpperCase();
    strChar2=strChar2.toUpperCase();
    strChar3=strChar3.toUpperCase();

    if ((strChar1=="D")||(strChar1=="DD"))
    {
        temp=parseInt(strtemp1,10);
        if ((strChar1=="D")&& (temp<10))
            strDay="0"+strtemp1;
        else
            strDay=strtemp1;
    }
    else if((strChar1=="M")||(strChar1=="MM"))
    {
        temp=parseInt(strtemp1,10);
        if ((strChar1=="M")&& (temp<10))
            strMonth="0"+strtemp1;
        else
            strMonth=strtemp1;
    }
    else
    {
        strYear=strtemp1;
    }

    if ((strChar2=="D")||(strChar2=="DD"))
    {
        temp=parseInt(strtemp2,10);
        if ((strChar2=="D")&& (temp<10))
            strDay="0"+strtemp2;
        else
            strDay=strtemp2;
    }
    else if((strChar2=="MM")||(strChar2=="MMM"))
    {
        if (strChar2=="MMM")
        {
            strtemp2=strtemp2.toUpperCase();
            if(strtemp2==JAN1)
                strMonth="01";
            else if(strtemp2==FEB1)
                strMonth="02";
            else if(strtemp2==MAR1)
                strMonth="03";
            else if(strtemp2==APR1)
                strMonth="04";
            else if(strtemp2==MAY1)
                strMonth="05";
            else if(strtemp2==JUN1)
                strMonth="06";
            else if(strtemp2==JUL1)
                strMonth="07";
            else if(strtemp2==AUG1)
                strMonth="08";
            else if(strtemp2==SEP1)
                strMonth="09";
            else if(strtemp2==OCT1)
                strMonth="10";
            else if(strtemp2==NOV1)
                strMonth="11";
            else if(strtemp2==DEC1)
                strMonth="12";
        }
        else
            strMonth=strtemp2;
    }

    if((strChar3=="D")||(strChar3=="DD"))
    {
        temp=parseInt(strtemp3,10);
        if ((strChar3=="D")&& (temp<10))
            strDay="0"+strtemp3;
        else
            strDay=strtemp3;
    }
    else
        strYear=strtemp3;

    strResult=strYear+"-"+strMonth+"-"+strDay+" "+strTime;
    if((typeof bEnableTimeZone != 'undefined') && (bEnableTimeZone == 'true'))
    {
        try
        {
            var timeDiff = (iServerTimeDiff-0)-(iClientTimeDiff-0);
            strResult = addMinutesToDBDate(strResult,timeDiff);
        }
        catch(e)
        {}
    }
    return strResult;
}


function ValidateDateFormat(val,sDateFormat,bShortDateFlag)
{
    var Day;
    var Month;
    var Year;
    var Pos;
    var Pos1;
    val=Trim(val);
    var strDateSep="/";
    
    if (sDateFormat=='')
    {
        sDateFormat='YYYY/MM/DD';
    }
    var msgDateFormat = sDateFormat;
    if(bShortDateFlag == undefined || !bShortDateFlag)
        msgDateFormat = msgDateFormat + " " + "HH:mm:ss";

    if (sDateFormat.indexOf("-") > 0) {
        strDateSep = "-";
    } else if (sDateFormat.indexOf("/") > 0) {
        strDateSep = "/";
    }

    /*  if(val.length>msgDateFormat.length)
        {
            alert(INVALID_FORMAT +msgDateFormat); //Date should be in proper format given in
            return 0;
        }*/ //Not supporting arabic

    Pos = FindPos(val, strDateSep);
    if(Pos == -1)
    {
        customAlert(INVALID_FORMAT +msgDateFormat); //Date should be in proper format given in
        return 0;
    }
	
    // gets the characters from the set date format
    var strChar1=sDateFormat.substring(0,sDateFormat.indexOf(strDateSep));

    Pos1=val.lastIndexOf(strDateSep)
    if(Pos1==-1)
    {
        customAlert(INVALID_FORMAT1);//"Invalid Date Format."
        return 0;
    }

    var strChar2=sDateFormat.substring(sDateFormat.indexOf(strDateSep)+1,sDateFormat.lastIndexOf(strDateSep));
    var strChar3=sDateFormat.substring(sDateFormat.lastIndexOf(strDateSep)+1,sDateFormat.length);

    strChar1=strChar1.toUpperCase();
    strChar2=strChar2.toUpperCase();
    strChar3=strChar3.toUpperCase();

    if(val != "0/0/0")
    {
        if ((strChar1=="D")||(strChar1=="DD"))
        {
            Day = val.substring(0,Pos);
            if(!IsNumericVal(Day))
            {
                customAlert(NON_NUMERIC_DAY);//'Day should be numeric'
                return 0;
            }
        }
        else if((strChar1=="M")||(strChar1=="MM"))
        {
            Month	= val.substring(0,Pos);
            if(!IsNumericVal(Month))
            {
                customAlert(NON_NUMERIC_MONTH);//'Month should be numeric'
                return 0;
            }
        }
        else
        {
            Year	= val.substring(0,Pos);
            if(Year<1900 || Year.length > 4)
            {
                customAlert(ALERT_YEAR_LENGTH_FORMAT);//'Year should be greater than 1900 and in YYYY format'
                return 0;
            }
            if(!IsNumericVal(Year))
            {
                customAlert(NON_NUMERIC_YEAR);//'Year should be numeric'
                return 0;
            }
        }

        val = val.substring(Pos + 1,val.length);
        Pos = FindPos(val, strDateSep);
        if(Pos == -1)
        {
            customAlert(INVALID_FORMAT +msgDateFormat);//"Date should be in proper format given in "
            return 0;
        }
	
        if ((strChar2=="D")||(strChar2=="DD"))
        {
            Day = val.substring(0,Pos);
            if(!IsNumericVal(Day))
            {
                customAlert(NON_NUMERIC_DAY);//'Day should be numeric'
                return 0;
            }
        }
        else if((strChar2=="MM")||(strChar2=="MMM"))
        {
            Month = val.substring(0,Pos);
			
            if (strChar2=="MMM")
            {
                Month=Month.toUpperCase();
                if(Month==JAN1)
                    Month="01";
                else if(Month==FEB1)
                    Month="02";
                else if(Month==MAR1)
                    Month="03";
                else if(Month==APR1)
                    Month="04";
                else if(Month==MAY1)
                    Month="05";
                else if(Month==JUN1)
                    Month="06";
                else if(Month==JUL1)
                    Month="07";
                else if(Month==AUG1)
                    Month="08";
                else if(Month==SEP1)
                    Month="09";
                else if(Month==OCT1)
                    Month="10";
                else if(Month==NOV1)
                    Month="11";
                else if(Month==DEC1)
                    Month="12";
                else
                {
                    customAlert(INVALID_MONTH_STRING+INVALID_FORMAT+msgDateFormat);
                    return 0;
                }
            }
            if(!IsNumericVal(Month))
            {
                customAlert(NON_NUMERIC_MONTH);//'Month should be numeric'
                return 0;
            }
        }

        var temptime="";
        if(val.indexOf(" ")!=-1)
        {
            temptime=val.substring(val.indexOf(" "),val.length);
            temptime=Trim(temptime);
            if (temptime.indexOf(":")==-1)
            {
                customAlert(INVALID_TIME);//TIME should be correct format
                return 0;
            }
            var temphr=temptime.substring(0,temptime.indexOf(":"));
            if(!IsNumericVal(temphr)||temphr>24 ||temphr<0)
            {
                customAlert(NON_NUMERIC_HOUR);//'HOUR should be numeric'
                return 0;
            }

            var tempmin;
            temptime=temptime.substring(temptime.indexOf(":")+1,temptime.length);

            if (temptime.indexOf(":")!=-1)
            {
                tempmin=temptime.substring(0,temptime.indexOf(":"));
                var tempsec=temptime.substring(temptime.indexOf(":")+1,temptime.length);
                if(!IsNumericVal(tempsec)||tempsec>=60 ||tempsec<0)
                {
                    customAlert(NON_NUMERIC_SEC);//'SEC should be numeric'
                    return 0;
                }

            }
            else
                tempmin=temptime.substring(0,temptime.length);

            if(!IsNumericVal(tempmin)||tempmin>=60 ||tempmin<0)
            {
                customAlert(NON_NUMERIC_MIN);//'MIN should be numeric'
                return 0;
            }

            val = val.substring(Pos + 1,val.indexOf(" "));
        }
        else
            val = val.substring(Pos + 1,val.length);
			
        Pos=val.length;

        if((strChar3=="D")||(strChar3=="DD"))
        {
            Day = val.substring(0,Pos);
            if(!IsNumericVal(Day))
            {
                customAlert(NON_NUMERIC_DAY);//'Day should be numeric'
                return 0;
            }
        }
        else
        {
            Year	= val.substring(0,Pos);
            if(Year<1900 || Year.length > 4)
            {
                customAlert(ALERT_YEAR_LENGTH_FORMAT);//'Year should be greater than 1900 and in YYYY format'
                return 0;
            }
            if(!IsNumericVal(Year))
            {
                customAlert(NON_NUMERIC_YEAR);//'Year should be numeric'
                return 0;
            }
		
        }
    }

    // Validate For Leap Year
    switch(parseInt(Month,10))
    {
        case 1 :
        case 3 :
        case 5 :
        case 7 :
        case 8 :
        case 10:
        case 12:
            if(Day > 31 || Day < 1)
            {
                customAlert(ALERT_VALID_DATE_31);//"Please enter valid day.\nDay should be greater than 0 and less than or equal to 31."
                return 0;
            }
            break;

        case 4 :
        case 6 :
        case 9 :
        case 11:
            if(Day > 30 || Day < 1)
            {
                customAlert(ALERT_VALID_DATE_30);//Please enter valid day.\nDay should be greater than 0 and less than or equal to 30.
                return 0;
            }
            break;

        case 2 :
            if((Year % 100) == 0)
                Year = parseInt(Year / 100);

            if((Year % 4) == 0)
            {
                if(Day > 29 || Day < 1)
                {
                    customAlert(ALERT_VALID_DATE_29);//Please enter valid day.\nDay should be greater than 0 and less than or equal to 29.
                    return 0;
                }
            }
            else
            {
                if(Day > 28 || Day < 1)
                {
                    customAlert(ALERT_VALID_DATE_28);//Please enter valid day.\nDay should be greater than 0 and less than or equal to 28
                    return 0;
                }
            }
            break;
        default :
        {
            customAlert(INVALID_DATE_MONTH);
            return 0;
        }
    }
    return 1;
}

function openCalender(ref,cal,bShortDate,width,position,funcCallOnDaySelect)
{
    if(cal=="null");
    {
        var navConfig = {
            strings: {
                month:MONTH,
                year:YEAR,
                submit: LABEL_OK,
                cancel: LABEL_CANCEL,
                invalidYear: PLEASE_ENTER_A_VALID_YEAR
            },
            monthFormat: YAHOO.widget.Calendar.LONG,
            initialFocus: "month"
        }

        
        cal = new YAHOO.widget.Calendar("calender","calContainer");
        
        cal.cfg.setProperty("title",CHOOSE_A_DATE_COLON);
        cal.cfg.setProperty("close",true);
        cal.cfg.setProperty("navigator",navConfig);
        cal.cfg.setProperty("LOCALE_MONTHS","long");// determines which length of month labels should be used. Possible values are "short" and "long". 
        
        cal.cfg.setProperty("SHOW_WEEK_FOOTER",true);
        //  cal.cfg.setProperty("SHOW_WEEK_HEADER",true);
        // Date labels for  locale

        cal.cfg.setProperty("WEEKDAYS_SHORT", [WEEKDAYS_SHORT_SUNDAY, WEEKDAYS_SHORT_MONDAY, WEEKDAYS_SHORT_TUESDAY, WEEKDAYS_SHORT_WEDNESDAY, WEEKDAYS_SHORT_THIRSDAY, WEEKDAYS_SHORT_FRIDAY, WEEKDAYS_SHORT_SATURDAY]);
        cal.cfg.setProperty("MONTHS_LONG",[JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER]);
        cal.cfg.setProperty("MONTHS_SHORT", [JAN, FEB , MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC]);
        
        // Month/Year label format 

        cal.cfg.setProperty("MY_LABEL_YEAR_POSITION",  2);
        cal.cfg.setProperty("MY_LABEL_MONTH_POSITION",  1);

        cal.cfg.setProperty("MY_LABEL_YEAR_SUFFIX",  LABEL_YEAR_SUFFIX);
        cal.cfg.setProperty("MY_LABEL_MONTH_SUFFIX",  LABEL_MONTH_SUFFIX);
        
        //YAHOO.util.Dom.setStyle("calContainer","height","220px"); //to open in omniapp
        if(typeof width != 'undefined' && width!=null && width!='') {
            if(typeof pageDirection!= 'undefined' && pageDirection!=null && pageDirection!='' && pageDirection=='rtl'){
                YAHOO.util.Dom.setStyle("calContainer","width",width+13+"px");//modified on 04/02/2018 bug id 75499//Bug 75618
            }
            else{
               YAHOO.util.Dom.setStyle("calContainer","width",width+"px"); 
            }
            
        }
        if(typeof funcCallOnDaySelect == "undefined"){
            cal.selectEvent.subscribe(mySelectHandler,cal,true);
        }
        else{
            cal.selectEvent.subscribe(funcCallOnDaySelect,cal,true);
        }
        if(bShortDate== undefined || !bShortDate){
            cal.renderEvent.subscribe(addTime,cal,true);

        }
        //Bug 72057 Start
        isCalDraggable = (typeof isCalDraggable == 'undefined')?true:isCalDraggable;
        if(isCalDraggable){
            cal.renderEvent.subscribe(moveCalender,cal,true);
        }
        //Bug 72057 End
        cal.render(); 
    }
    var calObj =document.getElementById("calContainer");
    cal.show();
    objCRcustomControlwindowPos=  findPosition(window.document.body);
    objCRcustomControlDivSubMenu=  findPosition(calObj);
    position=(typeof position == 'undefined')?'':position;
    if(position!=''){
        var posArr=position.split(',');
        calObj.style.left=posArr[0]+'px';
        calObj.style.top=posArr[1]+'px';
    }
    else{
        calObj.style.top=(((objCRcustomControlwindowPos.bottom-objCRcustomControlwindowPos.top)-(objCRcustomControlDivSubMenu.bottom-objCRcustomControlDivSubMenu.top))/2)+'px';
        calObj.style.left=(((objCRcustomControlwindowPos.right-objCRcustomControlwindowPos.left)-(objCRcustomControlDivSubMenu.right-objCRcustomControlDivSubMenu.left))/2)+'px';
    }
    
    calObj.style.right="";
    return cal;
}

function moveCalender()
{
    var calObj =document.getElementById("calContainer");
    title=getElementsByClassName("title",calObj);
    title.id="title_cal";
    dd = new YAHOO.util.DD("calContainer");
    dd.setHandleElId("title_cal");
}

function AppendRow(srcTableBody)
{
    if(srcTableBody != null)
    {
        var srcCurrent_row = document.createElement("tr");
        return srcTableBody.appendChild(srcCurrent_row);
    }
}

function AppendCell(srcRow,strClassName)
{
    if(srcRow != null)
    {
        var srcCurrent_cell = document.createElement("td");
        srcCurrent_cell.className=strClassName;
        return srcRow.appendChild(srcCurrent_cell);	
    }
}
function AppendLabel(srcparent,id,strClassName,width,value)
{
    if(srcparent != null)
    {
        var srcLabel = document.createElement("label");
        srcLabel.setAttribute("id", id);
        srcLabel.className=strClassName;
        srcLabel.width = width;
        srcLabel.innerHTML=value;
        return srcparent.appendChild(srcLabel);
    }
}
function AppendSelect(srcParent,id)
{
    if(srcParent != null)
    {
        var srcSelect = document.createElement("select");
        srcSelect.setAttribute("id",id);
        return srcParent.appendChild(srcSelect);	
    }
}
function addTime() 
{
    var calObj =document.getElementById("calContainer");
        
    var srcMainTable = document.createElement("table");
    var srcMainTableBody = document.createElement("tbody");
    srcMainTable.setAttribute("id", "pgTime_Main");
    srcMainTable.cellSpacing="1";
    srcMainTable.cellPadding="3";
    calObj.appendChild(srcMainTable);
    srcMainTable.appendChild(srcMainTableBody);
    var parentRowMain = AppendRow(srcMainTableBody);
    var parentColMain=AppendCell(parentRowMain,'PMWIDTH150');
        
    var srcParentTable = document.createElement("table");
    var srcParentTableBody = document.createElement("tbody");
    srcParentTable.setAttribute("id", "pgTime_Inner");
    srcParentTable.cellSpacing="0";
    srcParentTable.cellPadding="2";
    parentColMain.appendChild(srcParentTable);
    srcParentTable.appendChild(srcParentTableBody);
        
    var parentRow = AppendRow(srcParentTableBody);
    var parentCol1=AppendCell(parentRow,'PMWIDTH30');
    var selectHour=AppendSelect(parentCol1,'selectHour');
    for(var iLoop=0;iLoop<24;iLoop++)
    {
        var value=""
        if(iLoop<10)
            value='0';
        value= value+ iLoop;
        append2List(selectHour, value, value)
    }
    var parentCol2=AppendCell(parentRow,'PMWIDTH30');
    var selectMinute=AppendSelect(parentCol2,'selectMinute')
    for(var iLoop=0;iLoop<60;iLoop++)
    {
        var value=""
        if(iLoop<10)
            value='0';
        value= value+ iLoop;
        append2List(selectMinute, value, value)
    }
    var parentCol3=AppendCell(parentRow,'PMWIDTH30');
    var selectSecond=AppendSelect(parentCol3,'selectSecond')
    for(var iLoop=0;iLoop<60;iLoop++)
    {
        var value=""
        if(iLoop<10)
            value='0';
        value= value+iLoop;
        append2List(selectSecond, value, value)
    }
    var parentCol=AppendCell(parentRow,'PMWIDTH10');
    parentCol.innerHTML='<a href="#" onclick="return false;" title="'+TIME_FORMAT+'" class="helpclass"><label class="texthidden"></label></a>'
    /*var objCurrentDate = new Date();
    selectHour.options[objCurrentDate.getHours()].selected=true;
    selectMinute.options[objCurrentDate.getMinutes()].selected=true;
    selectSecond.options[objCurrentDate.getSeconds()].selected=true;*/
}
    
function getElementsByClassName(classname, node)  
{
    if(!node) node = document.getElementsByTagName("body")[0];
    var a = [];
    var re = new RegExp('\\b' + classname + '\\b');
    var els = node.getElementsByTagName("div");
    for(var i=0,j=els.length; i<j; i++)
    {
        if(re.test(els[i].className))
            return els[i];
    }
    return null;
}
function convertYahooToDbDate(dt)
{
    var day = parseInt(dt.getDate());
    var month = parseInt(dt.getMonth())+1;
    var year = parseInt(dt.getFullYear());
    if(month <10)
        month = format(month);
    if(day <10)
        day = format(day);
    return (year + "-" + month + "-" + day);
}

function convertJSDateToDbDate(dt)
{
    var day = parseInt(dt.getDate());
    var month = parseInt(dt.getMonth())+1;
    var year = parseInt(dt.getFullYear());
    if(month <10)
        month = format(month);
    if(day <10)
        day = format(day);
    return (year + "-" + month + "-" + day);
}

function LocalToJSDate(sLocalDate,sDateFormat)
{
    if(Trim(sLocalDate)== '')
        return '';
    var sDateSeparator=DATESEPARATOR;
    var nBegIndex=sLocalDate.indexOf(sDateSeparator);
    //Gets the value of the date from local
    var temp;
    var strtemp1 = sLocalDate.substring(0,sLocalDate.indexOf(sDateSeparator));
    var strtemp2 = sLocalDate.substring(nBegIndex+1,sLocalDate.lastIndexOf(sDateSeparator));
    var strtemp3;
    var strTime;

    if (sLocalDate.indexOf(" ")!=-1)
    {
        strtemp3 = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.indexOf(" "));
        strTime = sLocalDate.substring(sLocalDate.indexOf(" "),sLocalDate.length);
    }
    else
    {
        strtemp3 = sLocalDate.substring(sLocalDate.lastIndexOf(sDateSeparator)+1,sLocalDate.length);
        strTime = "00:00:00";
    }

    var strResult="";
    var strYear = "";
    var strMonth = "";
    var strDay = "";

    // gets the characters from the set date format
    var strChar1=sDateFormat.substring(0,sDateFormat.indexOf(sDateSeparator));
    var strChar2=sDateFormat.substring(sDateFormat.indexOf(sDateSeparator)+1,sDateFormat.lastIndexOf(sDateSeparator));
    var strChar3=sDateFormat.substring(sDateFormat.lastIndexOf(sDateSeparator)+1,sDateFormat.length);

    strChar1=strChar1.toUpperCase();
    strChar2=strChar2.toUpperCase();
    strChar3=strChar3.toUpperCase();

    if ((strChar1=="D")||(strChar1=="DD"))
    {
        temp=parseInt(strtemp1,10);
        if ((strChar1=="D")&& (temp<10))
            strDay="0"+strtemp1;
        else
            strDay=strtemp1;
    }
    else if((strChar1=="M")||(strChar1=="MM"))
    {
        temp=parseInt(strtemp1,10);
        if ((strChar1=="M")&& (temp<10))
            strMonth="0"+strtemp1;
        else
            strMonth=strtemp1;
    }
    else
    {
        strYear=strtemp1;
    }

    if ((strChar2=="D")||(strChar2=="DD"))
    {
        temp=parseInt(strtemp2,10);
        if ((strChar2=="D")&& (temp<10))
            strDay="0"+strtemp2;
        else
            strDay=strtemp2;
    }
    else if((strChar2=="MM")||(strChar2=="MMM"))
    {
        if (strChar2=="MMM")
        {
            strtemp2=strtemp2.toUpperCase();
            if(strtemp2==JAN1)
                strMonth="01";
            else if(strtemp2==FEB1)
                strMonth="02";
            else if(strtemp2==MAR1)
                strMonth="03";
            else if(strtemp2==APR1)
                strMonth="04";
            else if(strtemp2==MAY1)
                strMonth="05";
            else if(strtemp2==JUN1)
                strMonth="06";
            else if(strtemp2==JUL1)
                strMonth="07";
            else if(strtemp2==AUG1)
                strMonth="08";
            else if(strtemp2==SEP1)
                strMonth="09";
            else if(strtemp2==OCT1)
                strMonth="10";
            else if(strtemp2==NOV1)
                strMonth="11";
            else if(strtemp2==DEC1)
                strMonth="12";
        }
        else
            strMonth=strtemp2;
    }

    if((strChar3=="D")||(strChar3=="DD"))
    {
        temp=parseInt(strtemp3,10);
        if ((strChar3=="D")&& (temp<10))
            strDay="0"+strtemp3;
        else
            strDay=strtemp3;
    }
    else
        strYear=strtemp3;

    var myDate=new Date();
    myDate.setFullYear(strYear-0,strMonth-1,strDay-0);
         
    strTime=strTime.split(":");
    if(strTime !=null && strTime.length>0)
        myDate.setHours(strTime[0]-0);
    if(strTime !=null && strTime.length>1)
        myDate.setMinutes(strTime[1]-0);
    if(strTime !=null && strTime.length>2)
        myDate.setSeconds(strTime[2]-0);

    return myDate ;
}

function addMinutesToDBDate(sDbDate,iMinutes)
{
    if(sDbDate=='')
        return ' ';
    var nBegIndex=sDbDate.indexOf("-");
    //Gets the value of the date from DB
    var strYear = sDbDate.substring(0,sDbDate.indexOf("-"));
    var strMonth = sDbDate.substring(nBegIndex+1,sDbDate.lastIndexOf("-"))-1;
    var strDay;
    var strTime="";
    if (sDbDate.indexOf(" ")!=-1)
    {
        strDay = sDbDate.substring(sDbDate.lastIndexOf("-")+1,sDbDate.indexOf(" "));
        var strtimetemp=sDbDate.substring(sDbDate.indexOf(" ")+1,sDbDate.length);
        var index=strtimetemp.indexOf(":");
        var lastIndex=strtimetemp.lastIndexOf(":");

        if(index==lastIndex)
            strTime=strtimetemp;
        else
            strTime = sDbDate.substring(sDbDate.indexOf(" ")+1,sDbDate.lastIndexOf(":")+3);//gets the seconds as well

        if (strTime=="00:00:00")
            strTime="";
    }
    else
        strDay = sDbDate.substring(sDbDate.lastIndexOf("-")+1,sDbDate.length);

    var Hour = 0;
    var Min = 0;
    var Sec = 0;

    if(strTime.length>0)
    {
        Hour=strTime.substring(0,strTime.indexOf(":"));
        strTime=strTime.substring(strTime.indexOf(":")+1,strTime.length);

        Min=strTime.substring(0,strTime.indexOf(":"));
        Sec=strTime.substring(strTime.indexOf(":")+1,strTime.length);
    }

    var date=new Date(strYear,strMonth,strDay,Hour,Min,Sec);
    var dateMillis = date.valueOf();

    var MillisToAdd = (iMinutes-0)*60*1000;

    var newDateMillis = dateMillis+MillisToAdd;
    var newDate = new Date(newDateMillis);

    var newday = newDate.getDate();
    if (newday <10)
        newday= "0"+newday;

    var newmonth = newDate.getMonth() +1;
    if (newmonth <10) newmonth= "0"+newmonth;

    var newhr = newDate.getHours();
    if (newhr <10) newhr= "0"+newhr;

    var newmin = newDate.getMinutes();
    if (newmin <10) newmin= "0"+newmin;

    var nwsec = newDate.getSeconds();
    if (nwsec <10) nwsec= "0"+nwsec;

    var newDBDate = newDate.getFullYear()+ "-" + newmonth  + "-"+ newday +" " + newhr +":" +newmin +":" + nwsec ;

    return newDBDate;
}
function Comparedate(sDate1,sDate2,sDateFormat)
{
        var Date1=LocalToDB(sDate1,sDateFormat);
	var Date2=LocalToDB(sDate2,sDateFormat);
	var Year1=Date1.substring(0,Date1.indexOf("-")); //2003-12-12 12:12:12
	var Year2=Date2.substring(0,Date2.indexOf("-"));

	Date1=Date1.substring(Date1.indexOf("-")+1,Date1.length);//12-12 12:12:12
	Date2=Date2.substring(Date2.indexOf("-")+1,Date2.length);

	var Month1=Date1.substring(0,Date1.indexOf("-"));
	var Month2=Date2.substring(0,Date2.indexOf("-"));
	Date1=Date1.substring(Date1.indexOf("-")+1,Date1.length);//12 12:12:12
	Date2=Date2.substring(Date2.indexOf("-")+1,Date2.length);

	var Day1=Date1.substring(0,Date1.indexOf(" "));
	var Day2=Date2.substring(0,Date2.indexOf(" "));
	Date1=Date1.substring(Date1.indexOf(" ")+1,Date1.length);//12:12:12
	Date2=Date2.substring(Date2.indexOf(" ")+1,Date2.length);

	var Hour1=Date1.substring(0,Date1.indexOf(":"));
	var Hour2=Date2.substring(0,Date2.indexOf(":"));
	Date1=Date1.substring(Date1.indexOf(":")+1,Date1.length);//12:12
	Date2=Date2.substring(Date2.indexOf(":")+1,Date2.length);

	var Min1=Date1.substring(0,Date1.indexOf(":"));
	var Min2=Date2.substring(0,Date2.indexOf(":"));
	var Sec1=Date1.substring(Date1.indexOf(":")+1,Date1.length);//12
	var Sec2=Date2.substring(Date2.indexOf(":")+1,Date2.length);

//new Date(yy,mm,dd,hh,mm,ss)

	var d1=new Date(Year1,Month1,Day1,Hour1,Min1,Sec1);
	var d2=new Date(Year2,Month2,Day2,Hour2,Min2,Sec2);

	var i1 = d1.valueOf();
	var i2 = d2.valueOf();
      	if(i1 > i2)
            {
		return -1;
            }
	else 
		{
		  return 0;
                }
}


function append2List(list, name, value)
{
    var i;
    for(i=0; i< list.options.length; ++i)
    {
        if(name==list.options[i].text)
            break;
    }
    if(i==list.options.length)
    {
            list.options[i]= new Option(name,value);
    }
}



function removeListItem(list, n)
{
    list.options[n] = null;
}


function format(valuelessten)
{
    if(parseInt(valuelessten) <10)
    {
        switch(parseInt(valuelessten))
        {
            case 0:
                return("00");
            case 1:
                return("01");

            case 2:
                return("02");

            case 3:
                return("03");

            case 4:
                return("04");

            case 5:
                return("05");

            case 6:
                return("06");

            case 7:
                return("07");

            case 8:
                return("08");

            case 9:
                return("09");
        }
    }
    else
        return valuelessten;
}