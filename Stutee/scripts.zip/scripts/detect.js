
var agt=navigator.userAgent.toLowerCase();
var ie = (agt.indexOf("msie") != -1);
var ns = (navigator.appName.indexOf("Netscape") != -1);
var windw = ((agt.indexOf("win")!=-1) || (agt.indexOf("32bit")!=-1));
var mac = (agt.indexOf("mac")!=-1);
var pluginlist = '';

/*
pluginlist += navigator.javaEnabled() ? "Java," : "";

if (pluginlist.length > 0)
	pluginlist = pluginlist.substring(0,pluginlist.length-1);*/
