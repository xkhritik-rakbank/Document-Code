
var msg=new Object();
msg.messages=new Array();

msg.Message=function(id,message,width,height){
  this.id=id;
  msg.messages[id]=this;
  this.width = width;
  this.height = height;
  this.message=message;
  this.attachToBar();
}


msg.Message.prototype.attachToBar=function(){
  if (!msg.dialog){
        msg.dialog=msg.createDialog(this.id+"_dialog",true,this.width,this.height);
    }
  else{
        if(this.id.indexOf('wait')!=-1)
              msg.dialog.className = 'waitDialog';
        else
              msg.dialog.className='dialog';
        msg.dialog.style.width = this.width+'px';
        msg.dialog.style.height = this.height+'px';
        //msg.dialog.style.top = (window.screen.height - this.height)/2 + "px";
        //msg.dialog.style.left = (window.screen.width - this.width)/2 + "px";
        msg.dialog.style.top =(document.body.clientHeight- this.height)/2 +"px";
        msg.dialog.style.left =(document.body.clientWidth- this.width)/2+"px";
  }
    this.render(msg.dialog.tbod);
    msg.showDialog();
}



msg.createDialog=function(id,isModal,width,height){
  var dialog=document.createElement("div");
  if(id.indexOf('wait')!=-1)
      dialog.className = 'waitDialog';
  else
      dialog.className='dialog';
  dialog.style.width = width+'px';
  dialog.style.height = height+'px';
  //dialog.style.top = (window.screen.height - width)/2 + "px";
  //dialog.style.left = (window.screen.width - height)/2 + "px";
  dialog.style.top =(document.body.clientHeight - height)/2 +"px";
  dialog.style.left =(document.body.clientWidth - width)/2+"px";
  dialog.id=id;
  var tbl=document.createElement("table");
  dialog.appendChild(tbl);
  dialog.tbod=document.createElement("tbody");
  tbl.appendChild(dialog.tbod);
  if (isModal){
    dialog.modalLayer=document.createElement("div");
    dialog.modalLayer.className='modal';
    dialog.modalLayer.appendChild(dialog);
    document.body.appendChild(dialog.modalLayer);
  }else{
    dialog.className+=' non-modal';
    document.body.appendChild(dialog);
  }
  return dialog;
}


msg.Message.prototype.render=function(el){
        this.renderFull(el);
}


msg.Message.prototype.renderFull=function(el){
  var topEl=null;
  this.row=document.createElement("tr");
  styling.removeAllChildren(msg.dialog.tbod);//changed
  topEl=this.row;
  
  var txtTd=document.createElement("td");
  txtTd.valign='top';
  txtTd.className="msg_text";
  this.row.appendChild(txtTd);
  txtTd.innerHTML=this.message;
  el.appendChild(topEl);
}


msg.showDialog=function(e){
 var dialog=(this.dialog) ? this.dialog : msg.dialog;
  if (dialog){
    if (dialog.modalLayer){
        dialog.modalLayer.style.display='block';
   }else{
       dialog.style.display='block';
    }
  }
}

msg.hideDialog=function(e){
  var dialog=(this.dialog) ? this.dialog : msg.dialog;
  if (dialog){
    if (dialog.modalLayer){
      dialog.modalLayer.style.display='none';
    }else{
      dialog.style.display='none';
    }
  }
}

var styling=new Object();

styling.removeAllChildren=function(ele){
  if (ele){
    while(ele.firstChild){
      ele.removeChild(ele.firstChild);
    }
  }
}
