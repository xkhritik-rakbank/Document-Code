

var optionString;
var checked=0;
var deleteEnabled="N";
var deldoclist="";
var todel=true;
var index;
var docName;
var DocExt;
var ISIndex;  
var docIndex;
var versionNo;
var docAttrib;
var checkoutstatus;
var checkoutby;
var loggedinuser;
var queueType;
var lockstatus;
var viewmode;
var isConversation;
var NoOfPages;
var comments;
var CurrentSel="3";
var annot="n";
function allChecked(){
    optionString = document.getElementById('doclistview:doclisttable').tBodies[0].rows.length;
     var isPdfDoc=false;
     var downloadRights=true;
    if(document.getElementById('doclistview:doclisttable:hdrChk').checked == true){
        for(var wiNum=0; wiNum<optionString;wiNum++){   
            if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':isdownload').value == "false")
                downloadRights=false;
            document.getElementById('doclistview:doclisttable:'+ wiNum + ':iChk').checked = true;
            if(document.getElementById('doclistview:doclisttable:'+ wiNum + ':docExt').innerHTML=="pdf")
                isPdfDoc=true; 
        }
        // setSelection("all");
        /*if(isPdfDoc==true){
            document.getElementById("doclistview:printdoc").style.display = "inline";
            document.getElementById("doclistview:enprintdoc").style.display = "none";
        }else{
            document.getElementById("doclistview:printdoc").style.display = "none";
            document.getElementById("doclistview:enprintdoc").style.display = "inline";
        }*/
//        document.getElementById("doclistview:download").style.display = "none";
        if((typeof showStyleDownload != "undefined"  && showStyleDownload !="" && showStyleDownload =="Y") && ((typeof documentDownloadFlag != "undefined"  && documentDownloadFlag !="" && documentDownloadFlag =="Y")|| downloadRights==true || (typeof window.opener.isEnableDownloadPrint != 'undefined' && window.opener.isEnableDownloadPrint(strprocessname,stractivityName,userName)==true)) && (window.opener.strPrintOption=="2")){
            document.getElementById("doclistview:endownloaddoc").style.display = "inline";
            document.getElementById("doclistview:download").style.display = "none";
        }
        else{
            document.getElementById("doclistview:download").style.display = "inline";
            document.getElementById("doclistview:endownloaddoc").style.display = "none";
        }
    }
    else if (document.getElementById('doclistview:doclisttable:hdrChk').checked == false){
        for(var wiNum=0; wiNum<optionString;wiNum++)
            document.getElementById('doclistview:doclisttable:'+ wiNum + ':iChk').checked = false;
        /*document.getElementById("doclistview:printdoc").style.display = "inline";
        document.getElementById("doclistview:enprintdoc").style.display = "none";*/
        document.getElementById("doclistview:download").style.display = "inline";
        document.getElementById("doclistview:endownloaddoc").style.display = "none";
    }
    if (document.getElementById("doclistview:chkout") != null) {
        document.getElementById("doclistview:chkout").style.display = "inline";
    }
    if (document.getElementById("doclistview:encheckoutdoc") != null) {
        document.getElementById("doclistview:encheckoutdoc").style.display = "none";
    }
    if (document.getElementById("doclistview:encheckindoc") != null) {
        document.getElementById("doclistview:encheckindoc").style.display = "none";
    }
    if (document.getElementById("doclistview:version") != null) {
        document.getElementById("doclistview:version").style.display = "inline";
    }
    if (document.getElementById("doclistview:enversiondoc") != null) {
        document.getElementById("doclistview:enversiondoc").style.display = "none";
    }
    if(!(ShowDocListInReadMode=='Y'&&viewMode=='R'))
        enableDelete();
    if(typeof documentListWinHook != 'undefined')
        documentListWinHook(strprocessname,stractivityName,strqueuename,strqueueID);
    
}

function setSelection(){
    optionString = document.getElementById('doclistview:doclisttable').tBodies[0].rows.length;
    var isDocSelected=false;
    var isPdfDoc=false;
    var downloadRights=true;
    for(var wiNum=0; wiNum<optionString;wiNum++){ 
        if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':iChk').checked == true){
            checked=1; 
            }
        else{
            checked=0;
            break;
        } 
    }  
    for(var wiNum=0; wiNum<optionString;wiNum++){ 
        if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':iChk').checked == true){
            isDocSelected=true;
            if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':isdownload').value == "false")
                downloadRights=false;
             if(document.getElementById('doclistview:doclisttable:'+ wiNum + ':docExt').innerHTML=="pdf")
                 isPdfDoc=true; 
        } 
    }  
    
    if (checked==1)
        document.getElementById('doclistview:doclisttable:hdrChk').checked=true;
    else
        document.getElementById('doclistview:doclisttable:hdrChk').checked=false;
    if(isDocSelected==true && (typeof showStyleDownload != "undefined"  && showStyleDownload !="" && showStyleDownload =="Y") &&  ((typeof documentDownloadFlag != "undefined"  && documentDownloadFlag !="" && documentDownloadFlag =="Y")||downloadRights==true || (typeof window.opener.isEnableDownloadPrint != 'undefined' && window.opener.isEnableDownloadPrint(strprocessname,stractivityName,userName)==true) ) && (window.opener.strPrintOption=="2")){
        /*if(isPdfDoc==true){
            document.getElementById("doclistview:printdoc").style.display = "inline";
            document.getElementById("doclistview:enprintdoc").style.display = "none";
        }else{
            document.getElementById("doclistview:printdoc").style.display = "none";
            document.getElementById("doclistview:enprintdoc").style.display = "inline";
        }*/
        document.getElementById("doclistview:download").style.display = "none";
        document.getElementById("doclistview:endownloaddoc").style.display = "inline";
    }else{
        /*document.getElementById("doclistview:printdoc").style.display = "inline";
        document.getElementById("doclistview:enprintdoc").style.display = "none";*/
        document.getElementById("doclistview:download").style.display = "inline";
        document.getElementById("doclistview:endownloaddoc").style.display = "none";
    }
    if(!(ShowDocListInReadMode=='Y'&&viewMode=='R')){
        enableDelete();
        if(IsCheckoutOption=="Y")
            enableCheckIn(); 
        enableVersion();
        
    }
    
     enableVersion();
    
    if(typeof documentListWinHook != 'undefined')
        documentListWinHook(strprocessname,stractivityName,strqueuename,strqueueID);
}

function openDocument(documentIndex,documentType,ISIndex,documentName,docOrgName,docExt){
    var listParam=new Array();
    listParam.push(new Array("wid",encode_ParamValue(wid)));
    listParam.push(new Array("pid",encode_ParamValue(pid)));
    listParam.push(new Array("taskid",encode_ParamValue(taskid)));
    listParam.push(new Array("WD_SID",encode_ParamValue(WD_SID)));
    listParam.push(new Array("docIndex",encode_ParamValue(documentIndex)));
    listParam.push(new Array("docType",encode_ParamValue(documentType)));
    listParam.push(new Array("ISIndex",encode_ParamValue(ISIndex)));
    listParam.push(new Array("docName",encode_ParamValue(documentName.replace(/'/g,"\\'"))));
    listParam.push(new Array("docOrgName",encode_ParamValue(docOrgName.replace(/'/g,"\\'")) ));
    listParam.push(new Array("docExt",encode_ParamValue(docExt)));
    listParam.push(new Array("rid",encode_ParamValue(MakeUniqueNumber())));
    listParam.push(new Array("calledFrom",encode_ParamValue("D")));
    
    var wFeatures = 'scrollbars=no,status=yes,width='+650+',height='+580+',left='+(window.screen.width - 650)/2+',top='+(window.screen.height - 650)/2+',resizable=yes';

    var url = '/webdesktop/components/workitem/view/doclistview.app';
    url = appendUrlSession(url);
    var win;
    var winName = "docpopup_"+pid+"_"+documentIndex;
    if(typeof window.opener != 'undefined')
    {
        win = window.opener.openNewWindow(url,winName,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    }
    else
    {
        win = openNewWindow(url,winName,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    }
    win.focus();
} 

function openDocumentIframe(documentIndex){
    var listParam=new Array();
    listParam.push(new Array("wid",encode_ParamValue(wid)));
    listParam.push(new Array("pid",encode_ParamValue(pid)));
    listParam.push(new Array("taskid",encode_ParamValue(taskid)));
    listParam.push(new Array("docIndex",encode_ParamValue(documentIndex)));
    listParam.push(new Array("rid",encode_ParamValue(MakeUniqueNumber())));  
    var wFeatures = 'scrollbars=no,status=yes,width='+650+',height='+580+',left='+(window.screen.width - 650)/2+',top='+(window.screen.height - 650)/2+',resizable=yes';

    var url = '/webdesktop/components/workitem/view/doclistview.app';
    url = appendUrlSession(url);

    var win = openNewWindow(url,"",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
   
    win.focus();
} 
 
function deletedocs(){
     if(!confirm(COMMENT_DELETE_DOCUMENT))
         return false;
    optionString = document.getElementById('doclistview:doclisttable').tBodies[0].rows.length;
    var requestString='deldoclist='+deldoclist+'&CustomAjax=true&isMultiDelete=Y&pid='+encode_utf8(pid)+'&wid='+wid+'&taskid='+taskid;
    var ajaxReq;
    if (window.XMLHttpRequest) {
        ajaxReq= new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        ajaxReq= new ActiveXObject("Microsoft.XMLHTTP");
    }
    var url = "/webdesktop/ajaxdeleteDoc.app";
    url = appendUrlSession(url);
    var wd_rid=getRequestToken(url);
         url+="&WD_RID="+wd_rid;
    if (ajaxReq != null) {
        ajaxReq.open("POST", url, false);
        ajaxReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        ajaxReq.send(requestString);
        if (ajaxReq.status == 200 && ajaxReq.readyState == 4) {
            if ((typeof window.opener.opall_toolkit != 'undefined') && (window.opener.opall_toolkit != null)) {
                window.opener.opall_toolkit = null;
            }
            
        var docWin = window.opener;
        var objDocCombo = docWin.document.getElementById('wdesk:docCombo');
        if (typeof docWin != 'undefined' && docWin != null && typeof objDocCombo != 'undefined' && objDocCombo != null && deldoclist.length > 0) {            
            var arrDocIndex = deldoclist.split(',');
            var tmpDocIndex = -1;
            var comboIndex = -1;
            for (var c = 0; c < arrDocIndex.length; c++) {
                tmpDocIndex = Trim(arrDocIndex[c]);
                if (tmpDocIndex.length > 0) {
                    tmpDocIndex = parseInt(tmpDocIndex);
                    comboIndex = getDocComboIndex(objDocCombo, tmpDocIndex);
                    if (comboIndex != -1) {
                        objDocCombo.options[comboIndex] = null;
                    }
                    docWin.removeDocPane(tmpDocIndex, '0');
                }
            }

            var newDocIndex = -1;
            if (objDocCombo.options.length >= 1) {
                newDocIndex = objDocCombo.options[0].value;
                if (newDocIndex == -1 && objDocCombo.options.length > 1) {
                    newDocIndex = objDocCombo.options[1].value;
                    objDocCombo.selectedIndex = 1;
                } else {
                    objDocCombo.selectedIndex = 0;
                }
            }
			var noDoc = docWin.document.getElementById("wdesk:noDocPnl");
                        docWin.lastSelDocIndex = '-1';
            if (noDoc && hasCSS(noDoc, 'dn')) {
                docWin.loadWdSidebar('Documents', docWin.getParentSidebar('Documents'), null, 'opt=0', '', '','deletedoc');
            }

            if (newDocIndex != -1) {
                docWin.reloadapplet(newDocIndex, '', 'deletedoc', '', false);
            }
        }
        if (typeof deleteDocPostHandler != "undefined") {
            deleteDocPostHandler(deldoclist);
        }
        refreshDocumentList();
    } else {
        if (ajaxReq.status == 598) {
            customAlert(ajaxReq.responseText);
        } else if (ajaxReq.status == 599)
            window.open("/webdesktop/login/logout.jsp?" + "error=4020", reqSession);
        else if (ajaxReq.status == 310) {
            window.location = "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";
        } else if (ajaxReq.status == 250) {
            window.location = "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";
        } else if (ajaxReq.status == 400)
            customAlert(INVALID_REQUEST_ERROR);
        else if (ajaxReq.status == 12029) {
            customAlert(ERROR_SERVER);
        } else
            customAlert(ERROR_DATA);
        
        if (typeof deleteDocPostHandler != "undefined") {
            deleteDocPostHandler(deldoclist);
        }
    }
    window.focus();
}
}


function enableDelete(){
    todel=true;
    deldoclist="";
    var delflag=0;
    for(var wiNum=0; wiNum<optionString;wiNum++){
        if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':iChk').checked == true) {
            if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':isdeldoc').value=="true" && document.getElementById('doclistview:doclisttable:'+ wiNum + ':ischeckin').value=="false") {
                deldoclist=deldoclist+document.getElementById('doclistview:doclisttable:'+ wiNum + ':docIndex').value+",";
                if (todel==true)
                    todel=true;
                deleteEnabled="Y";
                delflag=1;
            }
            else
                todel=false;
            
        }   
        if (todel==false)
            break;
    }
    if (delflag==0)
        deleteEnabled="N";
     
    if (deleteEnabled=="Y" && todel==true){
        document.getElementById("doclistview:deletedoc").style.display = "none";
        document.getElementById("doclistview:endeletedoc").style.display = "inline";
    } 
    else{
        document.getElementById("doclistview:deletedoc").style.display = "inline";
        document.getElementById("doclistview:endeletedoc").style.display = "none";
    }
}

function enablePrint(){
    var count=0;    
    optionString = document.getElementById('doclistview:doclisttable').tBodies[0].rows.length;
    /*document.getElementById("doclistview:printdoc").style.display = "inline";
    document.getElementById("doclistview:enprintdoc").style.display = "none";*/
    
}
 var printPool =new Array();
 var  noOfrecods=0;
 var recordsPrinted = 0; 
 var winPrintStatues="";
 
function printdocs() {
     /*document.getElementById("doclistview:printdoc").style.display = "inline";
     document.getElementById("doclistview:enprintdoc").style.display = "none";*/
   var strRowLength= document.getElementById('doclistview:doclisttable').rows.length;
   printPool =new Array();
   noOfrecods=0;
     for(i=0;i<strRowLength-1;i++){ 
           if(document.getElementById('doclistview:doclisttable:'+i+':iChk').checked==true){
                  printPool[noOfrecods]=i; 
                  noOfrecods++;
               }
       }  
  /* if(printPool.length==1 &&document.getElementById('doclisttable:'+printPool[0]+ ':docType').value=="I" ){
       var url = '/webdesktop/faces/workitem/view/printdialog.jsp';    
       docName = document.getElementById('doclisttable:' + printPool[0]+ ':docNameVal').innerHTML;
       docIndex= document.getElementById('doclisttable:' + printPool[0] + ':docIndex').value;
       versionNo=document.getElementById('doclisttable:' +printPool[0] + ':docVersion').innerHTML;
       ISIndex=document.getElementById('doclisttable:' + printPool[0] + ':ISIndex').value;
       noPages=document.getElementById('doclisttable:' + printPool[0] + ':docNoOfPages').innerHTML;
       DocExt = document.getElementById('doclisttable:' + printPool[0] + ':docExt').innerHTML;
       url=url+"?docName="+encode_utf8(docName)+"&Version="+versionNo+"&ISIndex="+encode_utf8(ISIndex)+"&noPages="+noPages+"&docExt="+DocExt+"&docId="+docIndex;
       url = appendUrlSession(url);
       var win = link_popup(url, 'printDialog', 'resizable=no,scrollbars=no,width='+wratio*windowW+',height='+hratio*windowH+',left='+windowY+',top='+windowX,windowList,false);        
   }else{*/
      recordsPrinted=0; 
      winPrintStatues = window.open('','printStatus','height=200,width=150,resizable=no,left='+windowY+',top='+windowX);
      winPrintStatues.document.write("<HTML><HEAD><TITLE>");
      winPrintStatues.document.write(WL_STATUS);
      winPrintStatues.document.write(" </TITLE></HEAD><BODY>");
      winPrintStatues.document.write("<table width='100%'><tr><td align='RIGHT' width='100%'><img src='/webdesktop/resources/images/logo.jpg'/></td></tr><tr><td><center><div  style='color:green;FONT: ^8^pt Arial;' id='printStatuesDiv'><table width='100%'><tr><td style='color:green;FONT: ^8^pt Arial;' width='100%'>");
      winPrintStatues.document.write(recordsPrinted+" "+LABEL_OUT_OF+" "+printPool.length+" "+LABEL_DOCUMENTS_PRINTED);
      winPrintStatues.document.write("</td></tr><tr><td align='center'><img src='/webdesktop/resources/images/progress.gif'/></td></tr></table></div></d></tr></table></center></BODY></HTML>");
      printDocumentPool();
   //}
}
 function startPrinting() {
       if(winPrintStatues)
           winPrintStatues.document.getElementById("printStatuesDiv").innerHTML=encode_ParamValue("<table width='100%' ><tr><td style='color:green;FONT: ^8^pt Arial;' width='100%'>"+recordsPrinted+" "+LABEL_OUT_OF+" "+printPool.length +" "+LABEL_DOCUMENTS_PRINTED+"</td></tr><tr><td align='center'><img src='/webdesktop/resources/images/progress.gif'/></td></tr></table>");
        // winPrintStatues.document.getElementById("printStatuesDiv").innerHTML=recordsPrinted+" out of  "+printPool.length +" document gets printed";
     setTimeout("printDocumentPool()",8000);
 }
 
function printDocumentPool(){
    if(recordsPrinted==printPool.length){
        if(winPrintStatues){
            winPrintStatues.close();
            
        }
        /*document.getElementById("doclistview:printdoc").style.display = "none";
        document.getElementById("doclistview:enprintdoc").style.display = "inline";*/
        return;
    }else {
           if (document.getElementById('doclistview:doclisttable:'+printPool[recordsPrinted]+ ':docType').value!="I"){
            docName = document.getElementById('doclistview:doclisttable:' + printPool[recordsPrinted]+ ':docNameVal').innerHTML;
            docIndex= document.getElementById('doclistview:doclisttable:' + printPool[recordsPrinted] + ':docIndex').value;
            versionNo=document.getElementById('doclistview:doclisttable:' +printPool[recordsPrinted] + ':docVersion').innerHTML;
            ISIndex=document.getElementById('doclistview:doclisttable:' + printPool[recordsPrinted] + ':ISIndex').value;
            noPages=document.getElementById('doclistview:doclisttable:' + printPool[recordsPrinted] + ':docNoOfPages').innerHTML;
            DocExt = document.getElementById('doclistview:doclisttable:' + printPool[recordsPrinted] + ':docExt').innerHTML;
            recordsPrinted++; 
            var printUrl=sContextPath+"/servlet/getdocument?ISIndex="+encode_utf8(ISIndex)+"&DocExt="+DocExt+"&DocIndex="+encode_utf8(docIndex)+"&DocumentName="+encode_utf8(docName)+"&isPrint=Y&pid="+encode_utf8(pid)+"&wid="+wid+"&taskid="+taskid+"&WD_SID="+WD_SID+"&WD_RID="+getRequestToken('/webdesktop/servlet/getdocument');
            var innerText       = ""; 
            innerText 		= '<html>'+				
            '<frameset onload="window.print();window.close();">'+
            '<frame name="nonImage"  src="'+printUrl+'" onload="" frameborder="no" border="0" scrolling="no"></frame>'+									
            '</frameset>'+
            '</html>';	 
            var win = window.open('','name'+docIndex,'height=200,width=150,resizable=yes');
            var temp = win.document;				
            temp.write(innerText);							
            temp.close();  
        }
        else{
            var appletFrame    = window.frames.printApplet;
            var appletObject = appletFrame.document.IVApp;
            if(appletObject){
                while(true){  
                    if(appletObject.getPrintStatus() == 2) {
                        continue;
                    }
                    docName = document.getElementById('doclistview:doclisttable:' + printPool[recordsPrinted]+ ':docNameVal').innerHTML;
                    docIndex= document.getElementById('doclistview:doclisttable:' + printPool[recordsPrinted] + ':docIndex').value;
                    versionNo=document.getElementById('doclistview:doclisttable:' +printPool[recordsPrinted] + ':docVersion').innerHTML;
                    ISIndex=document.getElementById('doclistview:doclisttable:' + printPool[recordsPrinted] + ':ISIndex').value;
                    noPages=document.getElementById('doclistview:doclisttable:' + printPool[recordsPrinted] + ':docNoOfPages').innerHTML;
                    DocExt = document.getElementById('doclistview:doclisttable:' + printPool[recordsPrinted] + ':docExt').innerHTML;
                    recordsPrinted++;
                    var strUrl=strPrintUrl+"&ISIndex=" +encode_utf8(ISIndex) + "&DocIndex="+encode_utf8(docIndex)+ "&DocExt=" + DocExt+"&WD_SID="+WD_SID+"&wid="+wid+"&pid="+encode_utf8(pid)+"&taskid="+taskid;
                    var strPrintAnnotUrl=strAnnotUrl+"&DocId="+docIndex+"&WD_SID="+WD_SID;
                    //appletFrame.document.IVApp.sample();
                    appletFrame.document.IVApp.printDocument(strUrl,strPrintAnnotUrl,parseInt("1"),parseInt(noPages))
                    break;
                }
            }   
        
        }    
        startPrinting();
    }
   
   }


function enableCheckIn(){
    var count=0;        
    optionString = document.getElementById('doclistview:doclisttable').tBodies[0].rows.length;    
    for(var wiNum=0; wiNum<optionString;wiNum++){
        if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':iChk').checked == true) {
            count++;
            if (count==1)
                index=wiNum;
        }
        
    } 
    
    var isConversation = document.getElementById('doclistview:doclisttable:'+ index + ':isConversation').value;
    if(isConversation == "Y"){
        document.getElementById("doclistview:chkout").style.display = "inline";
        document.getElementById("doclistview:encheckoutdoc").style.display = "none";
        document.getElementById("doclistview:encheckindoc").style.display = "none";
        return;
    }
    
    if(document.getElementById('doclistview:doclisttable:'+ index + ':iChk').checked == true) {
        var docIndex = document.getElementById('doclistview:doclisttable:'+ index + ':docIndex').value;
        var attachmentStatus;
        docProperty(docIndex,pid,wid,taskid);
        if(docAttrib==-1)
            attachmentStatus ='a';
        else
            attachmentStatus = Trim(docAttrib.toLowerCase());
    
        attachmentStatus = (attachmentStatus == 'm' || attachmentStatus == 't' )? true : false;
        var toUser = ((checkoutby == userLoggedIn || checkoutby.toLowerCase() == loggedinuser.toLowerCase()) || ((viewmode.toUpperCase()=='W' || viewmode.toUpperCase()=='N') && (checkoutby=='' || checkoutby.toLowerCase() == 'null' || checkoutby=='0')))?true:false;
        var allowCheckInCheckOut =   (attachmentStatus && toUser && isConversation!="Y")? true : false; 
        if(allowCheckInCheckOut) {
            if (count==1 && document.getElementById('doclistview:doclisttable:'+ index + ':ischeckin').value=="false"){  // && (navigator.appName.indexOf("Microsoft") != -1)
        
                document.getElementById("doclistview:chkout").style.display = "none";
                document.getElementById("doclistview:encheckoutdoc").style.display = "inline";
                document.getElementById("doclistview:encheckindoc").style.display = "none";
                count=0;
        
            }
            else if (count==1 && document.getElementById('doclistview:doclisttable:'+ index + ':ischeckin').value=="true"){  // && (navigator.appName.indexOf("Microsoft") != -1)
        
                document.getElementById("doclistview:chkout").style.display = "none";
                document.getElementById("doclistview:encheckoutdoc").style.display = "none";
                document.getElementById("doclistview:encheckindoc").style.display = "inline";
                count=0;
        
            }
    
            else {
                document.getElementById("doclistview:chkout").style.display = "inline";
                document.getElementById("doclistview:encheckoutdoc").style.display = "none";
                document.getElementById("doclistview:encheckindoc").style.display = "none";
            }
        } else {
            document.getElementById("doclistview:chkout").style.display = "inline";
            document.getElementById("doclistview:encheckoutdoc").style.display = "none";
            document.getElementById("doclistview:encheckindoc").style.display = "none";
        }
    } else {
        document.getElementById("doclistview:chkout").style.display = "inline";
        document.getElementById("doclistview:encheckoutdoc").style.display = "none";
        document.getElementById("doclistview:encheckindoc").style.display = "none";
    }
    if(docType=="V"){
        document.getElementById("doclistview:chkout").style.display = "inline";
        document.getElementById("doclistview:encheckoutdoc").style.display = "none";
        document.getElementById("doclistview:encheckindoc").style.display = "none";  
    }
}

function enableVersion(){
    var count=0;    
    optionString = document.getElementById('doclistview:doclisttable').tBodies[0].rows.length;
    for(var wiNum=0; wiNum<optionString;wiNum++){
        if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':iChk').checked == true) {
            count++;
            if (count==1)
                index=wiNum;
        }
        
    } 
    
    if (count==1 && document.getElementById('doclistview:doclisttable:'+ index + ':isversion').value=="true"){  // && (navigator.appName.indexOf("Microsoft") != -1)
        
        document.getElementById("doclistview:version").style.display = "none";
        document.getElementById("doclistview:enversiondoc").style.display = "inline";
        count=0;
        
    }
    else{
        document.getElementById("doclistview:version").style.display = "inline";
        document.getElementById("doclistview:enversiondoc").style.display = "none";
    }
}

function enableDownload(){ 
        document.getElementById("doclistview:download").style.display = "none";
        document.getElementById("doclistview:endownloaddoc").style.display = "inline";
}

function downloadDocument(){
    optionString = document.getElementById('doclistview:doclisttable').tBodies[0].rows.length;
    var docName = ""; 
    var docIndex=  ""; 
    var versionNo= ""; 
    var ISIndex= ""; 
    var noPages= ""; 
    var DocExt =  ""; 
    var isDocDownlod=false; 
    var count=0;
    var tmpDocName, tmpDocName1, tmpDocExt, tmpDocComment;
    for(var i=0;i<optionString;i++){
        if(document.getElementById('doclistview:doclisttable:'+i+':iChk').checked==true){
            isDocDownlod=true;            
            count=count+1;
            
            tmpDocName = (document.getElementById('doclistview:doclisttable:' +i+ ':docNameVal').innerHTML).replace(/&amp;/g, '&');
            var sIndex = tmpDocName.lastIndexOf("(");
            if(sIndex != -1) {
                tmpDocName1 = tmpDocName.substring(0, sIndex);
            }
            tmpDocExt = document.getElementById('doclistview:doclisttable:' + i+ ':docExt').innerHTML;
            tmpDocComment = document.getElementById('doclistview:doclisttable:' + i+ ':docComment').value;
            var isDocCustomName = "N";
            if(typeof customDownloadedDocName != 'undefined') {
                var dldDispName = customDownloadedDocName(tmpDocName1, tmpDocComment, tmpDocExt, pid, strprocessname, stractivityName);
                if(typeof dldDispName != 'undefined' && dldDispName != "") {
                    tmpDocName = dldDispName;
                    sIndex = tmpDocName.lastIndexOf(".");
                    if(sIndex != -1) {
                        tmpDocName = tmpDocName.substring(0, sIndex);
                    }
                    isDocCustomName = "Y";
                }
            }
            
            tmpDocName = encode_utf8(tmpDocName);
            tmpDocExt = encode_utf8(tmpDocExt);
            tmpDocComment = encode_utf8(tmpDocComment);
            
            if(count>1){
                docName = docName+","+tmpDocName+",";
                docIndex= docIndex+","+document.getElementById('doclistview:doclisttable:' + i + ':docIndex').value+","; 
                ISIndex=ISIndex+","+document.getElementById('doclistview:doclisttable:' + i+ ':ISIndex').value+","; 
                DocExt =DocExt+","+tmpDocExt+",";
            }else{
                docName = docName + tmpDocName;
                docIndex= docIndex+document.getElementById('doclistview:doclisttable:' + i + ':docIndex').value ; 
                ISIndex=ISIndex+document.getElementById('doclistview:doclisttable:' + i+ ':ISIndex').value ; 
                DocExt =DocExt + tmpDocExt;
            }
        }
    }
    docIndex = encode_ParamValue(docIndex);
    ISIndex = encode_ParamValue(ISIndex);
    docName = docName.split("'").join("%27");
    if(typeof isAllowDownload != 'undefined' && !isAllowDownload(strprocessname, stractivityName, docName)) {
        return false;
    }
    if(isDocDownlod==true){
        if(count==1)
            docName=docName+"."+DocExt;
        var servlet = sContextPath+"/servlet/getdocument?WD_SID="+WD_SID+"&WD_RID="+getRequestToken('/webdesktop/servlet/getdocument');
        var reqToken = generateReqToken();
        var oIFrm;
        oIFrm = document.getElementById('svfrm');
        servlet = appendUrlSession(servlet);
        var popup = (oIFrm.contentWindow) ? oIFrm.contentWindow : (oIFrm.contentDocument.document) ? oIFrm.contentDocument.document : oIFrm.contentDocument;
        popup.document.open();
        popup.document.write("<HTML><HEAD><TITLE></TITLE></HEAD><BODY>");
        popup.document.write("<form id='postSubmit' method='post' action='"+servlet+"' accept-charset='UTF-8' enctype='application/x-www-form-urlencoded'>");//Bug 74449
        popup.document.write("<input type='hidden' id='ISIndex' name='ISIndex' value='"+ISIndex+"' />");
        popup.document.write("<input type='hidden' id='DocExt' name='DocExt' value='"+DocExt+"' />");
        popup.document.write("<input type='hidden' id='DocIndex' name='DocIndex' value='"+docIndex+"' />");
        popup.document.write("<input type='hidden' id='PageNo' name='PageNo' value='1' />");
        popup.document.write("<input type='hidden' id='DocumentName' name='DocumentName' value=\""+docName+"\" />");
        popup.document.write("<input type='hidden' id='ReqToken' name='ReqToken' value='"+reqToken+"' />");
        popup.document.write("<input type='hidden' id='wid' name='wid' value='"+wid+"' />");
        popup.document.write("<input type='hidden' id='pid' name='pid' value='"+pid+"' />");
        popup.document.write("<input type='hidden' id='DownloadFlag' name='DownloadFlag' value='Y' />");
        popup.document.write("<input type='hidden' id='WD_SID' name='WD_SID' value='"+WD_SID+"' />");
		popup.document.write("<input type='hidden' id='ArchivalMode' name='ArchivalMode' value='" + window.opener.ArchivalMode + "' />");
        popup.document.write("<input type='hidden' id='ArchivalCabinet' name='ArchivalCabinet' value='" + ArchivalCabinet + "' />");
        //popup.document.write("<input type='hidden' id='EngineName' name='EngineName' value='"+cabName+"' />");
        //popup.document.write("<input type='hidden' id='MultiDownload' name='MultiDownload' value='Y' />");
        if(count>1) {
            popup.document.write("<input type='hidden' id='MultiDownload' name='MultiDownload' value='Y' />");
        } else if(count == 1) {
            popup.document.write("<input type='hidden' id='DocCustomName' name='DocCustomName' value=\""+isDocCustomName+"\" />");
        }
        popup.document.write("</FORM></BODY></HTML>");
        popup.document.close();
        popup.document.forms[0].submit();
        /*var url =  sContextPath+"/servlet/getdocument?ISIndex="+encode_utf8(ISIndex)+"&DocExt="+encode_utf8(DocExt)+ "&DocIndex="+docIndex+"&PageNo=1&DocumentName="+encode_utf8(docName)+"&DownloadFlag=Y"+"&wid="+encode_utf8(wid)+"&pid="+encode_utf8(pid);    //Bug 62239

        if(count>1)
            url += "&MultiDownload=Y"; 
        
        url = appendUrlSession(url);
        
//        var listParam=new Array();
//        listParam.push(new Array("ISIndex",encode_ParamValue(ISIndex)));
//        listParam.push(new Array("DocExt",encode_ParamValue(DocExt)));
//        listParam.push(new Array("DocIndex",encode_ParamValue(docIndex)));
//        listParam.push(new Array("PageNo",encode_ParamValue("1")));
//        listParam.push(new Array("DownloadFlag",encode_ParamValue("Y")));
//        listParam.push(new Array("DocumentName",encode_ParamValue(docName+'.'+DocExt)));
//        generatePostRequest(window,url,listParam);
        var oIFrm;
        oIFrm = document.getElementById('svfrm');
        oIFrm.src = url;*/

    } 
}
function generateReqToken(){
    var xhReq;
    if (window.XMLHttpRequest)
        xhReq = new XMLHttpRequest();
    else{
        xhReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
    var url='/webdesktop/ajaxReqToken.app';
    url = appendUrlSession(url);
     var wd_rid=getRequestToken(url);
         url+="&WD_RID="+wd_rid;
    xhReq.open("POST", url, false);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhReq.send('&CustomAjax=true&WD_SID='+WD_SID);
    var serverResponse ="";
    if (xhReq.status == 200 && xhReq.readyState == 4){
        var serverResponse = xhReq.responseText;
        return serverResponse;
    }
     else if(xhReq.status==250)
            {
                window.location= "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";    
            }
    else{
          return serverResponse;
    }
}
function versionDocument() {
    var optionString = document.getElementById('doclistview:doclisttable').tBodies[0].rows.length;
    var strCheckIndex='';
    for(var wiNum=0; wiNum<optionString;wiNum++){
        if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':iChk').checked == true) {
            strCheckIndex=wiNum;
        } 
    }  
    docIndex = document.getElementById('doclistview:doclisttable:'+ strCheckIndex + ':docIndex').value;
    docProperty(docIndex,pid,wid,taskid);
    if(docAttrib==-1)
        var attachmentStatus ='a';
    else
        var attachmentStatus = Trim(docAttrib.toLowerCase());
    
    attachmentStatus = (attachmentStatus == 'm' || attachmentStatus == 't' )? true : false;
    var toUser = ((checkoutby.toLowerCase() == loggedinuser.toLowerCase()) || (viewmode.toUpperCase()=='W' && (checkoutby=='' || checkoutby == 'null')))?true:false;
    var allowDelete =   (attachmentStatus && toUser && queueType.toLowerCase()!='i' && !isConversation)? true : false; 
      var disableDeleteForOldVersion = (typeof window.opener.disableDeleteForOldVersion != 'undefined' && window.opener.disableDeleteForOldVersion(strprocessname,stractivityName,userName)) ? 'true' : 'false';
      var allowDownloadVersionDoc = ((window.opener.document.getElementById('wdesk:downloadDiv') && window.opener.document.getElementById('wdesk:downloadDiv').style.display == 'inline') || (typeof window.opener.enableDocDownloadFromVersion != 'undefined' && window.opener.enableDocDownloadFromVersion(strprocessname,stractivityName,userName))) ? 'true' : 'false';
    var url = '/webdesktop/components/workitem/document/version/docversionlist.app';
    url = appendUrlSession(url);
    var wFeatures = 'scrollbars=no,status=yes,resizable=yes,width='+window1W+',height='+window1H+',left='+window1Y+',top='+window1X;
    document.getElementById('doclistview:doclisttable:'+ index + ':isversion').value="true";
    document.getElementById('doclistview:doclisttable:'+ index + ':iChk').checked=false;
    setSelection();
    var listParam=new Array();
    listParam.push(new Array("ISIndex",encode_ParamValue(decode_utf8(ISIndex))));
    listParam.push(new Array("DocName",encode_ParamValue(docName)));
    listParam.push(new Array("DeleteFlag",encode_ParamValue(allowDelete)));    
    listParam.push(new Array("DocId",encode_ParamValue(docIndex)));    
    listParam.push(new Array("pid",encode_ParamValue(pid)));
    listParam.push(new Array("wid",encode_ParamValue(wid)));    
    listParam.push(new Array("taskid",encode_ParamValue(taskid)));
    listParam.push(new Array("fromDocList",encode_ParamValue("Y")));
    listParam.push(new Array("index",encode_ParamValue(strCheckIndex)));
    listParam.push(new Array("DisableDeleteForOldVersion",encode_ParamValue(disableDeleteForOldVersion)));
    listParam.push(new Array("AllowDownloadVersionDoc",encode_ParamValue(allowDownloadVersionDoc)));
    var win = openNewWindow(url,'Filter',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);  
}

function checkOut() {
    var optionString = document.getElementById('doclistview:doclisttable').tBodies[0].rows.length;
    var strCheckIndex='';
    for(var wiNum=0; wiNum<optionString;wiNum++){
        if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':iChk').checked == true) {
            strCheckIndex=wiNum;
        } 
    }  
    docIndex = document.getElementById('doclistview:doclisttable:'+ strCheckIndex + ':docIndex').value;
    docProperty(docIndex,pid,wid,taskid);    
    if(window.opener.SharingMode)
        window.opener.broadcastCheckOutDocEvent(docName,docType);
    var url = '/webdesktop/components/workitem/document/checkout/checkout_main.app';
    url = appendUrlSession(url);
    var wFeatures = 'scrollbars=yes,status=yes,resizable=yes,width='+windowW+',height='+windowH+',left='+windowY+',top='+windowX;
    
    var listParam=new Array();
    listParam.push(new Array("ISIndex",encode_ParamValue(decode_utf8(ISIndex))));
    listParam.push(new Array("Ext",encode_ParamValue(DocExt)));
    listParam.push(new Array("DocId",encode_ParamValue(docIndex)));
    listParam.push(new Array("DocName",encode_ParamValue(docName)));
    listParam.push(new Array("pid",encode_ParamValue(pid)));
    listParam.push(new Array("wid",encode_ParamValue(wid)));
    listParam.push(new Array("taskid",encode_ParamValue(taskid)));
    listParam.push(new Array("comments",encode_ParamValue(comments)));
    listParam.push(new Array("fromDocList",encode_ParamValue("Y")));
    listParam.push(new Array("index",encode_ParamValue(strCheckIndex)));
    var win = openNewWindow(url,'Filter',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    //document.getElementById('doclistview:doclisttable:'+ strCheckIndex + ':ischeckin').value="true";
    //document.getElementById('doclistview:doclisttable:'+ strCheckIndex + ':iChk').checked=false;
    //setSelection();
}
function checkIn() {
    var optionString = document.getElementById('doclistview:doclisttable').tBodies[0].rows.length;
    var strCheckIndex='';
    for(var wiNum=0; wiNum<optionString;wiNum++){
        if (document.getElementById('doclistview:doclisttable:'+ wiNum + ':iChk').checked == true) {
            strCheckIndex=wiNum;
        } 
    }  
    docIndex = document.getElementById('doclistview:doclisttable:'+ strCheckIndex + ':docIndex').value;
    docProperty(docIndex,pid,wid,taskid);
    var versionno=(version=='')?'1.0':version;
    var url = '/webdesktop/components/workitem/document/checkin/checkin.app';
    url = appendUrlSession(url);
    url += "&ISIndex="+encode_ParamValue(decode_utf8(ISIndex));
    url += "&DocName="+encode_utf8(docName);
    url += "&Extension="+encode_ParamValue(DocExt);
    url += "&VersionNo="+encode_ParamValue(versionno);
    url += "&DocId="+encode_ParamValue(docIndex);
    url += "&pid="+encode_utf8(pid);
    url += "&wid="+encode_ParamValue(wid);
    url += "&taskid="+encode_ParamValue(taskid);
    url += "&fromDocList="+encode_ParamValue("Y");
    url += "&index="+encode_ParamValue(strCheckIndex);
    var wFeatures = 'scrollbars=yes,status=yes,resizable=yes,width='+window8W+',height='+window8H+',left='+window8Y+',top='+window8X;
//    var listParam=new Array();
//    listParam.push(new Array("ISIndex",encode_ParamValue(decode_utf8(ISIndex))));
//    listParam.push(new Array("DocName",encode_ParamValue(docName)));
//    listParam.push(new Array("Extension",encode_ParamValue(DocExt)));
//    listParam.push(new Array("VersionNo",encode_ParamValue(versionno)));
//    listParam.push(new Array("DocId",encode_ParamValue(docIndex)));    
//    listParam.push(new Array("pid",encode_ParamValue(pid)));
//    listParam.push(new Array("wid",encode_ParamValue(wid)));    
//    listParam.push(new Array("fromDocList",encode_ParamValue("Y"))); 
//    listParam.push(new Array("index",encode_ParamValue(strCheckIndex))); 
    //var win = openNewWindow(url,'Filter',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    var win = link_popup(url,'Filter',wFeatures,windowList,'',false);
    
}

function  refreshDocList(from){
    clickLink("doclistview:refreshbtn");
        if(from=="DocumentList"){
             window.opener.sendAsynAjaxRequest('doc', "doc_main_view.app");
        }
    
    
}

function getPrintListUrl(){
    
    var docIndex = document.getElementById('doclisttable:' + index + ':docIndex').value;
    docPropertyPrint(docIndex,pid,wid);
    var printUrl="/webdesktop/servlet/getdocument?ISIndex="+ISIndex+"&DocExt="+DocExt+"&DocIndex="+encode_utf8(docIndex)+"DocumentName="+docName+"&WD_SID="+WD_SID+"&isPrint=Y"+"&wid="+encode_utf8(wid)+"&pid="+encode_utf8(pid)+"&WD_RID="+getRequestToken('/webdesktop/servlet/getdocument');     //Bug 62239
    return printUrl;
}   


function loadOpAllFrame(strDocIndex,strDocType)
{
        //var styleApp=document.getElementById('ivapp').style;
        var styleIfrm=document.getElementById('ifrm').style;
        var iframeCom=document.getElementById('ifrm');
        var getApplet=document.IVApplet?"N":"Y";
        var requestString='docindex='+encode_utf8(strDocIndex)+'&getApplet='+getApplet+'&pid='+encode_utf8(pid)+'&wid='+wid+'&taskid='+taskid+'&WD_SID='+WD_SID;
        if(typeof isFromCustom!='undefined' && isFromCustom=="Y"){
            requestString=requestString+'&fromCustom=Y';
        }
        var ajaxReq;
        if (window.XMLHttpRequest) {
            ajaxReq= new XMLHttpRequest();
        } else if (window.ActiveXObject) {
            ajaxReq= new ActiveXObject("Microsoft.XMLHTTP");
        }
        if(typeof isArchSearch=='undefined')
            isArchSearch="N";
        
        var url = "/webdesktop/ajaxgetdocument.app";
        url = appendUrlSession(url);
        var wd_rid=getRequestToken(url);
         url+="&WD_RID="+wd_rid;
            if (ajaxReq != null) {
            ajaxReq.open("POST", url, false);
            ajaxReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            ajaxReq.send(requestString + '&ArchiveSearch=' + isArchSearch);
            var res;
            if (ajaxReq.status == 200 && ajaxReq.readyState == 4) {

                //res=ajaxReq.responseText.substring(0,ajaxReq.responseText.indexOf("@"));
                //var appletHtm=ajaxReq.responseText.substring(ajaxReq.responseText.indexOf("@")+1,ajaxReq.responseText.length);

                res = ajaxReq.responseText;
                res = parseJSON("(" + res + ")");
                var appletHtm = res.htmlJSON;
            }
        }
            if (res != null) {
            var NoOfPages = res.document[0].NoOfPages - 0;
            var docType = res.document[0].DocType;
            var docExt = res.document[0].DocExt;
            var documentName = res.document[0].DocName;
            var imageAndVolIndex = res.document[0].ISIndex.split("%23");
        }
        if(imageAndVolIndex != null)
            var imageIndex = imageAndVolIndex[0];
            var volumeId=imageAndVolIndex[1];
          var bCustomDocumentExtFound = false;
            var customDocumentExt_array = customDocumentExt.split(',');
            for (var i = 0; i < customDocumentExt_array.length; i++) {
                customDocumentExt_array[i] = customDocumentExt_array[i].replace(/^\s*/, "").replace(/\s*$/, "");
                if (docExt.toUpperCase() == customDocumentExt_array[i].toUpperCase()) {
                    bCustomDocumentExtFound = true;
                    break;
                }
            }   
             var supportedMimeType = true;
           if (typeof res.document[0].SupportedMimeType != 'undefined') {
               var mimetype = res.document[0].SupportedMimeType;
                 if (mimetype == "N") {
                  //Bug 78222
                  supportedMimeType = false;
               }
           }
         if(docExt=="png"){
        docType="N";
    }
        if (typeof isPDFOpenInOpallViewer!="undefined"){
        var isInOpallView = isPDFOpenInOpallViewer(strprocessname,stractivityName,pid,docType,docExt);
            if (!isInOpallView){
                docType = "N";
            }
        }
        var videoDoc = ("V"==docType.toUpperCase());
        var audioDoc = ("U"==docType.toUpperCase());
        if(docType=="I" && supportedMimeType && (!bCustomDocumentExtFound)){
            var pnrStatus = 'Y';
            if(typeof bSaveAnnotationDialog != 'undefined' && bSaveAnnotationDialog=='N'){
                pnrStatus = 'N';
            }
            var annotUrl = res.document[0].servletPath +'/viewimageannotation?DocId='+strDocIndex+'&PageNo=1'+'&WD_SID='+WD_SID+"&WD_RID="+getRequestToken("/webdesktop/servlet/viewimageannotation");
            var writeUrl = res.document[0].servletPath +'/imageannotation?DocId='+strDocIndex+'&pid='+encode_utf8(pid)+'&wid='+wid+'&Option=SaveAnnot&PageNo=1'+strSessionStr+'&PnrStatus='+pnrStatus+'&WD_SID='+WD_SID+"&WD_RID="+getRequestToken("/webdesktop/servlet/imageannotation");
            if(taskid!=''){
                writeUrl += '&taskid='+taskid;
            }
            var stampUrl = res.document[0].servletPath +'/viewimagestamp'+strSessionStr+'?DocId='+strDocIndex+'&PageNo=1&WD_SID='+WD_SID+'&WD_RID='+getRequestToken('/webdesktop/servlet/viewimagestamp');
            
            //styleApp.display="none";
            styleIfrm.display="inline";
            var ifHeight=getDocHeightWidth(document).Height;
            iframeCom.innerHTML="<IFRAME id='docviewer' style='width:99%;height :"+(ifHeight-20)+"px' />"
            //iframeCom.innerHTML="<IFRAME id='docviewer' style='width:99%;height :"+(document.body.clientHeight-20)+"px' />"
            var ifrm2=document.getElementById('docviewer');
            var stampINIPath=res.document[0].servletPath+"/readStampINI?WD_SID="+WD_SID+"&WD_RID="+getRequestToken("/webdesktop/servlet/readStampINI");
            
            
            opall.PARAM.NumberOfPages = NoOfPages;
            opall.PARAM.num_VisiblePage = 1;
            opall.PARAM.MenuBar = "true";
            opall.PARAM.ShowUsernamesWithAllAnnotation = true;
            opall.PARAM.bViewWaterMark = bViewWaterMark;
            opall.PARAM.resizeExMaxZoomLimit = parseInt(resizeExMaxZoomLimit);
            opall.PARAM.resizeExMaxPixelLimit = parseInt(resizeExMaxPixelLimit);
            try {
                if (typeof resizeOption != "undefined") {
                    rOptMatch = document.cookie.match(new RegExp("ResizeOption" + '=([^;]+)'));
                    if (rOptMatch) {
                        resizeOption = rOptMatch[1] - 0;
                    }
                }
            } catch (exp) {
            }
            if (typeof resizeOption != "undefined") {
                if (resizeOption == '0') {
                    opall.PARAM.ResizeOption = resizeOption - 0;
                    if (typeof resizePercentage != "undefined") {
                        match = document.cookie.match(new RegExp("ResizePercentage" + '=([^;]+)'));
                        if (match) {
                            opall.PARAM.ResizePercentage = match[1] - 0;
                        }
                        else {
                            opall.PARAM.ResizePercentage = resizePercentage - 0;
                        }
                    }
                } else {
                    opall.PARAM.ResizeOption = resizeOption - 0;
                }
            }
            if (typeof bSaveAnnotationDialog != "undefined" && bSaveAnnotationDialog == "N")
                    opall.PARAM.bSaveAnnotationDialog = false;
                
            if (typeof userName != "undefined" )
            opall.PARAM.CurrentUserName = userName;
            
            if(typeof window.strPrintOption != 'undefined')
            {
            if (typeof printOption != "undefined" &&   printOption=="N" && typeof window.strPrintOption != "undefined"  &&    window.strPrintOption=="1"){
            opall.PARAM.printOption="false";
            } else {
            opall.PARAM.printOption='true';
            }
            } else if(typeof window.opener.strPrintOption != 'undefined')
            {
             if (typeof printOption != "undefined" &&   printOption=="N" && typeof window.opener.strPrintOption != "undefined"  &&    window.opener.strPrintOption=="1"){
            opall.PARAM.printOption="false";
            } else {
            opall.PARAM.printOption='true';
            }   
            }
            if (typeof  annotationColor != "undefined"  && annotationColor != "" && annotationColor.length > 0 )
	    opall.PARAM.AnnotationColor= annotationColor;
            
            if (typeof isZoomWindowChangeRequired != "undefined" && isZoomWindowChangeRequired != "" && isZoomWindowChangeRequired.length > 0 )
	    opall.PARAM.IsZoomWindowChangeRequired= isZoomWindowChangeRequired;
            
            if (typeof printParameter != "undefined" )
            opall.PARAM.PrintParameter = printParameter;
            
            if (typeof watermarkPrinting != "undefined" )
            opall.PARAM.watermarkPrinting = watermarkPrinting;
        
            if (typeof watermarkPosition != "undefined" )
            opall.PARAM.TextWaterMarkPosition = watermarkPosition;
		
			if(bPrintWaterMarkOnCanvas == "Y"){
                    opall.PARAM.TextWaterMarkPosition = 6;
                    opall.PARAM.bPrintWaterMarkOnCanvas = true;
                } 
				
            if (typeof watermarkProp != "undefined" )
            opall.PARAM.Watermark_Properties = watermarkProp;
        
            if (typeof getWaterMarkText != "undefined") {
                if (Trim(getWaterMarkText(strprocessname, stractivityName, pid, userName)) != "") {
                    opall.PARAM.bPrintDateTime = false;
                }
                opall.PARAM.TextAsWaterMark = Trim(getWaterMarkText(strprocessname, stractivityName, pid, userName));
            }
        
            // if ( typeof initialZoomLensPercentage != "undefined" && initialZoomLensPercentage.length > 0) {
            // opall.PARAM.InitialZoomLensPercentage= initialZoomLensPercentage;
            // } else {
            // if (typeof zoomLens != "undefined" && zoomLens == "1") {
            // opall.PARAM.InitialZoomLensStatus='true';
            // opall.PARAM.InitialZoomLensPercentage= zoomLensPercentage;
            // } else if (typeof zoomLens != "undefined"  && zoomLens == "0") {
            // opall.PARAM.InitialZoomLensStatus='false';
            // }
            // }
			
				// Bug 78052
                if (typeof initialZoomLensStatus != "undefined" && initialZoomLensStatus == "Y") {
                    opall.PARAM.InitialZoomLensStatus = 'true';
                    opall.PARAM.InitialZoomLensPercentage = initialZoomLensPercentage;
                } else {
                    opall.PARAM.InitialZoomLensStatus = 'false';
                    opall.PARAM.InitialZoomLensPercentage = initialZoomLensPercentage;
                }
            if (typeof bEnableSearchOption != "undefined" && bEnableSearchOption == "Y") {
                opall.PARAM.bEnableSearchOption = true;
            } else {
                opall.PARAM.bEnableSearchOption = false;
            }
                    
            if (typeof strZoomLens != "undefined" && strZoomLens=="Y") {           
            var zoomTokens = zoomLensAttributes.split(",");
            var strLensWidth =  zoomTokens[0];
            var strLensHeight =  zoomTokens[1];
            var strLensLoc =  zoomTokens[2];
            opall.PARAM.ZoomLensForZoning = strLensWidth+","+strLensHeight+","+strLensLoc+",true";
            }
            
            if (typeof strAnnotationFont != "undefined"  && strAnnotationFont !="")
            opall.PARAM.DefaultFontSettings = strAnnotationFont;
            
            if (typeof croppedImageMinQuality != "undefined"  && croppedImageMinQuality !="")
            opall.PARAM.cropImageMinQuality = croppedImageMinQuality;
        
            if (typeof CroppedImageSize != "undefined"  && CroppedImageSize !="")
            opall.PARAM.CroppedImageSize = CroppedImageSize-0;
        
            if (typeof isAnnotationBurningRequired != "undefined"  && isAnnotationBurningRequired !="")
            opall.PARAM.IsAnnotationBurningRequired  = isAnnotationBurningRequired;
        
            if (typeof transformOption != "undefined"  && transformOption !="")
            opall.PARAM.TransformOption = transformOption;
        
            if (typeof annotationOption != "undefined"  && annotationOption !="")
            opall.PARAM.AnnotationOption = parseInt(annotationOption);                 //Bug 89057
            
            if(typeof wiViewMode != "undefined" && wiViewMode=="R")
                    opall.PARAM.AnnotationOption = 1;
                    
                
                if(typeof hideAnnotationForWorkstep != "undefined"){
					if(typeof strQueueName != 'undefined'){     //Bug 95830
						var hideAnnotationForWorkstepFlag  = hideAnnotationForWorkstep(strprocessname,stractivityName,strQueueName);
					}
					else{
						var hideAnnotationForWorkstepFlag  = hideAnnotationForWorkstep(strprocessname,stractivityName,window.opener.strQueueName);
					}
                     if(!hideAnnotationForWorkstepFlag){
                         opall.PARAM.AnnotationOption = 1;
                     }
                      
                    } 
            
            opall.PARAM.url_ImageFileName = res.document[0].docUrl;
           
            if (typeof viewAnnotation != "undefined"  && viewAnnotation !="" && viewAnnotation=="Y") {
            opall.PARAM.URL_Annotation = annotUrl;
            opall.PARAM.url_WriteAnnotation = writeUrl;
            }
            var varHideStamp = true;
            if (typeof hideStamp != "undefined") {
             varHideStamp = hideStamp(strprocessname, stractivityName, strQueueName);
            }
            if (typeof strStampServletCall != "undefined"  && strStampServletCall !="" && strStampServletCall=="Y") {
            opall.PARAM.URL_ImageStampFile = stampUrl;
            if(varHideStamp){
             opall.PARAM.URL_StampINIPath = stampINIPath;
               }
             else{
              opall.PARAM.URL_StampINIPath = "";
              }
            }
            //opall.PARAM.DynamicHideNShowToolBar = 2;
            if(typeof isAllPages!='undefined' && isAllPages=='Y')
                opall.PARAM.ServerSupportMultiPage=false;
            else 
                opall.PARAM.ServerSupportMultiPage=true;
            
            opall.PARAM.AnnotationDisplay="true";
            opall.PARAM.ViewerWidth=parseInt(document.body.clientWidth)-60;
            opall.PARAM.ViewerHeight=document.body.clientHeight-100;
            opall.PARAM.localeDirection = pageDirection;
            opall.PARAM.StampWithoutINI = stampWithoutINI;
            isOnchangeDoc="onchange";
            var num = 1;
            opall.PARAM.MenuBar = "false";
            opall.PARAM.printApproach = opallPrintApproach;
            if(opallRetainAngleSettings == "Y") {
                opall.PARAM.RetainAngleSettings = true;
            } else {
                opall.PARAM.RetainAngleSettings = false;
            }
            
            if (typeof SinglePageScrollMode != "undefined") {
                var singlePageScrollMode = SinglePageScrollMode(strprocessname, stractivityName, strQueueName, docExt);
                if (singlePageScrollMode) {
                    opall.PARAM.bSinglePageScrollMode = true;
                }
            }
            opall.PARAM.RequestMethod = opallRequestMethod;
            opall.showViewer(ifrm2,"/OpAll/OpAll/HTML/OpAll.jsp?var="+num+"&WD_SID="+WD_SID+'&rid='+MakeUniqueNumber());     
        } else if((videoDoc || audioDoc) && typeof mimeTypeInfoMap[(docExt+"").toLowerCase()] != 'undefined'){
            if(document.getElementById('docFrameURL')){
                var docUrl = document.getElementById('docFrameURL').value;
                if(docUrl==""){
                    var url=res.document[0].docUrl;
	            document.getElementById('docFrameURL').value=url;
                    docUrl=url;
                }
                var ifrm = document.getElementById('docviewer');
                var iHeight = (getDocHeightWidth(document).Height-20);
                ifrm.style.height=iHeight + "px";
                if(ifrm != null && (videoDoc || audioDoc)) {
                    var vidElement;
                    if(videoDoc) {
                        vidElement = document.createElement('video');
                        vidElement.style.width = "100%";
                        vidElement.style.height = "100%";
                    } else if(audioDoc) {
                        vidElement = document.createElement('audio');
                        vidElement.style.width = "80%";
                        vidElement.style.marginTop = ((iHeight/2) - 30) + "px";
                        vidElement.setAttribute('tabindex', "-1");
                        vidElement.addEventListener('focus', function(event) {
                            event.preventDefault();
                            if (event.relatedTarget) {
                                event.relatedTarget.focus();
                            } else {
                                event.currentTarget.blur();
                            }
                        });
                        ifrm.style.background = "black";
                    }
                    
                    vidElement.id = "V_"+strDocIndex;
                    vidElement.controls = true;
                    vidElement.autoplay = false;
                    vidElement.muted = true;
                    vidElement.disablePictureInPicture = true;
                    if(vidElement.controlsList) {
                        vidElement.controlsList.add("nodownload");
                    }                   
                    
                    var doc = ifrm.contentDocument || ifrm.contentWindow.document;
                    doc.body.appendChild(vidElement);
                    if(audioDoc) {
                        doc.body.style.textAlign = "center";
                    }
                    if(videoStreamMode == 'Native' || audioDoc) {
                        var videoUrl = docUrl.replace("getdocument", "getdocstream");
                        var srcElement = document.createElement('source');
                        srcElement.type = mimeTypeInfoMap[(docExt+"").toLowerCase()];
                        vidElement.appendChild(srcElement);
                        srcElement.src = videoUrl;
                    } else if(videoStreamMode == 'Cloud' && Hls.isSupported()) {
                        var hls = new Hls(hlsConfig);
                        hls.loadSource(docUrl);
                        hls.attachMedia(vidElement);
                        hls.on(Hls.Events.MANIFEST_PARSED,function(){
                            vidElement.play();
                        });                      
                    }
                 }
            }
        }
        else
        {
            //Bug 67138
            if(document.getElementById('docFrameURL')){
                var docUrl = document.getElementById('docFrameURL').value;
                if (bCustomDocumentExtFound && (typeof bProcessCustomDoc!="undefined" && bProcessCustomDoc(strprocessname, stractivityName, strQueueName))) {
                    docUrl = "/webdesktop/custom/viewer/viewer.jsp?docExt=" + docExt + "&documentName=" + documentName + "&imageId=" + imageIndex + "&volIndex=" + volumeId + "&siteId=" + siteId + "&CabinetName=" + cabName + "&userDBid=" + userIndx + "&JtsAddress=" + jtsIP + "&portId=" + jtsPort;
                }
                if(docUrl==""){
                    var url=res.document[0].docUrl;
	            document.getElementById('docFrameURL').value=url;
                    docUrl=url;
                }
                var ifrm = document.getElementById('docviewer');
                ifrm.style.height=(getDocHeightWidth(document).Height-20)+"px";
                IframeRequestWithPost(docUrl,ifrm);
            }
        }
    updateViewedDocumentList(pid, wid, res.document[0]);
     if (typeof isTextSelectableInOpall != 'undefined'){
        if (isTextSelectableInOpall(strprocessname, stractivityName, docExt,docIndex)){
            opall.PARAM.isTextSelectable = true;
        }else {
            opall.PARAM.isTextSelectable = false;
        }
    }
}

function loadOpAllViewer()
{
        //var styleApp=document.getElementById('ivapp').style;
        var styleIfrm=document.getElementById('ifrm').style;
        var iframeCom=document.getElementById('ifrm');
        
        
        var requestString='&pid='+encode_utf8(pid)+'&wid='+wid+'&taskid='+taskid+'&WD_SID='+WD_SID;
        if(typeof isFromCustom!='undefined' && isFromCustom=="Y"){
            //requestString=requestString+'&fromCustom=Y';
        }
            var NoOfPages = noOfPages;
            var docType="I";
            
        if(docType=="I"){
            
            styleIfrm.display="inline";
            var ifHeight=getDocHeightWidth(document).Height;
            iframeCom.innerHTML="<IFRAME id='docviewer11' style='width:99%;height :659px' />"
            //iframeCom.innerHTML="<IFRAME id='docviewer11' style='width:99%;height :"+(document.body.clientHeight-20)+"px' />"
            var ifrm3=document.getElementById('docviewer11');
            //var stampINIPath=res.document[0].servletPath+"/readStampINI?WD_SID="+WD_SID;
            
            
            opall.PARAM.NumberOfPages = NoOfPages;
            opall.PARAM.num_VisiblePage = 1;
            opall.PARAM.MenuBar = "true";
            opall.PARAM.ShowUsernamesWithAllAnnotation = true;
            
            if ( typeof resizeOption != "undefined" ) {
                if(resizeOption =='0') {        
                    opall.PARAM.ResizeOption = resizeOption-0;
                    if (typeof resizePercentage != "undefined" )
                    opall.PARAM.ResizePercentage = resizePercentage-0;
            } else { 
                opall.PARAM.ResizeOption = resizeOption-0;   
                   }
            }
            
            if (typeof userName != "undefined" )
            opall.PARAM.CurrentUserName = userName;
            
            if(typeof window.strPrintOption != 'undefined')
            {
            if (typeof printOption != "undefined" &&   printOption=="N" && typeof window.strPrintOption != "undefined"  &&    window.strPrintOption=="1"){
            opall.PARAM.printOption="false";
            } else {
            opall.PARAM.printOption='true';
            }
            } else if(typeof window.opener.strPrintOption != 'undefined')
            {
             if (typeof printOption != "undefined" &&   printOption=="N" && typeof window.opener.strPrintOption != "undefined"  &&    window.opener.strPrintOption=="1"){
            opall.PARAM.printOption="false";
            } else {
            opall.PARAM.printOption='true';
            }   
            }
            if (typeof  annotationColor != "undefined"  && annotationColor != "" && annotationColor.length > 0 )
	    opall.PARAM.AnnotationColor= annotationColor;
            
            if (typeof isZoomWindowChangeRequired != "undefined" && isZoomWindowChangeRequired != "" && isZoomWindowChangeRequired.length > 0 )
	    opall.PARAM.IsZoomWindowChangeRequired= isZoomWindowChangeRequired;
            
            if (typeof printParameter != "undefined" )
            opall.PARAM.PrintParameter = printParameter;
            
            if (typeof watermarkPrinting != "undefined" )
            opall.PARAM.watermarkPrinting = watermarkPrinting;
        
            if (typeof watermarkPosition != "undefined" )
            opall.PARAM.TextWaterMarkPosition = watermarkPosition;
        
            if (typeof watermarkProp != "undefined" )
            opall.PARAM.Watermark_Properties = watermarkProp;
        
            if(typeof getWaterMarkText != "undefined" )    
            opall.PARAM.TextAsWaterMark = Trim(getWaterMarkText(strprocessname,stractivityName,pid));
        
            if ( typeof initialZoomLensPercentage != "undefined" && initialZoomLensPercentage.length > 0) {
            opall.PARAM.InitialZoomLensPercentage= initialZoomLensPercentage;
            } else {
            if (typeof zoomLens != "undefined" && zoomLens == "1") {
            opall.PARAM.InitialZoomLensStatus='true';
            opall.PARAM.InitialZoomLensPercentage= zoomLensPercentage;
            } else if (typeof zoomLens != "undefined"  && zoomLens == "0") {
            opall.PARAM.InitialZoomLensStatus='false';
            }
            }
            
            if (typeof strZoomLens != "undefined" && strZoomLens=="Y") {           
            var zoomTokens = zoomLensAttributes.split(",");
            var strLensWidth =  zoomTokens[0];
            var strLensHeight =  zoomTokens[1];
            var strLensLoc =  zoomTokens[2];
            opall.PARAM.ZoomLensForZoning = strLensWidth+","+strLensHeight+","+strLensLoc+",true";
            }
            
            if (typeof strAnnotationFont != "undefined"  && strAnnotationFont !="")
            opall.PARAM.DefaultFontSettings = strAnnotationFont;
            
            if (typeof croppedImageMinQuality != "undefined"  && croppedImageMinQuality !="")
            opall.PARAM.cropImageMinQuality = croppedImageMinQuality;
        
            if (typeof CroppedImageSize != "undefined"  && CroppedImageSize !="")
            opall.PARAM.CroppedImageSize = CroppedImageSize-0;
        
            if (typeof isAnnotationBurningRequired != "undefined"  && isAnnotationBurningRequired !="")
            opall.PARAM.IsAnnotationBurningRequired  = isAnnotationBurningRequired;
        
            if (typeof transformOption != "undefined"  && transformOption !="")
            opall.PARAM.TransformOption = transformOption;
        
            if (typeof annotationOption != "undefined"  && annotationOption !="")
            opall.PARAM.AnnotationOption = parseInt(annotationOption);                //Bug 89057
        
            if (typeof DynamicHideNShowToolBar != "undefined"  && DynamicHideNShowToolBar !="")//Bug 72907
                opall.PARAM.DynamicHideNShowToolBar=4;//Bug 72907
            
           opall.PARAM.AnnotationDisplay="false";
           var operation="ViewCaseSummary";
           if(typeof isAllPages!='undefined' && isAllPages=='Y')
                opall.PARAM.ServerSupportMultiPage=false;
            else 
                opall.PARAM.ServerSupportMultiPage=true;
           opall.PARAM.RequestMethod="POST";
           var fileBuffer= document.getElementById('hidFileBuffer').value;
           opall.PARAM.url_ImageFileName="/webdesktop/servlet/getCaseSummaryDoc?FileName="+fileName+"&Token="+strToken+"&Operation="+operation+"&FileType="+fileType+"&FileSize="+fileSize+"&FileBuffer="+encode_utf8(fileBuffer);
            opall.PARAM.ViewerWidth=parseInt(document.body.clientWidth)-60;
            opall.PARAM.ViewerHeight=document.body.clientHeight-300;
            opall.PARAM.localeDirection = pageDirection;
            isOnchangeDoc="onchange";
            var num = 1;
            opall.PARAM.MenuBar = "false";
            opall.PARAM.bCenterAlign = "true";
            opall.PARAM.bHoverToolbar = "true";
           // opall.PARAM.printApproach = opallPrintApproach;
            opall.showViewer(ifrm3,"/OpAll/OpAll/HTML/OpAll.jsp?var="+num+"&WD_SID="+WD_SID+'&rid='+MakeUniqueNumber());     
        }
        else
        {
            //Bug 67138
            if(document.getElementById('docFrameURL')){
                var docUrl = document.getElementById('docFrameURL').value;
                var ifrm = document.getElementById('docviewer11');
                ifrm.style.height=(getDocHeightWidth(document).Height-20)+"px";
                IframeRequestWithPost(docUrl,ifrm);
            }
        }
    
}
      
            
            
