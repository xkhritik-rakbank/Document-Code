

var excpFlag="";
var tempExcpTrig = new Array();
var ExpListJson;
var trig = new Array();
var isCommentMandatory="Y"
var checkDivRef=null;
var selectedExpId=null;
var ExceptionName="";
function Trigger(id,type,value){
    this.id = id;
    this.type = type;
    this.value = value;
}




var checkPrevDivRef=null;
function onmouseOverExp(ref,expId)
{
    if(selectedExpId == null || (selectedExpId != null && selectedExpId != expId))
    {
        ref=ref.parentNode.parentNode;
        var preClassName=ref.className;
        if(preClassName!='tablecontent row-selector')
            ref.className='tablecontent row-selector cursorpointer';
    }
    /*ref=ref.parentNode.parentNode;
        var preClassName=ref.className;
        if(preClassName!='wdSelected')
            ref.className='wdSelected';*/
    
}

function onmouseOutExp(ref,expId)
{
    
    if(selectedExpId == null || (selectedExpId != null && selectedExpId != expId))
    {
    ref=ref.parentNode.parentNode;
    var preClassName=ref.className;

    if(preClassName!='tablecontent')
        ref.className = 'tablecontent cursordefault';
    }
   /* ref=ref.parentNode.parentNode;
    var preClassName=ref.className;

    if(preClassName!='wdSimple')
        ref.className = 'wdSimple';*/
}


function clkMscExp(expId,expName,ref,comments,strBroadCast){
    
    
    
    
    
    var bBroadCast=false;
    if(strBroadCast!=undefined && strBroadCast=='Y'){
        bBroadCast=true;
    }
    selectedExpId=expId;
    ExceptionName=expName;
    var myBrowser = navigator.appName;

    if(checkDivRef!=null){
        if(checkDivRef.parentNode!=null){
            if(checkDivRef.parentNode.parentNode!=null) {
                checkDivRef=checkDivRef.parentNode.parentNode;
            }
        }        
        checkDivRef.className="tablecontent";
    }
    checkDivRef=ref;
    if(ref!=null){
         ref=ref.parentNode.parentNode;
        //ref.className='wdSelected';
        ref.className='tablecontent row-selector';
        expName = document.getElementById("wdesk:expTable:"+ref.rowIndex+":hidexpname").value;
    }

    document.getElementById("wdesk:selexpid").value = expId;
    document.getElementById("wdesk:selexpname").value = expName;
       
    if(comments!=undefined){
        document.getElementById("wdesk:comnt").value = document.getElementById("hidExp"+expId+"cmnt").value;
        //document.getElementById("wdesk:comnt").value =comments;
    }
    expChng(expId);
    var window_workdesk="";
    if(windowProperty.winloc=="M")
        window_workdesk=window;
    else
        window_workdesk=window.opener;
    if(window_workdesk.SharingMode && bBroadCast){
        window_workdesk.broadcastSelectExpEvent(expId, expName, checkDivRef, comments);
    }
}

function changeDesc(compnt){
    var val = compnt.value;
    document.getElementById('wdesk:desc').innerHTML = encode_ParamValue(val.substring(val.indexOf("#")+1));
}

function raise_exceptionClick(hideself)
{
    if(hideself)
    {
    var raise_c_Div = document.getElementById("raise_c_Div");
    raise_c_Div.style.display = 'none';
    
    document.getElementById('wdesk:NoExceptionWin').style.display = 'none';
    }
    
    var expOprDiv  = document.getElementById("expOprDiv");
    expOprDiv.style.display = 'inline';
    
    var ext_typelbl = document.getElementById("wdesk:ext_typelbl");
    ext_typelbl.style.display = 'inline';
    
    document.getElementById("wdesk:close_icon_raise").style.display = 'inline';
    
    
    raiseExcep_open("N");
}

function closeRaiseExp()
{
    if(document.getElementById("raise_c_Div"))
    {
        document.getElementById('wdesk:NoExceptionWin').style.display = 'inline';
        
        var raise_c_Div = document.getElementById("raise_c_Div");
        raise_c_Div.style.display = 'inline';
        
        
    }
    
    var expOprDiv  = document.getElementById("expOprDiv");
    expOprDiv.style.display = 'none';
    
    var ext_typelbl = document.getElementById("wdesk:ext_typelbl");
    ext_typelbl.style.display = 'none';
    
    document.getElementById("wdesk:close_icon_raise").style.display = 'none';
    
}

function raiseExcep_open(fromCustom)
{
    var expWtype="";
    var url="";
    if(document.getElementById('wdesk:expWtype')){
        expWtype=document.getElementById('wdesk:expWtype').value;
	url = '/webdesktop/components/workitem/operations/exception/raise_exception.app';
        var wd_rid=getRequestToken(url);
        url+="?WD_RID="+wd_rid;
        url += '&Pid='+encode_utf8(pid)+'&Wid='+wid+'&Taskid='+taskid+'&expWtype='+encode_utf8(expWtype)+"&WD_SID="+WD_SID+"&fromCustom="+fromCustom;
        var expHist = document.getElementById('expHistDiv');
        //expHist.className = 'wdDivBorderDis';
        var histTable = document.getElementById("wdesk:histGrid");
        histTable.style.display = 'none';
        var expCmnt = document.getElementById("wdesk:comnt");
        expCmnt.value = "";
        expCmnt.style.display = 'inline';

        document.getElementById('wdesk:expList').style.display = 'inline';
        document.getElementById('wdesk:expAllList').style.display = 'none';
        
        document.getElementById('wdesk:exp_title_detail').style.display = 'none';
        document.getElementById("wdesk:pnl_comment_label").style.display = 'inline';
        
        
        
        var val = document.getElementById('wdesk:expList').value;
        document.getElementById('wdesk:desc').innerHTML = encode_ParamValue(val.substring(val.indexOf("#")+1));
        var iframeExp=document.getElementById('expOpFrm');
        url = appendUrlSession(url);
        iframeExp.src = url;
        document.getElementById("wdesk:detailHdr").innerHTML = TITLE_RAISE_EXCEPTION;
        document.getElementById("wdesk:lblDetails").innerHTML = LABEL_EXCEPTION_COMMENTS;
        document.getElementById("wdesk:raisebtn").value = RAISE;
        document.getElementById("wdesk:raisebtn").style.display = 'inline';
        document.getElementById("wdesk:newbtn").disabled = true;
        //document.getElementById("wdesk:newbtn").src = sContextPath+"/webtop/"+PATH+"images/new_exp_dis.gif";
        document.getElementById("wdesk:cancelbtn").disabled = true;
        document.getElementById("wdesk:modifybtn").style.display = 'none';
        document.getElementById("wdesk:clearbtn").style.display = 'none';
        document.getElementById("wdesk:responsebtn").style.display = 'none';
        document.getElementById("wdesk:rejectbtn").style.display = 'none';
    }
        
}

function InitHWExpNew()
{    
    var cWidth = document.getElementById('expDiv').parentNode.style.width.split('p')[0];
    var cHeight = document.getElementById('expDiv').parentNode.style.height.split('p')[0];
    
    if(cWidth!="" && cHeight!=""){
        if(wDeskLayout.WDeskType == 'E'){
            //document.getElementById('expDiv').style.height = (cHeight-25)+"px";
            //document.getElementById('expGrid').style.height = (cHeight-25)+"px";    
            //document.getElementById('expDiv').style.width = (cWidth-4)+"px";
           // document.getElementById('expGrid').style.width = (cWidth)+"px";       
        } else {
            //document.getElementById('expDiv').style.height = (cHeight-5)+"px";
            //document.getElementById('expGrid').style.height = (cHeight-13)+"px";    
            //document.getElementById('expDiv').style.width = (cWidth)+"px";
            //document.getElementById('expGrid').style.width = (cWidth)+"px";       
        }
        
       /*getCustomScrollbar("#expGrid", true, "yx", true, false, true, true);       
       var docEle = $("#expGrid").find(".mCSB_container")[0];
       if(docEle){
            docEle.style.width = (cWidth-4)+"px";     
            var scrollDir = (pageDirection == 'ltr')? 'left': 'right';    
            $("#expGrid").mCustomScrollbar("scrollTo",scrollDir,{scrollInertia:0});
       }*/
    }
}


function InitHWExp()
{
    if((isEmbd !=undefined && isEmbd == "N") || ((typeof wdView != 'undefined') && (wdView != "em"))){
        InitHWExpNew();
    }

     var expTab = document.getElementById('expGrid');
    // if(expTab)
      //   expTab.style.height = expOpFrmHght+40;
     var expHistDiv = document.getElementById('expHistDiv');
     var val="";
     if(expHistDiv){
         //expHistDiv.style.height = expOpFrmHght-70;


         var selExpId= "";

          if(selectedExpId != null && selectedExpId != "" && selectedExpId != undefined)
              selExpId = selectedExpId;
          else
              selExpId = document.getElementById('wdesk:selecteExpSeqId').value;
     
         var expOpCmnt = document.getElementById('wdesk:comnt');

         var raiseDis = document.getElementById('wdesk:raiseDis').value;

         ExpListJson = parseJSON("("+encode_ParamValue(document.getElementById('wdesk:expVisJsonList').value)+")");
         val=document.getElementById('wdesk:expAllList').value;
         val=val.substring(val.indexOf("#")+1,val.length);

         if(ExceptionName==""){
             ExceptionName=val;
         }

         

         if(expOpCmnt.style.display == 'inline' || selExpId == ""){
            if(raiseDis == 'false'){
                raiseExcep_open('N');
            }
            else{
                document.getElementById('wdesk:comnt').style.display = 'none';
                document.getElementById('wdesk:histGrid').style.display = 'inline';
            }
            if(document.getElementById('wdesk:expAllList').style.display == 'inline' || document.getElementById('wdesk:exp_title_detail').style.display == 'inline'){
                val = document.getElementById('wdesk:expAllList').value;
                document.getElementById('wdesk:desc').innerHTML = encode_ParamValue(val.substring(val.indexOf("#")+1,val.length));
             }
             else{
                val = document.getElementById('wdesk:expList').value;
                document.getElementById('wdesk:desc').innerHTML = encode_ParamValue(val.substring(val.indexOf("#")+1,val.length));
             }
         }
         else{
            excpListSel();
         }


          

        selectExpTableFirstRowOnLoad(selExpId);
        document.getElementById("wdesk:selexpid").value = selExpId;
        //document.getElementById("wdesk:selexpname").value = expName;
        if(selExpId!="")
            expChng(selExpId);

        
     }
     
 }



function excpListSel(expId){
    
      
       if(typeof expId == 'undefined'){
            expId = document.getElementById('wdesk:selexpid').value;
        }
        document.getElementById("wdesk:detailHdr").innerHTML = TITLE_EXCEPTION_DETAILS;
        document.getElementById("wdesk:lblDetails").innerHTML = LABEL_DETAILS;
        document.getElementById('wdesk:expList').style.display = 'none';
        var expAll = document.getElementById('wdesk:expAllList');
        //expAll.style.display = 'inline';
       
       var exp_title;
        
        
    
        document.getElementById('wdesk:desc').innerHTML=encode_ParamValue(ExceptionName);
        for(var i=0; i<expAll.options.length; i++ ){
            var val = expAll.options[i].value;
            if(val.substring(0,val.indexOf('#')) == expId.substring(0,expId.indexOf('_'))){
                expAll.selectedIndex = i;
                exp_title = expAll.options[i].text;
                document.getElementById('wdesk:desc').innerHTML = encode_ParamValue(val.substring(val.indexOf("#")+1));
                break;
            }
        }
        
        
        var expOprDiv = document.getElementById("expOprDiv");
        expOprDiv.style.display = 'inline';

        var ext_typelbl = document.getElementById("wdesk:ext_typelbl");
        ext_typelbl.style.display = 'none';
        
        var exp_title_detail = document.getElementById("wdesk:exp_title_detail");
        exp_title_detail.innerHTML = encode_ParamValue(exp_title);
        exp_title_detail.style.display = 'inline';
        
        document.getElementById("wdesk:pnl_comment_label").style.display = 'none';
        document.getElementById("wdesk:close_icon_raise").style.display = 'none';
        
       
}
function checkLimit(field){
     textareaLimiter(field, 512);   //bug id - 34137
}



function addException(calledFrom,expTbl,excpId,excpName,status,cmnt,trigType,excpJSON,expTrigRes){
    try
    {
        cmnt = cmnt.replace(/(?:\r\n|\r|\n)/g, '<br />');
    }
    catch(ex){}
    if(trigType){
        var trigObj = new Trigger(excpId,trigType,"");
        tempExcpTrig[tempExcpTrig.length] = trigObj;
        document.getElementById("wdesk:okbtn").disabled = false;
        document.getElementById("wdesk:okbtn").value= "commit";
        clkMscExp(excpId,excpName);
    }

    document.getElementById('wdesk:selecteExpSeqId').value=excpId;
    
    if(document.getElementById('wdesk:calledFrom') != null){
        document.getElementById('wdesk:calledFrom').value=calledFrom;//Bug 68117 
    }
    
     selectedExpId = excpId;
     var bRefresh = true;

    if(excpJSON != undefined)
        {
            if(excpJSON.isTrig == "Y"){
                    var trigJson = excpJSON.trig;
                    //trigJson = parseJSON("("+trigJson+")");
                    if(trigJson[0].flag == '0' && trigJson[0].TriggerType=='DE'){
                        bRefresh = false;
                    }
                    }
        }
   // expChng(excpId);
     if(bRefresh){
        var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1; 
        if(isSafari){
            clickLinkSafari('wdesk:expRefresh'); 
        } else {
            var isIE = ((navigator.appName=='Netscape')?false:true);
            if(isIE) {
                var IEVersionRef = IEVersion();
                if(IEVersionRef.DocMode == 9){
                    clickLinkSafari('wdesk:expRefresh'); 
                } else {
                    clickLinkSafari('wdesk:expRefresh'); 
                }
            } else {
                clickLinkSafari('wdesk:expRefresh'); 
            }
        }
     }

    var winDesk;
    if(window.windowProperty.winloc == 'M')
        winDesk = window;
    else if(window.windowProperty.winloc == 'T')
        winDesk = window.opener.opener;
    else
        winDesk = window.opener;
    if(winDesk.SharingMode){
        winDesk.broadcastExpEvent(selectedExpId, excpName,calledFrom,expTrigRes);
    }
    //selectExpTableFirstRowOnLoad(excpId);
}

function clickLinkSafari(linkId)
{
    if(!linkId)
    {
        return false;
    }

    var fireOnThis = document.getElementById(linkId);
    
    if(fireOnThis != null && (fireOnThis.nodeName.toUpperCase() == "A")){
        if(fireOnThis.href.lastIndexOf("#") > -1){
            fireOnThis.href = "javascript:void(0)";
        }
    }
    if (fireOnThis != null) {
    if (document.createEvent)
    {
        //var evObj = document.createEvent('MouseEvents') ;
        //evObj.initEvent( 'click', true, false ) ;
        //fireOnThis.dispatchEvent(evObj) ;
        var evObj = document.createEvent('MouseEvents') ;
        evObj.initMouseEvent("click", true, true, window,0, 0, 0, 0, 0, false, false, false, false, 0, null);
        fireOnThis.dispatchEvent(evObj) ;
    }
    else if (document.createEventObject)
    {
        fireOnThis.click()  ;

    }
    }
    return ;
}

function closeExpOp(frm){
    if(typeof frm == 'undefined')
        frm = '';
    if(frm == 'modify'){
        window.parent.enableModify();
    }
    return false;
}

function enableModify(){
        var expHist = document.getElementById('expHistDiv');
        var histTable = document.getElementById("wdesk:histGrid");
        //expHist.className = 'wdDivBorder';
        histTable.style.display = 'inline';
        var expCmnt = document.getElementById("wdesk:comnt");
        expCmnt.style.display = 'none';

        document.getElementById("wdesk:detailHdr").innerHTML = TITLE_EXCEPTION_DETAILS;
        document.getElementById("wdesk:lblDetails").innerHTML = LABEL_DETAILS;
        document.getElementById("wdesk:modifybtn").value= MODIFY;
        var funName="modifyExcep_open()";
        document.getElementById("wdesk:modifybtn").onclick = function (){parseJSON(funName);return false;}
}

function modifyExcep_open()
{
    /*var pid=document.getElementById('wdesk:pid').value;
    var wid=document.getElementById('wdesk:wid').value;*/
    var excpId = document.getElementById('wdesk:selexpid').value;
    var cmnt=document.getElementById('wdesk:comnt').value;
    cmnt=cmnt.replace(/<br\s*\/?>/gi,"");
    document.getElementById('wdesk:desc').innerHTML=encode_ParamValue(ExceptionName);
    
    var url = '/webdesktop/components/workitem/operations/exception/modify_exception.app'
    var wd_rid=getRequestToken(url);
    url+="?WD_RID="+wd_rid;
    url+='&Pid='+encode_utf8(pid)+'&Wid='+encode_utf8(wid)+'&Taskid='+encode_utf8(taskid)+'&excpid='+encode_utf8(excpId)+'&Comnt='+encode_utf8(cmnt)+'&WD_SID='+WD_SID;

    var expHist = document.getElementById('expHistDiv');
    //expHist.className = 'wdDivBorderDis';
    var histTable = document.getElementById("wdesk:histGrid");
    histTable.style.display = 'none';
    var expCmnt = document.getElementById("wdesk:comnt");
    expCmnt.value = "";
    expCmnt.style.display = 'inline';
    var iframeExp=document.getElementById('expOpFrm');
    url = appendUrlSession(url);
    iframeExp.src = url;
    document.getElementById("wdesk:detailHdr").innerHTML = TITLE_MODIFY_EXCEPTION;
    document.getElementById("wdesk:lblDetails").innerHTML = LABEL_EXCEPTION_COMMENTS;
    document.getElementById("wdesk:modifybtn").value = " "+LABEL_OK+" ";
    var funName="modifyExpBtn()";
    document.getElementById("wdesk:modifybtn").onclick = Function("modifyExpBtn();return false;");
    document.getElementById("wdesk:clearbtn").style.display = 'none';
    document.getElementById("wdesk:responsebtn").style.display = 'none';
    document.getElementById("wdesk:rejectbtn").style.display = 'none';
    
    document.getElementById("wdesk:pnl_comment_label").style.display = 'inline';
    
    //expChng(excpId);
}

function saveData(op){
    
/***Needed a hook on  exception in case of being raised multiple times  wirhout getting cleared***/
   var Expid=window.parent.document.getElementById("wdesk:selexpid").value;
   var Expname=window.parent.document.getElementById("wdesk:selexpname").value;
   
   if(!isCustomValidException(Expname))
       return false;
    
   if(chkForRaisedExcp(Expid, Expname) == false){
      return false;
   }
   /***Needed a hook on  exception in case of being raised multiple times  wirhout getting cleared***/


    var status;
    var winDesk;
    if(window.parent.windowProperty.winloc == 'M')
        winDesk = window.parent;
    else if(window.parent.windowProperty == 'T')
            winDesk = window.parent.opener.opener;
    else
            winDesk = window.parent.opener;
    
    var formWindow = winDesk.getWindowHandler(winDesk.windowList,"formGrid");    
    var ngformIframe = formWindow.document.getElementById("ngformIframe");	
    if((winDesk.wiproperty.formType == "NGFORM") && (winDesk.ngformproperty.type == "applet") && !winDesk.bDefaultNGForm && !winDesk.bAllDeviceForm){       
       if(formWindow){           
           if(ngformIframe != null){
               // parameter passing           
               var ngformIframeWindow = ngformIframe.contentWindow;
               var wiDummySaveStructWinRef = ngformIframeWindow;
                if(formIntegrationApr == "4"){
                    wiDummySaveStructWinRef = window.parent;
                }
                
               wiDummySaveStructWinRef.WiDummySaveStruct.Type = 'SaveData';
               wiDummySaveStructWinRef.WiDummySaveStruct.Params.FormType = 'NGHTML';
               wiDummySaveStructWinRef.WiDummySaveStruct.Params.window_workdesk = winDesk;               
               wiDummySaveStructWinRef.WiDummySaveStruct.Params.operation=op;
               
               if(formIntegrationApr == "4"){
                    ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.fireFormValidation('S','Y')");	                                                                
                } else {		
                    ngformIframeWindow.clickLink('cmdNgFormDummySave');
                }
           }
           return false;
       }
   } else {
       if(winDesk.bCustomIForm){           
            if(formWindow){
               if(ngformIframe != null){
                   if(typeof ngformIframe.contentWindow.customIFormHandler != 'undefined'){
                        ngformIframe.contentWindow.customIFormHandler('S','Y');
                   }
               }
            }
       }
       return commonSaveData(winDesk,'',op);
   }
   
    /*status = winDesk.for_save('dummysave');
    winDesk.saveCalled = true;
    if(status == 'failure')
        return false;
    return true;*/
}

function commonSaveData(winDesk,formType,operation){
    formType = typeof formType == 'undefined'? '': formType;
    
    var exceptionGrid = winDesk.getWindowHandler(winDesk.windowList,"exceptionGrid");
    var expObj = exceptionGrid.frames['expOpFrm'];
    var status = winDesk.for_save('dummysave');
    winDesk.saveCalled = true;
    if(status == 'failure') {
        return false;
    }
    if(operation == 'RA') {
        expObj.raise_exception();
    } else if(operation == 'CL') {
        expObj.clearSubmit(operation);
    }
    return true;
}

function saveDataExp(op){
    wordWrap(window.parent.document.getElementById("wdesk:comnt"),65);
    var status;
    var winDesk;
    if(window.parent.windowProperty.winloc == 'M')
        winDesk = window.parent;
    else if(window.parent.windowProperty == 'T')
            winDesk = window.parent.opener.opener;
    else
            winDesk = window.parent.opener;
        
    if(typeof customRaiseExp != 'undefined' && customRaiseExp())
        setCustomExpVar();   
    
    var formWindow = winDesk.getWindowHandler(winDesk.windowList,"formGrid");
    var ngformIframe = formWindow.document.getElementById("ngformIframe");	
    if((winDesk.wiproperty.formType == "NGFORM") && (winDesk.ngformproperty.type == "applet") && !winDesk.bDefaultNGForm && !winDesk.bAllDeviceForm){       
       if(formWindow){           
           if(ngformIframe != null){
               // parameter passing           
               var ngformIframeWindow = ngformIframe.contentWindow;
               var wiDummySaveStructWinRef = ngformIframeWindow;
                if(formIntegrationApr == "4"){
                    wiDummySaveStructWinRef = window.parent;
                }
                
               wiDummySaveStructWinRef.WiDummySaveStruct.Type = 'SaveDataExp';
               wiDummySaveStructWinRef.WiDummySaveStruct.Params.FormType = 'NGHTML';
               wiDummySaveStructWinRef.WiDummySaveStruct.Params.window_workdesk = winDesk;               
               wiDummySaveStructWinRef.WiDummySaveStruct.Params.operation = op;
               
               if(formIntegrationApr == "4"){
                    ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.fireFormValidation('S','Y')");	                                                                
                } else {			
                    ngformIframeWindow.clickLink('cmdNgFormDummySave');
                }
           }
           return false;
       }
   } else {
       if(winDesk.bCustomIForm){
           if(formWindow){
               if(ngformIframe != null){
                   if(typeof ngformIframe.contentWindow.customIFormHandler != 'undefined'){
                        ngformIframe.contentWindow.customIFormHandler('S','Y');
                   }
               }
           }
       }
       
       return commonSaveDataExp(winDesk,'',op);
   }
   
    /*status = winDesk.for_save('dummysave');
    winDesk.saveCalled = true;
    if(status == 'failure')
        return false;
    return true;*/
}

function commonSaveDataExp(winDesk,formType,operation){
    formType = typeof formType == 'undefined'? '': formType;
    var status = winDesk.for_save('dummysave');
    winDesk.saveCalled = true;
    if(status == 'failure') {
        return false;
    }
    
    var exceptionGrid = winDesk.getWindowHandler(winDesk.windowList,"exceptionGrid");
    var expObj = exceptionGrid.frames['expOpFrm'];
    if(operation == 'RS'){
        expObj.clearSubmit(operation);
    } else if(operation == 'RJ'){
        expObj.clearSubmit(operation);
    } else {
        expObj.modify_Exception();
    }
    return true;
}

function raise_exception(){
   isCommentMandatory=window.parent.document.getElementById('wdesk:IsCommentMandatory').value;
   var comnts = Trim(window.parent.document.getElementById("wdesk:comnt").value);
   var objList = window.parent.document.getElementById('wdesk:expList');
   document.getElementById("raise:comnt").value = comnts;
   document.getElementById("raise:Exp").value = objList.value;
   document.getElementById("raise:expName").value = objList.options[objList.options.selectedIndex].text;
   
   if(typeof customRaiseExp != 'undefined' && customRaiseExp())
        setCustomExpVar();
    if(isCommentMandatory=="Y" && comnts==""){
        window.parent.customAlert(ALERT_RAISE_COMMENT);
        window.parent.document.getElementById("wdesk:comnt").focus();
        return false;
   }
   clickButton(document.getElementById('raise:raiseExpBtn2'));
   return true;
}

function modify_Exception(){
    isCommentMandatory=window.parent.document.getElementById('wdesk:IsCommentMandatory').value;
    var comnts = window.parent.document.getElementById("wdesk:comnt").value;
    comnts=comnts.replace(/<br\s*\/?>/gi,"");
    document.getElementById("modify:comnt").value = comnts;
    if(isCommentMandatory=='Y' && Trim(comnts) == ""){
        window.parent.customAlert(ALERT_MODIFY_COMMENT);
        window.parent.document.getElementById("wdesk:comnt").focus();
        return false;
   }
   clickButton(document.getElementById('modify:modifyExpBtn2'));
   return true;
}

function expChng(expId){
        var serverResponse = "";
        var window_workdesk;
        if(windowProperty.winloc == 'M')
            window_workdesk=window;
        else if(windowProperty.winloc == 'T')
            window_workdesk=window.opener.opener;
        else
            window_workdesk=window.opener;

        var xhReq;
        if (window.XMLHttpRequest)
            xhReq = new XMLHttpRequest();
        else
            xhReq = new ActiveXObject("Microsoft.XMLHTTP");
        var url = '/webdesktop/ajaxexpmodify.app?excpid='+expId+'&pid='+encode_utf8(pid)+'&wid='+wid+'&taskid='+taskid+'&rid='+ MakeUniqueNumber()+'&WD_SID='+WD_SID;
        url = appendUrlSession(url);
         var wd_rid=getRequestToken(url);
         url+="&WD_RID="+wd_rid;
        xhReq.open("GET", url, false);
        xhReq.send(null);
        serverResponse = xhReq.responseText;
        serverResponse=parseJSON("("+serverResponse+")");
        var histResponse = serverResponse.hist;
        var expHist = document.getElementById('expHistDiv');
        var histTable = document.getElementById("wdesk:histGrid");
        //expHist.className = 'wDDivBorder';
        histTable.style.display = 'inline';
        var expCmnt = document.getElementById("wdesk:comnt");
        expCmnt.style.display = 'none';
        excpListSel(expId);

        var htmlStr = "";
        var tempVar = 0;
        for(var k =0;k<histResponse.length;k++){
            tempVar = k+1;
            if(k == histResponse.length-1){
                tempVar = -1;
                if(k == 0)
                    tempVar = -2;
            }
            histResponse[k].C = decode_utf8(histResponse[k].C);
            htmlStr += createExcpDivHtml(histResponse[k].N,histResponse[k].A,histResponse[k].By,histResponse[k].At,histResponse[k].On,histResponse[k].C,expId,tempVar, histResponse[k].A);
            expCmnt.value = histResponse[k].C;
        }
        
        var expCount = document.getElementById("wdesk:expCount").value;
        
        var rowX = document.createElement('TR');
        var colY = document.createElement('TD');
        excpDiv = document.createElement("DIV");
        excpDiv.id = 'expDiv' + expId;
        excpDiv.innerHTML = encode_ParamValue(htmlStr);
        colY.appendChild(excpDiv);
        rowX.appendChild(colY);
        rowX.setAttribute('id','expDivRow'+expId);
        if(histTable.childNodes[0].nodeName=="TBODY"){
            if(histTable.children[0].children.length > 0)
                histTable.childNodes[0].deleteRow(0);
            histTable.childNodes[0].appendChild(rowX);
        }
        else{
            histTable.childNodes[1].innerHTML='';
            if(histTable.childNodes[1].childNodes.length > 2 || (expCount == '0' && histTable.childNodes[1].childNodes.length > 1))
                histTable.childNodes[1].deleteRow(0);
            histTable.childNodes[1].appendChild(rowX);
        }

        if(window_workdesk.wiproperty.locked != "Y"){
            document.getElementById("wdesk:raisebtn").style.display = 'none';
            if(serverResponse.raise == "enable"){
                document.getElementById("wdesk:newbtn").disabled = false;
               // document.getElementById("wdesk:newbtn").src = sContextPath+"/webtop/"+PATH+"images/new_exp.gif";
            }
            else{
                document.getElementById("wdesk:newbtn").disabled = true;
              //  document.getElementById("wdesk:newbtn").src = sContextPath+"/webtop/"+PATH+"images/new_exp_dis.gif";
            }
            changeBtnStatus(serverResponse.modify, serverResponse.clear, serverResponse.response, serverResponse.reject, serverResponse.undo);
        }
    }

function createExcpDivHtml(name,status,raisedBy,activityName,currentDate,comments,excpId,count, action){
    var excpDivHtml;
    excpDivHtml = "<table><TBODY>";
    excpDivHtml = excpDivHtml + "<TR><TD>";
    excpDivHtml = excpDivHtml + "<span class=wdrowtext>" + action+ " " + LABEL_EXCEPTION_BY + "</span>";
    excpDivHtml = excpDivHtml + "<span class=wdrowtext>"+raisedBy+"</span><br>";
    excpDivHtml = excpDivHtml + "<span class=wdrowtext>"+LABEL_EXCEPTION_AT+"</span><span class=wdrowtext>"+activityName+"</span><br>";
    excpDivHtml = excpDivHtml + "<span class=wdrowtext>"+LABEL_EXCEPTION_ON+"</span><span class=wdrowtext>"+currentDate+"</span>";
    excpDivHtml = excpDivHtml + "</TBODY></table>";
    excpDivHtml = excpDivHtml + "<table><TBODY>";
    excpDivHtml = excpDivHtml + "";
    if(count){
        if(count == -1 || count == -2)
            excpDivHtml = excpDivHtml + "<TR><TD valign='top'><span class=wdrowtextgray>&bull;</span></TD><TD class=wdlabelstyleblack><div id=newCmnt"+excpId+" style='word-break: break-word;'>"+comments+"</div></TD><TD></TD></TR>";
        else
            excpDivHtml = excpDivHtml + "<TR><TD valign='top'><span class=wdrowtextgray>&bull;</span></TD><TD class=wdlabelstyleblack><div style='word-break: break-word;'>"+comments+"</div></TD><TD></TD></TR>";
    }
    else
        excpDivHtml = excpDivHtml + "<TR><TD valign='top'><span class=wdrowtextgray>&bull;</span></TD><TD class=wdlabelstyleblack><div id=newCmnt"+excpId+" style='word-break: break-word;'>"+comments+"</div></TD><TD></TD></TR>";
    excpDivHtml = excpDivHtml + "</TBODY></table>";
    return excpDivHtml;
}

function changeBtnStatus(modify, clear, response, reject, undo){
        if(modify == "enable"){
            document.getElementById("wdesk:modifybtn").style.display = 'inline';
            document.getElementById("wdesk:modifybtn").value= MODIFY;
            document.getElementById("wdesk:modifybtn").onclick = Function("modifyExcep_open();return false;");
        }
        else
            document.getElementById("wdesk:modifybtn").style.display = 'none';

        if(clear == "enable"){
            document.getElementById("wdesk:clearbtn").style.display = 'inline';
            document.getElementById("wdesk:clearbtn").value = CLEAR;
            document.getElementById("wdesk:clearbtn").onclick = Function("clearExcep_open();return false;");
        }
        else
            document.getElementById("wdesk:clearbtn").style.display = 'none';

        if(response == "enable"){
            document.getElementById("wdesk:responsebtn").style.display = 'inline';
            document.getElementById("wdesk:responsebtn").value = RESPONSE;
            document.getElementById("wdesk:responsebtn").onclick = Function("responseExcep_open();return false;");
        }
        else
            document.getElementById("wdesk:responsebtn").style.display = 'none';

        if(reject == "enable"){
            document.getElementById("wdesk:rejectbtn").style.display = 'inline';
            document.getElementById("wdesk:rejectbtn").value = REJECT;
            document.getElementById("wdesk:rejectbtn").onclick = Function("rejectExcep_open();return false;");
        }
        else
            document.getElementById("wdesk:rejectbtn").style.display = 'none';

        if(undo == "enable"){
            document.getElementById("wdesk:cancelbtn").disabled = false;
            document.getElementById("wdesk:cancelbtn").value= UNDO;
        }
        else{
            document.getElementById("wdesk:cancelbtn").disabled = true;
            document.getElementById("wdesk:cancelbtn").value= UNDO;
        }
    }


function excpUnDo(){
        var excpId = document.getElementById('wdesk:selexpid').value;
        if(document.getElementById("expDiv" + excpId) != null){
        var serverResponse = unDoExpHist(excpId);
        serverResponse=parseJSON("("+serverResponse+")");
        
        
        for(var cnt=0; cnt<tempExcpTrig.length; cnt++){
            if(tempExcpTrig[cnt].id == excpId){
                tempExcpTrig.removeAt(cnt);
                break;
            }
        }
        addException('Undo','','',ExceptionName);
        
}
else {
customAlert(ALERT_SELECT_EXCEPTION);
}
}

function unDoExpHist(excpId){
    var xhReq;
    if (window.XMLHttpRequest)
        xhReq = new XMLHttpRequest();
    else
        xhReq = new ActiveXObject("Microsoft.XMLHTTP");
    /*var pid=document.getElementById('wdesk:pid').value;
    var wid=document.getElementById('wdesk:wid').value;*/
    var url = '/webdesktop/ajaxremoveHist.app?pid='+encode_utf8(pid)+'&wid='+wid+'&taskid='+taskid+'&expId='+excpId+'&rid='+MakeUniqueNumber()+'&WD_SID='+WD_SID;
    url = appendUrlSession(url);
     var wd_rid=getRequestToken(url);
         url+="&WD_RID="+wd_rid;
   // var retn = new msg.Message('waitDia','<table border="0" width="100%" cellpadding="4"><tr><td><img src="'+sContextPath+'/webtop/'+PATH+'images/progress.gif"></td></tr></table>',3,3);
    xhReq.open("GET", url, false);
    xhReq.send(null);
    var serverResponse = xhReq.responseText;
   /* if(msg.hideDialog)
            msg.hideDialog();*/
    return serverResponse;
}

function deleteRowFromTable(expId){
}

function clearExcep_open()
{
    var expWtype = "";
    /*var pid = document.getElementById('wdesk:pid').value;
    var wid = document.getElementById('wdesk:wid').value;*/
    var expId = document.getElementById('wdesk:selexpid').value;
    var expName = document.getElementById('wdesk:selexpname').value;
    if(document.getElementById('wdesk:expWtype'))
        expWtype = document.getElementById('wdesk:expWtype').value;
    var url = '/webdesktop/components/workitem/operations/exception/clear_exception.app';
    var wd_rid=getRequestToken(url);
    url+="?WD_RID="+wd_rid;
    url += '&Pid='+encode_utf8(pid)+'&Wid='+encode_utf8(wid)+'&Taskid='+encode_utf8(taskid)+'&expWtype='+expWtype+'&expId='+expId+'&expName='+encode_utf8(expName)+"&WD_SID="+WD_SID;

    var expHist = document.getElementById('expHistDiv');
    //expHist.className = 'EWDivBorderDis';
    var histTable = document.getElementById("wdesk:histGrid");
    histTable.style.display = 'none';
    var expCmnt = document.getElementById("wdesk:comnt");
    expCmnt.value = "";
    expCmnt.style.display = 'inline';
    var iframeExp=document.getElementById('expOpFrm');
    url = appendUrlSession(url);
    iframeExp.src = url;
    document.getElementById("wdesk:detailHdr").innerHTML = TITLE_CLEAR_EXCEPTION;
    document.getElementById("wdesk:lblDetails").innerHTML = LABEL_EXCEPTION_COMMENTS;
    document.getElementById("wdesk:clearbtn").value = LABEL_OK;
    var funName="clearExpBtn()";
    document.getElementById("wdesk:clearbtn").onclick = Function("clearExpBtn();return false;");
    document.getElementById("wdesk:modifybtn").style.display = 'none';
    document.getElementById("wdesk:responsebtn").style.display = 'none';
    document.getElementById("wdesk:rejectbtn").style.display = 'none';
}

function clearSubmit(operation){
    isCommentMandatory=window.parent.document.getElementById('wdesk:IsCommentMandatory').value;
    var comnts = window.parent.document.getElementById("wdesk:comnt").value;
    document.getElementById("clear:comnt").value = comnts;
    if(isCommentMandatory=='Y' && Trim(comnts) == ""){
        customAlert(ALERT_CLEAR_COMMENT);
        window.parent.document.getElementById("wdesk:comnt").focus();
        return false;
    }
    if(operation == 'CL') {
        clickButton(document.getElementById('clear:clearExpBtn2'));
    } else if(operation == 'RS') {
        clickButton(document.getElementById('clear:responseExpBtn2'));
    } else if(operation == 'RJ') {
        clickButton(document.getElementById('clear:rejectExpBtn2'));
    }
    return true;
}

function excpOk(frmSave,flag,data, from){

 //chkForRaisedExcp() is prehook on commit 
  try{
      from = (typeof from == 'undefined')? '': from;
        chkForRaisedExcp();

        excpFlag = "okClick";
        if(typeof frmSave =='undefined')
            frmSave = '';
        if(typeof data =='undefined')
            data = '';
        if(typeof flag =='undefined')
            flag = '';
  
        if(tempExcpTrig.length > 0 || flag !=''){
            var trigDesc = '';
            if(tempExcpTrig.length > 0){
                var wdesk_win = '';
                if(windowProperty.winloc == 'M')
                    wdesk_win = window;
                else if(windowProperty.winloc == 'T')
                    wdesk_win = window.opener.opener;
                else
                    wdesk_win = window.opener;
                if(!wdesk_win.commitException())  //ritu tbd
                    return "failure";
                var isAnyExp = false;
                for(var cnt=0; cnt<tempExcpTrig.length; cnt++){
                    if(isExpVisible(tempExcpTrig[cnt].id) || frmSave == 'save'){
                        isAnyExp = true;
                        trigDesc = trigDesc + '<Trigger>';
                        trigDesc = trigDesc + '<ID>' + tempExcpTrig[cnt].id + '</ID>';
                        trigDesc = trigDesc + '<Type>' + tempExcpTrig[cnt].type + '</Type>';
                        if(tempExcpTrig[cnt].type == "D") {
                            if(tempExcpTrig[cnt].value == undefined || tempExcpTrig[cnt].value == 'undefined'){
                                tempExcpTrig[cnt].value = "";
                            }
                            trigDesc = trigDesc + '<Value>' + tempExcpTrig[cnt].value + '</Value>';
                        }
                        trigDesc = trigDesc + '</Trigger>';
                    }
                }
                if(isAnyExp)
                    trigDesc = '<Triggers>' + trigDesc + '</Triggers>';
            }
            var xhReq;
            var   url ;
            for(var i=0;i<3;i++){
                url = '/webdesktop/ajaxexcpok.app';
                url = appendUrlSession(url);
           
                if (window.XMLHttpRequest)
                    xhReq = new XMLHttpRequest();
                else
                    xhReq = new ActiveXObject("Microsoft.XMLHTTP");
                 var wd_rid=getRequestToken(url);
         url+="&WD_RID="+wd_rid;
                xhReq.open("POST", url, false);
                xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhReq.send(data+'pid='+encode_utf8(pid)+'&CustomAjax=true&wid='+wid+'&taskid='+taskid+'&trigDesc='+encode_utf8(trigDesc)+'&flag='+flag+'&excpId='+document.getElementById('wdesk:selexpid').value+"&frmSave="+frmSave+"&WD_SID="+WD_SID);  
                break;
         
            
       
            }

            if (xhReq.status == 200 && xhReq.readyState == 4) {
                var expTrigRes = xhReq.responseText;
                if(expTrigRes == 'false'){
                    return expTrigRes;
                }
                else{
                    var cnt = 0;
                    if(frmSave == 'save'){
                        cnt = 1;
                    }
                    expTrigRes = parseJSON("("+expTrigRes+")");
                    for( ; cnt<expTrigRes.length; cnt++){
                        if(expTrigRes[cnt] != 'G'){
                            if(expTrigRes[cnt][0].flag=='0')
                            {
                                if(expTrigRes[cnt][0].TriggerType == 'S')
                                    expSetTrig(expTrigRes[cnt]);
                                else if(expTrigRes[cnt][0].TriggerType == 'DE'){
                                    expNewDETrig(expTrigRes[cnt],cnt);
                                }
                            }
                            else if(expTrigRes[cnt][0].flag=='-1'){
                                if(expTrigRes[cnt][0].TriggerType == 'M')
                                    customAlert(expTrigRes[cnt][0].description);
                            }
                        }
                    }
                    var excpId;
                    for(cnt=0; cnt<tempExcpTrig.length; cnt++){
                        excpId = tempExcpTrig[cnt].id;
                        if(document.getElementById('expNm'+excpId)){
                            var expNm = document.getElementById('expNm'+excpId).innerHTML;
                            expNm = expNm.substring(1);
                            document.getElementById('expNm'+excpId).innerHTML = expNm;
                            var expStatus = document.getElementById('expStat'+excpId).innerHTML;
                            expStatus=expStatus.substring(0,expStatus.indexOf("["));
                            document.getElementById('expStat'+excpId).innerHTML=expStatus;
                        }
                    }
                    if(frmSave == 'save' )
                        tempExcpTrig.length = 0;
                    else{
                        var excpId;
                        for(cnt=0; cnt<tempExcpTrig.length; cnt++){
                            if(isExpVisible(tempExcpTrig[cnt].id)){
                                tempExcpTrig.splice(cnt,1);
                                cnt--;
                            }
                        }
                    }

                    if(frmSave == 'save'){
                        if(document.getElementById("wdesk:modifybtn").style.display == 'inline'){
                            disableModify();
                            changeBtnStatus("enable", expTrigRes[0].clear, expTrigRes[0].response, expTrigRes[0].reject, "disable");
                        }
                        else
                            changeBtnStatus("disable", expTrigRes[0].clear, expTrigRes[0].response, expTrigRes[0].reject, "disable");
                    }

                    if(windowProperty.winloc != 'M' && frmSave != 'save')
                        window.close();
                    else{
                        document.getElementById("wdesk:cancelbtn").disabled = true;
                        document.getElementById("wdesk:cancelbtn").value = UNDO;
                        document.getElementById("wdesk:okbtn").disabled = true;
                        document.getElementById("wdesk:okbtn").value= COMMIT;
                    }
                    if(from != 'close'){
                        addException('Commit','','',ExceptionName,'','','','',expTrigRes);
                        saveExcpPostHook('Commit');	//Bug 68117
                    }	//Bug 68117
                    return 'true';
                }
           
            }
            else
            {
                if(xhReq.status==598)
                {
                    customAlert(xhReq.responseText);
                }
                else if(xhReq.status==599)
                {

                    /* url = "/webdesktop/faces/login/login.jsp?"+"error="+xhReq.getResponseHeader('ngerror');*/
                    //url = sContextPath+"/login/logout.jsp?"+"error=4020";
                    url = sContextPath+"/error/errorpage.app?msgID=4020";
                    url = appendUrlSession(url);
                    //window.open(url,reqSession);

                    var width = 320;
                    var height = 160;
                    var left = (window.screen.availWidth-width)/2;
                    var top = (window.screen.availHeight-height)/2;

                    //window.open(url,reqSession);
                    if (window.showModalDialog){
                        window.showModalDialog(url,'',"dialogWidth:"+width +"px;dialogHeight:"+height+"px;center:yes;dialogleft: "+left+"px;dialogtop: "+top+"px");
                    }
                }
                 else if(xhReq.status==250)
            {
                window.location= "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";    
            }  
                else if(xhReq.status==310)
            {
                window.location= "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";    
            }
                else if(xhReq.status == 400)
                    customAlert(INVALID_REQUEST_ERROR);
                else if(xhReq.status==12029){
                    customAlert(ERROR_SERVER); 
                }
                else {
                    customAlert(ALERT_OPERATION_UNSUCCESSFUL);
                    if(msg.hideDialog)
                        msg.hideDialog();
                    return false;
                }
                /*if(msg.hideDialog)
                msg.hideDialog();*/
                return 'failure';
            }
        }
        else{
            if(frmSave == 'save'){
                if(document.getElementById("wdesk:modifybtn").style.display == 'inline')
                    disableModify() ;
            }
        // if(windowProperty.winloc != 'M'  && frmSave != 'save')
        //  window.close();
        }
    }catch(e){
        return;
    }
}

function isExpVisible(expId){
    var ExpTypeList = ExpListJson.ExpList;
    var tempExpId = expId.substring(0, expId.indexOf("_"));
    for(var jcnt=0; jcnt<ExpTypeList.length; jcnt++){
        if(tempExpId == ExpTypeList[jcnt].EXPID)
            return true;
    }
    return false;
}

function disableModify(){
        var expHist = document.getElementById('expHistDiv');
        var histTable = document.getElementById("wdesk:histGrid");
        //expHist.className = 'wdDivBorder';
        histTable.style.display = 'inline';
        var expCmnt = document.getElementById("wdesk:comnt");
        expCmnt.style.display = 'none';

        document.getElementById("wdesk:detailHdr").innerHTML = TITLE_EXCEPTION_DETAILS;
        document.getElementById("wdesk:lblDetails").innerHTML = LABEL_DETAILS;
        document.getElementById("wdesk:modifybtn").style.display = 'none';
}

function addExcepInTable(expTbl,excpId,excpName,status,cmnt,isTemp){
    
}

function responseExcep_open(){
    var expWtype = "";
   /* var pid = document.getElementById('wdesk:pid').value;
    var wid = document.getElementById('wdesk:wid').value;*/
    var expId = document.getElementById('wdesk:selexpid').value;
    var expName = document.getElementById('wdesk:selexpname').value;
    if(document.getElementById('wdesk:expWtype'))
        expWtype = document.getElementById('wdesk:expWtype').value;
    var url = '/webdesktop/components/workitem/operations/exception/clear_exception.app';
    var wd_rid=getRequestToken(url);
    url+="?WD_RID="+wd_rid;
    url += '&Pid='+encode_utf8(pid)+'&Wid='+encode_utf8(wid)+'&Taskid='+encode_utf8(taskid)+'&expWtype='+expWtype+'&expId='+expId+'&expName='+encode_utf8(expName)+"&WD_SID="+WD_SID;

    var expHist = document.getElementById('expHistDiv');
    //expHist.className = 'wdDivBorderDis';
    var histTable = document.getElementById("wdesk:histGrid");
    histTable.style.display = 'none';
    var expCmnt = document.getElementById("wdesk:comnt");
    expCmnt.value = "";
    expCmnt.style.display = 'inline';
    var iframeExp=document.getElementById('expOpFrm');
    url = appendUrlSession(url);
    iframeExp.src = url;
    document.getElementById("wdesk:detailHdr").innerHTML = TITLE_RESPONSE_EXCEPTION;
    document.getElementById("wdesk:lblDetails").innerHTML = LABEL_EXCEPTION_COMMENTS;
    document.getElementById("wdesk:responsebtn").value = LABEL_OK;
    document.getElementById("wdesk:responsebtn").onclick = Function("responseExpBtn();return false;");
    document.getElementById("wdesk:modifybtn").style.display = 'none';
    document.getElementById("wdesk:clearbtn").style.display = 'none';
    document.getElementById("wdesk:rejectbtn").style.display = 'none';
}

function selectExpTableFirstRowOnLoad(expId){

    if(expId == null || expId == "" || expId == undefined)
        return;

    var tableId="wdesk:expTable";
    var ctrlTable=document.getElementById(tableId);
    if(ctrlTable==null)
        return;
    try
    {
        var rowCount = ctrlTable.tBodies[0].rows.length;
        
        if(rowCount>0){
            for(var k=0;k<rowCount;k++){
                var arrTd=ctrlTable.tBodies[0].rows[k].getElementsByTagName("td")
                
                for(var i=0;i<arrTd.length;i++){
                    var div=arrTd[i].getElementsByTagName("div");
                    for(var j=0;j<div.length;j++){
                        var id=div[j].id;
                        if(id.indexOf(expId)!=-1){
                            //ctrlTable.tBodies[0].rows[k].className="wdSelected";
                            ctrlTable.tBodies[0].rows[k].className="tablecontent row-selector cursorpointer";
                            break;
                        }
                    }
                }
            }
            selectedExpId=expId;
            checkDivRef=document.getElementById("expRow"+expId);
         }

         var comments = document.getElementById("hidExp"+expId+"cmnt");
         if(comments!=undefined)
            document.getElementById("wdesk:comnt").value =comments.value;

    }catch(ex){
    }
}


function expSetTrig(expTrig){
    var window_workdesk;
    if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else if(windowProperty.winloc == 'N')
        window_workdesk = window.opener;
    else
        window_workdesk = window;
    var bBroadCastEvent = false;
    if(window_workdesk.SharingMode){
        bBroadCastEvent = true;
    }
    for(var i=1; i<expTrig.length; i++){
        var valSetter=expTrig[i];
        if((window_workdesk.wiproperty.formType == "NGFORM") && (window_workdesk.ngformproperty.type == "applet") && !window_workdesk.bDefaultNGForm){
            var ngformIframe = window_workdesk.document.getElementById("ngformIframe");
            if(ngformIframe != null){
                if(window_workdesk.bAllDeviceForm){
                    try{
                    ngformIframe.contentWindow.eval("com.newgen.iforms.setValue('"+valSetter.attribXML+"')");
                }
                catch(ex){}
                } else {
                    try{
                    ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.setValue('ngform','"+valSetter.attribXML+"')");}
                catch(ex)
                {}             
               }
            }
        } else {
            if((window_workdesk.wiproperty.formType == "NGFORM") && (window_workdesk.ngformproperty.type == "applet")){
                var formWin = getWindowHandler(window_workdesk.windowList,"formGrid");
                formWin.document.wdgc.setFieldValueBag(valSetter.attribXML);
            }
            else
            {
                window_workdesk.setFormValue(valSetter.name,valSetter.value,valSetter.type);
            }
        }
    }
    
    if(bBroadCastEvent != undefined && bBroadCastEvent == true){
        window_workdesk.broadcastSetDataEvent(JSON.stringify(expTrig));
    }
}

function expNewDETrig(expTrig,cnt){
    var attributeData = '';
    var broadcastEvent = false;
    var window_workdesk="";
    if(windowProperty.winloc=="M")
        window_workdesk=window;
    else
        window_workdesk=window.opener;
    if(window_workdesk.SharingMode){
        broadcastEvent = true;
    }
    
    if((window_workdesk.wiproperty.formType == "NGFORM") && (window_workdesk.ngformproperty.type == "applet") && !window_workdesk.bDefaultNGForm){
        if(typeof expTrig[0].attribXML != 'undefined'){
            attributeData = expTrig[0].attribXML;
        }
    } else {
        attributeData = tempExcpTrig[cnt].value;
    }
    dataEntryHandler(attributeData,'ENew',broadcastEvent);
}

function removeTempExp(excpId, expSeqId, comments){
    
}

function CheckExpTempStatus(excpWindow)
    {
        var retVal = false;
        var tempExcpTrigArr = excpWindow.tempExcpTrig;
        var ExpTypeList = ExpListJson.ExpList;
        if(tempExcpTrigArr.length > 0){
            var tempExpId;
            for(var cnt=0; cnt<tempExcpTrigArr.length; cnt++){
                if(retVal)
                    break;

                tempExpId = tempExcpTrigArr[cnt].id.substring(0,tempExcpTrigArr[cnt].id.indexOf('_'));

                for(var jcnt=0; jcnt<ExpTypeList.length; jcnt++){
                    if(tempExpId == ExpTypeList[jcnt].EXPID)
                    {
                        retVal = true;
                        break;
                    }
                }

            }
        }
        return retVal;
    }
function SetDescription(data){
    if(data.status=='success'){
       document.getElementById('wdesk:desc').innerHTML=encode_ParamValue(ExceptionName);

       var expAll = document.getElementById('wdesk:expAllList');
        expAll.style.display = 'inline';
        if(selectedExpId!=null && selectedExpId!="")
            expAll.selectedIndex=(selectedExpId.substring(0,selectedExpId.indexOf('_'))-1);
    }
}

var lastExpId = null;
function expRefreshAction()
{
    //lastExpId = document.getElementById('wdesk:selecteExpSeqId').value;  
    var url = sContextPath + "/components/workitem/view/";
    url += "exp_main_view.app";    
    sendAsynAjaxRequest('exp', url, "exceptionReloadCallback()",false,false);
}

function exceptionReloadCallback()
{    
     saveExcpPostHook(calledFrom); //Bug 68117
//     RemoveIndicator("handlerCall");
}

function wordWrap(control, wrapLength)
	{
		var sString = control.value;
		var sStringResult = "";
		var iStartNow = 0;
		var iWrapPoint = 0;
		var iWrapItself = 0;

		while(iWrapPoint != -1)
		{
			// Hint : Use another wrap point for '\n' and find the best amont the two, to use it in on blur.
			iWrapItself = (sString.substring(iStartNow, addTOWord(iStartNow,wrapLength))).lastIndexOf("\n");
			if(iWrapItself != -1)
			{
				sStringResult += "\n" + sString.substring(iStartNow, addTOWord(iStartNow,iWrapItself));
				iStartNow =addTOWord(addTOWord(iStartNow,iWrapItself),1);
				continue;
			}
			iWrapPoint = (sString.substring(iStartNow, addTOWord(iStartNow,wrapLength))).lastIndexOf(" ");
			if(iWrapPoint == -1 && (sString.length > addTOWord(iStartNow, wrapLength)))
				iWrapPoint = wrapLength;
			if(sStringResult)
				sStringResult += "\n";
			if((iWrapPoint == -1) || (sString.length < addTOWord(iStartNow, wrapLength)))
			{
				sStringResult += sString.substring(iStartNow, sString.length);
				break;
			}
			else
				sStringResult += sString.substring(iStartNow, addTOWord(iStartNow,iWrapPoint));
			iStartNow =addTOWord(addTOWord(iStartNow,iWrapPoint),1);
		}
                 control.value = sStringResult;
		//destination.value = sStringResult;
	}
        function addTOWord(int1, int2)
	{
		//return ( (1-int1-int2)*-1+1 );
		return ( int1*1 + int2*1 )
	}














