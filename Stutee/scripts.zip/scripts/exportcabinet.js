

function connectFunc(ref, toClick) {
    var ip = document.getElementById("cabform:txtIp").value;
    var port = document.getElementById("cabform:txtPort").value;
    
    var wip = document.getElementById("cabform:WebServerIP").value;
    var wport = document.getElementById("cabform:WebServerPort").value;
    var userTarget = document.getElementById("cabform:DbUserTarget").value;
    
    if(ip == "" ) {
        fieldValidator("cabform:txtIp", SPECIFY_APP_IP, "absolute", true);
        //alert(SPECIFY_APP_IP);
        //document.getElementById("cabform:txtIp").focus();
        return false;
    }

    if( !( isValidIPAddress( ip ) ) ){
        fieldValidator("cabform:txtIp", INVALID_WFS_IP, "absolute", true);
       // alert( INVALID_WFS_IP );
       // document.getElementById("cabform:txtIp").focus();
        return false;
    }
    if (port == "" ) {
        fieldValidator("cabform:txtPort", SPECIFY_WFS_PORT, "absolute", true);
        //alert(SPECIFY_WFS_PORT);
        //document.getElementById("cabform:txtPort").focus( );
        return false;
    }
    if( !( isValidPort( port ) )){
        fieldValidator("cabform:txtPort", INVALID_PORT_NUMBER, "absolute", true);
        //alert(INVALID_PORT_NUMBER);
        //document.getElementById("cabform:txtPort").focus( );
        return false;
    }
    document.getElementById("cabform:hidServerIp").value = ip;
    document.getElementById("cabform:hidServerPort").value = port;
    document.getElementById("cabform:hidTargetDBUser").value=userTarget;
            document.getElementById("cabform:hidWebServerIp").value=wip;
            document.getElementById("cabform:hidWebServerPort").value=wport;
    document.getElementById("cabform:hidTempOperation").value ="S";
    document.getElementById("cabform:hidTargetDBPassword").value=document.getElementById("cabform:txtPasswordTarget").value;
    if(document.getElementById("cabform:cmbcabname") != null)
        document.getElementById("cabform:cmbcabname").value="";
    
    if(bPwdEncrypt == 'Y') {
        var refHidSourceDBPassword = document.getElementById("cabform:hidSourceDBPassword");
        var refHidTargetDBPassword = document.getElementById("cabform:hidTargetDBPassword");
        var refTxtPasswordSource = document.getElementById("cabform:txtPasswordSource");
        var refTxtPasswordTarget = document.getElementById("cabform:txtPasswordTarget");
        
        var bf = new Blowfish('DES');
        var encHidSourceDBPassword = bf.encryptx(refHidSourceDBPassword.value, eToken);
        var encHidTargetDBPassword = bf.encryptx(refHidTargetDBPassword.value, eToken);
        var encTxtPasswordSource = bf.encryptx(refTxtPasswordSource.value, eToken);
        var encTxtPasswordTarget = bf.encryptx(refTxtPasswordTarget.value, eToken);
        
        refHidSourceDBPassword.value = encode_utf8(encHidSourceDBPassword);
        refHidTargetDBPassword.value = encode_utf8(encHidTargetDBPassword);
        refTxtPasswordSource.value = encode_utf8(encTxtPasswordSource);
        refTxtPasswordTarget.value = encode_utf8(encTxtPasswordTarget);
    }
    
    ClickAnotherLink(ref,toClick);
    return false;
}

function isValidPort( port ){

    if(isNaN(port) ){
        return false;
    }

    if( parseInt( port ) > 65535 ) {
        return false;
    }
    return true;
}

function isValidIPAddress(ipaddr) {
    var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
    if (re.test(ipaddr)) {
        var parts = ipaddr.split(".");
        if (parseInt(parseFloat(parts[0])) == 0) {
            return false;
        }
        for (var i=0; i<parts.length; i++) {
            if (parseInt(parseFloat(parts[i])) > 255) {
                return false;
            }
        }
        return true;
    } else {
        return false;
    }
}


function setISOption(ref , toClick) {
    var ip = Trim(document.getElementById("cabform:txtIp").value);
    var port = Trim(document.getElementById("cabform:txtPort").value);
    
    if(ip == "" || port == "")
        return;
    
    if(document.getElementById("cabform:keepSourceIS"))
    {
        if(document.getElementById("cabform:keepSourceIS").checked) {
            document.getElementById("cabform:keepSourceIS").value =true;
            document.getElementById("cabform:hidKeepSourceIS").value ="Y";
        }
        else {
            document.getElementById("cabform:keepSourceIS").value =false;
            document.getElementById("cabform:hidKeepSourceIS").value ="N";
        }
    }
    ClickAnotherLink(ref,toClick);
}

function setSiteVol(ref,toClick) {
    
    var val = document.getElementById("cabform:cmbcabname").value;
    
    document.getElementById("cabform:hidSelCabName").value = val;
    document.getElementById("cabform:hidTempOperation").value ="S";
    ClickAnotherLink(ref,toClick);
}
function siteVolCallback(){
    if(document.getElementById("cabform:RequireTarget").checked){
        document.getElementById("cabform:txtTargetUserName").disabled = false;
        document.getElementById("cabform:txtTargetUserPassword").disabled = false;
        document.getElementById("cabform:txtPasswordTarget").value=document.getElementById("cabform:hidTargetDBPassword").value;
    }
}
function setVol(ref,toClick) {
    
    var val = document.getElementById("cabform:cmbcabname").value;
    
    document.getElementById("cabform:hidSelCabName").value = val;
    document.getElementById("cabform:hidSitename").value = document.getElementById("cabform:cmbsitename").value;
    document.getElementById("cabform:hidTempOperation").value ="S";
    ClickAnotherLink(ref,toClick);
}

function setExportInfo() {

    if(document.getElementById("cabform:DbUserSource").value == "") {
        fieldValidator("cabform:DbUserSource", SPECIFY_SOURCE_DB_USERNAME, "absolute", true);
        //alert(SPECIFY_SOURCE_DB_USERNAME);
        //document.getElementById("cabform:DbUserSource").focus( );
        return false;
    }
    
    var webIp = document.getElementById("cabform:WebServerIP").value;
    var webPort = document.getElementById("cabform:WebServerPort").value;

    if(document.getElementById("cabform:DbUserTarget").value== "" &&(webIp !="" || webPort!="" || document.getElementById("cabform:txtIp").value != "" || document.getElementById("cabform:txtPort").value != "" )) {
        fieldValidator("cabform:DbUserTarget", SPECIFY_TARGET_DB_USERNAME, "absolute", true);
        //alert(SPECIFY_TARGET_DB_USERNAME);
        //document.getElementById("cabform:DbUserTarget").focus( );
        return false;
    }
    if(document.getElementById("cabform:DbUserTarget").value!=""){
        if( webIp =="" ){
            fieldValidator("cabform:WebServerIP", SPECIFY_WEB_IP, "absolute", true);
            //alert(SPECIFY_WEB_IP);
            //document.getElementById("cabform:WebServerIP").focus();
            return false;
        }

        if( !isValidIPAddress( webIp ) ){
            fieldValidator("cabform:WebServerIP", INVALID_WEB_IP, "absolute", true);
            //alert( INVALID_WEB_IP );
            //document.getElementById("cabform:WebServerIP").focus();
            return false;
        }
        if (webPort == "" ) {
            fieldValidator("cabform:WebServerPort", SPECIFY_WEB_PORT, "absolute", true);
            //alert(SPECIFY_WEB_PORT);
            //document.getElementById("cabform:WebServerPort").focus();
            return false;
        }

        if( !( isValidPort( webPort ) ) ){
            fieldValidator("cabform:WebServerPort", INVALID_PORT_NUMBER, "absolute", true);
            //alert(INVALID_PORT_NUMBER);
            //document.getElementById("cabform:WebServerPort").focus();
            return false;
        }

        if(document.getElementById("cabform:txtIp").value == "" || ( !isValidIPAddress( document.getElementById("cabform:txtIp").value ))) {
            fieldValidator("cabform:txtIp", SPECIFY_TARGET_WFSIP, "absolute", true);
            //alert(SPECIFY_TARGET_WFSIP);
            //document.getElementById("cabform:txtIp").focus( );
            return false;
        }

        if(document.getElementById("cabform:txtPort").value == "" || document.getElementById("cabform:txtPort").value > 65535 ) {
            fieldValidator("cabform:txtPort", SPECIFY_TARGET_WFSPORT, "absolute", true);
            //alert(SPECIFY_TARGET_WFSPORT);
            //document.getElementById("cabform:txtPort").focus( );
            return false;
        }
        
        if(document.getElementById("cabform:cmbcabname")){
            document.getElementById("cabform:hidSelCabName").value=document.getElementById("cabform:cmbcabname").value;
        }
        document.getElementById("cabform:hidServerIp").value=document.getElementById("cabform:txtIp").value;
        document.getElementById("cabform:hidServerPort").value=document.getElementById("cabform:txtPort").value;
    
        document.getElementById("cabform:hidTargetDBUser").value=document.getElementById("cabform:DbUserTarget").value;
        document.getElementById("cabform:hidTargetDBPassword").value=document.getElementById("cabform:txtPasswordTarget").value;
        document.getElementById("cabform:hidWebServerIp").value=document.getElementById("cabform:WebServerIP").value;
        document.getElementById("cabform:hidWebServerPort").value=document.getElementById("cabform:WebServerPort").value;
    
        if(document.getElementById("cabform:cmbsitename")!=null)
            document.getElementById("cabform:hidSitename").value=document.getElementById("cabform:cmbsitename").value;
    
        if(document.getElementById("cabform:cmbvolname")!=null)
            document.getElementById("cabform:hidVolname").value=document.getElementById("cabform:cmbvolname").value;
    
        document.getElementById("cabform:hidTempOperation").value ="";
    }
    else{
        document.getElementById("cabform:hidSourceDBUser").value=document.getElementById("cabform:DbUserSource").value;

        document.getElementById("cabform:hidSourceDBPassword").value=document.getElementById("cabform:txtPasswordSource").value;

        document.getElementById("cabform:hidSelCabName").value="";
        document.getElementById("cabform:hidServerIp").value="";
        document.getElementById("cabform:hidServerPort").value="";
        document.getElementById("cabform:hidTargetDBUser").value="";
        document.getElementById("cabform:hidTargetDBPassword").value="";
        document.getElementById("cabform:hidWebServerIp").value="";
        document.getElementById("cabform:hidWebServerPort").value="";
    }

    if(document.getElementById("cabform:txtTargetUserName").disabled == false && document.getElementById("cabform:txtTargetUserPassword").disabled == false)
    {
        if(document.getElementById("cabform:txtTargetUserName").value == "") {
            fieldValidator("cabform:txtTargetUserName", SPECIFY_USER_NAME, "absolute", true);
            //alert(SPECIFY_USER_NAME);
            //document.getElementById("cabform:txtTargetUserName").focus();
            return false;
        }

        if(document.getElementById("cabform:txtTargetUserPassword").value == "") {
            fieldValidator("cabform:txtTargetUserPassword", SPECIFY_USER_PASSWORD, "absolute", true);
            //alert(SPECIFY_USER_PASSWORD);
            //document.getElementById("cabform:txtTargetUserPassword").focus();
            return false;
        }
    }
    
    document.getElementById("cabform:hidTargetUserName").value=document.getElementById("cabform:txtTargetUserName").value;
    document.getElementById("cabform:hidTargetUserPassword").value=document.getElementById("cabform:txtTargetUserPassword").value;
    
    if(document.getElementById("cabform:hidOperation").value!="U")
        document.getElementById("cabform:hidOperation").value="I";
    
    if(document.getElementById("cabform:keepSourceIS"))
    {
        if(document.getElementById("cabform:keepSourceIS").checked)
            document.getElementById("cabform:hidKeepSourceIS").value="Y";
        else
            document.getElementById("cabform:hidKeepSourceIS").value="N"; 
    }
    
    if(bPwdEncrypt == 'Y') {
        var refHidSourceDBPassword = document.getElementById("cabform:hidSourceDBPassword");
        var refHidTargetDBPassword = document.getElementById("cabform:hidTargetDBPassword");
        var refTxtPasswordSource = document.getElementById("cabform:txtPasswordSource");
        var refTxtPasswordTarget = document.getElementById("cabform:txtPasswordTarget");
        var refHidTargetUserPassword = document.getElementById("cabform:hidTargetUserPassword");
        var refTxtTargetUserPassword = document.getElementById("cabform:txtTargetUserPassword");
        
        var bf = new Blowfish('DES');
        var encHidSourceDBPassword = bf.encryptx(refHidSourceDBPassword.value, eToken);
        var encHidTargetDBPassword = bf.encryptx(refHidTargetDBPassword.value, eToken);
        var encTxtPasswordSource = bf.encryptx(refTxtPasswordSource.value, eToken);
        var encTxtPasswordTarget = bf.encryptx(refTxtPasswordTarget.value, eToken);
        var encHidTargetUserPassword = bf.encryptx(refHidTargetUserPassword.value, eToken);
        var encTxtTargetUserPassword = bf.encryptx(refTxtTargetUserPassword.value, eToken);
        
        refHidSourceDBPassword.value = encode_utf8(encHidSourceDBPassword);
        refHidTargetDBPassword.value = encode_utf8(encHidTargetDBPassword);
        refTxtPasswordSource.value = encode_utf8(encTxtPasswordSource);
        refTxtPasswordTarget.value = encode_utf8(encTxtPasswordTarget);
        refHidTargetUserPassword.value = encode_utf8(encHidTargetUserPassword);
        refTxtTargetUserPassword.value = encode_utf8(encTxtTargetUserPassword);
    }
    
    return true;
}

function deleteExportInfo() {
    var bConfirm = confirm(CONFIRM_EXPORT_INFO_DELETE);
    if(!bConfirm)
        return false;
    if(document.getElementById("cabform:DbUserTarget").value!="" && document.getElementById("cabform:RequireTarget").checked) {
        if(Trim(document.getElementById("cabform:txtIp").value) == "") {
            fieldValidator("cabform:txtIp", SPECIFY_TARGET_WFSIP, "absolute", true);
            //alert(SPECIFY_TARGET_WFSIP);
            return false;
        }
    
        if(Trim(document.getElementById("cabform:txtIp").value) == "") {
            fieldValidator("cabform:txtIp", SPECIFY_TARGET_WFSPORT, "absolute", true);
            //alert(SPECIFY_TARGET_WFSPORT);
            return false;
        }
        if(document.getElementById("cabform:cmbcabname")!=null){
             document.getElementById("cabform:hidSelCabName").value=document.getElementById("cabform:cmbcabname").value;
        }       
        if(document.getElementById("cabform:txtTargetUserName").value == "") {
            fieldValidator("cabform:txtTargetUserName", SPECIFY_USER_NAME, "absolute", true);
            //alert(SPECIFY_USER_NAME);
            //document.getElementById("cabform:txtTargetUserName").focus();
            return false;
        }
    
        if(document.getElementById("cabform:txtTargetUserPassword").value == "") {
            fieldValidator("cabform:txtTargetUserPassword", SPECIFY_USER_PASSWORD, "absolute", true);
            //alert(SPECIFY_USER_PASSWORD);
            //document.getElementById("cabform:txtTargetUserPassword").focus();
            return false;
        }
    
        document.getElementById("cabform:hidSelCabName").value=document.getElementById("cabform:cmbcabname").value;
        document.getElementById("cabform:hidServerIp").value=document.getElementById("cabform:txtIp").value;
        document.getElementById("cabform:hidServerPort").value=document.getElementById("cabform:txtPort").value;
    
        document.getElementById("cabform:hidTargetDBUser").value=document.getElementById("cabform:DbUserTarget").value;
        document.getElementById("cabform:hidTargetDBPassword").value=document.getElementById("cabform:txtPasswordTarget").value;
        document.getElementById("cabform:hidWebServerIp").value=document.getElementById("cabform:WebServerIP").value;
        document.getElementById("cabform:hidWebServerPort").value=document.getElementById("cabform:WebServerPort").value;
    
        if(document.getElementById("cabform:hidSitename").value != "")
            document.getElementById("cabform:hidSitename").value=document.getElementById("cabform:cmbsitename").value;
    
        if(document.getElementById("cabform:hidVolname").value != "")
            document.getElementById("cabform:hidVolname").value=document.getElementById("cabform:cmbvolname").value;

    } 
    else {
    
    document.getElementById("cabform:hidSelCabName").value="";
    document.getElementById("cabform:hidServerIp").value="";
    document.getElementById("cabform:hidServerPort").value="";

    document.getElementById("cabform:hidSourceDBUser").value=document.getElementById("cabform:DbUserSource").value;
    document.getElementById("cabform:hidSourceDBPassword").value=document.getElementById("cabform:txtPasswordSource").value;
    document.getElementById("cabform:hidTargetDBUser").value="";
    document.getElementById("cabform:hidTargetDBPassword").value="";
    document.getElementById("cabform:hidWebServerIp").value="";
    document.getElementById("cabform:hidWebServerPort").value="";

    }
    
    if(document.getElementById("cabform:RequireTarget").checked){
        if(document.getElementById("cabform:txtTargetUserName").value == "") {
            fieldValidator("cabform:txtTargetUserName", SPECIFY_USER_NAME, "absolute", true);
            //alert(SPECIFY_USER_NAME);
            //document.getElementById("cabform:txtTargetUserName").focus();
            return false;
        }

        if(document.getElementById("cabform:txtTargetUserPassword").value == "") {
            fieldValidator("cabform:txtTargetUserPassword", SPECIFY_USER_PASSWORD, "absolute", true);
            //alert(SPECIFY_USER_PASSWORD);
            //document.getElementById("cabform:txtTargetUserPassword").focus();
            return false;
        }
        document.getElementById("cabform:hidTargetUserName").value=document.getElementById("cabform:txtTargetUserName").value;
        document.getElementById("cabform:hidTargetUserPassword").value=document.getElementById("cabform:txtTargetUserPassword").value;
    }
    
    if(document.getElementById("cabform:keepSourceIS"))
    {
        if(document.getElementById("cabform:keepSourceIS").checked)
            document.getElementById("cabform:hidKeepSourceIS").value="Y";
        else
            document.getElementById("cabform:hidKeepSourceIS").value="N";
    }
    document.getElementById("cabform:hidOperation").value="D";
    return true;
}


function cablist_init() {
    var thisForm = window.document.forms["textForm"];
    var txtForm = window.parent.frames["export_button"].document.forms["textForm"];
    
    if(thisForm.cabinetList.length > 0)
        txtForm.btnSave.disabled = false;
    else
        txtForm.btnSave.disabled = true;
}

function DisableRequireTargetclick(){
    
    
         document.getElementById("cabform:DbUserTarget").value="";
         document.getElementById("cabform:DbUserTarget").disabled = true;
         document.getElementById("cabform:txtPasswordTarget").value="";
         document.getElementById("cabform:txtPasswordTarget").disabled = true;
         document.getElementById("cabform:WebServerIP").disabled = true;
         document.getElementById("cabform:WebServerIP").value="";
         document.getElementById("cabform:WebServerPort").value="";
         document.getElementById("cabform:WebServerPort").disabled = true;
         document.getElementById("cabform:txtIp").value="";
         document.getElementById("cabform:txtIp").disabled = true;
         document.getElementById("cabform:txtPort").value="";
         document.getElementById("cabform:txtPort").disabled = true;
         document.getElementById("cabform:connectButton").disabled = true;
         document.getElementById("cabform:txtTargetUserName").value="";
         document.getElementById("cabform:txtTargetUserName").disabled = true;
         document.getElementById("cabform:txtTargetUserPassword").value="";
         document.getElementById("cabform:txtTargetUserPassword").disabled = true;
         
         if(document.getElementById("cabform:appServerType")) {             
            //document.getElementById("cabform:appServerType").value="";
            document.getElementById("cabform:appServerType").options.selectedIndex=0;
            document.getElementById("cabform:appServerType").disabled = true;
         }  
        
         if(document.getElementById("cabform:cmbcabname"))
         {
            document.getElementById("cabform:cmbcabname").value="";
            document.getElementById("cabform:cmbcabname").disabled = true;

            if(document.getElementById("cabform:cmbsitename"))
            {
                document.getElementById("cabform:cmbsitename").value="";
                document.getElementById("cabform:cmbsitename").disabled = true;
            }
            if(document.getElementById("cabform:cmbvolname")) {
                document.getElementById("cabform:cmbvolname").value="";
                document.getElementById("cabform:cmbvolname").disabled = true;
            }                 
        }
}

function EnableRequireTargetclick(){
    
        document.getElementById("cabform:DbUserTarget").disabled = false;
         document.getElementById("cabform:txtPasswordTarget").disabled = false;
         document.getElementById("cabform:WebServerIP").disabled = false;
         document.getElementById("cabform:WebServerPort").disabled = false;
         document.getElementById("cabform:txtIp").disabled = false;
         document.getElementById("cabform:txtPort").disabled = false;
         document.getElementById("cabform:connectButton").disabled = false;
         document.getElementById("cabform:txtTargetUserName").disabled = false;
         document.getElementById("cabform:txtTargetUserPassword").disabled = false;
        if(document.getElementById("cabform:cmbcabname"))
         document.getElementById("cabform:cmbcabname").disabled = false;
        if(document.getElementById("cabform:cmbsitename")) 
            document.getElementById("cabform:cmbsitename").disabled = false;
        if(document.getElementById("cabform:cmbvolname")) 
            document.getElementById("cabform:cmbvolname").disabled = false;
        if(document.getElementById("cabform:appServerType")) 
            document.getElementById("cabform:appServerType").disabled = false;

}

function RequireTargetclick()
{
    
    if(document.getElementById("cabform:RequireTarget").checked)
    EnableRequireTargetclick();
    else
     DisableRequireTargetclick();
        
}

function onConnect(data){
    if(data.status == "success"){
        RequireTargetclick();
        if(document.getElementById("cabform:RequireTarget").checked){
            document.getElementById("cabform:txtPasswordTarget").value=document.getElementById("cabform:hidTargetDBPassword").value;
    }
    }
}

function onDeleteHandler(data){
    if(data.status == "success"){
        RequireTargetclick();
    }
}