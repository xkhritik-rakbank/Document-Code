


function htmlFormOk(customformwindow,prefix){
        var finalStatus = true;
	var validationStatus='false';
        var sDateFormat=wiproperty.sDateFormat;
        var formWindow="";
        var targetForm="";
        if(customformwindow)
            formWindow=customformwindow;
         else {
            if(windowProperty.winloc=="N")
                formWindow=getWindowHandler(window.opener.windowList,"formGrid");
            else
		formWindow=getWindowHandler(windowList,"formGrid");
        } 
        var inputObj=ngattribute;

        var queueVar_array=inputObj.split(SEPERATOR1);
        for(var i=0;i<queueVar_array.length;i++){
         var formEleInfo_array=queueVar_array[i].split(SEPERATOR2);
         var fieldName=formEleInfo_array[0];
         var fieldType='';
         var fieldLength=''; 
         if(wiproperty.formType=="NGFORM")
         {
                fieldType=formEleInfo_array[3];
                fieldLength=formEleInfo_array[2];
         }
         else{
                fieldType=formEleInfo_array[2];
                fieldLength=formEleInfo_array[1]; 
         }
        var field;  //added for Variant : 17 Oct 13
        var strPrefix;
        if(prefix)
            strPrefix = prefix;
        else
            strPrefix = "wdesk"
        field=formWindow.document.getElementById(strPrefix+":"+fieldName);
        var mandatory = "N";
        var length = "";
        if(typeof variantMode!="undefined" && variantMode=='Y' && formWindow.document.getElementById(strPrefix+":"+fieldName+"-length")!=null && formWindow.document.getElementById(strPrefix+":"+fieldName+"-length")!=''){
            length = formWindow.document.getElementById(strPrefix+":"+fieldName+"-length").value;
        }//till here added for Variant : 17 Oct 13
         if(typeof field != 'undefined' && field) {
            inputObjectValue=Trim(field.value);
            switch (parseInt(fieldType)){
			case NG_VAR_INT:
                            validationStatus = isInteger(inputObjectValue);
                             break;
                        case NG_VAR_LONG :
                            validationStatus = isLong(inputObjectValue);
                            break;
                        case NG_VAR_FLOAT:
                            validationStatus = isFloat(inputObjectValue);
                            break;
			case NG_VAR_DATE:
                            if (inputObjectValue != "")
				{
					validationStatus = ValidateDateFormatMsg(inputObjectValue,sDateFormat);
                                        if (validationStatus == 1)
					{
						validationStatus = "false";
						
					}
                                        else{
                                            //validationStatus=INVALID_FORMAT1;
                                            validationStatus=validationStatus;
                                            }    
				}
				else
					validationStatus = "false";
                            break;
                        case NG_VAR_SHORTDATE:
                            if (inputObjectValue != "")
				{
					validationStatus = ValidateShortDateFormat(inputObjectValue,sDateFormat); 
					if (validationStatus == 1)
						validationStatus = "false";
                                        else
                                            validationStatus=INVALID_SHORT_DATE;
				}
				else
					validationStatus = "false";
                            break;
                        case NG_VAR_TIME:
                            if (inputObjectValue != "")
                            {
                                    validationStatus = ValidateTimeFormat(inputObjectValue); 
                                    if (validationStatus == 1)
                                        validationStatus = "false";
                                    else
                                        validationStatus = INVALID_TIME_FORMAT;                                        
                            }
                            else
                                    validationStatus = "false";
                            break;
                        case NG_VAR_DURATION:
                            if (inputObjectValue != "")
                            {
                                    validationStatus = validateDurationFormat(inputObjectValue); 
                                    if (validationStatus == 1)
                                            validationStatus = "false";
                                    else
                                        validationStatus = INVALID_DURATION_FORMAT;
                            }
                            else
                                    validationStatus = "false";
                            break;
                        case NG_VAR_BOOLEAN:
                                validationStatus = "false";
                              break;
                        case NG_VAR_STRING :
                            validationStatus = isString(inputObjectValue,fieldLength);
                            break;
                      }
                
                var precision;
                if(validationStatus=="false" && length!="undefined" && length!=""){
                    validationStatus = checkFieldLength(fieldType, length, inputObjectValue);
                    if(validationStatus=="false" && fieldType==NG_VAR_FLOAT){
                        if(formWindow.document.getElementById(strPrefix+":"+fieldName+"-precision")){
                            precision = formWindow.document.getElementById(strPrefix+":"+fieldName+"-precision").value;
                            validationStatus = checkPrecision(inputObjectValue,precision);
                        }
                    }
                }
		if (validationStatus == "false")
		{
					
		}
		else
		{
                    validationStatus += LABEL_FORM_FIELD+fieldName;
                    field.select();
                    finalStatus="false";
                    break;
		}
            }  
          }
    return validationStatus;
}

function validateMandatoryFields(customformwindow,prefix){
    var mandatory = "N";
    var formWindow;
    var validationStatus='false';
    if(customformwindow)
        formWindow=customformwindow;
    else {
        if(windowProperty.winloc=="N")
            formWindow=getWindowHandler(window.opener.windowList,"formGrid");
        else
            formWindow=getWindowHandler(windowList,"formGrid");
    } 
    var strPrefix;
    if(prefix)
        strPrefix = prefix;
    else
        strPrefix = "wdesk";
    var inputObj=ngattribute;

    var queueVar_array=inputObj.split(SEPERATOR1);
    for(var i=0;i<queueVar_array.length;i++){
        var formEleInfo_array=queueVar_array[i].split(SEPERATOR2);
        var fieldName=formEleInfo_array[0];
        var field=formWindow.document.getElementById(strPrefix+":"+fieldName);
        if(typeof variantMode!= "undefined" && variantMode=='Y' && formWindow.document.getElementById(strPrefix+":"+fieldName+"-mandatory")!=null && formWindow.document.getElementById(strPrefix+":"+fieldName+"-mandatory")!=''){
            mandatory = formWindow.document.getElementById(strPrefix+":"+fieldName+"-mandatory").value;
        }//till here added for Variant : 17 Oct 13
        if(typeof field != 'undefined' && field) {
            inputObjectValue=Trim(field.value);
            if(mandatory=='Y'){//added for Variant : 17 Oct 13
                var val = inputObjectValue;
                if(val.length == 0)
                    validationStatus = INVALID_MANDATORY_VALUE;
            } 
            if (validationStatus == "false")
            {
					
            }
            else
            {
                var realName = fieldName;
                
                var indexFrom = fieldName.lastIndexOf('-');                
                if(indexFrom > -1){
                    realName = fieldName.substring(indexFrom+1);
                }
                
                validationStatus += LABEL_FORM_FIELD+realName;
                field.select();
                break;
                    
            }
        }
    }
    return validationStatus;
}

function checkFieldLength(fieldType,length,field){//added for Variant
    var fieldLength = field.length;
    if(fieldType==NG_VAR_FLOAT && field.indexOf(".")!=-1){
        fieldLength = fieldLength - 1;
    }
    if(fieldLength>length){
        return (INVALID_STRING_LENGTH);
    }
    return "false";
}
function checkPrecision(s,precision){//added for Variant
    var decimalPointDelimiter = "."
    var i=0;
    var s1;
    for (; i < s.length; i++)
    {
        var c = s.charAt(i);
        if ((c == decimalPointDelimiter)) 
        {
            s=s.toString(); 
            s1=s.substr(i+1, s.length)
            if(s1.length>precision){
                return INVALID_PRECISION_LENGTH;
            }
        }
        else if (!isDigit(c)) 
            return INVALID_FLOAT_NUMBER;
    }
    return "false";  
}
function htmlFormSaveClose(source){
if(source.name=='B1'){
window.opener.for_save('dummysave');
window.close();
}
else{
window.close();    
}

} 