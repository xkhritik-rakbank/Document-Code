


var gPopupMask;
var WD_SID;
function initPopUp() {
    if(gPopupMask == null) {
        // Add the HTML to the body
        theBody = document.getElementsByTagName('BODY')[0];
        popmask = document.createElement('div');
        popmask.id = 'popupMask';
        theBody.appendChild(popmask);
        gPopupMask = document.getElementById("popupMask");
        gPopupMask.style.display = "none";
        gPopupMask.style.position = "absolute";
        gPopupMask.style.zIndex = "200";
        gPopupMask.style.top = "0px";
        gPopupMask.style.left = "0px";
        gPopupMask.style.width = "100%";
        gPopupMask.style.height = "100%";
        gPopupMask.style.opacity = "0.4";
        gPopupMask.style.filter = "alpha(opacity=40)";
        gPopupMask.style.backgroundColor = "#d8dce0";
        
         gPopupMask.onmouseup = function (event){
            event.stopPropagation();
            event.preventDefault();
            return false;
        }
    }
}

function hidePopupMask()
{
    if(gPopupMask != null) {
        gPopupMask.style.display = "none";        
    }
}

function setPopupMask()
{
    if(gPopupMask ==null)
    {
        initPopUp(); 
    }
    if(gPopupMask !=null) {
        gPopupMask.style.display = "block";
        gPopupMask.style.height = window.document.documentElement.scrollHeight + "px";
        gPopupMask.style.width = document.documentElement.clientWidth + "px";
    }
}

var readyStateProbeTimeSequence = [250, 1000, 2000, 4000];
var READY_STATE_PROBE_INTERVAL = 5;
function readyStateChecker(iframeId, counter, switchInterval, callerIFrameWinRef) {
    var iframeDocumentRef = null;
    var isFirefox = (navigator.appName.indexOf('Netscape') > -1);

    try {        
        iframeDocumentRef = document.getElementById(iframeId).contentWindow.document;
        if(iframeDocumentRef != null) {
            if(iframeDocumentRef.body != null){
                if(isFirefox || (iframeDocumentRef.body.readyState == "complete")){
                    // Stores window object reference in a global variable of child window.
                    document.getElementById(iframeId).contentWindow.parentWindowRef = callerIFrameWinRef;
                    document.getElementById(iframeId).contentWindow.rootWindowRef = this;

                    // Bug Id: 28800
                    document.getElementById(iframeId).contentWindow.name = iframeId;
                    return;
                }
            }
        }

        if(counter>switchInterval){            
            switchInterval += READY_STATE_PROBE_INTERVAL;            
        }
        counter++;

        if(counter <= (readyStateProbeTimeSequence.length*READY_STATE_PROBE_INTERVAL)) {           
            setTimeout(function (){readyStateChecker(iframeId, counter, switchInterval, callerIFrameWinRef);}, readyStateProbeTimeSequence[switchInterval/READY_STATE_PROBE_INTERVAL-1]);
        }
    } catch(ex) {}
}

function popupIFrameOpenerWrapper(callerIFrameWinRef, id, url, width, height, left, top, isHeader, isMoveLink, isCloseLink, isModal, isCenter, display,ischeck, skipHeader) {
 
    var trui= getActionUrlFromURL(url);
    var servletUrl = "/webdesktop/secuidsv";
    (typeof WD_SID != 'undefined' && WD_SID != null) && (servletUrl += "?WD_SID=" + WD_SID);
            
    var xhReq = createXMLHttpRequest();
    //createIndicator(indicatorid);
    xhReq.open("POST", servletUrl, true);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhReq.onreadystatechange = onResponse;
    var params = servletUrl.substring("?");
    xhReq.send("T-URI="+trui);
   // xhReq.send();
    
    function onResponse() {        
        try {
            
            var wd_rid;
            
            if (xhReq.readyState==4) { 
                if (xhReq.status==200) {

                   wd_rid =  xhReq.getResponseHeader("WD_RID");
                   
                   popupIFrameOpener(callerIFrameWinRef, id, url+"&WD_RID="+wd_rid, width, height, left, top, isHeader, isMoveLink, isCloseLink, isModal, isCenter, display,ischeck, skipHeader)
                } 
            }
            
        } catch(e) {
            alert(ERROR_FETCHING_DATA);
        }
    }
       
}

function popupIFrameOpener(callerIFrameWinRef, id, url, width, height, left, top, isHeader, isMoveLink, isCloseLink, isModal, isCenter, display,ischeck, skipHeader) {
    skipHeader = (typeof skipHeader == 'undefined')? false: skipHeader;
    var isChrome = window.chrome; 
    
    if(isCenter!=null && isCenter!=undefined && isCenter){       
        if(typeof isChrome != 'undefined') {
            left=(window.screen.availWidth -width)/2 + window.document.body.scrollLeft;
            top=(window.screen.availHeight -height)/2 + window.document.body.scrollTop-40;
//            alert(left)
        }
        else{        
            left = (window.screen.width - width)/2 + window.document.documentElement.scrollLeft;
            top = (document.documentElement.clientHeight - height)/2 + window.document.documentElement.scrollTop;
            
        }
    } else {
        left -= width;
        if(ischeck){   //added by amar
            //alert("true");
        } else if((top+height+25)>document.documentElement.clientHeight){
            if((top-height) > -1){
                top -= height;
                //if top is less than Height
                if(top<0){
                    top = -top;
                }
            } else {
                top -= (top+height+25) - document.documentElement.clientHeight;
            }
        } else {
            if(!skipHeader){
                top += 25;
            }
        }

        if(left<0){
            left += width;
        }
    }
 
    try {
        var finalWindow = window;
        if(finalWindow.document.getElementById("popupIFrame_"+id) != null)
            return;

        if(isModal) {
            initPopUp();
            setPopupMask();
        }
        var iframe = finalWindow.document.createElement("IFRAME");
        // Creates IFRAME
        
        if(url.indexOf("?") == -1){
            url = url+"?WD_SID="+WD_SID;
        } else{
            url = url+"&WD_SID="+WD_SID;
        }
        
        /*
        
        if(typeof display != 'undefined' && !display){
            iframe.style.diplay = "none";
        }
        */
        
        iframe.style.zIndex = "1001";
        iframe.setAttribute("src", url);
        iframe.setAttribute("name", "popupIFrame_"+id);
        iframe.setAttribute("id", "popupIFrame_"+id);
        iframe.frameBorder="0";
        iframe.style.frameBorder="0";
        iframe.scrolling="no";
        iframe.style.scrolling="no";
        iframe.style.visibility="visible";
        iframe.style.position="absolute";

        iframe.style.width= width+"px";
        iframe.style.height = height+"px";
        iframe.style.left = left+"px";
        iframe.style.top = top+"px";
        iframe.className = "iframeShadow ";
        //iframe.style.width= "100%";
        //iframe.style.height = (height) + "px";
        iframe.style.backgroundColor = "white";
        //iframe.style.border = "1px solid green";
        //containerDiv.appendChild(iframe);        
        finalWindow.document.body.appendChild(iframe);

        //createMoveAction(containerDiv.id, width, isMoveLink);
        //createCloseAction(containerDiv.id, isCloseLink);

        setTimeout(function (){readyStateChecker("popupIFrame_"+id, 1, READY_STATE_PROBE_INTERVAL, callerIFrameWinRef);}, readyStateProbeTimeSequence[0]);
        
        document.getElementById("popupIFrame_"+id).contentWindow.parentWindowRef = callerIFrameWinRef;
        document.getElementById("popupIFrame_"+id).contentWindow.rootWindowRef = this;
    } catch(ex){}
}

function popupIFrameLoader(containerDivId, isCloseLink, url){    
    //createCloseAction(containerDivId, isCloseLink);
    document.getElementById("popupIFrame_"+containerDivId).src = url;    
}

function createCloseAction(containerDivId, isCloseLink){
    if(isCloseLink){
        // Creates ANCHOR
        var closeLink = document.createElement("A");
        closeLink.appendChild(document.createTextNode("Close"));
        closeLink.style.zIndex = "201";
        closeLink.style.visibility="visible";
        closeLink.style.position="absolute";
        closeLink.style.left = (parseInt(document.getElementById(containerDivId).style.width.split('p')[0])-36)+"px";
        closeLink.style.top = (parseInt(document.getElementById(containerDivId).style.height.split('p')[0]))+"px";

        closeLink.style.color = "#eeeeee";
        closeLink.style.backgroundColor = "#999999";
        closeLink.style.fontFamily = "arial,sans-serif";
        closeLink.style.fontSize = "10px";
        closeLink.style.fontWeight = "bold";

        closeLink.style.paddingLeft = "4px";
        closeLink.style.paddingRight = "4px";
        closeLink.style.paddingBottom = "2px";

        closeLink.style.cursor="pointer";
        closeLink.onmouseover = function (){
            closeLink.style.color = "#999999";
            closeLink.style.backgroundColor = "#eeeeee";
        }
        closeLink.onmouseout = function (){
            closeLink.style.color = "#eeeeee";
            closeLink.style.backgroundColor = "#999999";
        }
        closeLink.onclick = function (){
            removeIFramePopup(containerDivId);
        }

        document.getElementById(containerDivId).appendChild(closeLink);
    }
}

var containerHeaderHeight = 23;
function createMoveAction(containerDivId, width, isMoveLink){
    if(isMoveLink){
        // Creates ANCHOR
        var moveLink = document.createElement("DIV");
        moveLink.appendChild(document.createTextNode("Move"));
        moveLink.style.zIndex = "201";
        moveLink.style.visibility="visible";
        moveLink.style.position="absolute";
        moveLink.style.left = "0px";
        moveLink.style.top = "0px";
        moveLink.style.width = width/2 + "px";
        moveLink.style.height = 23 + "px";
        moveLink.style.backgroundColor = "gray";
        moveLink.style.opacity = "0";
        moveLink.style.filter = "alpha(opacity=0)";
        
        moveLink.onmousedown = function (event){
            event = (event != undefined)? event: window.event;            
            onMouseDownHandler(event, containerDivId);
        }

        moveLink.onmouseover = function (){          
            moveLink.style.cursor='move';
        }
        moveLink.onmouseout = function (){           
            moveLink.style.cursor='default';
        }        

        document.getElementById(containerDivId).appendChild(moveLink);
    }
}

function removeIFramePopup(id, bHideMasking)
{
    try {        
        window.document.body.removeChild(window.document.getElementById("popupIFrame_"+id));
        
        bHideMasking = (typeof bHideMasking == 'undefined')? true: bHideMasking;
        if(bHideMasking){
            hidePopupMask(); 
        }
    } catch(ex){ }
}

function getPopupIFrameOpenerObj(id){
    var obj = null;
    
    try {        
        obj = window.document.getElementById("popupIFrame_"+id);        
    } catch(ex){ }
    
    return obj;
}

function onMouseUpHandler(){
    mouseEvent = 'up';    
    document.body.onmouseup = prevBodyOnMouseUp;
    document.body.onmousemove = prevBodyOnMouseMove;    
}

function onMouseMoveHandler(event, popupDivId){
    if(mouseEvent == 'down') {
        var pos = DIF_getEventPosition(event);
        newX = pos.x;
        newY = pos.y;
        document.getElementById(popupDivId).style.left = parseInt(document.getElementById(popupDivId).style.left.split('p')[0]) + (newX - currentMousePosX) + "px";
        document.getElementById(popupDivId).style.top = parseInt(document.getElementById(popupDivId).style.top.split('p')[0]) + (newY - currentMousePosY) + "px";
        currentMousePosX = newX;
        currentMousePosY = newY;
    }
}

function onMouseDownHandler(event, popupDivId){
    mouseEvent='down';    
    prevBodyOnMouseUp = document.body.onmouseup;
    prevBodyOnMouseMove = document.body.onmousemove;

    currentMousePosX = event.clientX;
    currentMousePosY = event.clientY + window.document.documentElement.scrollTop;
    
    document.body.onmouseup = function (){
        onMouseUpHandler();
    }
    document.body.onmousemove = function (event){
        onMouseMoveHandler(event, popupDivId);
    }
}

function onMouseOverHandler(event, popupDivId){
    document.getElementById(popupDivId).style.cursor='move';
}

function onMouseOutHandler(event, popupDivId){
    document.getElementById(popupDivId).style.cursor='default';
}