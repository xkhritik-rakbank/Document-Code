var dPanelXML="<WDeskPanels><Left Overlay='Y'><Interface Type='Info'/><Interface Type='ToDoList'/></Left><Right Overlay='Y'><Interface Type='Documents'/><Interface Type='Exceptions'/></Right></WDeskPanels>";
var dPanelWithTaskXML="<WDeskPanels><Left Overlay='Y'><Interface Type='Tasks'/><Interface Type='ToDoList'/><Interface Type='Info'/><Interface Type='Progress'/></Left><Right Overlay='Y'><Interface Type='Documents'/><Interface Type='Exceptions'/></Right></WDeskPanels>";


var gPopupMask;
function initPopUp() {
    if(gPopupMask == null) {
        // Add the HTML to the body
        
        theBody = document.getElementsByTagName('BODY')[0];
        popmask = document.createElement('div');
        popmask.id = 'popupMask';
        theBody.appendChild(popmask);
        gPopupMask = document.getElementById("popupMask");
        gPopupMask.style.display = "none";
        gPopupMask.style.position = "absolute";
        gPopupMask.style.zIndex = "1000";
        gPopupMask.style.top = "0px";
        gPopupMask.style.left = "0px";
        gPopupMask.style.width = "100%";
        gPopupMask.style.height = "100%";
        gPopupMask.style.opacity = "0.4";
        gPopupMask.style.filter = "alpha(opacity=40)";
        gPopupMask.style.backgroundColor = "#d8dce0";
         gPopupMask.onmouseup = function (event){
            event.stopPropagation();
            event.preventDefault();
            return false;
        }
    }
}

function showPopupMask()
{
    if(gPopupMask != null) {
        gPopupMask.style.display = "block";
        gPopupMask.style.height = window.document.documentElement.clientHeight + document.documentElement.scrollTop + "px";        
        gPopupMask.style.width = document.documentElement.clientWidth + document.documentElement.scrollLeft + "px";
    }
}

function hidePopupMask()
{
    if(gPopupMask != null) {
        gPopupMask.style.display = "none";        
    }
}


var mouseStatus;
var lastPosX;
var lastPosY;
var lastResizePosX;
var lastResizePosY;
var srcElementId;
var moveDir = "";
var isDragMode = false;
var MOVE_STEP = 1;
function setPositionForDrag(e, contDivId){                
    var curEvent = (typeof event == 'undefined'? e: event);       
    lastPosX = curEvent.clientX + document.documentElement.scrollLeft;    
    lastPosY = curEvent.clientY + document.documentElement.scrollTop;
    lastResizePosX = lastPosX;
    lastResizePosY = lastPosY;   

    srcElementId = contDivId;
    var ref = document.getElementById(srcElementId);    
    repositionMoveDiv(ref);    

    isDragMode = true;    
    mouseStatus='down';
    showPopupMask();
}

function setPosition(e, contDivId, direction){
    var curEvent = (typeof event == 'undefined'? e: event);        
    lastPosX = curEvent.clientX + document.documentElement.scrollLeft;    
    lastPosY = curEvent.clientY + document.documentElement.scrollTop;   
    lastResizePosX = lastPosX;
    lastResizePosY = lastPosY;         

    srcElementId = contDivId;
    var ref = document.getElementById(srcElementId);
    repositionMoveDiv(ref);    

    moveDir = direction;
    mouseStatus = 'down';
    showPopupMask();
}

 function getPosition(e){    
    if(mouseStatus == 'down'){
        var ref = document.getElementById(srcElementId);   

        if(isDragMode){            
            ref.style.top = parseInt(ref.style.top.split('p')[0]) + (lastResizePosY - lastPosY) + "px";
            ref.style.left = parseInt(ref.style.left.split('p')[0]) + (lastResizePosX - lastPosX) + "px";            
        } else {
             var newWidth = 0;
             var newHeight = 0;
            if(moveDir == "both") {
                newWidth = parseInt(ref.style.width.split('p')[0]) + (lastResizePosX - lastPosX);
                newHeight = parseInt(ref.style.height.split('p')[0]) + (lastResizePosY - lastPosY);

                ref.style.width = newWidth + "px";
                ref.style.height = newHeight + "px";
            } else if(moveDir == "ver") {        

                newWidth = parseInt(ref.style.width.split('p')[0]) + (lastResizePosX - lastPosX);
                ref.style.width = newWidth + "px";
            } else if(moveDir == "hor") {
                newHeight = parseInt(ref.style.height.split('p')[0]) + (lastResizePosY - lastPosY);
                ref.style.height = newHeight + "px";
            }
        }        
        
        if(interfaceMap.get(srcElementId).value != null){
            setIntPosition(interfaceMap.get(srcElementId).value, ref); 
        }
        ref = document.getElementById("moveDiv");
        ref.style.display = "none";                        
    }    

    isDragMode = false;
    mouseStatus = 'up';
    moveDir = "";   
    var listRef = document.getElementById('availInterfaces');
    if (hasCSS(listRef, 'dn')) {
       hidePopupMask(); 
    }    
}

var CONT_WIDTH_LIMIT = 150;
var CONT_HEIGHT_LIMIT = 25;
var HORIZONTAL_LIMIT_MARGIN = 2;
var VERTICAL_LIMIT_MARGIN = 0;
function onMouseMove(e){    
    if(mouseStatus == 'down'){
        var curEvent = (typeof event == 'undefined'? e: event);
        var pos = DIF_getEventPosition(curEvent);

        var movePixX = (pos.x - lastResizePosX)/MOVE_STEP;
        var movePixY = (pos.y - lastResizePosY)/MOVE_STEP;

        movePixX = parseInt(movePixX)*MOVE_STEP;
        movePixY = parseInt(movePixY)*MOVE_STEP;

        if(movePixX != 0 || movePixY != 0){         
            var ref = document.getElementById("moveDiv");   
            var srcElementRef = document.getElementById(srcElementId);   
            var isTopLimit = false; 
            var isLeftLimit = false; 
            var isRightLimit = false; 
            var isBottomLimit = false; 
            var contDivRef = document.getElementById("containerDiv");                   
            
            if(isDragMode){                
                var posX = parseInt(ref.style.left.split('p')[0]) + movePixX;                
                var posY = parseInt(ref.style.top.split('p')[0]) + movePixY;                                

                if(posX >= (contDivRef.offsetLeft+HORIZONTAL_LIMIT_MARGIN)) {
                    isLeftLimit = false;
                } else {
                    isLeftLimit = true;
                }
                
                if((posX + ref.clientWidth) <= (contDivRef.offsetLeft+contDivRef.clientWidth-HORIZONTAL_LIMIT_MARGIN)) {                    
                    isRightLimit = false;
                } else {
                    isRightLimit = true;
                }
                
                if(!isLeftLimit && !isRightLimit){
                    ref.style.left = posX + "px";                
                }

                if(posY >= (contDivRef.offsetTop+VERTICAL_LIMIT_MARGIN)) {                    
                    isTopLimit = false;
                } else {
                    isTopLimit = true;
                }
                
                if((posY + ref.clientHeight) <= (contDivRef.offsetTop+contDivRef.clientHeight-VERTICAL_LIMIT_MARGIN)) {                    
                    isBottomLimit = false;
                } else {
                    isBottomLimit = true;
                }
                
                if(!isTopLimit && !isBottomLimit){
                    ref.style.top = posY + "px";                
                }
            } else {
                var height = parseInt(ref.style.height.split('p')[0]);
                var width = parseInt(ref.style.width.split('p')[0]);
                var srcElemenetTop = parseInt(srcElementRef.style.top.split('p')[0]);
                var srcElemenetLeft = parseInt(srcElementRef.style.left.split('p')[0]);
                
                if(moveDir == "both") {     
                    if(((srcElemenetLeft + width + movePixX) > (srcElemenetLeft + CONT_WIDTH_LIMIT)) && ((srcElemenetLeft + width + movePixX) < (contDivRef.offsetLeft+contDivRef.clientWidth-HORIZONTAL_LIMIT_MARGIN))){                        
                        isLeftLimit = false;
                    } else {
                        isLeftLimit = true;
                    } 
                    
                    if(!isLeftLimit){
                        ref.style.width = width + movePixX + "px";
                    }
                    
                    if(((srcElemenetTop + height + movePixY) > (srcElemenetTop + CONT_HEIGHT_LIMIT)) && ((srcElemenetTop + height + movePixY) < (contDivRef.offsetTop+contDivRef.clientHeight-VERTICAL_LIMIT_MARGIN+1))){                        
                        isTopLimit = false;
                    } else {
                        isTopLimit = true;
                    }
                    
                    if(!isTopLimit){
                        ref.style.height = height + movePixY + "px";
                    }
                } else if(moveDir == "ver") { 
                    if(((srcElemenetLeft + width + movePixX) > (srcElemenetLeft + CONT_WIDTH_LIMIT)) && ((srcElemenetLeft + width + movePixX) < (contDivRef.offsetLeft+contDivRef.clientWidth-HORIZONTAL_LIMIT_MARGIN))){
                        isLeftLimit = false;
                    } else {
                        isLeftLimit = true;
                    }
                    
                    if(!isLeftLimit){
                        ref.style.width = width + movePixX + "px";
                    }
                } else if(moveDir == "hor") {                     
                    if(((srcElemenetTop + height + movePixY) > (srcElemenetTop + CONT_HEIGHT_LIMIT)) && ((srcElemenetTop + height + movePixY) < (contDivRef.offsetTop+contDivRef.clientHeight-VERTICAL_LIMIT_MARGIN))){
                        isTopLimit = false;
                    } else {
                        isTopLimit = true;
                    }
                    
                    if(!isTopLimit){
                        ref.style.height = height + movePixY + "px";  
                    }
                }
            }

            if(!isLeftLimit && !isRightLimit){
                lastResizePosX += movePixX;
            }            
            if(!isTopLimit && !isBottomLimit){
                lastResizePosY += movePixY;
            }
        }
    }
}

function onFixedIntListClick(event, selectedContainer,pageDir){//Bug 75493
    var srcElement = (event != undefined)? event.target: window.event.srcElement;
    showFixedInterfaceList(srcElement.id.split('_')[1], selectedContainer,pageDir);//Bug 75493
}          

function renderLayout(){    
    if((wDeskLayoutJason != undefined) && (wDeskLayoutJason != null) && (wDeskLayoutJason != "")){        
        for(var i=0; i<wDeskLayoutJason.WDeskEditableLayout.Interfaces.length; i++){
            addContainer(wDeskLayoutJason.WDeskEditableLayout.WdeskFlag);
            interfaceMap.put("div_C"+(i+1), wDeskLayoutJason.WDeskEditableLayout.Interfaces[i].Interface);
        }
    }
}

function renderResponsiveLayout(){
    if((wDeskLayoutJason != undefined) && (wDeskLayoutJason != null) && (wDeskLayoutJason != "")){
        for(var i=0; i<wDeskLayoutJason.WDeskResponsiveLayout.Interfaces.length; i++){
            interfaceRespMap.put("div_RC"+(i+1), wDeskLayoutJason.WDeskResponsiveLayout.Interfaces[i].Interface);
            if(wDeskLayoutJason.WDeskResponsiveLayout.Interfaces[i].Interface.Type=="Document"){
                if(wDeskLayoutJason.WDeskResponsiveLayout.Interfaces[i].Interface.MultiPane){
                    multipane='Y';
                }
            }
        }
    }              
        var layout=document.getElementById("layoutData");
        initViewTable('tableWrap','mergeBtn',2,layout);
        defaultPanelOption(); 
}

//function initViewTable(tableContainerId, mergeButtonId, colMapping, viewTableStruct, opr){ 
//    opr = (typeof opr == 'undefined')? '': opr;
//    if(viewTableStruct != null && viewTableStruct.value != ''){
//        updateViewTable(tableContainerId, mergeButtonId, viewTableStruct.value, opr);
//    } else {        
//        var rows=document.getElementById(tableContainerId+'Rows').value-0;
//        renderTable(tableContainerId, mergeButtonId, rows, colMapping);   
//    }
//    
//    var viewTableObj = document.getElementById(tableContainerId).getElementsByTagName('table')[0]
//    addCSS(viewTableObj, "cursorCell");
//}

function stopEventPropagation(e) {
    e = e || window.event;
    if (e.preventDefault) {
        e.preventDefault();
    } else if (e.stopPropagation) {
        e.stopPropagation();
    } else {
        window.event.cancelBubble=true;
    }
}

var iMaxContainerNo = 0;
var INT_HEIGHT = 120;
var INT_WIDTH = 210;
function addContainer(wdeskFlag){
    iMaxContainerNo=iMaxContainerNo + 1;
    var containerid=iMaxContainerNo;    

    var contDivRef = document.getElementById("containerDiv");       
    var contDivLeft = findPosX(contDivRef);
    var contDivTop = findPosY(contDivRef);
    
    // Main interface container
    var ref = window.document.createElement("div");   
    ref.setAttribute("id", "div_C"+containerid);
    ref.className = "interface";
    ref.style.overflow= 'hidden';
    ref.style.position="absolute";  
    if((wdeskFlag != undefined) && (wdeskFlag != null) && (wdeskFlag == "U")){
        var screenWidth = "";
        var screenHeight = "";
        if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
            //IE 6+ in 'standards compliant mode'        
            screenWidth = document.documentElement.clientWidth;
            screenHeight = document.documentElement.clientHeight;
        } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {        
            //IE 4 compatible
            screenWidth = document.body.clientWidth;
            screenHeight = document.body.clientHeight;
        }
        
        if(wDeskLayoutJason.WDeskEditableLayout.IsDefaultLayout == "true"){
            wDeskLayoutJason.WDeskEditableLayout.ScreenWidth = screenWidth;
            wDeskLayoutJason.WDeskEditableLayout.ScreenHeight = screenHeight;
            if(wDeskLayoutJason.WDeskEditableLayout.IsTask == "false"){
                if(iMaxContainerNo == 1){
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Left = 0;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Top = 0;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Width = screenWidth/2 - 6;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Height = screenHeight - 35;
                } else if(iMaxContainerNo == 2){
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Left = screenWidth/2 + 4;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Top = 0;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Width = screenWidth/2 - 8;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Height = screenHeight - 35;
                }             
            }else{
                if(iMaxContainerNo == 1){
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Left = screenWidth/3 + 8;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Top = 0;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Width = (screenWidth/3 * 2) - 25;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Height = (screenHeight - 50)/2;
                } else if(iMaxContainerNo == 2){
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Left = screenWidth/3 + 8;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Top = ((screenHeight - 35)/2) + 3;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Width = (screenWidth/3 * 2) - 25;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Height = (screenHeight - 50)/2;
                } else if(iMaxContainerNo == 3){
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Left = 0;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Top = ((screenHeight - 35)/2) + 3;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Width = screenWidth/3;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Height = (screenHeight - 50)/2;
                } else if(iMaxContainerNo == 4){
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Left = 0;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Top = 0;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Width = screenWidth/3;
                    wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Height = (screenHeight - 50)/2;
                }
            }
        }
        
        ref.style.left = contDivLeft + (((wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Left)*screenWidth)/wDeskLayoutJason.WDeskEditableLayout.ScreenWidth) + "px";
        ref.style.top = contDivTop + (((wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Top)*screenHeight)/wDeskLayoutJason.WDeskEditableLayout.ScreenHeight) + "px";
        ref.style.width = (wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Width*screenWidth)/wDeskLayoutJason.WDeskEditableLayout.ScreenWidth + "px";
        ref.style.height = (wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Height*screenHeight)/wDeskLayoutJason.WDeskEditableLayout.ScreenHeight + "px";
        setIntPosition(wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface, ref);
        
        /*ref.style.top = layoutJason.Interfaces[containerid-1].Interface.Top + "px";
        ref.style.left = layoutJason.Interfaces[containerid-1].Interface.Left + "px";
        ref.style.width = layoutJason.Interfaces[containerid-1].Interface.Width + "px";
        ref.style.height = layoutJason.Interfaces[containerid-1].Interface.Height + "px";*/
    } else {
        ref.style.top = contDivTop + "px";
        ref.style.left = contDivLeft + "px";
        ref.style.width = INT_WIDTH + "px";
        ref.style.height = INT_HEIGHT + "px";     
    }
    ref.style.textAlign = 'right';    
    contDivRef.appendChild(ref);    
    
    // Header interface container
    var headerref = window.document.createElement("div");  
    headerref.setAttribute("id", "headerDiv_C"+containerid);
    //headerref.className = "wdheaderclass1";    
    headerref.style.overflow= 'hidden';
    headerref.style.position="absolute";  
    headerref.style.textAlign = 'left';    
    headerref.style.top = "0px";
    headerref.style.left = "0px";
    headerref.style.width = "100%";    
    headerref.style.height = 19 + "px";
    headerref.style.paddingLeft = "5px";
    headerref.style.paddingTop = "3px";
    headerref.style.borderBottom = "1px solid #dddddd";
    
    headerref.onmouseover = function (event){
        var srcElement = (event != undefined)? event.target: window.event.srcElement;
        srcElement.className = 'cursorMove';
    }
    
    headerref.onmouseout = function (event){
        var srcElement = (event != undefined)? event.target: window.event.srcElement;
        srcElement.className = 'cursorSimple';
    }
    
    if((wdeskFlag != undefined) && (wdeskFlag != null) && (wdeskFlag == "U")){
        headerref.innerHTML = wDeskLayoutJason.WDeskEditableLayout.Interfaces[containerid-1].Interface.Type;
    }
    
    headerref.onmousedown = function(event){
        event = (event != undefined)? event: window.event; 
        setPositionForDrag(event, "div_C"+containerid);
    }      
    ref.appendChild(headerref);       
    addContainerExternal(ref,containerid,wdeskFlag);
}

function addContainerExternal(parentRef,containerid, wdeskFlag){
    // Vertical resize
    var childRef = window.document.createElement("div");
    childRef.setAttribute("id", "divResizeVer_C"+containerid);
    childRef.style.overflow= 'hidden';
    childRef.className='resizablever';    
    childRef.onmousedown = function(event){
        event = (event != undefined)? event: window.event; 
        setPosition(event, "div_C"+containerid, "ver");
    }    
    childRef.onmouseover = function(event){        
        var srcElement = (event != undefined)? event.target: window.event.srcElement;
        changeResizeColor(srcElement,'#BFDCFC');
    }        
    childRef.onmouseout = function(event){
        var srcElement = (event != undefined)? event.target: window.event.srcElement;
        changeResizeColor(srcElement,'#ededed');
    }
    parentRef.appendChild(childRef);    

    // Horizontal resize
    childRef = window.document.createElement("div");
    childRef.setAttribute("id", "divResizeHor_C"+containerid);
    childRef.style.overflow= 'hidden';
    childRef.className='resizablehor';    
    childRef.onmousedown = function(event){
        event = (event != undefined)? event: window.event; 
        setPosition(event, "div_C"+containerid, "hor");
    }    
    childRef.onmouseover = function(event){               
        var srcElement = (event != undefined)? event.target: window.event.srcElement;
        changeResizeColor(srcElement,'#BFDCFC');
    }        
    childRef.onmouseout = function(event){
        var srcElement = (event != undefined)? event.target: window.event.srcElement;
        changeResizeColor(srcElement,'#ededed');
    }
    parentRef.appendChild(childRef);  

    // Vertical and Horizontal resize
    childRef = window.document.createElement("div");
    childRef.setAttribute("id", "divResize_C"+containerid);
    childRef.style.overflow= 'hidden';
    childRef.className='resizable';    
    childRef.onmousedown = function(event){
        event = (event != undefined)? event: window.event; 
        setPosition(event, "div_C"+containerid, "both");
    }    
    childRef.onmouseover = function(event){        
        var srcElement = (event != undefined)? event.target: window.event.srcElement;
        changeResizeColor(srcElement,'#BFDCFC');
    }        
    childRef.onmouseout = function(event){
        var srcElement = (event != undefined)? event.target: window.event.srcElement;
        changeResizeColor(srcElement,'#ededed');
    }
    parentRef.appendChild(childRef);      
    
    // Interface menu
    childRef = window.document.createElement("div");
    childRef.setAttribute("id", "intList_C"+containerid);    
    childRef.style.cursor="pointer";
    childRef.className = "arrowDown";
    
    if((wdeskFlag != undefined) && (wdeskFlag != null) && (wdeskFlag == "U")){
        childRef.style.display="none";
    } else {
        childRef.style.display="inline";
    }
    
    childRef.onclick = function(event){
        var srcElement = (event != undefined)? event.target: window.event.srcElement;
        showInterfaceList(srcElement.id.split('_')[1]);
    }          
    parentRef.appendChild(childRef);  
    
    // Close interface
    childRef = window.document.createElement("img");
    childRef.setAttribute("id", "closeimg_C"+containerid);
    childRef.style.paddingRight = "5px";
    childRef.style.paddingBottom = "1px";
    childRef.style.paddingLeft = "4px";
    childRef.style.paddingTop = "5px";
    childRef.style.width="12px";
    childRef.style.height="12px";
    childRef.style.cursor="pointer";
    childRef.style.position="relative";
    childRef.style.cursor="inline-block";
    childRef.onclick = function(event){
        var srcElement = (event != undefined)? event.target: window.event.srcElement;
        closeInterface(srcElement.id.split('_')[1]);
    }      
    childRef.src = "/webdesktop/resources/images/closehw.png";
    parentRef.appendChild(childRef);  
}

function findPosX(obj){
    var curleft = 0;
    if(obj.offsetParent)
        while(1)
        {
            curleft += obj.offsetLeft;
            if(!obj.offsetParent)
                break;
            obj = obj.offsetParent;
        }
    else if(obj.x)
        curleft += obj.x;
    return curleft;
}

function findPosY(obj){
    var curtop = 0;
    if(obj.offsetParent)
        while(1)
        {
            curtop += obj.offsetTop;
            if(!obj.offsetParent)
                break;
            obj = obj.offsetParent;
        }
    else if(obj.y)
        curtop += obj.y;
    return curtop;
}

function changeResizeColor(ref, color){    
    ref.style.backgroundColor = color;
}

function repositionMoveDiv(divRef){    
    var ref = document.getElementById("moveDiv");    
    ref.style.width = divRef.style.width;
    ref.style.height = divRef.style.height;
    ref.style.top = divRef.style.top;
    ref.style.left = divRef.style.left;
    ref.style.display = "block";
    ref.style.zIndex = "1000";
}

function onRowMouseOver(ref)
{
    ref.style.backgroundColor = "#e8e8e8";
    ref.style.cursor = "pointer";
}

function onRowMouseOut(ref)
{
    ref.style.backgroundColor = "";
}

var selectedContId = "";
function showInterfaceList(contId){
    selectedContId = contId;    
    var ref = document.getElementById("intList_"+contId);        
    var listDivRef = document.getElementById("interfaceListDiv");
    listDivRef.style.top = parseInt(findPosY(ref)) + 16 + "px";
    listDivRef.style.left = parseInt(findPosX(ref)) + 6 - parseInt(listDivRef.style.width.split('p')[0]) + "px";    
    listDivRef.style.display = "block";
}

var selectedFixedContId = "";
function showFixedInterfaceList(contId, selectedContainer,pageDir){  //Bug 75493
    selectedFixedContId = contId;
    if(typeof pageDir == "undefined"){//Bug 75493 Start
        var pageDir="ltr";
    }//Bug 75493 Start
    var ref = document.getElementById("intList_"+contId);        
    var listDivRef = document.getElementById("fixedInterfaceListDiv");
    listDivRef.style.top = parseInt(findPosY(ref)) + 16 + "px";
    if(pageDir=="rtl"){//Bug 75493 Start
        listDivRef.style.left=parseInt(findPosX(ref)) + 6+"px";
    }
    else{
        listDivRef.style.left = parseInt(findPosX(ref)) + 6 - parseInt(listDivRef.style.width.split('p')[0]) + "px";    
    }
    //listDivRef.style.left = parseInt(findPosX(ref)) + 6 - parseInt(listDivRef.style.width.split('p')[0]) + "px"; 
    //Bug 75493 End
	listDivRef.style.display = "block";
    document.getElementById("selectedContainer").value = selectedContainer;
}

function interfaceAddHandler(){
    var selectedIntName = document.getElementById("selectedIntName").value
    // Hides interface menu
    var ref = document.getElementById("intList_"+selectedContId);   
    ref.style.display = "none";
    
    // Names interface header
    ref = document.getElementById("headerDiv_"+selectedContId);   
    ref.innerHTML = encode_ParamValue(selectedIntName);
    
    ref = document.getElementById("div_"+selectedContId);
     var intJason = {
         "Type": selectedIntName,
         "Left": ref.style.left.split('p')[0],
         "Top": ref.style.top.split('p')[0],
         "Width": ref.style.width.split('p')[0],
         "Height": ref.style.height.split('p')[0]
     }

     interfaceMap.put("div_"+selectedContId, intJason);
}

function closeInterface(contId){
    selectedContId = contId;    
    var ref = document.getElementById("headerDiv_"+selectedContId);   
    document.getElementById("selectedIntName").value = ref.innerHTML; 
    if(ref.innerHTML == ""){
        ref = document.getElementById("div_"+selectedContId);  
        try{
            document.getElementById("containerDiv").removeChild(ref);
            interfaceMap.remove("div_"+selectedContId);
        }catch(e){
            //alert(e);
        }
    } else {
        clickLink("closeIntBtn");
    }
}

function interfaceCloseHandler(){
    var ref = document.getElementById("intList_"+selectedContId);   
    ref.style.display = "inline";
    
    ref = document.getElementById("headerDiv_"+selectedContId);   
    ref.innerHTML = "";
    
    interfaceMap.remove("div_"+selectedContId);
}

function onSave(){
    var ref = document.getElementsByClassName('colinp');
    var sum = 0;
    for (var i = 0; i < ref.length; i++) {
        sum += Number(ref[i].value);
    }
    if (sum > 12 || sum < 12) {
        customAlert(ALERT_COLUMN_SUM);
        return false;
    }
    var returnValue = true;
    var rowHeightInputObj = document.getElementById('tableWrap').firstElementChild.getElementsByClassName('rowHeightInput');
    
    for(var i=0; i< rowHeightInputObj.length; i++){
        returnValue = new Validator(rowHeightInputObj[i], true, false).isNumberInRange(MINIMUM_ROW_HEIGHT);
        if(!returnValue){
            break;
        }
    }
    
    if(!returnValue){
        customAlert(ALERT_ROW_HEIGHT);
        return false;
    }
    
    var rtnValue=checkForMandatoryOption();
    
    if(rtnValue!=true){
        if(rtnValue=='Tasks'){
            customAlert(TASK_MANDATE_OPTION);
        } else if(rtnValue=='Progress'){
            customAlert(PROGRESS_MANDATE_OPTION);
        }  
        return false;
    }
    
    var layoutType = document.getElementById("m_strLayoutType").value;  
    var ref = document.getElementById("containerDiv");
    if(layoutType == "F"){
        ref = document.getElementById("fixedContainerDiv");
    }
    if(layoutType == "R"){
        ref = document.getElementById("respContainer");
    }
    
    var contDivTop = findPosY(ref);
    var contDivLeft = findPosX(ref);
        
    if(!bEditableLayoutLoaded){  
        for(var i=0; i<wDeskLayoutJason.WDeskEditableLayout.Interfaces.length; i++){            
            interfaceMap.put("div_C"+(i+1), wDeskLayoutJason.WDeskEditableLayout.Interfaces[i].Interface);
        }
        
        contDivTop = 0;
        contDivLeft = 0;
    }
    
    var intArrayRef; 
        intArrayRef = interfaceMap.getIterator();
        var wDeskInterfacesXML = "<WDeskInterfaces>";
        for (var i = 0; i < intArrayRef.length; i++) {
            var interfaceXML = "<Interface";
            interfaceXML = interfaceXML + " Type='" + intArrayRef[i].value.Type + "' Top='" + (intArrayRef[i].value.Top - contDivTop) + "' Left='" + (intArrayRef[i].value.Left - contDivLeft) +
                    "' Width='" + intArrayRef[i].value.Width + "' Height='" + intArrayRef[i].value.Height + "'/>"
            wDeskInterfacesXML += interfaceXML;
        }

        wDeskInterfacesXML += "</WDeskInterfaces>";
        intArrayRef = interfaceRespMap.getIterator();
        var wDeskRespInterfacesXML = "<WDeskInterfaces SplitView='Y' Columns='2'>";
        var newTbl=document.getElementById('tableWrap').children[0].children[0];
        var tableWrapRef=newTbl;
        var trchildCount=document.getElementById('tableWrap').children[0].children[0].rows.length;
        var tableHTML="<table>";
            var trChildRef=document.getElementById('tableWrap').children[0].children[0].rows;
            var splitColumns=trChildRef[trChildRef.length-1].cells;
            tableHTML+="<tr>";
            for(var i=0;i<splitColumns.length-1;i++){
                var childEle=splitColumns[i].firstElementChild;
                tableHTML+="<td><div/>"+childEle.children[1].value+"</td>";
            }
            tableHTML+="<td><div/></td></tr>";
            for(var j=0;j<trChildRef.length-1;j++){
                var tdChildRef=trChildRef[j].cells;
                var rwhRef=tdChildRef[tdChildRef.length-1];
                tableHTML += "<tr RowHeight='"+rwhRef.firstElementChild.children[1].firstElementChild.value+"'>";
                for(var k=0;k<tdChildRef.length-1;k++){
                    tdChildRef[k].removeAttribute("class");
                    tdChildRef[k].firstElementChild.removeAttribute("class");
                    if(tdChildRef[k].firstElementChild.firstElementChild!=null){
                      if(tdChildRef[k].firstElementChild.childElementCount==2){  
                        tdChildRef[k].firstElementChild.removeChild(tdChildRef[k].firstElementChild.firstElementChild);
                        tdChildRef[k].firstElementChild.firstElementChild.removeAttribute("class");
                        if(tdChildRef[k].firstElementChild.firstElementChild.innerHTML.indexOf(",")>0){
                            var temp=tdChildRef[k].firstElementChild.firstElementChild.innerHTML.split(",");
                            tdChildRef[k].firstElementChild.removeChild(tdChildRef[k].firstElementChild.firstElementChild);
 
                            for(var i=0;i<temp.length;i++){
                                var divRef=document.createElement('div');
                                divRef.innerHTML=temp[i].trim();
                                if(temp[i].trim()=="Document"){
                                    if(multipane=='Y')
                                      divRef.setAttribute("MultiPane","Y");
                                }
                                tdChildRef[k].firstElementChild.appendChild(divRef);
                            }
                        } else {
                           if (tdChildRef[k].firstElementChild.firstElementChild.innerHTML.trim() == "Document") {
                               if (multipane == 'Y')
                                tdChildRef[k].firstElementChild.firstElementChild.setAttribute("MultiPane", "Y");
                           }
                        }
                        
                        tdChildRef[k].firstElementChild.removeAttribute('id');
                        tableHTML += tdChildRef[k].outerHTML;
                      } else {
                          tdChildRef[k].firstElementChild.firstElementChild.removeAttribute("class");
                          tdChildRef[k].firstElementChild.firstElementChild.removeChild(tdChildRef[k].firstElementChild.firstElementChild.firstElementChild);
                          if(tdChildRef[k].firstElementChild.innerHTML.trim()=="Document"){
                              if(multipane=='Y')
                                  tdChildRef[k].firstElementChild.setAttribute("MultiPane","Y");
                          }
                          tableHTML += tdChildRef[k].outerHTML;
                      }
                    } else {
                        tdChildRef[k].firstElementChild.removeAttribute("class");
                        if(tdChildRef[k].firstElementChild.innerHTML=="&nbsp;")
                           tdChildRef[k].firstElementChild.innerHTML="";
                        tableHTML += tdChildRef[k].outerHTML;
                    }
                    
                }
                tableHTML += "<td><div/></td>";
                tableHTML += "</tr>"
            }
        tableHTML+="</table>";
        wDeskRespInterfacesXML+=tableHTML;
        wDeskRespInterfacesXML += "</WDeskInterfaces>";
        var wDeskPnlInterface="<WDeskPanels>";
        if(document.getElementById('lType:0').checked==true){
            wDeskPnlInterface+="<Left Overlay='Y'>";
        } else if(document.getElementById('lType:1').checked==true){
            wDeskPnlInterface+="<Left Overlay='N'>";
        }
                
        var lrows=document.getElementById('lpanel').rows;
        for(var i=0;i<lrows.length;i++){
           var lcells=lrows[i].cells;    
           for(var j=0;j<lcells.length;j++){               
               if(lcells[0].children[0].checked==true){
                   wDeskPnlInterface+="<Interface Type='";
                   wDeskPnlInterface+=lcells[0].children[1].innerHTML.trim()+"'/>";
               }
           }
        }
        wDeskPnlInterface+="</Left>";
        if(document.getElementById('rType:0').checked==true){
            wDeskPnlInterface+="<Right Overlay='Y'>"; 
        } else if(document.getElementById('rType:1').checked==true){
            wDeskPnlInterface+="<Right Overlay='N'>"; 
        }
        
        var rrows=document.getElementById('rpanel').rows;
        for(var i=0;i<rrows.length;i++){
           var rcells=rrows[i].cells; 
           for(var j=0;j<rcells.length;j++){
              if(rcells[0].children[0].checked==true){
                   wDeskPnlInterface+="<Interface Type='";
                   wDeskPnlInterface+=rcells[0].children[1].innerHTML.trim()+"'/>";
               } 
           }
        }
        wDeskPnlInterface+="</Right>";
        wDeskPnlInterface+="</WDeskPanels>";        
    
    document.getElementById("wDeskInterfacesXML").value = wDeskInterfacesXML;
    document.getElementById("wDeskRespInterfacesXML").value= wDeskRespInterfacesXML;
    document.getElementById("wDeskPnlInterfacesXML").value= wDeskPnlInterface;
    setResolution();
    clickLink("saveBtn");
}

function setIntPosition(intJason, divRef){
    intJason.Left = divRef.style.left.split('p')[0];
    intJason.Top = divRef.style.top.split('p')[0];
    intJason.Width = divRef.style.width.split('p')[0];
    intJason.Height = divRef.style.height.split('p')[0];
}

function setResolution(){
    var width = "";
    var height = "";
    if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
        //IE 6+ in 'standards compliant mode'        
        width = document.documentElement.clientWidth;
        height = document.documentElement.clientHeight;
    } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {        
        //IE 4 compatible
        width = document.body.clientWidth;
        height = document.body.clientHeight;
    }    
    document.getElementById("screenWidth").value = width;
    document.getElementById("screenHeight").value = height;
    document.getElementById("respWidth").value=screen.width;
    document.getElementById("respHeight").value=screen.height;
}

function  hideOnDocumentClick(e){
    var eventTarget = (e && e.target) || (event && event.srcElement);
    var listDivRef = document.getElementById("interfaceListDiv");
    var fixedListDivRef = document.getElementById("fixedInterfaceListDiv");
    if(isRemovable(eventTarget)){    
        if(listDivRef.style.visibility == 'visible'){
            listDivRef.style.visibility = 'hidden';
        } else if((listDivRef.style.display == 'inline') || (listDivRef.style.display == 'block')){
            listDivRef.style.display = 'none';
        }
        
        if(fixedListDivRef.style.visibility == 'visible'){
            fixedListDivRef.style.visibility = 'hidden';
        } else if((fixedListDivRef.style.display == 'inline') || (fixedListDivRef.style.display == 'block')){
            fixedListDivRef.style.display = 'none';
        }
    }
}

function isRemovable(eventTarget) {
    var tempParentObj = eventTarget;
    var ref = document.getElementById("intList_"+selectedContId);   
    var ref2 = document.getElementById("intList_"+selectedFixedContId);   
    while(tempParentObj !=null) {
        if((tempParentObj == ref) || (tempParentObj == ref) || (tempParentObj == ref2) || (tempParentObj == ref2) ){
            return false;
        }
        tempParentObj = tempParentObj.parentNode;
    }
    
    return true;
}

function clickLink(linkId)
{
    if(!linkId)
    {
        return false;
    }

    var fireOnThis = document.getElementById(linkId);
    
    if(fireOnThis != null && (fireOnThis.nodeName.toUpperCase() == "A")){
        if(fireOnThis.href.lastIndexOf("#") > -1){
            fireOnThis.href = "javascript:void(0)";
        }
    }
    
    if (fireOnThis != null) {
        if (document.createEvent)
        {
            //var evObj = document.createEvent('MouseEvents') ;
            //evObj.initEvent( 'click', true, false ) ;
            //fireOnThis.dispatchEvent(evObj) ;
            var evObj = document.createEvent('MouseEvents');
            evObj.initMouseEvent("click", false, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
            fireOnThis.dispatchEvent(evObj);
        }
        else if (document.createEventObject)
        {
            fireOnThis.click();

        }
    }
    return ;
}

function clickLinkBubbleEvt(linkId)
{
    if(!linkId)
    {
        return false;
    }

    var fireOnThis = document.getElementById(linkId);
    
    if(fireOnThis != null && (fireOnThis.nodeName.toUpperCase() == "A")){
        if(fireOnThis.href.lastIndexOf("#") > -1){
            fireOnThis.href = "javascript:void(0)";
        }
    }
    if (fireOnThis != null) {
        if (document.createEvent)
        {
            //var evObj = document.createEvent('MouseEvents') ;
            //evObj.initEvent( 'click', true, false ) ;
            //fireOnThis.dispatchEvent(evObj) ;
            var evObj = document.createEvent('MouseEvents');
            evObj.initMouseEvent("click", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
            fireOnThis.dispatchEvent(evObj);
        }
        else if (document.createEventObject)
        {
            fireOnThis.click();

        }
    }
    return ;
}

function isIE(){
   return ((navigator.appName=='Netscape')?false:true);
}

function HashMap(){
    this.hashArray = new Array();
    this.getIterator = function (){
        return this.hashArray;
    }
}

HashMap.prototype.put = function (key, value){
    var jasonObj = this.get(key);
    if(jasonObj.value == null){
        this.hashArray[this.hashArray.length] = {"key":key, "value":value};
    } else {
        this.hashArray[jasonObj.index].value = value;
    }
}

HashMap.prototype.get = function (key){
    var value = null;
    var index = 0;
    for(index; index<this.hashArray.length; index++){
        if(this.hashArray[index].key == key){
            value = this.hashArray[index].value;
            break;
        }
    }

    if(index == this.hashArray.length){
        index = -1;
    }

    return {"value":value, "index":index};
}

HashMap.prototype.remove = function (key){
    var value = null;
    var index = 0;
    for(index; index<this.hashArray.length; index++){
        if(this.hashArray[index].key == key){
            value = this.hashArray[index].value;
            this.hashArray.splice(index, 1);            
            break;
        }
    }

    if(index == this.hashArray.length){
        index = -1;
    }

    return {"value":value, "index":index};
}

HashMap.prototype.clear = function (){
    this.hashArray = new Array();
}

function stopSelection(ref){    
    ref.onselectstart = function(e){
        if(typeof e != 'undefined'){
            if (typeof e.preventDefault != 'undefined' && e.preventDefault != null) {
                e.preventDefault();
            } else if (typeof e.stopPropagation != 'undefined' && e.stopPropagation != null){
                e.stopPropagation();
            } else {
                window.event.cancelBubble=true;
            }  
        }      
            
        return false;
    };
}

var srcParentId=null;
var srcParentRef=null;
function showHideInterfacesList(event){
    var listRef = document.getElementById('availInterfaces');
    adjustInterfaceList();
    event = event || window.event;
    var source = event.target || event.srcElement;   
    srcParentId=source.parentNode.parentNode.id;
    srcParentRef=source.parentNode.parentNode;
    setPopupMask();
    showPopupMask();    
    var tblRef=document.getElementById('tableWrap');
    var rowsRef=tblRef.firstElementChild.rows;
    var tabPresent=new HashMap(); 
    var tabPresent1=new HashMap(); 
    for(var i=0;i<rowsRef.length-1;i++){
        var cellsRef=rowsRef[i].cells;
        for(var j=0;j<cellsRef.length-1;j++){
            var cellRef=cellsRef[j];
            if (hasCSS(cellRef, 'splitCellCSS')) {
                if (cellRef.children[0].children[1] != null && cellRef.children[0].children[1].innerHTML != '&nbsp;') {
                    if(cellRef.children[0].children[1].innerHTML.trim().indexOf(",")>0){
                        var temp=cellRef.children[0].children[1].innerHTML.trim().split(",");
                        for(var k=0;k<temp.length;k++){
                            tabPresent.put(temp[k].trim(), temp[k].trim());                            
                        }
                    } else {
                        tabPresent.put(cellRef.children[0].children[1].innerHTML.trim(), cellRef.children[0].children[1].innerHTML.trim());                        
                    }
                    
                }
            } else {
                if (cellRef.children[0].children[1] != null && cellRef.children[0].children[1].innerHTML != '&nbsp;') {
                    if(cellRef.children[0].children[1].innerHTML.trim().indexOf(",")>0){
                        var temp=cellRef.children[0].children[1].innerHTML.trim().split(",");
                        for(var k=0;k<temp.length;k++){
                            tabPresent1.put(temp[k].trim(), temp[k].trim());                            
                        }
                    } else {
                        tabPresent1.put(cellRef.children[0].children[1].innerHTML.trim(), cellRef.children[0].children[1].innerHTML.trim());
                    }
                }
            }
            
        }
    }
    
    var childcount=document.getElementById('interfaces').rows.length;
    
    for(var i=0;i<childcount;i++){
        var ref=document.getElementById('interfaces:'+i+':intName');
        var ref2=document.getElementById('interfaces:'+i+':addInter');
        var docPane;
        try {
            if (ref.innerHTML.trim() == "Document") {
                docPane = document.getElementById('interfaces:' + i + ':multiInter');
            }
            if (blockedContainer.contains(ref.innerHTML.trim())) {

                ref.parentNode.parentNode.style.display = "none";
            } else if (tabPresent.get(ref.innerHTML.trim()).index != -1) {
                ref.parentNode.parentNode.style.display = "";
                ref2.checked = true;
                if (ref.innerHTML.trim() == "Document") {
                    if (multipane == 'Y') {
                        docPane.checked = true;
                    }
                }
            } else {
                ref.parentNode.parentNode.style.display = "";
                ref2.checked = false;
                if (ref.innerHTML.trim() == "Document") {
                    if (multipane == 'Y') {
                        docPane.checked = true;
                    }
                }
            }
        } catch (err) {
        }
        if(tabPresent1.get(ref.innerHTML.trim()).index!=-1){
            ref.parentNode.parentNode.style.display="none";
            ref2.checked=false;
        }
    }
    
    //checkNoTabForDocument(tabPresent);
    disableMultiPane(event,'showHideInterfacesList');
    showHideInteraceList();
    
    var status=checkForInterfaceDisplay();
    if(status){
        if (hasCSS(listRef, 'dn')) {
            removeCSS(listRef, 'dn');
            addCSS(listRef, 'db');
        }
    } else {
        hidePopupMask();
        customAlert(NO_INTERFACE_AVAILABLE);
        return false;
    }
          
}

function hidePanelOption(ref,ptype){
    var index=ref.id.split(":");
    if(ptype=='R'){
        document.getElementById("lpanel:"+index[1]+":lpanelcheck").checked=false; 
    } else if(ptype=='L'){
        document.getElementById("rpanel:"+index[1]+":rpanelcheck").checked=false;
    }
    hideInAvailableList(ref,ptype);
}

function addContainerToCell(event){
    var tblRef=document.getElementById('tableWrap');
    var rowsRef=document.getElementById('tableWrap').firstElementChild.rows;
    var trRef=document.getElementById('interfaces').rows;
    var nocheckedflag=true;
    var firstIteration=true;
    //if(srcParentId ==''){
        if(srcParentRef !=null){
            srcParentRef.innerHTML="";
            //srcParentRef.removeChild(srcParentRef.firstElementChild);
            createToolBoxDiv(srcParentRef);
            srcParentRef.appendChild(document.createElement('div'));
            srcParentRef.childNodes[1].className ="content";
            addCSS(srcParentRef.parentNode, 'filledCellCSS');            
        }
    //}
    srcParentRef.childNodes[1].innerHTML="";
    for(var j=0;j<trRef.length;j++){
        var tdRefs=trRef[j].cells;
        for(var k=0;k<tdRefs.length;k++){
            if(tdRefs[k].children[0]!=null){
            if(tdRefs[k].children[0].checked==true){
                nocheckedflag=false;
                if (firstIteration) {
                    if (typeof containerId[tdRefs[k].children[1].innerHTML.trim()] != 'undefined' && containerId[tdRefs[k].children[1].innerHTML.trim()] != null)
                        srcParentRef.id = "divChild_" + tdRefs[k].children[1].innerHTML.trim() + "#$#$#Int" + containerId[tdRefs[k].children[1].innerHTML.trim()];
                    else
                        srcParentRef.id = "divChild_" + tdRefs[k].children[1].innerHTML.trim() + "#$#$#Int" + k;
                  firstIteration=false;  
                }
                 
//                if (srcParentId != '') {
//                    var divRef=document.getElementById(srcParentId);
//                    if(srcParentRef.childNodes[1].innerHTML =='' || srcParentRef.childNodes[1].innerHTML =='&nbsp;'){
//                      divRef.childNodes[1].innerHTML = tdRefs[k].children[1].innerHTML.trim();
//                    } else {
//                        divRef.childNodes[1].innerHTML +=","+ tdRefs[k].children[1].innerHTML.trim();
//                    }
//                } else 
                    if(tdRefs[k].children[1].innerHTML.trim()=="Document"){
                        if (document.getElementById('interfaces:'+j+':multiInter') != null) {
                            if (document.getElementById('interfaces:'+j+':multiInter').checked) {
                                multipane = 'Y';
                            } else {
                                multipane = 'N';
                            }
                        }
                        
                    }
                    if (srcParentRef != null) {
                      if (srcParentRef.childNodes[1].innerHTML == '' || srcParentRef.childNodes[1].innerHTML == '&nbsp;') {
                        srcParentRef.childNodes[1].innerHTML = tdRefs[k].children[1].innerHTML.trim();
                       } else {
                        srcParentRef.childNodes[1].innerHTML += "," + tdRefs[k].children[1].innerHTML.trim();
                       }
                    }
           }
           }
        }
    }
    if(nocheckedflag==true){
        removeCSS(srcParentRef.parentNode, 'filledCellCSS');
        srcParentRef.removeAttribute('id');
        srcParentRef.removeChild(srcParentRef.childNodes[1]);
        srcParentRef.firstElementChild.removeChild(srcParentRef.firstElementChild.firstElementChild);
        srcParentRef.firstElementChild.removeChild(srcParentRef.firstElementChild.firstElementChild);
        
    }
    showHidePanelOptions();
    var listRef = document.getElementById('availInterfaces');
    if(hasCSS(listRef,'db')){
        removeCSS(listRef,'db');
        addCSS(listRef,'dn');          
    }
    hidePopupMask(); 
}

function closeInterfaceList(){
    var listRef = document.getElementById('availInterfaces');
    if(hasCSS(listRef,'db')){
        removeCSS(listRef,'db');
        addCSS(listRef,'dn');
        hidePopupMask();
    }
}

function createToolBoxDiv(srcParentRef) {
    srcParentRef.appendChild(document.createElement('div'));
    srcParentRef.childNodes[0].className = "toolbox";
    srcParentRef.childNodes[0].appendChild(document.createElement('div'));
    srcParentRef.childNodes[0].appendChild(document.createElement('div'));
    srcParentRef.childNodes[0].appendChild(document.createElement('div'));
    srcParentRef.childNodes[0].childNodes[0].className += "ib move";
    srcParentRef.childNodes[0].childNodes[0].title = DRAG_TO_MOVE_COMP;
    srcParentRef.childNodes[0].childNodes[0].innerHTML = "&nbsp;";
    srcParentRef.childNodes[0].childNodes[0].onmousedown = function (event) {
        srcMouseDownElement = this.parentNode.parentNode;
        stopEventPropagation(event);
    }
    srcParentRef.childNodes[0].childNodes[1].className += 'ib close';
    srcParentRef.childNodes[0].childNodes[1].title = CLICK_TO_CLOSE_COMP;
    srcParentRef.childNodes[0].childNodes[1].innerHTML = "&nbsp;";
    srcParentRef.childNodes[0].childNodes[1].onclick = function (event) {
        if (this.parentNode.parentNode != null) {
            var name=this.parentNode.parentNode.children[1].innerHTML.trim();
            this.parentNode.parentNode.removeAttribute('id');
            this.parentNode.parentNode.removeChild(this.parentNode.parentNode.childNodes[1]);
            removeCSS(this.parentNode.parentNode.parentNode, 'filledCellCSS');
            this.parentNode.removeChild(this.parentNode.firstElementChild);
            this.parentNode.removeChild(this.parentNode.firstElementChild);
            showHidePanelOptions();
            removeMultipane(name);
        }
    }
    srcParentRef.childNodes[0].childNodes[2].className += 'ib addInterface';
    srcParentRef.childNodes[0].childNodes[2].title = ADD_INTERFACE;
    srcParentRef.childNodes[0].childNodes[2].innerHTML = "&nbsp;";
    srcParentRef.childNodes[0].childNodes[2].onclick = function (event) {
        showHideInterfacesList(event);
    }
}

function showHidePanelOptions(){
    var tblRef=document.getElementById('tableWrap');
    var rowsRef=tblRef.firstElementChild.rows;
    var tabPresent = new HashMap();
    for (var i = 0; i < rowsRef.length-1; i++) {
        var cellsRef = rowsRef[i].cells;
        for (var j = 0; j < cellsRef.length-1; j++) {
            var cellRef = cellsRef[j];
            if (cellRef.children[0].children[1] != null && cellRef.children[0].children[1].innerHTML != '&nbsp;') {
                if (cellRef.children[0].children[1].innerHTML.trim().indexOf(",") > 0) {
                    var temp = cellRef.children[0].children[1].innerHTML.trim().split(",");
                    for (var k = 0; k < temp.length; k++) {
                        tabPresent.put(temp[k].trim(), temp[k].trim());
                    }
                } else {
                    tabPresent.put(cellRef.children[0].children[1].innerHTML.trim(), cellRef.children[0].children[1].innerHTML.trim());
                }
            }

        }
    }
    
    var childcount=document.getElementById('lpanel').rows.length;
    for(var i=0;i<childcount;i++){
        var refLc=document.getElementById('lpanel:'+i+':lpanelcheck');
        var refLL=document.getElementById('lpanel:'+i+':lpanellbl');
        var refRc=document.getElementById('rpanel:'+i+':rpanelcheck');
        var refRL=document.getElementById('rpanel:'+i+':rpanellbl');
        if(tabPresent.get(refLL.innerHTML.trim()).index!=-1 || blockedPanel.contains(refLL.innerHTML.trim()) || !allowedPanel.contains(refLL.innerHTML.trim())){
            refLc.parentNode.parentNode.style.display="none";
            refRc.parentNode.parentNode.style.display="none";
        } else {
            refLc.parentNode.parentNode.style.display="";
            refRc.parentNode.parentNode.style.display="";
        }        
    }
    
}

function showHideInteraceList(){
    var childcount=document.getElementById('lpanel').rows.length;
    var pnlPresent=new HashMap();
    for(var i=0;i<childcount;i++){
        var refLc=document.getElementById('lpanel:'+i+':lpanelcheck');
        var refLL=document.getElementById('lpanel:'+i+':lpanellbl');
        var refRc=document.getElementById('rpanel:'+i+':rpanelcheck');
        var refRL=document.getElementById('rpanel:'+i+':rpanellbl');
        if(refLc.checked==true){
            pnlPresent.put(refLL.innerHTML.trim(),refLL.innerHTML.trim());
        } else if(refRc.checked==true) {
            pnlPresent.put(refRL.innerHTML.trim(),refRL.innerHTML.trim());
        }        
    }
    childcount=document.getElementById('interfaces').rows.length;
    
    for(var i=0;i<childcount;i++){
        var ref=document.getElementById('interfaces:'+i+':intName');
        var ref2=document.getElementById('interfaces:'+i+':addInter');
        if(pnlPresent.get(ref.innerHTML.trim()).index!=-1){
            ref.parentNode.parentNode.style.display="none";
        }      
    } 
    
}

function hideInAvailableList(ref,ptype){
    var index=ref.id.split(":");
    var id;
    if(ptype=='R'){
        id='rpanel:'+index[1]+':rpanellbl';
    } else if(ptype=='L'){
        id='lpanel:'+index[1]+':lpanellbl';
    }
    var trRef=document.getElementById('interfaces').rows;
    for(var i=0;i<trRef.length;i++){
        var tdRef=trRef[i].cells;
        if(tdRef[0].children[1].innerHTML.trim()==document.getElementById(id).innerHTML.trim()){
            if(document.getElementById(ref.id).checked==true)
              tdRef[0].parentNode.style.display="none";
            if(document.getElementById(ref.id).checked==false)
                tdRef[0].parentNode.style.display="";
        }
    }
}

function defaultPanelOption(){
    var childcount=document.getElementById('lpanel').rows.length;
    var interFace=interfaceRespMap.getIterator();
    for(var i=0;i<childcount;i++){
        var refLc=document.getElementById('lpanel:'+i+':lpanelcheck');
        var refLL=document.getElementById('lpanel:'+i+':lpanellbl');
        var refRc=document.getElementById('rpanel:'+i+':rpanelcheck');
        var refRL=document.getElementById('rpanel:'+i+':rpanellbl');
        for(var j=0;j<interFace.length;j++){
           if(interFace[j].value.Location=="Left"){
               if(interFace[j].value.Type==refLL.innerHTML.trim()){
                   if(interFace[j].value.InterfacePresent==true)
                     refLc.checked=true;
                   else
                      refLc.checked=false; 
               }
           }
           if(interFace[j].value.Location=="Right"){
               if(interFace[j].value.Type==refRL.innerHTML.trim()){
                   if(interFace[j].value.InterfacePresent==true)
                     refRc.checked=true;
                    else
                      refRc.checked=false;  
               }
           }
        }
    }
    if(wDeskLayoutJason.WDeskResponsiveLayout.LeftPanelType=="Expanded"){
        document.getElementById("lType:1").checked=true;
        document.getElementById("lType:0").checked=false;
    } else {
        document.getElementById("lType:0").checked=true;
        document.getElementById("lType:1").checked=false;
    }
    
    if(wDeskLayoutJason.WDeskResponsiveLayout.RightPanelType=="Expanded"){
        document.getElementById("rType:1").checked=true;
        document.getElementById("rType:0").checked=false
    } else {
        document.getElementById("rType:0").checked=true;
        document.getElementById("rType:1").checked=false;
    }
    showHidePanelOptions();
}

var containerId={"FormView":"71",
    "CaseView":"72",
    "Document":"73",
    "SAPGUIAdapter":"74",
    "Tasks":"75",
    "Progress":"76",
    "Info":"77",
    "Documents":"78",
    "ToDoList":"79",
    "Exceptions":"80",
    "Calendar":"81"
};

var multipane='N';

function Validator(obj, isSetFocus, isDOMEvent){
    this.isDOMEvent = (typeof isDOMEvent == 'undefined')? true: isDOMEvent;
    this.isSetFocus = (typeof isSetFocus == 'undefined')? true: isSetFocus;
    
    if(this.isDOMEvent){
        this.obj = obj || window.event;
        this.source = obj.target || obj.srcElement;
        this.keyCode = this.obj.keyCode || this.obj.which;
    } else {
        this.obj = obj;
        this.source = obj;
        this.keyCode = -1;
    }
    
    this.returnValue = true;    
        
    this.isEmailAddress = function (){
       var pattern =/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
       return pattern.test(this.source.value);
    };
    
    this.isNotEmpty = function (){
       var pattern =/\S+/;
       return pattern.test(this.keyCode);
    };
    
    this.isNumber = function (){       
        if (this.keyCode > 47 && this.keyCode < 58) {            
        } else {
            this.returnValue = false;
        }
       
       return this.returnValue;
    };    
    
    this.isNumberInRange = function (minValue, maxValue){       
        if(minValue && (this.source.value < (minValue-0))){
            this.returnValue = false;
        }
        
        if(maxValue && (this.source.value > (maxValue-0))){
            this.returnValue = false;
        }
       
       this.isSetFocus && !this.returnValue && setElementFocus(this.source);
       
       return this.returnValue;
    };    
};

function checkForMandatoryOption(){
    var childcount=document.getElementById('lpanel').rows.length;
    for(var i=0;i<childcount;i++){
        var refLc=document.getElementById('lpanel:'+i+':lpanelcheck');
        var refLL=document.getElementById('lpanel:'+i+':lpanellbl');
        var refRc=document.getElementById('rpanel:'+i+':rpanelcheck');
        var refRL=document.getElementById('rpanel:'+i+':rpanellbl');
        if(mandatoryOptions.contains(refLL.innerHTML.trim())){
            if(refLc.checked==false && refRc.checked==false){
                return refLL.innerHTML.trim();
            }
        }       
           
    }
    return true;
}

//function checkNoTabForDocument(tabPresent){
//    var childcount=document.getElementById('interfaces').rows.length;
//    var noTabSupport=false;
//    var noDocShow=false;
//    if(tabPresent.get("Document").index!=-1){
//        noTabSupport=true;
//    } else {
//        if(tabPresent.hashArray.length>0){
//            noDocShow=true;
//        }
//    }
//    
//    for (var i = 0; i < childcount; i++) {
//        var ref = document.getElementById('interfaces:' + i + ':intName');
//        var ref2 = document.getElementById('interfaces:' + i + ':addInter');
//        if (noTabSupport) {
//            if (ref.innerHTML.trim() != 'Document') {
//                ref.parentNode.parentNode.style.display = "none";
//                ref2.checked = false;
//            }
//        }
//        if(noDocShow) {
//            if (ref.innerHTML.trim() == 'Document') {
//                ref.parentNode.parentNode.style.display = "none";
//                ref2.checked = false;
//            }
//        }
//    }    
//    
//}

function disableMultiPane(event,callFrom){
    var childcount=document.getElementById('interfaces').rows.length;
    
    var flagForOptionEn=true;
    for(var i=0;i<childcount;i++){
        var ref=document.getElementById('interfaces:'+i+':intName');
        var ref2=document.getElementById('interfaces:'+i+':addInter');
        if(ref.innerHTML.trim()=="Document"){
            var ref3=document.getElementById('interfaces:'+i+':multiInter');
            if(ref2.checked==true){                
                if(multipane=='Y'){
                    ref3.checked=true;
                } else {
                    ref3.checked=false;
                }        
                ref3.disabled=false;
                flagForOptionEn=false;
            } else if(ref2.checked==false){
                ref3.disabled=true;
                ref3.checked=false;
                ref2.checked=false;
                //multipane='N';
            }
        }
    }
    if(!flagForOptionEn){
        for (var i = 0; i < childcount; i++) {
            var ref = document.getElementById('interfaces:' + i + ':intName');
            var ref2 = document.getElementById('interfaces:' + i + ':addInter');
            if (typeof callFrom == 'undefined') {
                if (event.srcElement.parentNode.children[1].innerHTML.trim() == "Document") {
                    if (ref.innerHTML.trim() != "Document") {
                        if (ref2.checked == true) {
                            ref2.checked = false;
                        }
                    }
                } else {
                    if (ref.innerHTML.trim() == "Document") {
                        var ref3=document.getElementById('interfaces:'+i+':multiInter');
                        if (ref2.checked == true) {
                            ref2.checked = false;
                            ref3.checked =false;
                            ref3.disabled = true;
                            multipane='N';
                        }
                    }
                }
            }
           
        }
    }
}

function checkForInterfaceDisplay(){
    var childcount=document.getElementById('interfaces').rows.length;
    for(var i=0;i<childcount;i++){
        var ref=document.getElementById('interfaces:'+i+':intName');
        if(ref.parentNode.parentNode.style.display==""){
            return true;
        }
    }
    return false;
}

function removeMultipane(name){
    if(name!=null){
        if(name=="Document"){
            multipane='N';
        }
    }
}