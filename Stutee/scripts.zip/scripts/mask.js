var iPopupMask;
var WD_SID;
function initIPopUp() {
    if(iPopupMask == null) {
        // Add the HTML to the body
        theBody = document.getElementsByTagName('BODY')[0];
        ipopmask = document.createElement('div');
        ipopmask.id = 'ipopupMask';
        theBody.appendChild(ipopmask);
        iPopupMask = document.getElementById("ipopupMask");
        iPopupMask.style.display = "none";
        iPopupMask.style.position = "absolute";
        iPopupMask.style.zIndex = "100";
        iPopupMask.style.top = "0px";
        iPopupMask.style.left = "0px";
        iPopupMask.style.width = "100%";
        iPopupMask.style.height = "100%";
        iPopupMask.style.opacity = "0.4";
        iPopupMask.style.filter = "alpha(opacity=40)";
        iPopupMask.style.backgroundColor = "#d8dce0"; 
    }
}

function hideIPopupMask()
{
    if(iPopupMask != null) {
        iPopupMask.style.display = "none";        
    }
}

function setIPopupMask()
{
    if(iPopupMask ==null)
    {
        initIPopUp(); 
    }
    if(iPopupMask !=null) {
        iPopupMask.style.display = "block";
        iPopupMask.style.height = window.document.documentElement.scrollHeight + "px";
        iPopupMask.style.width = document.documentElement.clientWidth + "px";
    }
}