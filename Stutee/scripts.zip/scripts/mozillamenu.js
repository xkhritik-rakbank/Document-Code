
 
/*
Tabs Menu (mouseover)- By Dynamic Drive
For full source code and more DHTML scripts, visit http://www.dynamicdrive.com
This credit MUST stay intact for use
*/

var submenu=new Array()

//Set submenu contents. Expand as needed. For each content, make sure everything exists on ONE LINE. Otherwise, there will be JS errors.
 
//Set delay before submenu disappears after mouse moves out of it (in milliseconds)
var delay_hide=500

/////No need to edit beyond here



function showit(event,which){    
    
    clear_delayhide()

    var tempthecontent=(which==-1)? "" : submenu[which]
    
    if((typeof tempthecontent == 'undefined') || (tempthecontent.length<=0)){
        return false;
    }
    
    thecontent = tempthecontent;
    // thecontent="<table><tr>"+thecontent+"</tr></table>"

    if(which=='nothing')
        thecontent="";
    if (document.getElementById||document.all)
    menuobj.innerHTML=encode_ParamValue(thecontent);
    else if (document.layers){
    menuobj.document.write(thecontent)

    menuobj.document.close()
    }
     var widthforarabic = window.innerWidth
|| document.documentElement.clientWidth
|| document.body.clientWidth;
    var wdsubmenu = document.getElementById("wdsubmenu");
    if((thecontent.length>0) && wdsubmenu){
        event = event || window.event;
        var source = event.target || event.srcElement;    
        
        var childs = wdsubmenu.getElementsByTagName("div");
        if(childs){
            wdsubmenu.style.display = "block";
            
            var wdsubmenuproxy = document.getElementById("wdsubmenuproxy");
            if(wdsubmenuproxy){
                wdsubmenuproxy.focus();
            }
            
            if(childs.length > 10){
                var childsHeight = childs[0].clientHeight * 10;
                wdsubmenu.style.height = childsHeight - 10 + "px";
            } else {
                wdsubmenu.style.height = "";
            }
        }
        
        if(strLocale=='ar-SA' || strLocale=='ar'){
         wdsubmenu.style.right = widthforarabic-70-findAbsPosX(source) + "px";
         
    }
    else{
         wdsubmenu.style.left = findAbsPosX(source) + "px"; 
    }
       
        var viewport = isElementInViewport(wdsubmenu);
        if(!viewport.IsInHView){
             if(strLocale=='ar-SA' || strLocale=='ar'){
          wdsubmenu.style.right = widthforarabic-70-findAbsPosX(source) - wdsubmenu.clientWidth + source.clientWidth + 10 + "px";    
    }
    else{
         wdsubmenu.style.left = findAbsPosX(source) - wdsubmenu.clientWidth + source.clientWidth + 10 + "px";    
    }
                   
        }
        
        /*var mainWDMenuObj = document.getElementById("myMenuID");
        if(mainWDMenuObj){
            removeChildrenCSS(mainWDMenuObj, "tabItemSelected");
            addClass(source, "tabItemSelected");
        }*/
    }/*else {
        wdsubmenu.style.display = "none";
    }*/
     showIframeMenu(wdsubmenu) ;
}

function showitresponsive(event,which,openDiv){    
    
    clear_delayhide();
    
    if(typeof openDiv=='undefined'){
        openDiv='';
    } else if(openDiv=='mm'){
        hideMoreOpt();
    }

    var tempthecontent=(which==-1)? "" : submenu[which]
    
    if((typeof tempthecontent == 'undefined') || (tempthecontent.length<=0)){
        hideWDSubMenu();
        return false;
    }
    
    thecontent = tempthecontent;

    if(which=='nothing')
        thecontent="";
    if (document.getElementById||document.all)
    menuobj.innerHTML=encode_ParamValue(thecontent);
    else if (document.layers){
    menuobj.document.write(thecontent)

    menuobj.document.close()
    }
     var widthforarabic = window.innerWidth
|| document.documentElement.clientWidth
|| document.body.clientWidth;
    var wdsubmenu = document.getElementById("wdsubmenu");
    if((thecontent.length>0) && wdsubmenu){
        event = event || window.event;
        var source = event.target || event.srcElement;    
        
        var childs = wdsubmenu.getElementsByTagName("div");
        if(childs){
            wdsubmenu.style.display = "block";
            
            var wdsubmenuproxy = document.getElementById("wdsubmenuproxy");
            if(wdsubmenuproxy){
                wdsubmenuproxy.focus();
            }
            
            if(childs.length > 10){
                var childsHeight = childs[0].clientHeight * 10;
                wdsubmenu.style.height = childsHeight - 10 + "px";
            } else {
                wdsubmenu.style.height = "";
            }
        }
        
        var left = 0;
        var rd = getRealDimension(document.getElementById("MoreOptDiv"));
        if (strLocale == 'ar-SA' || strLocale == 'ar') {
            if(openDiv =='mm'){
               left = (findAbsPosX(source) -75);
               
               if(left < 0){
                   left = findAbsPosX(document.getElementById("MoreOptDiv")) + rd.Width + 1;
               }
               
               wdsubmenu.style.left = left + "px";
               wdsubmenu.style.top =(source.offsetTop + getRealDimension(document.getElementById("wdesk:placeHolder").Height)) + "px";
            } else {
               left = (findAbsPosX(document.getElementById("MoreOptDiv"))- rd.Width -70);
               
                if(left < 0){
                   left = findAbsPosX(document.getElementById("MoreOptDiv")) + rd.Width + 1;
               }
                
                wdsubmenu.style.left = left + "px";
                wdsubmenu.style.top =findAbsPosY(source) + "px";
            }
            //wdsubmenu.style.top =(source.offsetTop + getRealDimension(document.getElementById("wdesk:placeHolder").Height)) + "px";

        } else {
            if(openDiv =='mm'){
                left = (findAbsPosX(source) -75);
                
                if(left < 0){
                   left = findAbsPosX(document.getElementById("MoreOptDiv")) + rd.Width + 1;
               }
                
                wdsubmenu.style.left = left + "px";
                wdsubmenu.style.top =(source.offsetTop + getRealDimension(document.getElementById("wdesk:placeHolder")).Height) + "px";
            } else {
                left = (findAbsPosX(document.getElementById("MoreOptDiv")) - rd.Width - 70);
                
               if(left < 0){
                   left = findAbsPosX(document.getElementById("MoreOptDiv")) + rd.Width + 1;
               }
               
               wdsubmenu.style.left = left + "px";
               wdsubmenu.style.top =findAbsPosY(source) + "px";
            }
            //wdsubmenu.style.top =(source.offsetTop + getRealDimension(document.getElementById("wdesk:placeHolder")).Height) + "px";
        }
       
//        var viewport = isElementInViewport(wdsubmenu);
//        if(!viewport.IsInHView){
//             if(strLocale=='ar-SA' || strLocale=='ar'){
//          wdsubmenu.style.right = widthforarabic-70-findAbsPosX(source) - wdsubmenu.clientWidth + source.clientWidth + 10 + "px";    
//    }
//    else{
//         wdsubmenu.style.left = findAbsPosX(source) - wdsubmenu.clientWidth + source.clientWidth + 10 + "px";    
//    }
//                   
//        }
       
    }
     showIframeMenu(wdsubmenu) ;
}

function resetit(e){
if (document.all&&!menuobj.contains(e.toElement))
delayhide=setTimeout("showit(event,-1)",delay_hide)
else if (document.getElementById&&e.currentTarget!= e.relatedTarget&& !contains_ns6(e.currentTarget, e.relatedTarget))
delayhide=setTimeout("showit(event,-1)",delay_hide)
}

function clear_delayhide(){
if (window.delayhide)
clearTimeout(delayhide)
}

function contains_ns6(a, b) {
while (b!=null && b.parentNode)
if ((b = b.parentNode) == a)
return true;
return false;
}
 
 function convertIT(divID){
    var mainMenuString="";
    var custom; 
    var moreOptDivString="";

    if(CustomShow())
        custom='';
    else
        custom=OP_WI_CUSTOM_INTERFACES; 
    var hideWdeskSubMenu="" ;
    var hideWdeskMenu=[]; 
    if(typeof hideWdeskSubMenuitems != 'undefined'){
        hideWdeskSubMenu=hideWdeskSubMenuitems();
        hideWdeskSubMenu=hideWdeskSubMenu.split(","); 
    }
    if(typeof hideWdeskMenuitems != 'undefined'){
        hideWdeskMenu=hideWdeskMenuitems(); 
        hideWdeskMenu=hideWdeskMenu.split(",");
    }
    
    /*var bCalledFromMail = (typeof CalledFrom == 'undefined')? false: (CalledFrom == "M");
    if(bCalledFromMail){
        hideWdeskMenu[hideWdeskMenu.length] = "Close";
    }*/
    
    mainMenuString+=""
    var isHideItem=false;
    for(var i=0;i<myMenu.length;i++){ 
        for(var k=0;k<hideWdeskMenu.length ;k++){
            isHideItem=false;
            if(myMenu[i][1]==hideWdeskMenu[k]){
                isHideItem=true;
                break;
            } 
        }
        if(myMenu[i][1]!=custom && !isHideItem){
        

            if(myMenu[i].length==5){
                if(bRespWdesk){
                    if(myMenu[i][3]=="Save" || myMenu[i][3]=="Close" || myMenu[i][3]=="Introduce" || myMenu[i][3]=="Done" || myMenu[i][3]=="Chat"){
                         var cssClass='Tertiary_btn';
                         if(myMenu[i][3]=="Save" || myMenu[i][3]=="Chat"){
                            cssClass='secondaryButtonStyle'
                        } else if(myMenu[i][3]=="Introduce" || myMenu[i][3]=="Done"){
                            cssClass='primary_btn';
                        }
                        mainMenuString+="<a class='"+cssClass+" d-if btn-head al-ic wcp' id='"+myMenu[i][1]+"' onclick="+myMenu[i][2]+" title='"+myMenu[i][4]+"'><label class='"+myMenu[i][3]+" al-text wcp d-xs-inline-block d-sm-inline-block d-md-inline-block d-lg-inline-block d-xl-inline-block'></label><label style='line-height:2' class='wdverticalaligntop al-mr6 wcp d-none d-sm-none d-md-none d-lg-inline-block d-xl-inline-block'>"+myMenu[i][1]+"</label></a><span style='visibility:hidden'>.</span>"; 
                    } else {
                        moreOptDivString+="<span class='wdalignleft wcp' onMouseover='showitresponsive(event,"+i+")' onclick="+myMenu[i][2]+"><a class='cursorpointer al-mr6' style='white-space:nowrap;'>"+myMenu[i][1]+"</a></span>";
                    }
                    
                } else {
                    mainMenuString+="<td><a class='cursorpointer' style='padding: 0px;white-space:nowrap' id='"+myMenu[i][1]+"'  title='"+myMenu[i][4]+"' onMouseover=showit(event,'nothing') onClick="+myMenu[i][2]+">"+myMenu[i][1]+"<span class='separatorclass'>|</span></a></td>" ;
                }
                
            }
            else{
		
                if(bRespWdesk){
                    if(myMenu[i][3]=="CustomInterfaces"){
                        mainMenuString+=" <a class='Tertiary_btn d-if wcp btn-head al-ic' id='"+myMenu[i][1]+"' title='"+myMenu[i][4]+"' onMouseover="+"showitresponsive(event,"+i+",'mm')"+"><label class='"+myMenu[i][3]+" al-text d-xs-inline-block d-sm-inline-block wcp d-md-inline-block d-lg-inline-block d-xl-inline-block'></label><label style='line-height:2' class='wdverticalaligntop al-mr6 wcp d-none d-sm-none d-md-none d-lg-inline-block d-xl-inline-block'>"+myMenu[i][1]+"</label></a><span style='visibility:hidden'>.</span>";
                    } else {
                        moreOptDivString+="<span class='wdalignleft wcp' style='position:relative' onMouseover='showitresponsive(event,"+i+")'><a  class='cursorpointer' style='white-space:nowrap;'>"+myMenu[i][1]+"</a><span class='PaginationRightEnableSm carot'></span> </span>";
                    }                    
                } else {
                    mainMenuString+="<td><a  class='cursorpointer' style='padding: 0px;white-space:nowrap' onMouseover="+"showit(event,"+i+")"+">"+myMenu[i][1]+"</a><span class='separatorclass'>|</span></td>";
                }
                
                var subString='' 
                for(var j=5;j<myMenu[i].length;j++){
                    var isHideSubItem=false;
                    for(var k=0;k<hideWdeskSubMenu.length ;k++){
                        if(myMenu[i][j][1]==hideWdeskSubMenu[k]){
                            isHideSubItem=true;
                            break;
                        } 
                    }
                    if(!isHideSubItem){
                        subString+="<div title='"+myMenu[i][j][4]+"' onmousedown="+myMenu[i][j][2]+">"+myMenu[i][j][1]+"</div>"
                    }
                }

              
                submenu[i]=subString+"<a style='width:0px;height:0px' id='wdsubmenuproxy' onblur='hideWDSubMenu();' href='about:blank'></a>";

            }
        }
 
    }

    var menudiv=document.getElementById(divID);
        
    mainMenuString+=""
    
    menudiv.innerHTML=encode_ParamValue(mainMenuString);
    if(bRespWdesk){
        var moreBtn=document.getElementById("menuMoreOpt");
       var moreOptDiv=document.getElementById("MoreOptDiv");
       var temp=document.getElementById("template");
       moreOptDivString+="";
       moreOptDiv.innerHTML=encode_ParamValue(moreOptDivString);
       for(var i=0;i<temp.children.length;i++){
           moreOptDiv.innerHTML +=temp.children[i].outerHTML;
       }
       if(checkMenuOptionDisplay()){
            removeCSS(moreBtn,"dn");
            addCSS(moreBtn,"db");            
       }
    }

}

function checkMenuOptionDisplay(){
    var temp=document.getElementById("MoreOptDiv");
    for(var i=0;i<temp.children.length;i++){
        if((temp.children[i].style.display !="none") || (hasCSS(temp.children[i],"db"))){
              return true; 
        }
    }
}

function displayMoreOpt(event) {
    var moreOptDiv = document.getElementById("MoreOptDiv");
    hideAllOAPMenu(moreOptDiv);
    if (hasCSS(moreOptDiv, "db")) {
        removeCSS(moreOptDiv, "db");
        addCSS(moreOptDiv, "dn");
        moreOptDiv.style.display = 'none';
        hideIframe('ifrmMoreOptDiv');
    } else {
        removeCSS(moreOptDiv, "dn");
        addCSS(moreOptDiv, "db");
        moreOptDiv.style.display = 'block';
        event = event || window.event;
        var source = event.target || event.srcElement;
        var left = findAbsPosX(source) + getRealDimension(source).Width - getRealDimension(document.getElementById("MoreOptDiv")).Width;
        
        if(left < 0){
            left = findAbsPosX(source);
        }
        
        moreOptDiv.style.left =  left + "px";
        moreOptDiv.style.top = getRealDimension(document.getElementById("wdesk:placeHolder")).Height + "px";
        showWrapperIframe(moreOptDiv,'ifrmMoreOptDiv');
    }
    
    cancelBubble(event);
}

 /*function convertIT(divID){
    var mainMenuString="";
    var custom; 

    if(CustomShow())
        custom='';
    else
        custom=OP_WI_CUSTOM_INTERFACES; 
    var hideWdeskSubMenu="" ;
    var hideWdeskMenu=""; 
    if(typeof hideWdeskSubMenuitems != 'undefined'){
        hideWdeskSubMenu=hideWdeskSubMenuitems();
        hideWdeskSubMenu=hideWdeskSubMenu.split(","); 
    }
    if(typeof hideWdeskMenuitems != 'undefined'){
        hideWdeskMenu=hideWdeskMenuitems(); 
        hideWdeskMenu=hideWdeskMenu.split(",");
    }
    mainMenuString+="<table cellpadding='0' cellspacing='0'><tr>"
    var isHideItem=false;
    for(var i=0;i<myMenu.length;i++){ 
        for(var k=0;k<hideWdeskMenu.length ;k++){
            isHideItem=false;
            if(myMenu[i][1]==hideWdeskMenu[k]){
                isHideItem=true;
                break;
            } 
        }
        if(myMenu[i][1]!=custom && !isHideItem){
        

            if(myMenu[i].length==5){
                mainMenuString+="<td><a class='cursorpointer' style='padding: 0px;white-space:nowrap' id='"+myMenu[i][1]+"'  title='"+myMenu[i][4]+"' onMouseover=showit('nothing') onClick="+myMenu[i][2]+">"+myMenu[i][1]+"<span class='separatorclass'>|</span></a></td>" ;
            }
            else{
		
                mainMenuString+="<td><a  class='cursorpointer' style='padding: 0px;white-space:nowrap' onMouseover="+"showit("+i+")"+">"+myMenu[i][1]+"<span class='separatorclass'>|</span></a></td>";
                var subString='' 
                for(var j=5;j<myMenu[i].length;j++){
                    var isHideSubItem=false;
                    for(var k=0;k<hideWdeskSubMenu.length ;k++){
                        if(myMenu[i][j][1]==hideWdeskSubMenu[k]){
                            isHideSubItem=true;
                            break;
                        } 
                    }
                    if(!isHideSubItem){
                        subString+="<td nowrap><a class='linkstyle wdSubMenuStyle' title='"+myMenu[i][j][4]+"' onClick="+myMenu[i][j][2]+">"+myMenu[i][j][1]+"<span class='separatorclass'>|</span></a></td>"
                    }
                }

              
                submenu[i]=subString+"";

            }
        }
 
    }

    var menudiv=document.getElementById(divID);
    mainMenuString+="</tr></table>"

    menudiv.innerHTML=mainMenuString;

}*/

function showIframeMenu(ref)
{
     var IfrRef = document.getElementById('HiddenMenuDiv');
    if(typeof IfrRef!= 'undefined' && IfrRef!=null){
      
        IfrRef.style.width = ref.offsetWidth;
        IfrRef.width = ref.offsetWidth;
        IfrRef.style.height = ref.offsetHeight;
        IfrRef.height = ref.offsetHeight;
        IfrRef.style.top = ref.offsetTop+'px';	   
        IfrRef.style.left = ref.style.left;
        IfrRef.style.zIndex = ref.style.zIndex - 1;
        IfrRef.style.display = "";
    }
    
    
}

function showWrapperIframe(ref,ifrRefId)
{
    var IfrRef = typeof ifrRefId != 'undefined' ? document.getElementById(ifrRefId):null;
    if(typeof IfrRef!= 'undefined' && IfrRef!=null){     
        IfrRef.style.width = ref.offsetWidth;
        IfrRef.width = ref.offsetWidth;
        IfrRef.style.height = ref.offsetHeight;
        IfrRef.height = ref.offsetHeight;
        IfrRef.style.top = ref.offsetTop+'px';	   
        IfrRef.style.left = ref.style.left;
        var zInd = ref.style.zIndex;
        IfrRef.style.zIndex = (typeof zInd !='undefined' && zInd!='') ? ref.style.zIndex - 1:'999';
        IfrRef.style.display = "";
    }  
}
