
/*
url-loading object and a request queue built on top of it
*/

/* namespacing object */
var net=new Object();

net.READY_STATE_UNINITIALIZED=0;
net.READY_STATE_LOADING=1;
net.READY_STATE_LOADED=2;
net.READY_STATE_INTERACTIVE=3;
net.READY_STATE_COMPLETE=4;

/*--- content loader object for cross-browser requests ---*/
net.ContentLoader=function(url,onload,onerror,method,params,async,contentType){


var indicatorId = randomANString();

    url = appendUrlSessionAjax(url);
    if(url.indexOf("?")>0)
    {
        url=url + "&sid="+ Math.random();
    }
    else
    {
        url=url + "?sid="+ Math.random();
    }

    if(url.indexOf("?")>0)
    {
        if(WD_SID != undefined || WD_SID != null)
            url=url + "&WD_SID="+ WD_SID;
    }
    else
    {
        if(WD_SID != undefined || WD_SID != null)
            url=url + "?WD_SID="+ WD_SID;
    }
     url += "&CustomAjax=true";     //to handle error in case of ajax call through net.contentLoader
    var ret=null;
    
    
        this.indicatorId = indicatorId;
        CreateIndicator(indicatorId);
   
    this.req=null;
    this.onload=onload;
    this.onerror=(onerror) ? onerror : this.defaultError;
    this.loadXMLDoc(url,method,params,async,contentType);
}

function createXMLHttpRequest() {
    //try {return new ActiveXObject("Msxml2.XMLHTTP");} catch (e) {}
    try {return new ActiveXObject("Microsoft.XMLHTTP");} catch (e) {}
    try {return new XMLHttpRequest();} catch(e) {}
    return null;
}

function ContentLoaderWrapperData(url,onload,onerror,method,params,async,contentType,requestData){
    var trui= getActionUrlFromURL(url);
    var servletUrl = "/webdesktop/secuidsv";
    (typeof WD_SID != 'undefined' && WD_SID != null) && (servletUrl += "?WD_SID=" + WD_SID);
            
    var xhReq = createXMLHttpRequest();
    //createIndicator(indicatorid);
    xhReq.open("POST", servletUrl, false);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhReq.onreadystatechange = onResponse;
    
    xhReq.send("T-URI="+trui);
   
    function onResponse() {        
        try {
            
            var wd_rid;
            
            if (xhReq.readyState==4) { 
                if (xhReq.status==200) {

                   wd_rid =  xhReq.getResponseHeader("WD_RID");
                   
                   if(params != undefined)
                   {
                       params = params+"&WD_RID="+wd_rid;
                      // return params;
                   }
                   else
                   {
                       url = url+"&WD_RID="+wd_rid;
                      //  return url;
                   }
                    var objGenerateIndex= new net.ContentLoader(url,onload,onerror,method,params,async,contentType);
                    for(var i=0;i<requestData.length;i++){
                        var kid=Object.keys(requestData[i])[0];
                        objGenerateIndex[kid]=requestData[i][kid];
                    }
                     
                } 
            }       
        } catch(e) {
            alert(ERROR_FETCHING_DATA);
        }
    }
}
function getActionUrlFromURL(sURL)
{
    var ibeginingIndex=sURL.indexOf("?");
    if (ibeginingIndex == -1)
        return sURL;
    else
        return sURL.substring(0,ibeginingIndex);
 }

function ContentLoaderWrapper(url,onload,onerror,method,params,async,contentType){
    var trui= getActionUrlFromURL(url);
    var servletUrl = "/webdesktop/secuidsv";
    (typeof WD_SID != 'undefined' && WD_SID != null) && (servletUrl += "?WD_SID=" + WD_SID);
            
    var xhReq = createXMLHttpRequest();
    //createIndicator(indicatorid);
    xhReq.open("POST", servletUrl, false);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    var refloader;
    xhReq.onreadystatechange = onResponse;
    
    xhReq.send("T-URI="+trui);
   
    function onResponse() {        
        try {
            
            var wd_rid;
            
            if (xhReq.readyState==4) { 
                if (xhReq.status==200) {

                   wd_rid =  xhReq.getResponseHeader("WD_RID");
                   
                   if(params != undefined)
                   {
                       params = params+"&WD_RID="+wd_rid;
                   }
                   else
                   {
                       url = url+"&WD_RID="+wd_rid;
                   }
                   
                }
                refloader= new net.ContentLoader(url,onload,onerror,method,params, async, contentType);
            }       
        } catch(e) {
            alert(ERROR_FETCHING_DATA);
        }
    }
    return refloader;
}

net.ContentLoader.prototype.loadXMLDoc=function(url,method,params,async,contentType){
    
  if (!method){
    method="GET";
  }

  if(contentType == undefined)
      contentType = '';

  if (contentType == '' && method=="POST"){
    contentType='application/x-www-form-urlencoded';
  }
  if (window.XMLHttpRequest){
    this.req=new XMLHttpRequest();
  } else if (window.ActiveXObject){
    this.req=new ActiveXObject("Microsoft.XMLHTTP");
  }
  if (this.req){
   	try{
      var loader=this;
      this.req.onreadystatechange=function(){
        net.ContentLoader.onReadyState.call(loader);
      }
      if(async == null)
          async = true;
         
      this.req.open(method,url,async);
      if (contentType){
	     this.req.setRequestHeader('Content-Type', contentType);
      }
      this.req.send(params);
      if(!async) {          
          RemoveIndicator(this.indicatorId);          
      }
    }catch (err){
      this.onerror.call(this);
    }
  }

}



net.ContentLoader.onReadyState=function(){
  try{  
  var req=this.req;
  var ready=req.readyState;
  if (ready==net.READY_STATE_COMPLETE){
    var httpStatus=req.status;
    if (httpStatus==200 || httpStatus==0){
                    
        this.onload.call(this);
       
    }
     else if(httpStatus==310)
    {
        window.location= "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";    
    }
    else if(httpStatus==250)
    {
        window.location= "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";    
    }
    else{
        this.onerror.call(this);     
    }
    

    
    RemoveIndicator(this.indicatorId);
    
    
  }
  }
  catch(e){
      try{
          RemoveIndicator(this.indicatorId);
      }catch(e){}
  }

}

net.ContentLoader.prototype.defaultError=function(){
if(this.req.status==250)
{       
   window.location= "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002"; 
}
else if(this.req.status==12029){
    customAlert(ERROR_SERVER); 
}
else
{
   
    customAlert(ERROR_DATA);    
}
}

function randomANString() {
	var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
	var string_length = 10;
	var randomstring = '';
	for (var i=0; i<string_length; i++) {
		var rnum = Math.floor(Math.random() * chars.length);
		randomstring += chars.substring(rnum,rnum+1);
	}
	return randomstring;
}

