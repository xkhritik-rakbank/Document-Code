
function getFieldValueBag(prefix,isApplet)
{   
	var fvb = "";
	var inputObj=ngattribute;
	var val = "";
        var sDateFormat=wiproperty.sDateFormat;
        var queueVar_array=inputObj.split(SEPERATOR1);
	if(isApplet)
	{ 
		var counter;
		counter=0;
               
		 for(var i=0;i<queueVar_array.length;i++)
		{
                    var formEleInfo_array=queueVar_array[i].split(SEPERATOR2);
                    var fieldName=formEleInfo_array[0];
                    var fieldValue=formEleInfo_array[1];
                    var fieldLength=formEleInfo_array[2];
                    var fieldType=formEleInfo_array[3];
                    fvb += 	"<Field><Name>"+prefix+"_"+fieldName+"</Name><Value>"+ fieldValue + "</Value></Field>" ;
			counter++;
		}
		
                fvb = "<FieldValueBag><Count>" + counter + "</Count>" + fvb;
		fvb += "</FieldValueBag>";
	}
	else
	{ 
		 for(var i=0;i<queueVar_array.length;i++)
		{
                    var formEleInfo_array=queueVar_array[i].split(SEPERATOR2);
                    var fieldName=formEleInfo_array[0];
                    var fieldValue=formEleInfo_array[1];
                    var fieldLength=formEleInfo_array[2];
                    var fieldType=formEleInfo_array[3];
                    fvb += 	prefix+"_"+fieldName+"\u00B5"+fieldValue+"\u00B6";    
		}
		
		if(fvb!='')
			fvb = fvb.substring(0,fvb.length-1);
	
        }
        
       
	return fvb;
}
function getProperty(){

    var ctst="";
    if(wiproperty.formType=="NGFORM" && (typeof document.wdgc!='undefined') && document.wdgc&&ngformproperty.type=="activex")
        {
            //var ngdata= eval("("+ngformproperty+")");  
        if(typeof document.wdgc.PassDataToNgfUsr !='undefined'){
            document.wdgc.UserId=ngformproperty.UserIndex;
            document.wdgc.UserName=ngformproperty.UserName;
            document.wdgc.WFProcessName=ngformproperty.WFProcessName;
            document.wdgc.WFActivityName=ngformproperty.WFActivityName;
            document.wdgc.WFFolderId=ngformproperty.WFFolderId;
          
            document.wdgc.PassDataToNgfUsr(ngformproperty.WFGeneralData);
            document.wdgc.WFGeneralData = ngformproperty.WFGeneralData;
            
            if (windowProperty.winloc == "M")
             document.wdgc.WindowTitle=window.top.document.title + ctst;
            else if (windowProperty.winloc =="S")
               document.wdgc.WindowTitle=window.top.document.title + ctst;
            else
               document.wdgc.WindowTitle=window.top.opener.top.document.title + ctst;

            document.wdgc.UseServerDateFormat = true;
            document.wdgc.WFCacheTime=ngformproperty.WFCacheTime;

            document.wdgc.WFCacheFile=ngformproperty.WFCacheFile; 

            document.wdgc.FileCompressed = true;

            document.wdgc.FileUrl=ngformproperty.FileUrl;

            var fvb=getFieldValueBag(document.wdgc.NGClassString,false);

            if(typeof fvb !='undefined' && Trim(fvb)!='')
            document.wdgc.FieldValueBag=fvb;
           }
           else{
                customAlert("form view plugin not installed");
        }
    }
    else if(wiproperty.formType=="NGFORM" && (typeof document.wdgc!='undefined') && document.wdgc&&ngformproperty.type=="applet")
        {
            if((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm){                
            } else {
                //var fvb=getFieldValueBag(document.wdgc.getNGClassString(),true);            
                var fvb = strAttribData;
                //alert("Going to set data \n\n"+fvb);
                if(document.wdgc){
                    if(typeof fvb !='undefined' && Trim(fvb)!='')
                        document.wdgc.setFieldValueBag(fvb);
                }
            }
       }
}

function saveNGForm()
{
	var MAIN_SEPARATOR = "\u00B6";
	var SUB_SEPARATOR = "\u00B5";
	var msg ="";
	var str="";
        if (ngformproperty.type=="applet")
	{       
		var status='';    
                if(typeof document.wdgc != 'undefined'){
                    status= document.wdgc.ValidateControls(msg);
                }

		if (status == false)
		{
			//alert(INCOMPATIBLE_FORM_DATA);
			return 'true';
		}
	}
	else
	{
                var status='';    
		status= document.wdgc.ValidateControls(msg);                
		if (status == false)
		{
			//alert(INCOMPATIBLE_FORM_DATA);
			return 'true';
		}                
        }
        return 'false';        
}

function getNGFormValuesForAjax(){

    var MAIN_SEPARATOR = "\u00B6";
    var SUB_SEPARATOR = "\u00B5";
    var qstring=""; 
if(!(ngformproperty.type=="applet")){ 
        var formWindow=getWindowHandler(windowList,"formGrid");
        var formBuffer = new String(document.wdgc.FieldValueBag);        
        var str = document.wdgc.NGClassString + "_";

        var formArray = formBuffer.split(MAIN_SEPARATOR );
        var tempArray;
        for ( var i=0;i<formArray.length;i++)
        {
            tempArray = formArray[i].split(SUB_SEPARATOR);
            if (tempArray[0].indexOf("_") != -1)
            {
                fieldName =tempArray[0].substring(tempArray[0].indexOf(str)+str.length, tempArray[0].length);
                                
                fieldValue=tempArray[1];
                qstring += encode_utf8("wdesk:"+fieldName) +  "=" + encode_utf8(fieldValue) + "&"; 				
                        }
        }
          }
        else{
            if((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm){                
            } else {
                var formBuffer=document.wdgc.getFieldValueBagEx();     
            
                
               //alert("formBuffer =   "+formBuffer);
                
                qstring += makeVarFromXml(formBuffer);
            }    
            //alert(qstring);
                
        }                
    return qstring;
}
function getfvbForset(varName,varValue,isapplet){
	var fvb = "";
	var attrList =ngattribute;
	var val = "";
	var prefix="";
        var sDateFormat=wiproperty.sDateFormat;
	 var varAttr=ngattribute;
	 var queueVar_array=varAttr.split(SEPERATOR1);
	  for(var i=0;i<queueVar_array.length;i++)
	{
           var formEleInfo_array=queueVar_array[i].split(SEPERATOR2);
           var fieldName=formEleInfo_array[0];
           var fieldType=formEleInfo_array[3];
	  if(fieldName==varName)
		break;
	}
	/*if(isapplet)
	{	prefix=document.wdgc.getNGClassString();
		
			if(fieldType==NG_VAR_DATE)
				 fvb = 	"<Field><Name>"+prefix+"_"+varName+"</Name><Value>"+ LocalToDB(varValue,sDateFormat) + "</Value></Field>" ;            
             else
                  fvb = 	"<Field><Name>"+prefix+"_"+varName+"</Name><Value>"+ varValue + "</Value></Field>" ;
		
		
	}
	else{
			var prefix = document.wdgc.NGClassString;
			if(fieldType==NG_VAR_DATE)
				 fvb = 	prefix+'_'+varName+'\u00b5'+LocalToDB(varValue,sDateFormat);
             else
                  fvb = prefix+'_'+varName+'\u00b5'+varValue;
		
	}*/
        if(fieldType==NG_VAR_DATE)
            varValue = LocalToDB(varValue,sDateFormat);
	return varValue;
}

var strAttribName="";
var strValue = "";
var strFormVal="";

function makeVarFromXml(strTemp) {
    var xmlDoc="";
    var isIE  = (navigator.appName.indexOf("Microsoft") != -1);
    if(isIE){
        try //Internet Explorer
        {
            xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
            xmlDoc.async="true";
            xmlDoc.loadXML(strTemp);
        }
        catch(e) {//alert(e.message)        
        }
    }
    else {
        try //Firefox, Mozilla, Opera, etc.
        {
            var parser=new DOMParser();
            xmlDoc=parser.parseFromString(strTemp,"text/xml");
        }
        catch(e) {//alert(e.message)        
        }
    }
    
    var j =0;
    var xvar =xmlDoc.documentElement;       
    
    strFormVal="";            
    strAttribName = "wdesk:";
    extractElement(xvar,strAttribName);       
    
   //alert("query string =  "+strFormVal);
    return strFormVal;
}

function AttribObject()
{
 this.AttribName = '';
 this.AttribType = '';
 this.Unbounded = 'N';
 this.SubElements = new Array(); 
 }


function extractElement(Node,strAttribName) {
    var NodesArray = new Array();    
    var objAttrib;    
    if(Node != null){
        if(Node.hasChildNodes()){                               //case for the subnodes it may be node or text val
            var i = 0;        
            for (i=0;i<Node.childNodes.length;i++) {
                if(Node.childNodes[i].tagName) {

                    if(!containsNodeCheck(NodesArray,Node.childNodes[i].tagName)) {     //contains check
                        objAttrib = new AttribObject();
                        objAttrib.AttribName = Node.childNodes[i].tagName;
                        var UnboundedCheck = Node.childNodes[i].getAttribute("Unbounded"); 
                        //alert(UnboundedCheck);
                        if(UnboundedCheck == 'Y' || UnboundedCheck == 'y')
                        objAttrib.Unbounded = "Y";

                        objAttrib.SubElements = GetElementsByTagName(Node,Node.childNodes[i].tagName);            
                        NodesArray[NodesArray.length]= objAttrib;
                    }
                }
                else {                    
                    if(Node.firstChild){ 
                        strValue=Node.firstChild.nodeValue;
                        appendValue(strAttribName.substring(0,strAttribName.lastIndexOf('-')),strValue);
                    }
                    else {
                        strValue="";              
                        appendValue(strAttribName.substring(0,strAttribName.lastIndexOf('-')),strValue);
                    }
                }

            }

            var j=0;
            var SubChilds;
            for (j=0;j<NodesArray.length;j++) {
                SubChilds = NodesArray[j].SubElements;

                if(NodesArray[j].Unbounded == 'Y')			//identified as array ***********to be identified by attrib properties*****
                {
                    var i = 0;
                    for(i=0;i<SubChilds.length;i++) {
                        extractElement(SubChilds[i],strAttribName+NodesArray[j].AttribName.toUpperCase()+'-'+i+'-');   
                    }                
                    var arrLength = SubChilds.length;
                    if(!SubChilds[0].childNodes[0])
                       arrLength=0;
                    appendValue((strAttribName+NodesArray[j].AttribName.toUpperCase()+"-value"),arrLength+"");
                }

                else {
                    var i = 0;
                    for(i=0;i<SubChilds.length;i++) {
                        extractElement(SubChilds[i],strAttribName+NodesArray[j].AttribName.toUpperCase()+'-');   
                    }
                }            
            }        
        }else {
            strValue="";              
            appendValue(strAttribName.substring(0,strAttribName.lastIndexOf('-')),strValue);
        }
    }
}

function GetElementsByTagName(ElementNode,tagname)
{
    var RetArr = new Array();
    var i = 0;
    for(i=0;i<ElementNode.childNodes.length;i++) {
        if(tagname == ElementNode.childNodes[i].tagName)
                RetArr[RetArr.length]   =  ElementNode.childNodes[i];                
        }        
    return RetArr;
    }

function containsNodeCheck(NodeArray,AttribName) {
    var i = 0;
    
    for(i=0;i<NodeArray.length;i++) {
        if(AttribName == NodeArray[i].AttribName) {
            return true;
            break;
        }
    }
    
    return false;
}

function appendValue(strAttribName,strValue) {
    if(strFormVal.length==0) {
        strFormVal = encode_utf8(strAttribName)+"="+encode_utf8(strValue)+"&";
    }
    else {
        strFormVal = strFormVal+encode_utf8(strAttribName)+"="+encode_utf8(strValue)+"&";
    }
}