
var WD_SID;
function setValue(ref,hId){
    //alert("inside set value");
    //var iframe =window.parent.parent.getComponentRef(strCompInsId);
   //alert(iframe.id) ;
    var arr = ref.id.split(":");
    var len = arr.length;   
    var strName = "";
    for(var count=0;count<len-1;count++){
        if(count==0)
            strName = arr[count] ;
        else
        {
            strName=strName + ":" + arr[count] ;
        }
    }
    
    var hidId = strName+":"+hId;  
    var id = document.getElementById(hidId).value;  
    
    var refValue = document.getElementById(ref.id).title;  
    
    if(strNoneType>0)
    {
        id = strNoneID;
        if(strReturnNoneText == 0)
            refValue = '';
    }
    if(strparentFlag!="true")
    {
        try
        {
            try
            {
            window.parent.document.getElementById(strTextFieldID).value=refValue;
            window.parent.document.getElementById(strIDFieldID).value=id;
            window.parent.document.getElementById(strTextHidden).value=refValue;
            }
            catch(e){}

            if(strCallback.length>0 && Trim(strCallback).length>0)
            {
                var Temp='window.parent.' + strCallback + '();';              
                parseJSON(Temp);               
            }
            removeIFrame(CurrentPickListId);
        }catch(e){           
        }
    }
    else if(strparentFlag=="true")
    {
        try
        {
            iframe=window.parent.document.getElementById(strparentIFrame);
            iframe.contentWindow.document.getElementById(strTextFieldID).value=refValue;
            iframe.contentWindow.document.getElementById(strIDFieldID).value=id;
            iframe.contentWindow.document.getElementById(strTextHidden).value=refValue;
            if(strCallback.length>0 && Trim(strCallback).length>0)
            {
                var Temp='iframe.contentWindow.' + strCallback + '();';
                parseJSON(Temp);
            }
            removeIFrame(CurrentPickListId);
        }catch(e){          
        }
    }

    
}
function openCalenderPicklist(ref,option,txtboxid,varType)
{
    
    var refId = ref.id;
    var txtbox = ref.form.id+":"+txtboxid;
    var bShortDate = true;
    cal = openCalender(document.getElementById(DataTextBoxId),cal,bShortDate);
}
function ShowPickList(reference,type,nameCtrl,iDCtrl,hidNameCtrl,flag,NoneType,NoneID,ReturnNoneText,FunctionName,Extra1,Extra2,Extra3,Extra4,Extra5,parentFlag,EmailIdCntrl,OpenedFor,processDefId,activityId,taskId,scope)
{
    var posLeft = findAbsPosX(reference); 
    var posTop = findAbsPosY(reference);
    var isModal = false;
    var picklistWt = 200;
    var picklistHt = 200;
    var url;
    var iframeHeight=290;
    var picklistwidth = 250;
    var formid=reference.form.id;

    var pickListID="PickList";
    var callBack="";
    if(FunctionName!=undefined){
        if(Trim(FunctionName).length>0)
        {
            callBack="&CallBack=" + Trim(FunctionName);
        }
    }
    

    if(type=='ValuePickList')
    {
        iframeHeight=230;
        picklistwidth = 210;
           var arr = reference.id.split(":");
            var len = arr.length;
            var strName = "";
          for(var count=0;count<len-1;count++){
             if(count==0)
                 strName = arr[count] ;
             else
             {
            strName=strName + ":" + arr[count] ;
            }
          }
          //nameCtrl = strName+":"+nameCtrl;
          //iDCtrl = strName+":"+iDCtrl;
          //hidNameCtrl = strName+":"+hidNameCtrl;
          var iDCtrlValue = document.getElementById(iDCtrl).value;
          var hidNameCtrlValue = document.getElementById(hidNameCtrl).value;
          var Extra1Value = Extra1;
          var Extra2Value = Extra2;
          pickListID="Picklist";
          url="/webdesktop/components/search/picklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrlValue + "&strFormFieldTextHidden=" + hidNameCtrlValue + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID +"&QueueId="+Extra1Value+"&ProcessDefId="+Extra2Value+ "&Callback=" + FunctionName + "&flag" + flag + "&PopupDivId=" + pickListID+"&WD_SID="+WD_SID;
       
    }
    else if(type=='VariableList')
        {
            pickListID="VariablePicklist";
            url="/webdesktop/components/search/variablepicklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+ "&ProcessDefID=" +Extra1+ "&ProcessName=" +Extra2+ "&PopupDivId=" + pickListID+"&WD_SID="+WD_SID;
            
        }
    else if(type=='GroupList')
     { 
         activityId = (typeof activityId == 'undefined')? "": activityId;
         processDefId=(typeof processDefId == 'undefined')? "": processDefId;
         taskId=(typeof taskId == 'undefined')? "": taskId;
         scope=(typeof scope == 'undefined')? "": scope;
         picklistHt = iframeHeight=220;
        picklistWt = picklistwidth = 210;
          pickListID="GroupList";
          if(Extra1!=undefined){
        url="/webdesktop/components/search/grouplist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+ "&Callback=" + FunctionName + "&flag=" + flag +"&flagType=" + pickListID + "&compInsId="+Extra1+"&PopupDivId=" + pickListID+"&WD_SID="+WD_SID;
          }else{
                url="/webdesktop/components/search/grouplist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+ "&Callback=" + FunctionName + "&flag=" + flag +"&flagType=" + pickListID+"&PopupDivId=" + pickListID+"&WD_SID="+WD_SID;
          }
          url+="&Width="+picklistWt+"&Height="+picklistHt;
          if(scope=="P"){
              url+="&ProcessDefId="+processDefId+"&ActivityId="+activityId+"&taskid="+taskId;
          }
          posLeft = findPosX(reference); 
          posTop = findPosY(reference);
          isModal = true;
     }else if(type == "QueueList"){
        //   iframeHeight=320;
        iframeHeight=230;
        picklistwidth = 210;
        pickListID="queuepicklist";
        var OpenedFor = OpenedFor;
       
        if(OpenedFor == "PM")  //for process manager
        {
            url="/webdesktop/components/queue/queuelist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+"&comp_ins_id=1&ListType=QP&AuthQFlag=N&MyQFlag=N&BatchingFlag=Y&BatchSize=15&SortOrder=A&OrderBy=2&ShowAddBtnFlag=N&ShowDeleteBtnFlag=N&ShowModifyBtnFlag=N&ShowSetPreferredBtnFlag=N&Comp_height=205&Comp_width=200"+ "&Callback=" + FunctionName + "&flag=" + flag + "&flagType=" + pickListID+"&PopupDivId="+pickListID+"&OpenedFor="+OpenedFor+"&WD_SID="+WD_SID;
        }
        else
        {
         url="/webdesktop/components/queue/queuelist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+"&comp_ins_id=1&ListType=QP&AuthQFlag=N&MyQFlag=N&BatchingFlag=Y&BatchSize=15&SortOrder=A&OrderBy=2&ShowAddBtnFlag=N&ShowDeleteBtnFlag=N&ShowModifyBtnFlag=N&ShowSetPreferredBtnFlag=N&Comp_height=205&Comp_width=200"+ "&Callback=" + FunctionName + "&flag=" + flag + "&flagType=" + pickListID+"&PopupDivId="+pickListID+"&WD_SID="+WD_SID;
        }
        

    } else if(type == "ProcessList"){
        var queueName="";
        var queueId="0";
        var stateflag="B";
        var tat="";
        var usecal="";
        // alert(Extra1);
        if(Extra1 != undefined)
            queueName = Extra1;
        if(Extra2 != undefined)
            queueId = Extra2;
        if(Extra3!= undefined)
          var compInsId = Extra3;
            //stateflag=Extra3;

        if(Extra4!= undefined)
            tat=Extra4;
        if(Extra5!=undefined)
            usecal=Extra5;
        var pickListID="ProcessPickList";

        var OpenedFor = OpenedFor;
        if(Extra3!=undefined){
            url="/webdesktop/components/process/processpicklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+"&QueueName="+queueName+"&QueueId="+queueId+"&stateflag="+stateflag+"&tat="+tat+"&usecal="+usecal+"&compInsId="+compInsId+ "&CallBack=" + FunctionName + "&flag=" + flag +  "&flagType=" + pickListID+"&OpenedFor="+OpenedFor+"&PopupDivId="+pickListID+"&WD_SID="+WD_SID;
        }else{
            url="/webdesktop/components/process/processpicklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+"&QueueName="+queueName+"&QueueId="+queueId+"&stateflag="+stateflag+"&tat="+tat+"&usecal="+usecal+"&CallBack=" + FunctionName + "&flag=" + flag +  "&PopupDivId=" + pickListID+"&OpenedFor="+OpenedFor+"&PopupDivId="+pickListID+"&WD_SID="+WD_SID;
        }
        
        try
        {
            removeIFrame("worksteppicklist"); //so that workstep list if open closed
        }
        catch(e){}
        iframeHeight=220;
        picklistwidth = 210;
    } else if(type == "ActivityList"){
        iframeHeight=220;
        picklistwidth = 300;
        var isAdhoc="";
        if(Extra4 != undefined && Extra4 != "" && Extra4=="Adhoc")
            isAdhoc = Extra4;
        pickListID="worksteppicklist";
        url="/webdesktop/components/workstep/worksteppicklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&ReturnNoneValue=" +ReturnNoneText + "&NoneType=" + NoneType + "&NoneValue=" +NoneID+ "&ProcessDefID=" +Extra1+ "&ProcessName=" +Extra2+ "&Mode=" +Extra3+"&QueueID="+Extra4+ "&Callback=" + FunctionName + "&flag" + flag +  "&flagType=" + pickListID+"&WD_SID="+WD_SID;
        if(isAdhoc!="")
            url=url+"&IsAdhoc=Y";
        
    }

    if(parentFlag != undefined )
    {
        if(parentFlag=="true"){
            //alert(parentFlag+"890");
            url=url +"&parentFlag="+parentFlag+"&parentIFrame="+CurrentPickListId;

        }

        else
        {
          //  parentFlag=="false";
            url=url +"&parentFlag="+parentFlag+"&parentIFrame="+"";
        }

    }
    else
    {
        parentFlag="false";
        url=url +"&parentFlag="+parentFlag+"&parentIFrame="+"";
    }

    //url=url + callBack;
    if(parentFlag=="true"){
        //createPopUpIFrameWrapper(pickListID,url,350,220);
          //alert("11"+parentFlag);
        createIFrame(pickListID,iframeHeight,url,nameCtrl,true,picklistwidth);
    }
    else{
        //createPopUpIFrameWrapper(pickListID,url,250,220);
           
       // alert("11656"+parentFlag);
     //  createIFrame(pickListID,iframeHeight,url,nameCtrl,false,picklistwidth,true);     
     window.popupIFrameOpenerWrapper(this, pickListID, url, picklistWt, picklistHt, posLeft, posTop, false, true, false, isModal);
    }
    
    return false;
}


function createIFrame(IFrameId,height,srcUrl,textboxname,frameFlag,pickWidth,bMiddle)
{
    try
    {
        
        var flag=false;
        var finalWindow=window;
        var frameRelativeLeft =frameRelativeTop=0;
        if(frameFlag)  //if new iframe is outside of all iframes find outside window ref
        {   
            while(1)
            {     
                if(finalWindow.frameElement)
                {  
                    flag=true;
                    var ctrlOld=finalWindow.frameElement;
                    finalWindow=finalWindow.parent;                    
                    if (ctrlOld.offsetParent)
                    {
                        frameRelativeLeft = ctrlOld.offsetLeft
                        frameRelativeTop = ctrlOld.offsetTop
                        while (ctrlOld = ctrlOld.offsetParent)
                        {
                            frameRelativeLeft += ctrlOld.offsetLeft
                            frameRelativeTop += ctrlOld.offsetTop
                        }
                    }
                }
                else
                    break;
            }//end of while
        }
        if(finalWindow.document.getElementById(IFrameId) != null)
            return;
       
        iframe=finalWindow.document.createElement("IFRAME");
      
        // iframe.setAttribute("allowtransparency","true");
        iframe.allowtransparency="true";
        iframe.style.allowtransparency="true";

        iframe.setAttribute("src",srcUrl);
        
        iframe.setAttribute("name", IFrameId);
        iframe.setAttribute("id", IFrameId);
        iframe.className = "iframeShadow ";


        ctrlname= document.getElementById(textboxname);
        bodyCtrlName=finalWindow.document.body;        
        var cdRight=cdLeft=cdTop=cdBottom=0;
        var bodyRight=bodyLeft=bodyTop=bodyBottom=0;
        var picklistTop=pickListLeft=picklistBottom=picklistRight=0;
        var scrollLeft=scrollTop=0;
        var viewportLeft=viewportRight=viewportTop=viewportBottom=0;
        // alert(textboxname);
        var picklistHeight=height;
        var picklistWidth=250;

        if(pickWidth != undefined)
        {
            picklistWidth = pickWidth-0;
        }
        var Lmargin=8;
        var Rmargin=8;
        var margin=5;
        var anotherBrowser=false;
        /*----------------------------------Absolute top-left position of text box--------------------------------------------------*/
        var absoluteleft = absolutetop = 0;
        var tempCtrlname=ctrlname;
       
        if (tempCtrlname.offsetParent)
        {
           
            absoluteleft = tempCtrlname.offsetLeft;
            absolutetop = tempCtrlname.offsetTop;
            while (tempCtrlname = tempCtrlname.offsetParent)
            {
                absoluteleft += tempCtrlname.offsetLeft;
                absolutetop += tempCtrlname.offsetTop;
            }
        }
        absoluteleft += 2;
        absolutetop += 2;
        /*  to find top ,left ,bottom and right of textbox control . Actual top,left is 2 pixel less then calculated*/
         
        try
        {
            if(ctrlname.getBoundingClientRect)//internet explorer
            {
                rcts = ctrlname.getBoundingClientRect();
                bodyRcts=bodyCtrlName.getBoundingClientRect();

                cdRight = rcts.right ;  //these are relative positions
                cdLeft = rcts.left;
                cdTop = rcts.top;
                cdBottom = rcts.bottom ;

                bodyRight = bodyRcts.right ;
                bodyLeft = bodyRcts.left;
                bodyTop = bodyRcts.top;
                bodyBottom = bodyRcts.bottom ;

                if(absoluteleft  !=  cdLeft || absolutetop  !=cdTop)   //to change relative to absolute positions
                {
                    absoluteHorizontalDiff=absoluteleft-cdLeft;
                    absoluteVerticalDiff=absolutetop-cdTop;

                    cdTop+=absoluteVerticalDiff;
                    cdBottom+=absoluteVerticalDiff;
                    cdLeft+=absoluteHorizontalDiff;
                    cdRight+=absoluteHorizontalDiff;
                }
               
            }
            else if(document.getBoxObjectFor) //mozilla
            {
                rcts = document.getBoxObjectFor(ctrlname);
                bodyRcts=finalWindow.document.getBoxObjectFor(bodyCtrlName);

                cdLeft = rcts.x ;
                cdTop = rcts.y ;
                cdRight = rcts.width+ cdLeft;
                cdBottom = rcts.height+cdTop ;

                bodyLeft = bodyRcts.x ;
                bodyTop =  bodyRcts.y ;
                bodyRight =  bodyRcts.width+ bodyLeft;
                bodyBottom =bodyRcts.height+bodyTop ;
            }
            else
            {

                cdLeft =absoluteleft ;
                cdTop = absolutetop ;
                cdRight = curleft+100;
                cdBottom = curtop+10 ;
            }

        }catch(e){}
        /*-------------------------------------to set exact positions-----------------------------------------------------------------*/
        if(cdLeft !=0)
            cdLeft -=2;
        if(cdTop !=0)
            cdTop -=2;
        cdRight -=2;
        cdBottom -=2;

        if(bodyLeft!=0)
            bodyLeft -=2;
        if(bodyTop!=0)
            bodyTop -=2;
        bodyRight -=2;
        bodyBottom -=2;
        /*-----------------------------------To find the active view of window-------------------------------------------------------------------*/
        try
        {
            scrollLeft=bodyCtrlName.scrollLeft;
            scrollTop=bodyCtrlName.scrollTop;
        }
        catch(e)
        {
            scrollLeft=0;
            scrollTop=0;
        }

        viewportLeft=bodyLeft+scrollLeft;
        viewportRight=bodyRight+scrollLeft;
        viewportTop=bodyTop+scrollTop;
        viewportBottom=bodyBottom+scrollTop;
        /*-----------------------------------to set the position of pickList-------------------------------------------------------------------*/

        
        if(flag)   //if it gose outside  of inner pick list
        {
            width=cdRight-cdLeft;
            height=cdBottom-cdTop;

            cdLeft = cdLeft+frameRelativeLeft ;
            cdTop = cdTop+frameRelativeTop ;
            cdRight = cdLeft+width;
            cdBottom = cdTop+height ;
        }

        pickListLeft=cdRight - picklistWidth+Rmargin;				//to show bottom-right of textbox aligned to top-right of picklist
        picklistTop= cdBottom;
        picklistRight=pickListLeft+picklistWidth;
        picklistBottom=picklistTop+picklistHeight;


        if(pickListLeft<viewportLeft)        //right align with control
        {
            pickListLeft=cdLeft-Lmargin;
            picklistRight=pickListLeft+picklistWidth;

        }
        if(picklistRight>viewportRight)  //again right align ,maximum cases not possible
        {
            tempVar=picklistRight-viewportRight-margin;

            pickListLeft=pickListLeft-tempVar;
            picklistRight=picklistRight-tempVar;
        }
        if(picklistBottom>viewportBottom)  //above the control
        {

            picklistBottom=cdTop;
            picklistTop=picklistBottom-picklistHeight;
        }
        if(picklistTop<viewportTop)
        {
            tempVar=viewportTop-picklistTop+margin;

            picklistTop=picklistTop+tempVar;
            picklistBottom=picklistBottom+tempVar;
        }

        var bOpenMiddle=false;
      
        if(bMiddle != undefined) {

            bOpenMiddle = bMiddle;

        }
        if(bOpenMiddle) {
            try{
                pickListLeft=parseInt((bodyRight-bodyLeft)/2)-parseInt(picklistWidth/2);
                picklistTop=parseInt((bodyBottom-bodyTop)/2)-parseInt(picklistHeight/2);
            }catch(ex){}
        }

        iframe.frameBorder="0";
        iframe.style.frameBorder="0";

        iframe.scrolling="no";
        iframe.style.scrolling="no";

        iframe.style.visibility="visible";
        iframe.style.position="absolute";

        iframe.style.width= picklistWidth+"px";
        iframe.style.height=picklistHeight+"px";

        iframe.style.left = pickListLeft;
        iframe.style.top = picklistTop;


        refFrame=finalWindow.document.body.appendChild(iframe);
      
        refFrame.parent=finalWindow;
    //alert(refFrame.document.getElementById(IFrameId).id);

    //alert(iframe.id);
    }
    catch(ex)
    {
    //alert("exception= "+ex);
    }

}


function handlePickListEnter(e,id)
{
    var browser=navigator.appName;
    if(browser=="Netscape")
    {

        if(e.which == 13)
        {
            try
            {
                if(id != undefined)
                {
                    window.document.getElementById(id).focus();
                }
                else
                    setValue();
            }
            catch(e){}
        }
    }
    else
    {
        e=window.event;
        if(e.keyCode == 13)
        {
            try
            {
                if(id != undefined)
                {
                    window.document.getElementById(id).focus();
                }
                else
                    setValue();
            }
            catch(e){}
        }
    }
}

function setValueForRegNo(procDefId){
        var procListArray = parseJSON("("+procJSON+")");
        for(var i=0;i<procListArray.length;i++){
            if(procDefId == procListArray[i].ID || procDefId==procListArray[i].ProcessId){
                strPrefix=procListArray[i].Prefix;
                strSuffix=procListArray[i].Suffix;
                strRegLength=procListArray[i].RegLength;
                parentWindowRef.document.getElementById("frmsearchworkitem:hidPrcPrefix").value = strPrefix;
                parentWindowRef.document.getElementById("frmsearchworkitem:hidPrcSuffix").value = strSuffix;
                parentWindowRef.document.getElementById("frmsearchworkitem:hidPrcRegLen").value = strRegLength;
                break;
            }
        }
   

}
var arrQueues=new Array();
var arrProcesses=new Array();
function queueInfo(queuename ,queueid){
    this.queuename=queuename;
    this.queueid=queueid;
}

function processInfo(processname ,processid){
    this.processname=processname;
    this.processid=processid;
}

function addQueues(queueInfo)
{
    var len = arrQueues.length;
    if(len>0){
        arrQueues[len] = queueInfo;
    }else{
        arrQueues[0]=queueInfo;
    }
   
}

function addProcesses(processInfo)
{
    var len = arrProcesses.length;
    if(len>0){
        arrProcesses[len] = processInfo;
    }else{
        arrProcesses[0]=processInfo;
    }
   
}


var jsonString = '{"QueueInfoList":[';
function createQueuesJson(mode){
    var queue_Info="";
    jsonString = '{"QueueInfoList":[';
    
    for(var iCount=0;iCount < arrQueues.length;iCount++)
    {
        queue_Info="";
        queue_Info=arrQueues[iCount];
        
        jsonString += '{"QueueName":"'+queue_Info.queuename.replace(/'/g, "\\'").replace(/"/g,'\\\\"')+'","QueueId":"'+queue_Info.queueid + '"},';
      
    }
    
    
    if(jsonString.lastIndexOf(",") > -1){
        jsonString = jsonString.substring(0, jsonString.lastIndexOf(","));
    }
    jsonString += ']}';
    
    if(typeof mode != 'undefined'){
        if(mode == 'GL'){            
            if(arrQueues.length <1){
                window.parent.showAlert("Please select a queue.");       
                return false;   
            }
        }
    }
    
    if(strCallback.length>0 && Trim(strCallback).length>0) {
        var Temp = 'parentWindowRef.' + strCallback + "('"+jsonString+"')";
        parseJSON(Temp);
        
        closeBp();
        return false;
    }
}


var jsonStringProcess = '{"ProcessInfoList":[';
function createProcessJson(mode){
    var process_Info="";
    jsonStringProcess = '{"ProcessInfoList":[';
    
    for(var iCount=0;iCount < arrProcesses.length;iCount++)
    {
        process_Info="";
        process_Info=arrQueues[iCount];
        
        jsonStringProcess += '{"ProcessName":"'+process_Info.processname.replace(/'/g, "\\'").replace(/"/g,'\\\\"')+'","PeocessDefId":"'+process_Info.processid + '"},';
      
    }
    
    
    if(jsonStringProcess.lastIndexOf(",") > -1){
        jsonStringProcess = jsonStringProcess.substring(0, jsonStringProcess.lastIndexOf(","));
    }
    jsonStringProcess += ']}';
    
    if(typeof mode != 'undefined'){
        if(mode == 'GL'){            
            if(arrProcesses.length <1){
                window.parent.showAlert("Please select a queue.");       
                return false;   
            }
        }
    }
    
    if(strCallback.length>0 && Trim(strCallback).length>0) {
        var Temp = 'parentWindowRef.' + strCallback + "('"+jsonStringProcess+"')";
        parseJSON(Temp);
        
        closeBp();
        return false;
    }
}

function getSelectCheckBox(ref) {
    var checkId=ref.id;
   // var allSelected=false;
    checkId=checkId.substring(0,checkId.lastIndexOf(":"));
    checkId=checkId.substring(checkId.lastIndexOf(":")+1,checkId.length);
    var checkBoxId = "qnamechk";
     var dataTableRef = document.getElementById('QueuePickList:bp:dataTable');
    if(checkId=='0' && ref.checked){
        handleAllQueueSelect(dataTableRef);
        allSelected=true;
    }else if(checkId=='0' && !ref.checked && allSelected){
        handleAllQueueUnSelect(dataTableRef);
    }
    
    if(allSelected){
        var qname=document.getElementById("QueuePickList:bp:dataTable:"+0+":"+"hidQueueName").value;
        parentWindowRef.document.getElementById(strTextFieldID).value=qname;
        addAllQueues(ref);
        return true;
    }
    
   
    var tempRef = null;
    var jsonStr="";
    var count=checkId;
    var qname=document.getElementById("QueuePickList:bp:dataTable:"+count+":"+"hidQueueName").value;
    var qid=document.getElementById("QueuePickList:bp:dataTable:"+count+":"+"hidQId").value;
    
    var queue_Info="";
    if(ref.checked){
        queue_Info="";
        queue_Info=new queueInfo(qname,qid);
        addQueues(queue_Info);
    }else{
        for(var iCount=0;iCount < arrQueues.length;iCount++)
        {
            queue_Info=arrQueues[iCount];
            if(queue_Info.queuename==qname){
                arrQueues.splice(iCount,1);
            }
        }
    }
}

function clearQueueData(){
    var dataTableRef = document.getElementById('QueuePickList:bp:dataTable');
    handleAllQueueUnSelect(dataTableRef);
    arrQueues="";
    document.getElementById('QueuePickList:bp:Prefix').value="";
}

function addAllQueues(ref) {
    
        var qname = document.getElementById("QueuePickList:bp:dataTable:" + 0 + ":" + "hidQueueName").value;
        var qid = -1; //for all queues

        var queue_Info = "";
        if (ref.checked) {
            queue_Info = "";
            queue_Info = new queueInfo(qname, qid);
            addQueues(queue_Info);
        } else {
            for (var iCount = 0; iCount < arrQueues.length; iCount++)
            {
                queue_Info = arrQueues[iCount];
                if (queue_Info.queuename == qname) {
                    arrQueues.splice(iCount, 1);
                }
            }
        }
    
}


function handleAllQueueSelect(dtRef){
    for(var iCount=0;iCount < dtRef.rows.length;iCount++){
        document.getElementById("QueuePickList:bp:dataTable:"+iCount+":"+"qnamechk").checked=true;
       // document.getElementById("QueuePickList:bp:dataTable:"+iCount+":"+"hidSelected").value=true;
    }
}

function handleAllQueueUnSelect(dtRef){
     parentWindowRef.document.getElementById(strTextFieldID).value="";
    for(var iCount=0;iCount < dtRef.rows.length;iCount++){
        var chkRef= document.getElementById("QueuePickList:bp:dataTable:"+iCount+":"+"qnamechk");
        if(chkRef.checked==true)
            document.getElementById("QueuePickList:bp:dataTable:"+iCount+":"+"qnamechk").checked=false;
            allSelected=false;
          //  document.getElementById("QueuePickList:bp:dataTable:"+iCount+":"+"hidSelected").value=false;
    }
}