
var win_purge;
function setThenclick(ref,toClick)
{    
    var selId = document.getElementById("textform:cmbPvariables").selectedIndex;
    
   var val = document.getElementById("textform:cmbPvariables").options[selId].value;
   
    document.getElementById("textform:hidSelQueryVar").value = val;

    var rowcount = -1;
    //checking if data table is empty
    var ins=document.getElementById("textform:advFilterTable:0:VarName");
    if(ins!=null)
           rowcount = document.getElementById("textform:advFilterTable").rows.length;

    if(!document.getElementById("textform:chkPurgeWiData").checked)
			document.getElementById("textform:hidPurgeWiData").value="N";
	if(!document.getElementById("textform:chkPurgeDocData").checked)
			document.getElementById("textform:hidPurgeDocData").value="N";
	
    if (rowcount == -1)
        document.getElementById("textform:hidJoinCondition").value = "N";
    else if (rowcount > 1)
        document.getElementById("textform:hidJoinCondition").value = "Y";
    document.getElementById("textform:advFilterTable:chkHdrFilter").checked=false;
    clickLink(toClick);
}

function SelectCheckBoxes(ref)
{   
    var formid=ref.form.id;
    
    var tableid=formid+':advFilterTable';

    try
    {
        var noofrows = document.getElementById(tableid).rows.length;

        var flag=0;
        for (var i=0;i< noofrows-1 ;i++)
        {

            var id=tableid+':'+i+':chkFilter';
            document.getElementById(id).checked=ref.checked;
        }

        return '';
    }
    catch(e)
    {
        //alert(e);
        return "";
    }
}
function SelectCheckBoxesPurgeList(ref)
{
    var formid=ref.form.id;
    var tableid=formid+':purgeLists';

    try
    {
        var noofrows = document.getElementById(tableid).rows.length;

        var flag=0;
        for (var i=0;i< noofrows-1 ;i++)
        {

            var id=tableid+':'+i+':chkBox';
            document.getElementById(id).checked=ref.checked;
        }
        if(ref.checked){
            document.getElementById("frmpurgecriteriamgmt:cmdDelete").removeAttribute("disabled");
        }
        else{
           document.getElementById("frmpurgecriteriamgmt:cmdDelete").setAttribute("disabled","true");
        }
        return '';
    }

    catch(e)
    {
        //alert(e);
        return "";
    }
}
function checkRowData(ref,toClick)
{

    var tableID = 'textform:advFilterTable';
    var table = document.getElementById(tableID);

    var rowCount = 0;
    var chkBoxID=tableID+":";
    var currentChkBoxID="";
    var noOfSelectedRows=0;
    var selectedIndexes="";
    var submitFlag = false;
    rowCount = table.rows.length;
    if(document.getElementById("textform:chkBoxPurge")!=null){
    if(!document.getElementById("textform:chkBoxPurge").checked){
        document.getElementById("textform:hidPurgeWiData").value="N";
        document.getElementById("textform:hidPurgeWiData").disabled=true;
        document.getElementById("textform:hidPurgeDocData").value="N";
        document.getElementById("textform:hidPurgeDocData").disabled=true;
}
    }
    if(document.getElementById("textform:chkPurgeWiData")!=null && !document.getElementById("textform:chkPurgeWiData").checked)
			document.getElementById("textform:hidPurgeWiData").value="N";
		if(document.getElementById("textform:chkPurgeDocData")!=null && !document.getElementById("textform:chkPurgeDocData").checked)
			document.getElementById("textform:hidPurgeDocData").value="N";
		if(document.getElementById("textform:chkExportWiData")!=null && !document.getElementById("textform:chkExportWiData").checked)
			document.getElementById("textform:hidExportWiData").value="N";
		if(document.getElementById("textform:chkExportDocData")!=null && !document.getElementById("textform:chkExportDocData").checked)
			document.getElementById("textform:hidExportDocData").value="N";
    if(rowCount <= 1)
    {
        submitFlag = false;
        return false;
    }
    else
    {

        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
                currentChkBoxID=chkBoxID + iCount +":chkFilter" ;
                try
                {
                        if(document.getElementById(currentChkBoxID).checked)
                        {
                                noOfSelectedRows++;
                                if(selectedIndexes.length > 0)
                                        selectedIndexes=selectedIndexes + ":"+ iCount ;
                                else
                                        selectedIndexes = iCount +"";

                         }


                }
                catch(e)
                {
                    selectedIndexes ="";
                    noOfSelectedRows=0;
                }
        }
    }

    if(noOfSelectedRows == 0)
    {   
        //Bug 72802 Start
        var messageWidth = 260;
        var left = (document.documentElement.clientWidth - messageWidth) / 2;
        notifierAbs('notifier', SEL_FIELD_TO_DELETE, "absolute", false, left, 34);
        //Bug 72802 End
        submitFlag = false;
        return false;
    }
    else
    {
        submitFlag = true;
        document.getElementById("textform:hidSelvarList").value = selectedIndexes;
    }
    if(document.getElementById("textform:advFilterTable:chkHdrFilter").checked)
        document.getElementById("textform:advFilterTable:chkHdrFilter").checked=false;
    if(submitFlag == true)
        clickLink(toClick);

}
function GetTitles(thisEle,Type)//checked
{
	var strTitle;
	var strType = Type.substring(2);
        var DateFormat=document.getElementById("textform:hidDateFormat").value;
	switch(strType)
	{
		case "10":
			strTitle = INSERT_STR_VAL;
			break;
		case "B":
			strTitle = INSERT_BOOL_VAL;
			break;
		case "8":
			tempDteFormat = DateFormat;
			strTitle = INSERT_DATE_VAL+" '"+DateFormat+"'";
			break;
		case "3":
			strTitle = INSERT_INT_VAL;
			break;
		case "6":
			strTitle = INSERT_DEC_VAL;
			break;
		case "T":
			strTitle = INSERT_RAW_VAL;
			break;
		case "4":
			strTitle = INSERT_LONG_VAL;
			break;
                case "12":
                        strTitle = INSERT_BOOL_VAL;
                        break;
		default:
	}
		thisEle.title = strTitle;
var indx = parseInt(thisEle.name.lastIndexOf(':'));
var tempstr1 = thisEle.name.substring(0,indx)+":assignOperator";
var tempstr2 = thisEle.name.substring(0,indx)+":dateTypeVariables";
var operator1 =  document.getElementById(tempstr1).selectedIndex;
var varvalue1 =  document.getElementById(tempstr2).selectedIndex;
if(operator1 != "0" || varvalue1 != "0") thisEle.title = "Please INSERT Integer Values";
}

                
function clickCommandLink()
    {
        var ref = document.getElementById("textform");
        ClickAnotherLink(ref,'saveQuery');
        return true;
       /* var ref = document.getElementById("textform");
        if(CheckDataAndCreateXMLs(ref))
        {
            ClickAnotherLink(ref,'saveQuery');
            return true;
        }
        else
            return false;*/

    }
function CheckDataAndCreateXMLs(ref)
{

      //validate inputs for Purge data
        if(!ValidateProcessData())
            return false;

        if(!createDataXML())
			return false;
    return true;
}
function createDataXML()
{
    var tmpFieldList = "";
    var strTempXml = "";
    var strData ="";

    var prefix ="textform:blankp:bp:";
    var txtForm = document.getElementById("textform");
    var stradvsearch="N";
    var tablePrefix="";
    var entryFlag=false;
     stradvsearch="Y";
     tablePrefix = prefix+"advFilterTable";
     //alert("checking body element");
     //alert( document.getElementById(tablePrefix).tBodies.length);
      //alert( document.getElementById(tablePrefix).rows.length);
    var rowCount = -1;
    var ins=document.getElementById(tablePrefix+":0:VarName");
    if(ins!=null)
        rowCount = document.getElementById(tablePrefix).rows.length;
   
//alert("in createDateXML");
   if(document.getElementById("textform:blankp:bp:chkExport").checked)
	{
                document.getElementById("textform:hidExportFlag").value="Y";
		strData+= appendTagAndValue("WorkitemData",document.getElementById("textform:blankp:bp:chkExportWiData").checked?"Y" :"N");
		strData+= appendTagAndValue("Documents",document.getElementById("textform:blankp:bp:chkExportDocData").checked?"Y" :"N");
		strData = appendTagAndValue("ExportCriteria",strData);
	}
        else
        {
        document.getElementById("textform:hidExportFlag").value="N";
        }

    strTempXml += appendTagAndValue("WorkitemData",document.getElementById("textform:blankp:bp:chkPurgeWiData").checked?"Y" :"N");
    strTempXml += appendTagAndValue("Documents",document.getElementById("textform:blankp:bp:chkPurgeDocData").checked?"Y" :"N");
    if(rowCount > 1)
    {
        var iCount=0;

        var varvalue="";
        for(iCount=0 ; iCount < (rowCount-1) ; iCount++)
        {
            var varname = document.getElementById(tablePrefix+":"+iCount+":VarName").innerHTML;
            var vartype = document.getElementById(tablePrefix+":"+iCount+":VarType").value;
            var varlength = document.getElementById(tablePrefix+":"+iCount+":VarLength").value;
            var varoperator="";
            var varjoincond="";
            var varopenparenthesis="";
            var varcloseparenthesis="";
            var selIndex = -1;
            var strXML ="";

                varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterData").value;
                if(document.getElementById(tablePrefix+":"+iCount+":procfilterData").value=="")
                {
                    customAlert(BLANK_FIELD_VALUE);
		return false;
                }
                selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").selectedIndex;
                //alert(selIndex);
                varoperator = document.getElementById(tablePrefix+":"+iCount+":advCmbOperator").options[selIndex].value;
                if(iCount!=0)
                {
                    selIndex = document.getElementById(tablePrefix+":"+iCount+":advCmbJoin").selectedIndex;
                    varjoincond = document.getElementById(tablePrefix+":"+iCount+":advCmbJoin").options[selIndex].value;
                 }
                selIndex = document.getElementById(tablePrefix+":"+iCount+":openparaenthesis").selectedIndex;
                varopenparenthesis = document.getElementById(tablePrefix+":"+iCount+":openparaenthesis").options[selIndex].value;
                 selIndex = document.getElementById(tablePrefix+":"+iCount+":closeparaenthesis").selectedIndex;
                varcloseparenthesis = document.getElementById(tablePrefix+":"+iCount+":closeparaenthesis").options[selIndex].value;
                if(Trim(varvalue)=='')
                    entryFlag = true;

            if(vartype == '8' && varvalue != '')
            {
                varvalue = LocalToDB(varvalue,DateFormat);
            }

               if(varopenparenthesis!="")
               strXML = strXML + appendTagAndValue("OpenBracket","Y");
               else
               strXML = strXML + appendTagAndValue("OpenBracket","N");
               //alert("VarName="+varname);
                strXML = strXML + appendTagAndValue(VarName,varname);
                strXML = strXML + appendTagAndValue(VarType,vartype);
                strXML = strXML + appendTagAndValue(Length,varlength);
                strXML = strXML + appendTagAndValue(VarValue,varvalue);
                strXML = strXML + appendTagAndValue(Operator,varoperator);
                if(varcloseparenthesis!="")
                strXML = strXML + appendTagAndValue("CloseBracket","Y");
                else
                strXML = strXML + appendTagAndValue("CloseBracket","N");
                if(iCount!=0)
                strXML = strXML + appendTagAndValue(JoinCondition,varjoincond);

                 tmpFieldList += appendTagAndValue("Field",strXML);
         }
         if(tmpFieldList != "")
		strTempXml += appendTagAndValue("Fields",tmpFieldList);
        }
     strData += appendTagAndValue("PurgeCriteria",strTempXml);
     document.getElementById("textform:hidDataXML").value=strData;
     document.getElementById("textform:blankp:bp:hidProcessName").value=document.getElementById("textform:blankp:bp:txtProcessName").value;
     document.getElementById("textform:hidCriteriaName").value=document.getElementById("textform:blankp:bp:txtCriteriaName").value;

     document.getElementById("textform:hidOperation").value = document.getElementById("textform:hidOperation").value;

	return true;
    }

function appendTagAndValue(tagName,tagValue)
{
    var tagAndValue="";
    if(tagValue != "")
        tagAndValue = "<" + tagName + ">" + tagValue + "</" + tagName + ">";
    return tagAndValue;
}
function ValidateProcessData()
{
    var prefix ="textform:blankp:bp:";//parent.document.getElementById("frmpurgecriteriamgmt")
    var tablePrefix="";
    var criCount="";
    //alert(parent.document.getElementById("frmpurgecriteriamgmt:blankp:bp:purgeLists"));
    //if(window.opener.document.getElementById("purgemgt:purgeLists"))
    if(parent.document.getElementById("frmpurgecriteriamgmt:blankp:bp:purgeLists"))
	{
	criCount=window.parent.document.getElementById("frmpurgecriteriamgmt:blankp:bp:purgeLists").rows.length;
       	}
	else{
	criCount=0;
	}
    var operation=document.getElementById("textform:hidOperation").value;
    
    if(operation=='I'){
    if(criCount>0)
    {
        var iCnt = 0;
        for(iCnt=0;iCnt<criCount-1;iCnt++)
        {if(document.getElementById("textform:blankp:bp:txtCriteriaName").value==window.parent.document.getElementById("frmpurgecriteriamgmt:blankp:bp:purgeLists:"+iCnt+":criName").innerHTML)
            {customAlert(PURGING_CRITERIA_EXISTS);
                document.getElementById("textform:blankp:bp:txtCriteriaName").value="";
                return false;
            }
        }
    }
    }
    tablePrefix = prefix+"advFilterTable";
    

      if(document.getElementById("textform:blankp:bp:txtCriteriaName").value == "")
	{
		customAlert(BLANK_CRITERIA_NAME);
		return false;
	}
      if(!document.getElementById("textform:blankp:bp:chkPurgeWiData").checked && !document.getElementById("textform:blankp:bp:chkPurgeDocData").checked)
        {
		customAlert(SELECT_ONE_PURGE_OPTION);
		return false;
	}
    var rowCount = -1;
    //checking if data table is empty
    var ins=document.getElementById(tablePrefix+":0:VarName");
    if(ins!=null)
        rowCount = document.getElementById(tablePrefix).rows.length;
    var elementId="";
    var varvalue="";
    if(rowCount > 1)
    {
        var iCount=0;
        for(iCount=0 ; iCount < (rowCount-1) ; iCount++)
        {   
            var varname = document.getElementById(tablePrefix+":"+iCount+":VarName").innerHTML;
            var vartype = document.getElementById(tablePrefix+":"+iCount+":VarType").value;
				vartype = vartype.substring(2);
            var varlength = document.getElementById(tablePrefix+":"+iCount+":VarLength").value;
               varvalue = document.getElementById(tablePrefix+":"+iCount+":procfilterData").value;
               elementId = tablePrefix+":"+iCount+":procfilterData";

            if(Trim(varvalue)!='')
              {
                  if(vartype == '3')
                   {
                       if(!IsNumericVal(varvalue))
                         {
                            customAlert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                         }
                        else if (varvalue<-Math.pow(2,31) || varvalue>(Math.pow(2,31)-1))
                        {
                            customAlert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                        }
                    }
                else if(vartype == '4')
                {
                    if(!IsNumericVal(varvalue))
                    {
                            customAlert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                    else if (varvalue<-Math.pow(2,31) || varvalue>(Math.pow(2,31)-1))
                    {
                            customAlert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                }
                else if(vartype == '6')
                {
                    if(isNaN(varvalue))
                    {
                            customAlert(INVALID_NUMERIC_VALUE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                    else if (varvalue< parseFloat("-1.79e+308") || varvalue> parseFloat("+1.79e+308"))
                    {
                            customAlert(INDEX_VALUE_OUT_OF_RANGE);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
                }
                else if(vartype == '8' && varvalue != '')
                {
                    var ret = ValidateDateFormat(varvalue,DateFormat);
                    if(ret==0)
                    {
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
               }
            else if(vartype == '10')
            {
                    if ( (varvalue.indexOf('\u00ff') != -1) || (varvalue.indexOf('\u00fc') != -1) ||(varvalue.indexOf('\u00b5') != -1) || (varvalue.indexOf('<') != -1) || (varvalue.indexOf('>') != -1) )
                    {
                            customAlert(INVALID_STRING);
                            document.getElementById(elementId).focus();
                            document.getElementById(elementId).select();
                            return false;
                    }
            }
          } // if Trim
      } // for loop ends
    } //rowCount > 1
    
    return true;

}//fucn ends

function setPurgeWiOption()
{
	if(document.getElementById("textform:chkPurgeWiData").checked)
	{

		if(document.getElementById("textform:chkExport").checked)
			document.getElementById("textform:chkExportWiData").disabled=false;

	}
	else
	{
		document.getElementById("textform:chkExportWiData").checked = false;
		document.getElementById("textform:chkExportWiData").disabled=true;

	}
}


function chkPurge()
{
     if(!document.getElementById("textform:chkBoxPurge").checked){
        document.getElementById("textform:hidPurgeWiData").value="N";
        document.getElementById("textform:chkPurgeWiData").checked=false;
        document.getElementById("textform:chkPurgeWiData").disabled=true;
        document.getElementById("textform:hidPurgeDocData").value="N";
        document.getElementById("textform:chkPurgeDocData").checked=false;
        document.getElementById("textform:chkPurgeDocData").disabled=true;
        }
     else
     {
        document.getElementById("textform:hidPurgeWiData").value="Y";
        document.getElementById("textform:chkPurgeWiData").checked=true;
        document.getElementById("textform:chkPurgeWiData").disabled=true;
        document.getElementById("textform:chkPurgeDocData").checked=false;
        document.getElementById("textform:chkPurgeDocData").disabled=false;
     }
}

function chkPurgeModified()
{
        document.getElementById("textform:hidPurgeWiData").value="Y";
        document.getElementById("textform:chkPurgeWiData").checked=true;
        document.getElementById("textform:chkPurgeWiData").disabled=true;
        document.getElementById("textform:chkPurgeDocData").checked=false;
        document.getElementById("textform:chkPurgeDocData").disabled=false;
}
function DeletePurgeCriteria(ref, toClick)
{
    var formID="frmpurgecriteriamgmt";
    var sPidList='' ;
   var tableID = 'frmpurgecriteriamgmt:purgeLists';
    var chkboxName=":chkBox";
    var noOfSelectedRows=0;
    var processID="";
    var processName="";

    try
    {
    var rowCount=document.getElementById(tableID).rows.length ;
    var processIDId;
    var processNameId;
    var operation;
    var name;

    for (var iCount=0;iCount < (rowCount-1) ;iCount++)
    {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            processIDId=tableID+":" + iCount +":ProcessDefId";
            //operation = tableID+":" + iCount +":Operation";
            if(document.getElementById(currentChkBoxID).checked)
            {
            sPidList +=document.getElementById(processIDId).value+",";

            //document.getElementById("frmpurgecriteriamgmt:hidOperation").value="D";
            }

    }
    }
    catch(e)
            {
                            //alert("Error in=="+iCount);
            }

    if(sPidList == "")
    {
            customAlert(SELECT_CRITERIA_TO_DELETE);
            return false;
    }

    var bConfirm = confirm(CONFIRM_PURGE_DELETE);
   
    if(!bConfirm)
            return false;

    sPidList = sPidList.substring(0,sPidList.length -1);
    
   
    document.getElementById("frmpurgecriteriamgmt:pidList").value=sPidList;
    
    document.getElementById("frmpurgecriteriamgmt:hidOperation").value = "D";
    clickLink(toClick);

}

function clickPurgeChk(){
    var tableID = 'frmpurgecriteriamgmt:purgeLists';
   var chkboxName=":chkBox";
    var chkCount = 0;
    try{
	var rowCount=document.getElementById(tableID).rows.length ;
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            if(document.getElementById(currentChkBoxID).checked)
                chkCount++;
        }

        if(chkCount < rowCount-1)
            document.getElementById("frmpurgecriteriamgmt:purgeLists:headerChk").checked = false;
        else if(chkCount == rowCount-1)
            document.getElementById("frmpurgecriteriamgmt:purgeLists:headerChk").checked = true;
        if(chkCount>0){            
            document.getElementById("frmpurgecriteriamgmt:cmdDelete").removeAttribute("disabled");
        }
        else{     
            document.getElementById("frmpurgecriteriamgmt:cmdDelete").setAttribute("disabled","true");
        }
    }catch(e){}
}

function clickFilterHeadrChk(){
    var tableID = 'textform:advFilterTable';
    var chkboxName=":chkFilter";
    var chkCount = 0;
    try{
	var rowCount=document.getElementById(tableID).rows.length ;
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
            currentChkBoxID=tableID+":" + iCount +chkboxName ;
            if(document.getElementById(currentChkBoxID).checked)
                chkCount++;
        }

        if(chkCount < rowCount-1)
            document.getElementById("textform:advFilterTable:chkHdrFilter").checked = false;
        else if(chkCount == rowCount-1)
            document.getElementById("textform:advFilterTable:chkHdrFilter").checked = true;
    }catch(e){}
}
 function ClosePopup_Purge()
    {
        if (win_purge != null)

       {
        win_purge.close();

        }
        return false;
    }

function setFocus(){
        var err=document.getElementById("textform:hidMessage").value;
        if(err == 'true'){
            var row=document.getElementById("textform:hidErrorRow").value;
            if(row > -1){
                document.getElementById("textform:advFilterTable:"+row+":procfilterData").select();
                }

        }
    }
