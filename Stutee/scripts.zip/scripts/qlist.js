function handleEnter(e,id)
{
    var browser=navigator.appName;
    if(browser=="Netscape")
    {
        if(e.which == 13)
        {
            var ref = document.getElementById("QueueListForm:queuePrefix");
            var refPnl = document.getElementById("QueueListForm:panelforQuickSearch:queuePrefix");
            if(ref != null){
                ref.value=document.getElementById("QueueListForm:Prefix").value;
            } else if(refPnl != null) {
                
                refPnl.value=document.getElementById("QueueListForm:panelforQuickSearch:Prefix").value;
            } else{
                ref=document.getElementById("preferenceForm:queuePrefix");
                ref.value=document.getElementById("preferenceForm:prefix").value;
            }
            
            var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1;
            if(typeof cancelBubble!='undefined')
              cancelBubble(e);
            if(isSafari){
                clickLink(id);
            } else {
                //document.getElementById(id).focus();
                clickLink(id);
            }
        }
    }
    else
    {
        e=window.event;
        if(e.keyCode == 13)
        {
            var ref = document.getElementById("QueueListForm:queuePrefix");
            var refPnl=document.getElementById("QueueListForm:panelforQuickSearch:queuePrefix");
            if(ref != null){
                ref.value=document.getElementById("QueueListForm:Prefix").value;
            } else if(refPnl!=null){
                    ref = refPnl;
                    ref.value=document.getElementById("QueueListForm:panelforQuickSearch:Prefix").value;
            } else {
                    ref = document.getElementById("preferenceForm:queuePrefix");
                    ref.value = document.getElementById("preferenceForm:prefix").value;
            }
            //alert(document.getElementById("QueueListForm:Prefix").value);
            //document.getElementById(id).focus();
            if(typeof cancelBubble!='undefined')
               cancelBubble(e);
            clickLink(id);
        }
    }
}

function resizeCompWH(height,width,type,diffHeight){
    type = (typeof type == 'undefined')? '':type;
    diffHeight = (typeof diffHeight == 'undefined')? null:diffHeight;
    var scrollDivRef = null;
    
    scrollDivRef = document.getElementById('scroll');
    if(scrollDivRef && (diffHeight != null)){
        scrollDivRef.style.height = (parseInt(scrollDivRef.style.height)+diffHeight)+'px';
    }
    
    scrollDivRef = document.getElementById('scrollQM');
    if(scrollDivRef && (diffHeight != null)){
        scrollDivRef.style.height = (parseInt(scrollDivRef.style.height)+diffHeight)+'px';
    }
    
    if(width!=undefined && width!=""){
        document.getElementById('QueueListForm:hidWidth').value=width;
        
        var tableHeaderFix = document.getElementsByClassName('table-header-fix');
        if(tableHeaderFix){
            tableHeaderFix = tableHeaderFix[0];
            if(tableHeaderFix){
                //tableHeaderFix.style.width = width-20+'px';

                scrollDivRef = document.getElementById('scrollQM');
                //scrollDivRef.style.width = width-20+'px';
                
                //initTableHeaderFix();
            }
        }
    }
    
    if(height!=undefined && height!="")
        document.getElementById('QueueListForm:hidHeight').value=height;
//    clickLink("QueueListForm:lnkRefresh");
}
function QueueEventHandler(event_DefId,event_name,jsonoutput){
                
    var incomingJson = JSON.parse(jsonoutput.replace(/\\'/g, "'"));
    incomingJson = incomingJson.Outputs;
                
    incomingJson = incomingJson.filter(function(item) {
        return item.Output['DefId'] == 7
    });
                
    if(incomingJson.length>0){
        window.parent.queueAliasName = incomingJson[0].Output.Value;
    }
                
    if(typeof window.parent.queueEventHandler != 'undefined'){
        var ret = window.parent.queueEventHandler(jsonoutput);
        if(!ret){
            return false;
        }
    }               
    window.parent.CompEventHandler(comp_ins_id,event_DefId,event_name,jsonoutput.replace("'","\\'",'g'));               
}

function qehw(event_DefId,event_name,jsonoutput){
    if(typeof isShowCustomWorklist !='undefined' && isShowCustomWorklist=='Y'){
        var queuename='';
        var queueId='';
        var queuetype='';
        var allowReassign='';
        var order='';
        var sortingorder='';
        var batchSize='';
        var batchingFlag='';
        var tempResponseOutputjson = parseJSON("(" + jsonoutput+ ")");
        for(var i=0 ; i < tempResponseOutputjson.Outputs.length ; i++){
            if(tempResponseOutputjson.Outputs[i].Output.Name=="QueueName"){
                queuename=tempResponseOutputjson.Outputs[i].Output.Value;
                           
            }else if(tempResponseOutputjson.Outputs[i].Output.Name=="QueueId"){
                queueId=tempResponseOutputjson.Outputs[i].Output.Value;
            }else if(tempResponseOutputjson.Outputs[i].Output.Name=="QueueType"){
                queuetype=tempResponseOutputjson.Outputs[i].Output.Value;
            }else if(tempResponseOutputjson.Outputs[i].Output.Name=="AllowReassignment"){
                allowReassign=tempResponseOutputjson.Outputs[i].Output.Value;
            }else if(tempResponseOutputjson.Outputs[i].Output.Name=="OrderBy"){
                order=tempResponseOutputjson.Outputs[i].Output.Value;
            }else if(tempResponseOutputjson.Outputs[i].Output.Name=="SortOrder"){
                sortingorder=tempResponseOutputjson.Outputs[i].Output.Value;
            }
                        
        }
                   
        checkCustomWorklist(queueId,queuename,queuetype,allowReassign,order,sortingorder,batchSize,batchingFlag,event_DefId,event_name,jsonoutput);
                    
    }
    else{
        QueueEventHandler(event_DefId,event_name,jsonoutput);
    }
    window.parent.setSessionCheckTimeout((window.parent.SessionWarnExtendTime-0)*60);
}

function searchOnImageClick(){
    var ref = document.getElementById("QueueListForm:queuePrefix");
    if(ref != null){
        ref.value=document.getElementById("QueueListForm:Prefix").value;
    } else {
        ref = document.getElementById("QueueListForm:panelforQuickSearch:queuePrefix");
        ref.value=document.getElementById("QueueListForm:panelforQuickSearch:Prefix").value;
    }
    if(ref.value == SEARCH_QUEUE){
        ref.value="";
        clickLink("QueueListForm:cmdBtn");
    }
    else{
        clickLink("QueueListForm:cmdBtn");
    }
}

function changeimage(flag,callFrom)
{
    if (typeof callFrom != 'undefined' && callFrom != null && callFrom != '') {
        var prefix = document.getElementById("preferenceForm:prefix");
        var queuePrefix = document.getElementById("preferenceForm:queuePrefix");
    } else {
        var queuePrefix = document.getElementById("QueueListForm:queuePrefix");
        var prefix = document.getElementById("QueueListForm:Prefix");
    }
    if(flag ==1)
    {

        if(queuePrefix.value=="")
            prefix.value="";
        else{
            if(prefix.value != queuePrefix.value){
                prefix.value=queuePrefix.value;
            }
        }
    }
    else
    {
        if(prefix.value != SEARCH_QUEUE || Trim(prefix.value) != ""){
            queuePrefix.value=prefix.value;
        }
        if(queuePrefix.value=="")
            prefix.value=SEARCH_QUEUE;
        else{
            if(prefix.value != queuePrefix.value){
                prefix.value=queuePrefix.value;
            }
        }
    }
}

function refreshQueueMgmt(){
    clickLink("QueueListForm:lnkRefreshQM");
}
function clickNavCmdLinkWrapper(linkId){
    //document.getElementById("QueueListForm:"+linkId).click();
    if(!navigationLinkInitiated){
        navigationLinkInitiated = true
        clickLink("QueueListForm:"+linkId);                
    }
}            
            
function HandleEventWrapper(data){
    if(data.status == "success"){
        navigationLinkInitiated = false;
        iCount=0;
        clearTimeout(timeOut);
        setCountWI() ;
    }
                
    HandleProgressBar(data);
    HandleOutcome(data);
    RefreshHandler(data);
}
            
function FAjaxErrorHandlerWrapper(data){
    if(data.status == "success"){
        navigationLinkInitiated = false;
    }
                
    FAjaxErrorHandler(data);
}

function openSearch(ref){
    if(document.getElementById('QuickSearchDiv').style.display == 'none'){
        positionmenu(ref.id,'QuickSearchDiv');
        document.getElementById('QuickSearchDiv').style.display = 'inline';
    }
    else{
        document.getElementById('QuickSearchDiv').style.display = 'none';
        positionmenu(ref.id,'QuickSearchDiv');
    }

    var ref = document.getElementById("QueueListForm:panelforQuickSearch:Prefix");
    if(ref != null){
        changeimagewp(1);
        if(document.getElementById('QuickSearchDiv').style.display != "none"){
            ref.focus();
        }
    }
}
            
function changeimagewp(flag)
{
    var queuePrefix = document.getElementById("QueueListForm:panelforQuickSearch:queuePrefix");
    var prefix = document.getElementById("QueueListForm:panelforQuickSearch:Prefix");
    if(flag ==1)
    {
        if(queuePrefix.value=="")
            prefix.value="";
        else{
            if(prefix.value != queuePrefix.value){
                prefix.value=queuePrefix.value;
            }
        }
    }
    else
    {
        if(prefix.value != SEARCH_QUEUE || Trim(prefix.value) != ""){
            queuePrefix.value=prefix.value;
        }
        if(queuePrefix.value=="")
            prefix.value=SEARCH_QUEUE;
        else{
            if(prefix.value != queuePrefix.value){
                prefix.value=queuePrefix.value;
            }
        }
    }
}

function adjustQueueTab(width){
    var gridCtrlname=document.getElementById('QueueListForm:grid1');
    var moreOption=document.getElementById('QueueListForm:moreOpt');
    var moreOptionArray=new Array();
    var tabArray=new Array();
    tabArray[0]=document.getElementById('QueueListForm:tab1');
    tabArray[1]=document.getElementById('QueueListForm:tab2');
    tabArray[2]=document.getElementById('QueueListForm:tab3');
    moreOptionArray[0]=document.getElementById('QueueListForm:panel:more1');
    moreOptionArray[1]=document.getElementById('QueueListForm:panel:more2');
    moreOptionArray[2]=document.getElementById('QueueListForm:panel:more3');

    adjustHideShowLinks(gridCtrlname,Math.ceil(width),tabArray,moreOption,moreOptionArray);
}
    
function loading(){
    setCountWI();
//  adjustQueueTab(document.getElementById('QueueListForm:hidWidth').value);
}

function HandleOutcome(data){
    if(data.status=="success"){
//        adjustQueueTab(document.getElementById('QueueListForm:hidWidth').value);
    }
}

function HandleEventRefWrapper(data)
{
    if(data.status=="success"){
        iCount=0;
        clearTimeout(timeOut);
        setCountWI() ;
    }
    HandleProgressBar(data);
    HandleOutcome(data);
    RefreshHandler(data);
}
            
function HandleEventPopWrapper(data)
{
    if(data.status=="success"){
        iCount=0;
        clearTimeout(timeOut);
        setCountWI() ;
    }
    HandleProgressBar(data);
    HandleOutcome(data);
    RefreshHandler(data);
}
            
function HandleEvent(data){
    HandleProgressBar(data);
    HandleOutcome(data);
    RefreshHandler(data);
}
            
function compRefresh(op){
    if(op!="popout" && op!="popin"){
        clearSearcPrefixvalue();
        clickLink("QueueListForm:lnkRefreshQM");
    }
}
function clearSearcPrefixvalue(){
    try{
        var prefix = document.getElementById("QueueListForm:Prefix");
        if(prefix != null){
            prefix.value = SEARCH_QUEUE;
        } else{
            prefix = document.getElementById("QueueListForm:panelforQuickSearch:Prefix");
            prefix.value = "";
        }
    }catch(e){}
}

function HandleCmdButton(data){
    HandleProgressBar(data);
    if(data.status=="success"){
        iCount = 0;
        
        if (document.getElementById('QueueListForm:AuthorizationFlag').value == 'Y') {
            customAlert(REQUEST_SENT_FOR_APPROVAL);
        }
        clearTimeout(timeOut);
        setCountWI();
    }RefreshHandler(data);
}

function callSearchOnProcessSelection(){
    clickLink("QueueListForm:cmdBtn");
}

function CommentDiv(ref,Callback,Validate,hidCommentId,thisObj){
    var bOpenWindow=true;
    if(Validate.length > 0)
    {   
        bOpenWindow=parseJSON(Validate + '();');
        
    }
    if(bOpenWindow)
    {   
        var sURL="/webdesktop/components/process/wdcomment.app?";
        sURL=sURL+"Callback="+Callback+"&Validate="+Validate+"&CommentWindow="+hidCommentId;
        sURL = sURL + "&WD_SID="+WD_SID;
        sURL=appendUrlSession(sURL);
        var posLeft = findAbsPosX(ref);
        var posTop = findAbsPosY(ref);
        sURL = sURL + "&Width="+260+"&Height="+160;
        
        window.parent.popupIFrameOpenerWrapper(this, "CommentWindow",sURL, 260, 165, posLeft,posTop, false, false, false, true);
    }
    return false;
}

function validatePage(Callback,finalWindow,containerDiv,hidCommentId){
    var comments= window.document.getElementById('txtcomment').value;
    
    if(comments !=''){
        window.document.getElementById(hidCommentId).value=comments;
        finalWindow.document.body.removeChild(containerDiv);
        clickLink(Callback);
    }
}
function setCountWI()
{
    if(isWICountOnQueue=='Y'){
        if(queueListType=='QL' && (document.getElementById('QueueListForm:dataTable:'+iCount+':hidQId'))!=null){
            var queueId =  document.getElementById('QueueListForm:dataTable:'+iCount+':hidQId').value;
            queryString = 'QueueId='+queueId + '&WD_SID='+WD_SID; 
            sendCallToGetCount(queryString);
        }
    }
}
function sendCallToGetCount(queryString)
{
    var workitemCount= ContentLoaderWrapper('/webdesktop/ajaxwicount.app',setWorkitemCountOnQueue,callBackOnError,"POST",queryString);    
}
           
function setWorkitemCountOnQueue(){
    var response=this.req.responseText;
             
    if(isNaN(parseInt(response))){
        //customAlert("Unable to Count Workitem");
        return false;
    } 
    else
    {
        if(this.req.status==200){
            var nCount=iCount+1;
            try{
                document.getElementById('QueueListForm:dataTable:'+iCount+':count').innerHTML=encode_ParamValue(" ["+response+"]");
            }catch(e){
                document.getElementById('QueueListForm:dataTable:'+iCount+':count').innerHTML = " ["+response+"]";
            }
            timeOut = setTimeout(function() {
                iCount++;
                setCountWI();
            }, wICountInterval);
                    
        }
    }
}

function adjustHideShowLinks(gridCtrlName,width,tabArray,moreOptionBtn,moreOptionArray){
    var flag = true;
    for(var i=tabArray.length-1; i >= 0;i--){
        var returnFlag = repeat(gridCtrlName.offsetWidth,width,tabArray[i],moreOptionArray[i]);
        if(!returnFlag){
            flag = false;
        }
    }
    if(moreOptionBtn){
        if(flag){
            moreOptionBtn.style.display = "none";
        }else{
            moreOptionBtn.style.display = "none";
        }
    }
}

function repeat(gridWidth,width,tab,moreOptionElement){
    var flag= true;
    if(tab){
        if(gridWidth > width){
            tab.style.display="none";
            moreOptionElement.style.display="inline";
            flag = false;
        }else{
            tab.style.display="inline";
            moreOptionElement.style.display="none";
        }
    }
    return flag;
}

function initTableHeaderFix(){    
    var headerFixContainer = null;
    var hwJSON = null, overflow = false;   

    headerFixContainer = document.getElementsByClassName("table-header-fix");
    if(headerFixContainer){
        for(var i=0; i<headerFixContainer.length; i++){
            if((headerFixContainer[i].firstElementChild != null) && (headerFixContainer[i].firstElementChild.firstElementChild != null)){
                if(headerFixContainer[i].firstElementChild.style.width.indexOf('px') < 0){
                    hwJSON = getElementHW(headerFixContainer[i].firstElementChild);

                    headerFixContainer[i].firstElementChild.style.width = hwJSON.Width + "px";
                    headerFixContainer[i].firstElementChild.firstElementChild.style.width = hwJSON.Width + "px";
                    headerFixContainer[i].style.width = hwJSON.Width + "px"; 
                }
            
                headerFixContainer[i].firstElementChild.style.overflowX = "hidden";
                headerFixContainer[i].firstElementChild.style.overflowY = "auto";
                overflow = hasCSS(headerFixContainer[i], 'xy');
                if(overflow){
                    headerFixContainer[i].firstElementChild.style.overflowX = "auto";                    
                }
                                
                var k=0, bodyRow=null, eps = null, ebs = null, headerCell = null, bodyCell = null, tHead = headerFixContainer[i].firstElementChild.firstElementChild.tHead, tBody = headerFixContainer[i].firstElementChild.firstElementChild.tBodies[0];
                if(tHead.firstElementChild.cells.length == tBody.firstElementChild.cells.length){
                    bodyRow = tBody.children[k];
                    
                    for(; (k < tBody.rows.length) && (bodyRow.style.display == 'none');){
                        bodyRow = tBody.children[++k];
                    }
                    
                    if(k == tBody.rows.length){
                        return false;
                    }
                    
                    for(var j=0; j<tHead.firstElementChild.cells.length; j++){
                        headerCell = tHead.firstElementChild.cells[j];
                        bodyCell = bodyRow.cells[j];

                        if(headerCell.offsetWidth > bodyCell.offsetWidth){
                            eps = getElementStyle(headerCell, "padding");
                            ebs = getElementStyle(headerCell, "border");
                            headerCell.style.minWidth = bodyCell.style.minWidth = headerCell.offsetWidth - (eps.PaddingLeft+ebs.BorderHorizontalWidth) + "px";
                        } else if(headerCell.offsetWidth < bodyCell.offsetWidth){
                            eps = getElementStyle(bodyCell, "padding");
                            ebs = getElementStyle(bodyCell, "border");
                            headerCell.style.minWidth = bodyCell.style.minWidth = bodyCell.offsetWidth - (eps.PaddingLeft+ebs.BorderHorizontalWidth) + "px";
                        }
                    }
                }
               
                headerFixContainer[i].firstElementChild.onscroll = function(event){
                    event = event || window.event;
                    var source = event.target || event.srcElement;
                    var scrollLeft = source.scrollLeft;                    
                    
                    if((typeof pageDirection != 'undefined') && (pageDirection == 'rtl')) {
                        /*Browser           Type       Most Left    Most Right  Initial
                          WebKit(Chrome)    default    0            100         100
                          Gecko(Firefox)    negative   -100         0           0
                          IE                reverse    100          0           0
                        */
                       
                        var isFirefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
                        var isChrome = (typeof window.chrome != 'undefined') ? true : false;
                        var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1;
                        if (isChrome){
                            var scrollRight = source.scrollWidth - (scrollLeft + source.clientWidth);           
                            source.firstElementChild.tHead.firstElementChild.style.right = -1*scrollRight + "px";                
                        } 
                        else if(isFirefox || isSafari){
                            source.firstElementChild.tHead.firstElementChild.style.right = (scrollLeft) + "px"; 
                        //source.firstElementChild.tHead.firstElementChild.style.left = (-scrollLeft) + "px";                
                        } else {
                            source.firstElementChild.tHead.firstElementChild.style.right = -1*scrollLeft + "px";                
                        }                       
                    } else {
                        source.firstElementChild.tHead.firstElementChild.style.left = -1*scrollLeft + "px";                                        
                    }
              
                }     
            }
        }        
    }    
}

function hasCSS(element, cls) {
    var bHasClass = false;    
    if(element != null){
        bHasClass = (' ' + element.className + ' ').indexOf(' ' + cls + ' ') > -1;
    }
    
    return bHasClass;
}

function clickLink(linkId)
{    
    if(!linkId)
    {
        return false;
    }

    var fireOnThis = document.getElementById(linkId);
    
    if(fireOnThis != null && (fireOnThis.nodeName.toUpperCase() == "A")){
        if(fireOnThis.href.lastIndexOf("#") > -1){
            fireOnThis.href = "javascript:void(0)";
        }
    }
    
    if (document.createEvent && fireOnThis != null)
    {
        //var evObj = document.createEvent('MouseEvents') ;
        //evObj.initEvent( 'click', true, false ) ;
        //fireOnThis.dispatchEvent(evObj) ;
        var evObj = document.createEvent('MouseEvents') ;
        evObj.initMouseEvent("click", false, false, window,0, 0, 0, 0, 0, false, false, false, false, 0, null);
        fireOnThis.dispatchEvent(evObj) ;
    }
    else if (document.createEventObject && fireOnThis != null)
    {
        fireOnThis.click()  ;

    }
    return ;
}

function FAjaxErrorHandler(data){
    if(data.responseCode == '250')
    {
        window.location= "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";
    //        createPopUpIFrameWrapper('iFrameId','/omniapp/pages/error/errorpagepopup.app?msgID=-8002&HeadingID=8002',330,450);
    //        var screenHeight = window.screen.height;
    //        document.getElementById('iFrameId').style.top = screenHeight/6+"px";
    }
    else if(data.responseCode=='350'){
        //            createPopUpIFrameWrapper('iFrameId','/webdesktop/error/errorpagepopup.app?msgID=-8002&HeadingID=8002',330,450);
        //            var screenHeight = window.screen.height;
        //            document.getElementById('iFrameId').style.top = screenHeight/6+"px";
        window.parent.parent.initPopUp();
        window.parent.parent.setPopupMask();
        window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe','/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message='+INVALID_REQUEST_IS_MADE,140,435);
        var screenHeight = window.screen.height;
        //alert(window.parent.parent.document.getElementById('genericErrorIframe'));
        window.parent.parent.document.getElementById('genericErrorIframe').style.top = screenHeight/6+"px";
        window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 300;
    }
}

function HandleProgressBar(data){
    if(data.status == "begin"){
        CreateIndicator("application");
    }
    else if(data.status == "complete"){
        RemoveIndicator("application");
    }
    else if(data.status == "success"){
        handleFieldFocus(data);
    }
}

function CreateIndicator(indicatorFrameId){
    var ParentDocWidth = document.body.clientWidth;
    var ParentDocHeight = document.body.clientHeight;
    var ImgTop=ParentDocHeight/2-70;
    var ImgLeft=ParentDocWidth/2-25;
    try {
        if(document.getElementById(indicatorFrameId) != null){
            return;
        }
        img = document.createElement("IMG");
        img.setAttribute("src", "/webdesktop/resources/images/progressimg.gif");
        img.setAttribute("name", indicatorFrameId);
        img.setAttribute("id", indicatorFrameId);
        img.style.left = ImgLeft+"px";
        img.style.top = ImgTop+"px";
        img.style.width = "54px";
        img.style.height = "55px";
        img.style.position="absolute";
        img.style.zIndex = "201";
        img.style.visibility="visible";
        //initPopUp();setPopupMask();
        document.body.appendChild(img);
    }
    catch(ex) {}
    document.body.style.cursor='wait';
}

function RemoveIndicator(indicatorFrameId){
    try {
        
        var img = document.getElementById(indicatorFrameId);
        if(img!=null){
            document.body.removeChild(img);
        }
    // hidePopupMask();
    }
    catch(ex) {
        hidePopupMask();
    }
    document.body.style.cursor='auto';
}

function handleFieldFocus(data, ids) {
    var bAjaxRequest = true;
    if(data == null){
        bAjaxRequest = false;
    }

    if (!bAjaxRequest || (data.status == "success")) {
        if (!bAjaxRequest || data.requestObject){
            var FocusId = null;
            if(bAjaxRequest){
                FocusId = data.requestObject.getResponseHeader("FocusId");
            } else {
                if(ids != null){                    
                    FocusId = ids;
                }
            }
            
            if (FocusId != null && FocusId != ""){                
                FocusId = FocusId.split(","); 
                if(FocusId.length > 0){                    
                    var genericCSSNodeMap = {
                        "div": "div",
                        "table": "table"
                    };
                    var controlObj = null;
                    
                    for(var i=0; i<FocusId.length; i++){                        
                        controlObj = document.getElementById(FocusId[i]);
                        if(controlObj != null && !controlObj.disabled){
                            if(genericCSSNodeMap[controlObj.nodeName.toLowerCase()] != null){
                                addCSS(controlObj, "genericCSS");
                            } else {
                                addCSS(controlObj, "mandatoryControlCSS");
                            }
                            
                            if(FocusId.length == 1){
                                setElementFocus(controlObj);
                            }
                        }
                    }                    
                }
            }
        }
    }
}

function addCSS(ref, className) {    
    if(ref != null){
        ref.className += " "+className;
    }
}

function setElementFocus(controlObj){
    if((typeof controlObj != 'undefined') && (controlObj != null)){
        var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1;
        
        if(typeof window.chrome != 'undefined'){
            if(typeof controlObj.focus != 'undefined'){
                controlObj.focus();
            } else if(typeof controlObj.select != 'undefined'){
                controlObj.select();
            }
        } else if(isSafari){
            if(typeof controlObj.select != 'undefined'){
                controlObj.select();
            } else if(typeof controlObj.focus != 'undefined'){
                controlObj.focus();                                      
            }
        } else {
            if(typeof controlObj.select != 'undefined'){
                controlObj.select();
            } else if(typeof controlObj.focus != 'undefined'){
                controlObj.focus();
            }
        }  
    }
}

function getElementStyle(el, property){ 
    var styleJSON = {};
	
    switch(property){
        case "border":
            styleJSON = {
                BorderLeftWidth:0, 
                BorderRightWidth:0, 
                BorderTopWidth:0, 
                BorderBottomWidth:0
            };
            if (el.currentStyle){
                var value = el.currentStyle.borderLeftWidth.split('p')[0]-0;
                styleJSON.BorderLeftWidth = isNaN(value)? 0: value;
                value = el.currentStyle.borderRightWidth.split('p')[0]-0;
                styleJSON.BorderRightWidth = isNaN(value)? 0: value;
                value = el.currentStyle.borderTopWidth.split('p')[0]-0;
                styleJSON.BorderTopWidth = isNaN(value)? 0: value;
                value = el.currentStyle.borderBottomWidth.split('p')[0]-0;
                styleJSON.BorderBottomWidth = isNaN(value)? 0: value;
            } else if (window.getComputedStyle){
                styleJSON.BorderLeftWidth = getComputedStyle(el,null).getPropertyValue("border-left-width").split('p')[0]-0;
                styleJSON.BorderRightWidth = getComputedStyle(el,null).getPropertyValue("border-right-width").split('p')[0]-0;
                styleJSON.BorderTopWidth = getComputedStyle(el,null).getPropertyValue("border-top-width").split('p')[0]-0;
                styleJSON.BorderBottomWidth = getComputedStyle(el,null).getPropertyValue("border-bottom-width").split('p')[0]-0; 
            }
			
            styleJSON.BorderHorizontalWidth = styleJSON.BorderLeftWidth + styleJSON.BorderRightWidth;
            styleJSON.BorderVerticalWidth = styleJSON.BorderTopWidth + styleJSON.BorderBottomWidth;
            break;
			
        case "padding":
            styleJSON = {
                PaddingLeft:0, 
                PaddingRight:0, 
                PaddingTop:0, 
                PaddingBottom:0
            };
            if (el.currentStyle){
                styleJSON.PaddingLeft = el.currentStyle.paddingLeft.split('p')[0]-0;
                styleJSON.PaddingRight = el.currentStyle.paddingRight.split('p')[0]-0;
                styleJSON.PaddingTop = el.currentStyle.paddingTop.split('p')[0]-0;
                styleJSON.PaddingBottom = el.currentStyle.paddingBottom.split('p')[0]-0;
            } else if (window.getComputedStyle){
                styleJSON.PaddingLeft = getComputedStyle(el,null).getPropertyValue("padding-left").split('p')[0]-0;
                styleJSON.PaddingRight = getComputedStyle(el,null).getPropertyValue("padding-right").split('p')[0]-0;
                styleJSON.PaddingTop = getComputedStyle(el,null).getPropertyValue("padding-top").split('p')[0]-0;
                styleJSON.PaddingBottom = getComputedStyle(el,null).getPropertyValue("padding-bottom").split('p')[0]-0; 
            }
			
            styleJSON.PaddingHorizontalWidth = styleJSON.PaddingLeft + styleJSON.PaddingRight;
            styleJSON.PaddingVerticalWidth = styleJSON.PaddingTop + styleJSON.PaddingBottom;

            break;
    }
   
    return styleJSON;
}

function qehwe(p1,p2,p3,p4,p5,p6,p7){
    //p2=encode_utf8(p2);
    var qEHandlerPH = "{\"Outputs\":[{\"Output\":{\"Name\":\"QueueId\",\"Value\":\""+p1+"\",\"DefId\":\"1\"}},{\"Output\":{\"Name\":\"QueueName\",\"Value\":\""+p2.replace("'","\\'",'g')+"\",\"DefId\":\"2\"}},{\"Output\":{\"Name\":\"QueueType\",\"Value\":\""+p3+"\",\"DefId\":\"3\"}},{\"Output\":{\"Name\":\"SortOrder\",\"Value\":\""+p4+"\",\"DefId\":\"5\"}},{\"Output\":{\"Name\":\"OrderBy\",\"Value\":\""+p5+"\",\"DefId\":\"4\"}},{\"Output\":{\"Name\":\"AllowReassignment\",\"Value\":\""+p6+"\",\"DefId\":\"6\"}},{\"Output\":{\"Name\":\"EntityName\",\"Value\":\""+p7+"\",\"DefId\":\"7\"}}]}";        
    qehw('1','QueueClick',qEHandlerPH);
}

function checkCustomWorklist(queueId, queuename, queuetype, allowReassign, order, sortingorder, batchSize, batchingFlag,event_DefId,event_name,jsonoutput) {
    var doneLoader=ContentLoaderWrapper('/webdesktop/ajaxCheckFile.app', cutomWLHandler, callBackOnError, "POST", 'QueueName=' + encode_utf8(queuename) + '&QueueId=' + encode_utf8(queueId) + '&SortingOrder=' + sortingorder + '&QueueType=' + queuetype  + '&AllowReassign=' + allowReassign + '&Order=' + order + '&WD_SID=' + WD_SID ,null, null);
    doneLoader.event_DefId=event_DefId;
    doneLoader.event_name=event_name;
    doneLoader.jsonoutput=jsonoutput;
}

function cutomWLHandler() {
    try {
        var response = this.req.responseText;
        response = parseJSON("(" + response + ")");
        var isCustomWLFileExists = false;
        var queueID = "";
        var ErrorMsg = "";
        var customWLurl = "";
        var queueName = "";
        queueName = response.QueueName;
        isCustomWLFileExists = response.AllowCustomWLOperation == "Y" ? true : false;

        if (isCustomWLFileExists) {
            window.parent.allowCustomWL=true;
            window.parent.divCustomWLRef=window.parent.getComponentRefDiv(window.parent.iFrameWorkitemListRef.comp_ins_id);
            window.parent.iFrameCustomWLRef=window.parent.getComponentRef(window.parent.iFrameWorkitemListRef.comp_ins_id);
            window.parent.changePanelTitle(window.parent.iFrameWorkitemListRef.comp_ins_id,queueName);
            window.parent.componentNotifier(window.parent.iFrameWorkitemListRef.comp_ins_id,queueName);
       
            if (window.parent.iFrameCustomWLRef != null && typeof window.parent.iFrameCustomWLRef != 'undefined') {
                if (window.parent.iFrameCustomWLRef.style.visibility == "visible" || window.parent.iFrameCustomWLRef.style.display != 'none') {
                    window.parent.iFrameCustomWLRef.style.display = "none";
                }
            }

            customWLurl = response.CustomWLURL;
            var containerDiv;
            if (typeof window.parent.document.getElementById("customWLIframe") != 'undefined' && window.parent.document.getElementById("customWLIframe") != null) {
                window.parent.document.getElementById("customWLIframe").src = customWLurl;
                window.parent.document.getElementById("customWLIframe").style.display = "";
                if (window.parent.divCustomWLRef != null && typeof window.parent.divCustomWLRef != 'undefined') {
                    containerDiv = window.parent.document.getElementById(window.parent.divCustomWLRef.id);
                }
                /**
                if (typeof containerDiv != 'undefined' && containerDiv != null) {
                    containerHeight = getValueFromPX(containerDiv.style.height);
                    containerWidth = getValueFromPX(containerDiv.style.width);
                    containerTop = getValueFromPX(containerDiv.style.top);
                    window.parent.document.getElementById("customWLIframe").style.width = containerWidth + "px";
                    window.parent.document.getElementById("customWLIframe").style.height = containerHeight - 24 + "px";
                }
                */
            } else {
                createCustomIFrame(customWLurl);
            }
            return true;
        } else {
            if (typeof window.parent.document.getElementById("customWLIframe") != 'undefined' && window.parent.document.getElementById("customWLIframe") != null) {
                if (window.parent.document.getElementById("customWLIframe").style.visibility == "visible" || window.parent.document.getElementById("customWLIframe").style.display != 'none') {
                    window.parent.document.getElementById("customWLIframe").style.display = "none";
                }
            }
            if (window.parent.iFrameCustomWLRef != null && typeof window.parent.iFrameCustomWLRef != 'undefined') {
                if (window.parent.iFrameCustomWLRef.style.display == "none") {
                    window.parent.iFrameCustomWLRef.style.display = "";
                }
            }
            window.parent.allowCustomWL=false;
            QueueEventHandler(this.event_DefId,this.event_name,this.jsonoutput);
       
            ErrorMsg = response.ErrorMsg;
            return false;
        }
    } catch(e) {
        window.parent.allowCustomWL=false;
        QueueEventHandler(this.event_DefId,this.event_name,this.jsonoutput);
    }
}

function createCustomIFrame(url) {
    // Creates IFRAME
    var iframe = window.parent.document.createElement("IFRAME");
    /**
    var containerHeight;
    var containerWidth;
    var containerTop;
    var containerDiv;
    if (window.parent.divCustomWLRef != null && typeof window.parent.divCustomWLRef != 'undefined') {
        containerDiv = window.parent.document.getElementById(window.parent.divCustomWLRef.id);
    }
    if (typeof containerDiv != 'undefined' && containerDiv != null) {
        containerHeight = getValueFromPX(containerDiv.style.height);
        containerWidth = getValueFromPX(containerDiv.style.width);
        containerTop = getValueFromPX(containerDiv.style.top);
    }
    */
    //iframe.style.zIndex = "1001";
    iframe.setAttribute("src", url);
    iframe.setAttribute("name", "customWLIframe");
    iframe.setAttribute("id", "customWLIframe");
    iframe.frameBorder = "0";
    //iframe.style.frameBorder = "0";
    iframe.scrolling = "yes";
    //iframe.style.scrolling = "yes";
    iframe.style.visibility = "visible";
    // iframe.style.position="absolute";
    iframe.marginHeight = "0px";
    iframe.marginWidth = "0px";
    //iframe.style.width = containerWidth + "px";
    //iframe.style.height = containerHeight - 24 + "px";
    //iframe.style.left = 0 + "px";
    iframe.className = "embed-responsive-item";
    //iframe.style.top = containerTop - 27 + "px";
    iframe.style.backgroundColor = "white";
    window.parent.iFrameCustomWLRef.parentNode.insertBefore(iframe, window.parent.iFrameCustomWLRef.nextSibling);
}

function callBackOnError(){
    var status = this.req.status;
    var screenHeight = window.screen.height;
    if(status == 250){
        window.location= "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";
    }else if(status == 350){
        window.parent.parent.initPopUp();
        window.parent.parent.setPopupMask();
        window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe','/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message='+INVALID_REQUEST_IS_MADE,140,435);
            
        window.parent.parent.document.getElementById('genericErrorIframe').style.top = screenHeight/6+"px";
        window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 300;
    } else if(status == 599){
        window.parent.parent.initPopUp();
        window.parent.parent.setPopupMask();
        window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe','/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message='+INVALID_SESSION,140,435);
            
        window.parent.parent.document.getElementById('genericErrorIframe').style.top = screenHeight/6+"px";
        window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 300;
    }else{
        window.parent.parent.initPopUp();
        window.parent.parent.setPopupMask();
        window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe','/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message='+ERROR_AT_SERVER_END,140,435);
            
        window.parent.parent.document.getElementById('genericErrorIframe').style.top = screenHeight/6+"px";
        window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 300;
    // alert(ERROR_DATA);
    }
}

var ENCODING="UTF-8";
function encode_utf8(ch)
{
    if (ENCODING.toUpperCase() != "UTF-8")
        return escape(ch);
    
    return encodeURIComponent(ch);
}

function appendUrlSessionAjax(url)
{
    return handleJSessionID(url);
}
var cookie = navigator.cookieEnabled;
var sessionVal="";

function handleJSessionID(url)
{
    var cookieFlag = 'Y';


    if(cookie)
        cookieFlag = 'Y';
    else
        cookieFlag = 'N';

    try
    {
        if(cookieFlag == 'N' && SessionVariable!="" )
        {
            if(url.indexOf('?') != '-1')
                url = url.substring(0,url.indexOf('?'))+SessionVariable+url.substring(url.indexOf('?'));
            else
                url = url + SessionVariable;
        }
    }catch(Ex)
    {
        var frmAction = document.forms[0].action;
        if(sessionVal == "" && frmAction.indexOf(";")!="-1")
            sessionVal = frmAction.substring(frmAction.indexOf(";"));

        if(cookieFlag == 'N' && sessionVal!="" )
        {
            if(url.indexOf('?') != '-1')
                url = url.substring(0,url.indexOf('?'))+sessionVal+url.substring(url.indexOf('?'));
            else
                url = url + sessionVal;
        }
    }
    return url;
}

/*----------------QueueList Ext Function Start-------------------------------------------*/
function addToFavQueue(ref, qid) {
    document.getElementById("preferenceForm:paramQid").value = qid;
    document.getElementById("preferenceForm:paramOperation").value = "";
    document.getElementById("preferenceForm:setPreferences").click();
    // document.getElementById("preferenceForm:setPreferences").click();
}
function removeFromFavQueue(qid) {
    document.getElementById("preferenceForm:paramQid").value = qid;
    document.getElementById("preferenceForm:paramOperation").value = "D";
    document.getElementById("preferenceForm:removeFromPreference").click();
}
function fetchNextBatch(comp_id) {
    if (comp_id == 'prevBatch') {
        document.getElementById("preferenceForm:prevCmdLink").click();
    } else {
        document.getElementById("preferenceForm:nextCmdLink").click();
    }
}
function toggleSearchBar(type) {
    var qLabel=document.getElementById("preferenceForm:queueLabel");
    var prefixRef = document.getElementById("preferenceForm:prefix");
    var searchQueue = document.getElementById("searchQueue");
    var showResult= document.getElementById("showResult");
    var closeSearch=document.getElementById("closeSearch");
    var queueRef=document.getElementById("preferenceForm:queuePrefix");
    
    if (type == 'S') {
        qLabel.style.display = "none";
        closeSearch.style.display = "";
        prefixRef.style.display = "";
        showResult.style.display="";
        searchQueue.style.display="none";
    } else if(type == 'H'){
         qLabel.style.display = "";
         closeSearch.style.display = "none";
         prefixRef.style.display = "none";
         prefixRef.value=SEARCH_QUEUE;
         queueRef.value="";
         showResult.style.display="none";
         searchQueue.style.display="";
         clickLink("preferenceForm:lnkRefreshQM");
    }
    
}

var loadedQueue;
function loadWorkitemList(qid,qname,qtype,allowResign,orderBy,sortOrder,batchSize,batchingFlag){
    if(qid != '0'){
        window.parent.toogleOverlay();
    }
  window.parent.switchView('M');
  
  //if(loadedQueue!=qid){
    //  loadedQueue=qid;
    if(typeof window.parent.queueClickHandler!='undefined'){
        window.parent.queueClickHandler();
    }
      window.parent.iFrameWorkitemListRef.ReloadWorkitemList(qid,qname,qtype,allowResign,orderBy,sortOrder,batchSize,batchingFlag);
  //}
  
}

function searchQueue(){
    var ref = document.getElementById("preferenceForm:queuePrefix");
    if(ref != null){
        ref.value=document.getElementById("preferenceForm:prefix").value;
    } 
    
    if(ref.value == SEARCH_QUEUE){
        ref.value="";
        clickLink("preferenceForm:cmdBtn");
    }
    else{
        clickLink("preferenceForm:cmdBtn");
    }
}

/*----------------QueueListExt Function End-------------------------------------------*/

var newWICurrentSrc = null;
var iQCurrentSrc = null;
var introQueueListLoaded = false;
var iqlMenuParent = null;
function getIntroQueueList(e,thisId,parent){  
    parent = (typeof parent =='undefined')?window:parent;
    iqlMenuParent = parent;
    
    cancelBubble(e);
    
    var itemListRef = document.getElementById("preferenceForm:iqlist");
    var oapMenuVisible = isOAPItemMenuVisible(itemListRef);
    
    var thisRef = parent.document.getElementById(thisId);
    
    if(!oapMenuVisible || iQCurrentSrc != thisRef){
        if(!introQueueListLoaded){    
            iQCurrentSrc = thisRef;
            clickLink("preferenceForm:getIntroQueueList");
            introQueueListLoaded = true;
        } else {
           var rd = null;
           if(iqlMenuParent==window){
                rd = iqlMenuParent.getRealDimension(thisRef);        
           } else {
               rd = iqlMenuParent.getRealDimension(iqlMenuParent,thisRef);
           }

           var left = iqlMenuParent.findAbsPosX(thisRef)+rd.Width+5;
           var top = iqlMenuParent.findAbsPosY(thisRef);
           if(iqlMenuParent==window){
               
           } else {
               if((typeof pageDirection != 'undefined') && (pageDirection == 'rtl'))
                   left =  rd.Width+5;
           }
           showOAPItemMenu(iQCurrentSrc,itemListRef,window.frameElement.contentWindow,true,true,left,top);
        }
    } else {
        hideAllOAPItemPMenu(null,thisRef);
    }
}

function getIntroQueueListHandler(data){
    HandleProgressBar(data);
      
    if(data.status=='success'){       
        var hidiQueueError = document.getElementById('preferenceForm:hidiQueueError').value;
        if(hidiQueueError == "false"){
           var itemListRef = document.getElementById("preferenceForm:iqlist");
           var rd = null;
           if(iqlMenuParent==window){
                rd = iqlMenuParent.getRealDimension(iQCurrentSrc);        
           } else {
               rd = iqlMenuParent.getRealDimension(iqlMenuParent,iQCurrentSrc);
           }

           var left = iqlMenuParent.findAbsPosX(iQCurrentSrc)+rd.Width+5;
           var top = iqlMenuParent.findAbsPosY(iQCurrentSrc);
           if(iqlMenuParent==window){
               
           } else {
               if((typeof pageDirection != 'undefined') && (pageDirection == 'rtl'))
                   left =  rd.Width+5;
           }
           showOAPItemMenu(iQCurrentSrc,itemListRef,window.frameElement.contentWindow,true,true,left,top);
        }
    }
}

var menuParent = null;
function createNewWi(e,thisId,qid,qname,parent){       
    cancelBubble(e);
    parent = (typeof parent =='undefined')?window:parent;
    menuParent = parent;
    
    var itemListRef = document.getElementById("preferenceForm:qprclist");
    var oapMenuVisible = isOAPItemMenuVisible(itemListRef);
    var thisRef = parent.document.getElementById(thisId);
    
    if(!oapMenuVisible || newWICurrentSrc != thisRef){
        newWICurrentSrc = thisRef;
        document.getElementById("preferenceForm:hidQueueId").value=qid;
        document.getElementById("preferenceForm:hidQN").value=qname;
        clickLink("preferenceForm:getQueueProcessList");        
    } else {
        hideAllOAPItemPMenu(null,thisRef);
    }
}
function AlertMsgFavQueueProperties(data) {
    if (data.status == 'success') {
        var errorFlag = document.getElementById('preferenceForm:hidErrorQueueProp').value;
        var errorMsg = document.getElementById('preferenceForm:hidmsgQueueProp').value;
        if (errorFlag == 'true')
            window.parent.customFloater(errorMsg,'error');
    }

}
function createNewWiWrapperHandler(data){
   HandleProgressBar(data);
      
   if(data.status=='success'){       
        var bPrcListError = document.getElementById('preferenceForm:hidbPrcListError').value;
        var bMultiplePrc = document.getElementById('preferenceForm:hidMultiplePrc').value;
        var PDefIdNewWi = document.getElementById('preferenceForm:hidPDefIdNewWi').value;
        var PVariantIdNewWi = document.getElementById('preferenceForm:hidPVariantIdNewWi').value;

        if(bPrcListError == "true" || bMultiplePrc == "true"){
           var itemListRef = document.getElementById("preferenceForm:qprclist");
           var rd = getRealDimension(newWICurrentSrc);        

           var scroll2 = document.getElementById("scroll2");

           var left = findAbsPosX(newWICurrentSrc)+rd.Width-scroll2.scrollLeft+5;
           if(menuParent != null){
               left-=5;
           }
           if(iqlMenuParent==window){
               if((typeof pageDirection != 'undefined') && (pageDirection == 'rtl'))
                   left =  rd.Width+getRealDimension(iQCurrentSrc).Width + 20;
           } else {
               if((typeof pageDirection != 'undefined') && (pageDirection == 'rtl'))
                   left =  rd.Width+getRealDimension(iQCurrentSrc).Width + 10;
           }
           
           var top = menuParent.findAbsPosY(newWICurrentSrc)-scroll2.scrollTop;//+10;
           showOAPItemMenu(newWICurrentSrc,itemListRef,window.frameElement.contentWindow,true,true,left,top);
        } else if(PDefIdNewWi != "") {
            hideAllOAPItemPMenu();
            openNewWorkitem(PDefIdNewWi,PVariantIdNewWi,'preferenceForm','QL');
        }
   }
}

function onDocClickQL(e){
    var eventTarget = (e && e.target) || (event && event.srcElement);
    
    var bMenuCtrClick = hasCSS(eventTarget,'fmcc');
    if(!bMenuCtrClick){
        window.parent.hideAllOAPMenu(null,eventTarget,true);
    }
}

function showprogress(data){
    window.parent.HandleProgressBarEx(data);
}