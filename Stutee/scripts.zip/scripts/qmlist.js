function scbck(nodeChkBox,showQProperty,showQUserProp,showQActivityProp,showQDelete)
{
    var iCount;
    var index = nodeChkBox.id.lastIndexOf(':');
    var arr=nodeChkBox.id.split(":");
    var iArrLength = arr.length ;
    var strName="";
    for (var count=0; count < arr.length-2 ; count++ )
    {
        if(count==0)
            strName = arr[count] ;
        else
        {
            strName=strName + ":" + arr[count] ;
        }
    }
    var btnUpdate=document.getElementById("QueueListForm:BtnUpdate");
    var btndisUpdate=document.getElementById("QueueListForm:BtndisUpdate");
    var btnDelete=document.getElementById("QueueListForm:BtnDelete");
    var btndisDelete=document.getElementById("QueueListForm:BtndisDelete");
    var BtnAdd=document.getElementById("QueueListForm:BtnAdd");
    var BtndisAdd=document.getElementById("QueueListForm:BtndisAdd");
    
    var btnMoreUpdate=document.getElementById("QueueListForm:panel:BtnMoreUpdate");
    var btnMoredisUpdate=document.getElementById("QueueListForm:panel:BtnMoredisUpdate");
        
    var btnMoreDelete=document.getElementById("QueueListForm:panel:BtnMoreDelte");
    var btnMoreDisDelete=document.getElementById("QueueListForm:panel:BtnMoredisDelete");
    
    var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length;
    if(nodeChkBox.checked == true)
    {
         BtnAdd.style.display="none";
         BtndisAdd.style.display="inline-block";
         
        for(iCount = 0; iCount < rowCount;iCount++)
        {

            if(iCount != arr[iArrLength-2])
            {
                var el=document.getElementById(strName+":"+iCount +":"+arr[iArrLength-1]);
                if(el!=undefined) //Ref BugId-61913
                    el.checked=false;
            }
        }
        
        if(showQProperty=="false" && showQUserProp=="false" && showQActivityProp=="false"){
            if(btnUpdate!=null && btnUpdate!=undefined){
                btnUpdate.style.display="none";
                btndisUpdate.style.display="inline-block";
            }
           
        }else{
            if(btnUpdate!=null && btnUpdate!=undefined){
                btnUpdate.style.display="inline-block";
                btndisUpdate.style.display="none"; 
            }
            
        }
        if(showQDelete=="false"){
            if(btnDelete!=null && btnDelete!=undefined){
                btnDelete.style.display="none";
                btndisDelete.style.display="inline-block";
            }
            
        }else{
            if(btnDelete!=null && btnDelete!=undefined){
                btnDelete.style.display="inline-block";
                btndisDelete.style.display="none";
            }           
        }        
               
        if(btnMoreUpdate!=null){
            if(showQProperty=="false" && showQUserProp=="false" && showQActivityProp=="false"){
                btnMoreUpdate.style.display="none";
                btnMoredisUpdate.style.display="inline-block";
            }else{
                btnMoreUpdate.style.display="inline-block";
                btnMoredisUpdate.style.display="none";
            }
        }
        
        if(btnMoreDelete!=null){
            if(showQDelete=="false"){
                btnMoreDelete.style.display="none";
                btnMoreDisDelete.style.display="inline-block";
            }else{
                btnMoreDelete.style.display="inline-block";
                btnMoreDisDelete.style.display="none";
            }
            
        }
    }else{
        BtnAdd.style.display="inline-block";
        BtndisAdd.style.display="none";
        
        if(btnUpdate!=null && btnUpdate!=undefined && btndisUpdate!=null && btndisUpdate!=undefined){
            btnUpdate.style.display="none";
            btndisUpdate.style.display="inline-block";
        }
       
        if(btnDelete!=null && btnDelete!=undefined && btndisDelete!=null && btndisDelete!=undefined){
            btnDelete.style.display="none";
            btndisDelete.style.display="inline-block"; 
        }
           
        if(btnMoreUpdate!=null){
            btnMoreUpdate.style.display="none";
            btnMoredisUpdate.style.display="inline-block";
        }
        if(btnMoreDelete!=null){
            btnMoreDelete.style.display="none";
            btnMoreDisDelete.style.display="inline-block";
        }
    }
}

function updateQueue(ref)
{
    RefreshLink=ref;
    var QueueID="-1";
    var iCount=0;
    var pendingActions="";
    var queueName = "";
    var rightString=""
    try
    {
        for(iCount=0;;iCount++)
        {
            var ctrlName= "QueueListForm:queueLists:" + iCount +":chkBoxQueue";
            var ctrlName2 ="QueueListForm:queueLists:" + iCount +":queueType";
            
            if((document.getElementById(ctrlName)).checked==true)
            {
                rightString=document.getElementById("QueueListForm:queueLists:" + iCount +":hidUserRightString").value;
                if(document.getElementById(ctrlName2).value=="I")
                {
                
                }
                ctrlName="QueueListForm:queueLists:" + iCount +":queueID";
                QueueID=(document.getElementById(ctrlName)).value;                
                queueName = document.getElementById("QueueListForm:queueLists:" + iCount +":queueName").value                
                try
                {
                    pendingActions=document.getElementById("QueueListForm:queueLists:"+ iCount +":PendingActions").value;
                }
                catch(ex)
                {}
                   
                break;
            }
        }
    }
    catch(ex)
    {
        alert(NO_QUEUE_SELECTED);
        return;
    }   
    var Url="/webdesktop/components/queue/queuemgmt.app";
    Url = appendUrlSession(Url);
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window6H+85;
    var WindowWidth=window6W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2) - 15;
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;
    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("Mode",encode_ParamValue("2")));
    listParam.push(new Array("showTab",encode_ParamValue("1")));
    listParam.push(new Array("QueueID",encode_ParamValue(QueueID)));
    listParam.push(new Array("QueueName",encode_utf8(queueName)));
    listParam.push(new Array("PendingActions",encode_ParamValue(pendingActions)));
    listParam.push(new Array("RightString",encode_ParamValue(rightString)));
        
    var win = openNewWindow(Url,"changequeue"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}

function showOptions(ref){
    var moreDiv = document.getElementById('MoreDiv');
    if(moreDiv != null){
        if(moreDiv.style.display == 'none'){
            var posLeft = findPosX(ref);
            var posTop = findPosY(ref);
            moreDiv.style.left = posLeft + "px";
            moreDiv.style.top = posTop + 88 + "px";
            moreDiv.style.display = 'inline';
        }
        else{
            moreDiv.style.display = 'none';
        }
    }
}
function removeOptions()
{
    var moreDiv = document.getElementById('MoreDiv');
    if(moreDiv != null && moreDiv.style.display == 'inline'){
        moreDiv.style.display = 'none';
    }
}

function delQueue()
{
    var QueueID="-1";
    var iCount=0;
    try
    {
        for(iCount=0;;iCount++)
        {
            var ctrlName= "QueueListForm:queueLists:" + iCount +":chkBoxQueue";
            if((document.getElementById(ctrlName)).checked==true)
            {
                ctrlName="QueueListForm:queueLists:" + iCount +":queueID";
                QueueID=(document.getElementById(ctrlName)).value;
                ctrlName="QueueListForm:queueLists:" + iCount +":queueType";
                if(document.getElementById(ctrlName).value=="I" || document.getElementById(ctrlName).value=="Q" || document.getElementById(ctrlName).value=="E" || document.getElementById(ctrlName).value=="H")
                {
                    alert(QUEUE_CAN_NOT_BE_DELETED);
                    document.getElementById("QueueListForm:hidQueueId").value="";
                    return false;
                }
                else
                {
                    document.getElementById("QueueListForm:hidQueueId").value=QueueID;
                    return true;                    
                }
            }
        }
    }
    catch(ex)
    {
        alert(NO_QUEUE_SELECTED);
        document.getElementById("QueueListForm:hidQueueId").value="";
        return false;
    }
    return false;
}
            
function newQueue(ref)
{
    RefreshLink=ref;
    var QueueID="123";
    
    var Url="/webdesktop/components/queue/queuemgmt.app";
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window6H+85;
    var WindowWidth=window6W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2) - 15;
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;
    
    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("Mode",encode_ParamValue("1")));
    listParam.push(new Array("showTab",encode_ParamValue("1")));
    listParam.push(new Array("QueueID",encode_ParamValue(QueueID)));
    var win = openNewWindow(Url,"newqueue"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}            
function delQueueConfirm()
{
    try
    {
        var toclickid='QueueListForm:btnConfirmDelete';
        clickLink(toclickid);
    }
    catch(e)
    {
    }
}
function RefreshAdminOption()
{   
    if(RefreshLink !=null)
    {
        ClickAnotherLink(RefreshLink,'cmdBtn');
    }
}