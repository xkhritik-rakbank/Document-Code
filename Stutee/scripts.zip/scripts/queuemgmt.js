
var WD_SID;
function tabGeneralOnLoad(data){
    HandleProgressBar(data);
    
    if(data.status=="success"){
        ActiveTab="GeneralTab";
        onloadfunc();
        QueuepropertiesOnLoad();
        arabicFixHeader(); //Bug 75839 
        if(document.getElementById("QueueMgmtForm:hidQType").value==="G") {
            enableDisableActMobTabs('D');
        }
    }
    resizeContainers();
}
function tabUserOnLoad(data){
    HandleProgressBar(data);   
    if(data.status=="success"){
     ActiveTab="UserTab";
        QueuepropertiesOnLoad();
        arabicFixHeader();//Bug 75839
        if(document.getElementById("QueueMgmtForm:hidQType").value==="G") {
            enableDisableActMobTabs('D');
        }
    }
    resizeContainers();
}
function tabActivityOnLoad(data){
    HandleProgressBar(data);
    if(data.status=="success"){
         setValuesStream();
         ActiveTab="ActivityTab";
         document.getElementById("QueueMgmtForm:txtProcessName").value = "";
         QueuepropertiesOnLoad();
         arabicFixHeader();//Bug 75839 
    }
    resizeContainers();
}
function tabMobileConfigurationsOnLoad(data){
    HandleProgressBar(data);
    if(data.status=="success"){       
       ActiveTab="MobileConfigurationsTab";
       QueuepropertiesOnLoad();
       arabicFixHeader();//Bug 75839 
    }
    resizeContainers();
}

function onloadfunc()       //for bug id 1726
{
    onloadparam = true;    
    setValues(); 
    if(document.getElementById('QueueMgmtForm:hidDisable').value == 'true'){
        try{
            disableAll();
        } catch(e){            
        }
    }
    if((qRefreshinterval-0)>0){
        if(document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"])
        {
            document.getElementById("QueueMgmtForm:refreshInterval").disabled=false;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"].checked='checked';
        }
    }
    onloadparam = false;
    
//    $.mCustomScrollbar.defaults.scrollButtons.enable=true;
//    $.mCustomScrollbar.defaults.axis="y";
//    $.mCustomScrollbar.defaults.autoHideScrollbar=true;
//    $("body").mCustomScrollbar({theme:"dark"});
    if(ActiveTab=='GeneralTab'){
        if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optGlobal"] && document.forms["QueueMgmtForm"]["QueueMgmtForm:optGlobal"].checked)
            clickGlobal();
    }
}
function disableAll()
{
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][0].disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][1].disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].disabled=true;
    document.getElementById("QueueMgmtForm:chkAllowReassignment").disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_All"].disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=true;
    document.getElementById("QueueMgmtForm:cmbEqualTo").disabled=true;
    document.getElementById("QueueMgmtForm:cmbNotEqualTo").disabled=true;
    document.getElementById("QueueMgmtForm:QueueOrderByWIP").disabled=true;
    document.getElementById("QueueMgmtForm:QueueSortOrderWIP").disabled=true;
     //document.getElementById("QueueMgmtForm:cmd_ProcessVar").disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifo"].disabled=true;

    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWip"].disabled=true;

    document.getElementById("QueueMgmtForm:txtQueueName").disabled=true;

    document.getElementById("QueueMgmtForm:txtDescription").disabled=true;
    if(document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"])
    {
        document.getElementById("QueueMgmtForm:refreshInterval").disabled=true;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"].disabled=true;
    }

}
function showRefreshTime()
{
    if(document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"].checked)
    {
        document.getElementById("QueueMgmtForm:refreshInterval").disabled=false;
    }
    else
    {
        document.getElementById("QueueMgmtForm:refreshInterval").disabled=true;
    }
}

function enableDisableActMobTabs(val){
    if(val=='E'){        
        document.getElementById('QueueMgmtForm:activityTab').classList.add("toolbarLink");
        document.getElementById('QueueMgmtForm:activityTab').classList.remove("toolbarLinkDisabled");
        document.getElementById('QueueMgmtForm:mobileConfTab').classList.add("toolbarLink");
        document.getElementById('QueueMgmtForm:mobileConfTab').classList.remove("toolbarLinkDisabled");
    } else if(val=='D'){
        document.getElementById('QueueMgmtForm:activityTab').classList.remove("toolbarLink");
        document.getElementById('QueueMgmtForm:activityTab').classList.add("toolbarLinkDisabled");
        document.getElementById('QueueMgmtForm:mobileConfTab').classList.remove("toolbarLink");
        document.getElementById('QueueMgmtForm:mobileConfTab').classList.add("toolbarLinkDisabled");
    }
}
function clickFIFO()
{
    //document.getElementById("QueueMgmtForm:divFIFO").style.display="inline";
    document.getElementById("QueueMgmtForm:divWIP").style.display="none";
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifo"].checked=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWip"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optGlobal"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][0].checked=true;
    //document.getElementById("QueueMgmtForm:pnlGeneralTab").style.minHeight="450px";
    setValues();
    document.getElementById("QueueMgmtForm:QueueSortOrderWIP").style.display = "none";
    document.getElementById("QueueMgmtForm:QueueSortOrderFIFO").style.display = "inline";
    document.forms["QueueMgmtForm"]["QueueMgmtForm:chkProce"].disabled=false;
    enableDisableActMobTabs('E');

}

function clickWIP()
{
//    document.getElementById("QueueMgmtForm:divFIFO").style.display="none";
    document.getElementById("QueueMgmtForm:divWIP").style.display="inline";
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifo"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWip"].checked=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optGlobal"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].checked=true;
    //document.getElementById("QueueMgmtForm:QueueOrderByWIP").options[9].selected=true;
    document.getElementById("QueueMgmtForm:QueueOrderByWIP").disabled=false;
    //document.getElementById("QueueMgmtForm:cmd_ProcessVar").disabled=false;
    //document.getElementById("QueueMgmtForm:pnlGeneralTab").style.minHeight="500px";

    document.getElementById("QueueMgmtForm:QueueSortOrderWIP").options[1].selected=true;
    clickAll();
    setValues();
    document.getElementById("QueueMgmtForm:QueueSortOrderFIFO").style.display = "none";
    if(strLocale=='ar-SA' || strLocale=='ar'){
        document.getElementById("QueueMgmtForm:QueueSortOrdeLbl").style.paddingLeft = "16px";//Bug 69109 
    }
    else{
        document.getElementById("QueueMgmtForm:QueueSortOrdeLbl").style.paddingRight = "50px";//Bug 69109 
    }
    
    document.getElementById("QueueMgmtForm:QueueSortOrderWIP").style.display = "inline";
    document.forms["QueueMgmtForm"]["QueueMgmtForm:chkProce"].disabled=false;
    enableDisableActMobTabs('E');
}

function clickGlobal() {
    document.getElementById("QueueMgmtForm:divWIP").style.display="none";
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifo"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWip"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optGlobal"].checked=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:chkProce"].disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:chkProce"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:txtProcName"].value="";
    document.forms["QueueMgmtForm"]["QueueMgmtForm:txtProcName"].disabled=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:cmdPicklist_Proc"].disabled=true; 
    document.forms["QueueMgmtForm"]["QueueMgmtForm:hidQProcessName"].value=""; 
    setValues();
    enableDisableActMobTabs('D');
    
}

function clickAll()
{
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_All"].checked=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].checked=false;

    setCombos();

}

function clickEqual()
{
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_All"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].checked=true;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].checked=false;

    setCombos();
}

function clickNotEqual()
{
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_All"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].checked=false;
    document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].checked=true;

    setCombos();
}

function clickOkWithComments()
{
    clickLink('QueueMgmtForm:btnOk');
}
function disableother(ref)
{
    if(ref=='optWipfetch2')
    {
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].checked=true;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].value="";
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].checked=false;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].checked=false;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=true;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch4"].checked=false;  
	document.forms["QueueMgmtForm"]["QueueMgmtForm:searchfilter"].disabled=true;
    }
    else if(ref=='optWipfetch3')
    {
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].checked=true;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].value="";
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].checked=false;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].checked=false;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=true;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch4"].checked=false;  
	document.forms["QueueMgmtForm"]["QueueMgmtForm:searchfilter"].disabled=true;
    }
    else if(ref=='optWipfetch1')
    {
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].checked=true;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].checked=false;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].checked=false;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=false;
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch4"].checked=false;  
	document.forms["QueueMgmtForm"]["QueueMgmtForm:searchfilter"].disabled=true;
    }
    else if(ref=='optWipfetch4')		
    {
          document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].checked=false;  
          document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].checked=false;
          document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].checked=false;
          document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch4"].checked=true;  
          document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=true;
          document.forms["QueueMgmtForm"]["QueueMgmtForm:searchfilter"].disabled=false;
    }
}
function setCombos()
{
    if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].checked && document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].disabled==false)
        document.getElementById("QueueMgmtForm:cmbEqualTo").disabled=false;
    else
        document.getElementById("QueueMgmtForm:cmbEqualTo").disabled=true;

    if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].checked && document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].disabled==false)
        document.getElementById("QueueMgmtForm:cmbNotEqualTo").disabled=false;
    else
        document.getElementById("QueueMgmtForm:cmbNotEqualTo").disabled=true;
}

function setValues()
{
    if(bError && bError2)
    {
        disableAll();
    }
    if(!disIntQ)
    {try{
        if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifo"].checked)
        {
            //document.getElementById("QueueMgmtForm:pnlGeneralTab").style.minHeight="450px";
            //document.getElementById("QueueMgmtForm:divFIFO").style.display="inline";
            document.getElementById("QueueMgmtForm:divWIP").style.display="none";
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][0].disabled=false;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][1].disabled=false;

            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].disabled=true;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].disabled=true;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].disabled=true;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch4"].disabled=true;

            document.getElementById("QueueMgmtForm:chkAllowReassignment").disabled=true;
            //document.getElementById("QueueMgmtForm:QueueOrderByWIP").disabled=true;
            //document.getElementById("QueueMgmtForm:cmd_ProcessVar").disabled=true;
            //document.getElementById("QueueMgmtForm:QueueSortOrderWIP").disabled=true;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_All"].disabled=true;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].disabled=true;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].disabled=true;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=true;
            if(document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"])
            {
                document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"].disabled=true;
                document.getElementById("QueueMgmtForm:refreshInterval").disabled=true;
            }
            setCombos();
            document.getElementById("QueueMgmtForm:QueueSortOrderFIFO").style.display = "inline";
            document.getElementById("QueueMgmtForm:QueueSortOrderWIP").style.display = "none";
        }
        else if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWip"].checked)
        {
            if(m_strAssignmentType=="Search"){
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].disabled=true;
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].disabled=true;
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].disabled=true;
                document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=true;
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch4"].disabled=false; 
                document.forms["QueueMgmtForm"]["QueueMgmtForm:searchfilter"].disabled=false;
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifo"].disabled=true;
                }
            else{
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifo"].disabled=false;
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].disabled=false;
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].disabled=false;
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].disabled=false;

                 document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch4"].disabled=false; 
                document.forms["QueueMgmtForm"]["QueueMgmtForm:searchfilter"].disabled=true;
                if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].checked)   //for bug id 1726
                {
                    document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=false;
                }
                else
                {
                    document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=true;
                }

            }  
            //document.getElementById("QueueMgmtForm:pnlGeneralTab").style.minHeight="500px";
//            document.getElementById("QueueMgmtForm:divFIFO").style.display="none";
            document.getElementById("QueueMgmtForm:divWIP").style.display="inline";
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][0].disabled=true;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][1].disabled=true;

            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].disabled=false;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].disabled=false;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].disabled=false;
            document.getElementById("QueueMgmtForm:chkAllowReassignment").disabled=false;
            //document.getElementById("QueueMgmtForm:QueueOrderByWIP").disabled=false;
            //document.getElementById("QueueMgmtForm:QueueSortOrderWIP").disabled=false;
            if(document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"])
                document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"].disabled=false;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_All"].disabled=false;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].disabled=false;
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].disabled=false;
//            if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].checked)   //for bug id 1726
//            {
//                document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=false;
//            }
//            else
//            {
//                document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=true;
//            }
            if(!onloadparam)
            {
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].checked=false;
                document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].checked=false;
                document.forms["QueueMgmtForm"]["QueueMgmtForm:chkAllowReassignment"].checked=false;
            }

            setCombos();
            document.getElementById("QueueMgmtForm:QueueSortOrderFIFO").style.display = "none";
           if(strLocale=='ar-SA' || strLocale=='ar'){
        document.getElementById("QueueMgmtForm:QueueSortOrdeLbl").style.paddingLeft = "16px";//Bug 69109 
    }
    else{
        document.getElementById("QueueMgmtForm:QueueSortOrdeLbl").style.paddingRight = "50px";//Bug 69109 
    }
            document.getElementById("QueueMgmtForm:QueueSortOrderWIP").style.display = "inline";

        }
        if(m_strMode=="1"){
            document.getElementById("QueueMgmtForm:txtQueueName").focus();
        }
        
    }catch(ex){}
    }
    
}
function submitValues(element)
{
    if(bError && bError2)
    {
        return false;
    }
    else
    {
        var qName="";
        var qDesc="";
        var qType=m_strQueueType;
        var qOrderBy="";
        var qSortOrder="";
        var qReAssignment="N";
        var qFilterOption="";
        var FilterValue="";
        var qID="";
        var GenealXML="";
        var qRefreshinterval="";
        var qFilter="";
        var qProcSpecific=false;
        var qProcName="";
        var qOrderByName="";
        var objQueueSortOrder;
        qName=document.getElementById("QueueMgmtForm:txtQueueName").value;
        qName=Trim(qName);
        qDesc=document.getElementById("QueueMgmtForm:txtDescription").value;
        qDesc=Trim(qDesc);
        if(qName.length==0)
        {
            customAlert(SPECIFY_QUEUE_NAME);
            document.getElementById("QueueMgmtForm:txtQueueName").focus();
            return false;
        }
        if(document.forms["QueueMgmtForm"]["QueueMgmtForm:chkProce"]){
            qProcSpecific=document.forms["QueueMgmtForm"]["QueueMgmtForm:chkProce"].checked;

            if(qProcSpecific){
                if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optGlobal"]!=null && typeof document.forms["QueueMgmtForm"]["QueueMgmtForm:optGlobal"]!='undefined' && document.forms["QueueMgmtForm"]["QueueMgmtForm:optGlobal"].checked) {
                    checkQProcflag=false;
                } else {
                    checkQProcflag=true;
                }
                if(checkQProcflag){
                   qProcName=Trim(document.getElementById("QueueMgmtForm:txtProcName").value);                        
                    if(qProcName==""){
                        customAlert(ALERT_SELECT_PROCESSNAME);
                        return false;
                    } 
                }                   
            }
        }

        GenealXML="<" + TAG_QueueName + ">" + qName + "</" + TAG_QueueName + ">";
        GenealXML=GenealXML + "<" + TAG_Description + ">" + handleSpecialChar(qDesc) + "</" + TAG_Description + ">";
        GenealXML=GenealXML + "<" + TAG_QPROCESSNAME + ">" + qProcName + "</" + TAG_QPROCESSNAME + ">";
        if(!disIntQ)
        {
            if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifo"].checked)
            {
                qType="F";
                document.forms["QueueMgmtForm"]["QueueMgmtForm:hidQType"].value="FIFO";
                 if(qType=="F"){
                     objQueueSortOrder=document.getElementById("QueueMgmtForm:QueueSortOrderFIFO");
                 }else{
                     objQueueSortOrder=document.getElementById("QueueMgmtForm:QueueSortOrderWIP");
                 } 
                qOrderBy = document.getElementById("QueueMgmtForm:hidQOrderBy").value;
                qSortOrder=objQueueSortOrder.options[objQueueSortOrder.selectedIndex].value;
                qOrderByName=document.getElementById("QueueMgmtForm:hidQOrderByName").value;

            }
            else if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWip"].checked)
            {
                document.forms["QueueMgmtForm"]["QueueMgmtForm:hidQType"].value="WIP";
                if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].checked)
                {
                    qType="N";
                    qFilter=document.getElementById("QueueMgmtForm:queuefilter").value;
                }else if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch4"].checked)  
                {
                    try{
                    if(element.id=="QueueMgmtForm:activityTab"){
                      customAlert(WORKSTEP_CAN_NOT_BE_ADDED_FOR_SEARCH_QUEUE); 
                        return false;
                    }
                      } catch(ex){}

                     qType="T";
                     qFilter=document.getElementById("QueueMgmtForm:searchfilter").value;
                }
                if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].checked)
                    qType="D";
                if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].checked)
                    qType="S";
                if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch4"].checked)
                    qType="T";  
                                    
                if(document.getElementById("QueueMgmtForm:chkAllowReassignment").checked)
                    qReAssignment="Y";

                if(document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"])
                {
                    if(document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"].checked)
                    {
                        qRefreshinterval=document.getElementById("QueueMgmtForm:refreshInterval").options[document.getElementById("QueueMgmtForm:refreshInterval").selectedIndex].value;
                    }
                }
                if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_All"].checked)
                {
                    qFilterOption=document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_All"].value;
                    FilterValue="";
                }
                if (document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].checked)
                {
                    qFilterOption=document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].value;
                    FilterValue=document.getElementById("QueueMgmtForm:cmbEqualTo").value;
                }
                if (document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].checked)
                {
                    qFilterOption=document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].value;
                    FilterValue=document.getElementById("QueueMgmtForm:cmbNotEqualTo").value;
                }

                var objQueueSortOrder=document.getElementById("QueueMgmtForm:QueueSortOrderWIP")
                qOrderBy = document.getElementById("QueueMgmtForm:hidQOrderBy").value;
                qSortOrder=objQueueSortOrder.options[objQueueSortOrder.selectedIndex].value;
                qOrderByName=document.getElementById("QueueMgmtForm:hidQOrderByName").value;

            } else if(document.forms["QueueMgmtForm"]["QueueMgmtForm:optGlobal"].checked){
                qType="G";
                document.forms["QueueMgmtForm"]["QueueMgmtForm:hidQType"].value = "G";
                
                var objQueueSortOrder=document.getElementById("QueueMgmtForm:QueueSortOrderWIP")
                qOrderBy = document.getElementById("QueueMgmtForm:hidQOrderBy").value;
                qSortOrder=objQueueSortOrder.options[objQueueSortOrder.selectedIndex].value;
                qOrderByName=document.getElementById("QueueMgmtForm:hidQOrderByName").value;
            }
            else
            {
                document.forms["QueueMgmtForm"]["QueueMgmtForm:hidQType"]="m_strQueueType";
                qType=m_strQueueType;
            }
            GenealXML="<" + TAG_QueueName + ">" + qName + "</" + TAG_QueueName + ">";
            GenealXML=GenealXML + "<" + TAG_Description + ">" + handleSpecialChar(qDesc) + "</" + TAG_Description + ">";
            GenealXML=GenealXML + "<" + TAG_QueueType + ">" + qType + "</" + TAG_QueueType + ">";
            GenealXML=GenealXML + "<" + TAG_FilterOption + ">" + qFilterOption + "</" + TAG_FilterOption + ">";
            GenealXML=GenealXML + "<" + TAG_QueueFilter + ">" + qFilter + "</" + TAG_QueueFilter + ">";
            GenealXML=GenealXML + "<" + TAG_FilterValue + ">" + FilterValue + "</" + TAG_FilterValue + ">";
            GenealXML=GenealXML + "<" + TAG_OrderBy + ">" + qOrderBy + "</" + TAG_OrderBy + ">";
            GenealXML=GenealXML + "<" + TAG_OrderByName + ">" + qOrderByName + "</" + TAG_OrderByName + ">";
            GenealXML=GenealXML + "<" + TAG_SortOrder + ">" + qSortOrder + "</" + TAG_SortOrder + ">";
            GenealXML=GenealXML + "<" + TAG_AllowReassignment + ">" + qReAssignment + "</" + TAG_AllowReassignment + ">";
            GenealXML=GenealXML + "<" + TAG_QPROCESSNAME + ">" + qProcName + "</" + TAG_QPROCESSNAME + ">";
        }
        else if(m_strQueueType=='M'){
            qFilter=document.getElementById("QueueMgmtForm:queuefilter1").value;
            
            var objQueueSortOrder=document.getElementById("QueueMgmtForm:QueueSortOrderWIP")
            qOrderBy = document.getElementById("QueueMgmtForm:hidQOrderBy").value;
            qSortOrder=objQueueSortOrder.options[objQueueSortOrder.selectedIndex].value;
            qOrderByName=document.getElementById("QueueMgmtForm:hidQOrderByName").value;
                
            GenealXML=GenealXML + "<" + TAG_OrderBy + ">" + qOrderBy + "</" + TAG_OrderBy + ">";
            GenealXML=GenealXML + "<" + TAG_OrderByName + ">" + qOrderByName + "</" + TAG_OrderByName + ">";
            GenealXML=GenealXML + "<" + TAG_SortOrder + ">" + qSortOrder + "</" + TAG_SortOrder + ">";
            GenealXML=GenealXML + "<" + TAG_QueueFilter + ">" + qFilter + "</" + TAG_QueueFilter + ">";
        }
        GenealXML=GenealXML + "<" + TAG_QueueType + ">" + qType + "</" + TAG_QueueType + ">";
        if(m_strMode=="2")
        {
            GenealXML=GenealXML + "<" + TAG_QueueID + ">" + document.getElementById("QueueMgmtForm:QueueId").value + "</" + TAG_QueueID + ">";
        }
        if(document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"])
        {
            if(document.forms["QueueMgmtForm"]["QueueMgmtForm:autoRefresh"].checked)
            {
                GenealXML=GenealXML + "<" + TAG_RefreshInterval + ">" + qRefreshinterval + "</" + TAG_RefreshInterval + ">";
            }
        }        
        document.getElementById("QueueMgmtForm:QueueInfo").value=GenealXML;
        return true;
    }
}
/*------------------------USER TAB--------------------------------------------------------*/
function clearSavedVales(){
    if(document.getElementById("QueueMgmtForm:optGroup:0").checked)
        document.getElementById("QueueMgmtForm:UserID").value='';
    if(document.getElementById("QueueMgmtForm:optGroup:1").checked)
        document.getElementById("QueueMgmtForm:GroupID").value='';
    
}
function addUser()
{  
    funOk();
    var groupexistid;
    var iCount;
    var userexistid;

    if(document.getElementById("QueueMgmtForm:optGroup:0").checked)
    {
        var groupid=document.getElementById("QueueMgmtForm:GroupID").value;
        if(groupid=='' || groupid=='-1' || groupid=='0')
        {
            fieldValidator("QueueMgmtForm:GroupName", NO_GROUP_SELECTED, "absolute", true);
            //alert(NO_GROUP_SELECTED);            
            return(false);
        }
        var table = document.getElementById("QueueMgmtForm:UGLists");
        if (table){
                        
            var rowCount = table.rows.length; 
            rowCount=rowCount-1;
            var gname = document.getElementById("QueueMgmtForm:GroupName").value;
            for(iCount = 0; iCount <rowCount; iCount++)
                        
            {
                    groupexistid =  document.getElementById("QueueMgmtForm:UGLists:"+iCount +":UGName").innerHTML;
                    if (gname==groupexistid)
                    {
                        fieldValidator(null, gname + " " + TEXT_ALREADY_ADDED, "absolute", true);
                        //alert(gname + " " + TEXT_ALREADY_ADDED);
                        return(false);
                    }
                }
        }
        document.getElementById("QueueMgmtForm:m_strUGIndex").value=groupid;
        document.getElementById("QueueMgmtForm:m_strUGName").value=document.getElementById("QueueMgmtForm:HidGroupName").value;
        document.getElementById("QueueMgmtForm:m_strUGType").value="G";
        document.getElementById("QueueMgmtForm:GroupID").value="0";
        document.getElementById("QueueMgmtForm:m_strUserJson").value="";
    }
    else if(document.getElementById("QueueMgmtForm:optGroup:1").checked)
    {
        var userData=document.getElementById("QueueMgmtForm:UserName").value;
        if(userData=="") {
            fieldValidator("QueueMgmtForm:UserName", NO_USER_SELECTED, "absolute", true);
            return(false);
        }
//        var userid=document.getElementById("QueueMgmtForm:UserID").value;
//        if(userid=='' || userid=='-1' || userid=='0')
//        {
//            fieldValidator("QueueMgmtForm:UserName", NO_USER_SELECTED, "absolute", true);
//            //alert(NO_USER_SELECTED);
//            return(false);
//        }
//        table = document.getElementById("QueueMgmtForm:UGLists");
//        if (table){
//            rowCount = table.rows.length; 
//            rowCount=rowCount-1;
//            var uname = document.getElementById("QueueMgmtForm:UserName").value;
//            for(iCount = 0; iCount <rowCount; iCount++)
//            {
//                userexistid =  document.getElementById("QueueMgmtForm:UGLists:"+iCount +":UGName").innerHTML;
//                if (uname==userexistid)
//                {
//                    fieldValidator(null, uname + " " + TEXT_ALREADY_ADDED, "absolute", true);
//                    //alert(uname + " " + TEXT_ALREADY_ADDED);
//                    return(false);
//                }
//            }
//        }
          document.getElementById("QueueMgmtForm:m_strUGIndex").value="";
          document.getElementById("QueueMgmtForm:m_strUGName").value="";
          document.getElementById("QueueMgmtForm:m_strUGType").value="U";
//        document.getElementById("QueueMgmtForm:UserID").value="0";
    }
    else
        return false;
    return true;
}
                
function removeUser()
{
    try
    {
        var nodeChkBox=document.getElementById("QueueMgmtForm:UGLists:0:chkBoxUG");
        var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length; 
        
        if(rowCount<1)
        {
//            customAlert(NO_USER_SPECIFIED);
            fieldValidator(null, NO_USER_SPECIFIED, "absolute", true);
            return false;
        }
        for(iCount = 0; iCount < rowCount;iCount++)
        {
            if(document.getElementById("QueueMgmtForm:UGLists:"+iCount +":chkBoxUG").checked)
            {
                document.getElementById("QueueMgmtForm:m_strRemoveIndex").value=iCount;
                document.getElementById("QueueMgmtForm:m_strSetFilterIndex").value=document.getElementById("QueueMgmtForm:UGLists:" + iCount + ":uniqId").value;
                return true;
            }
        }
    }
    catch(e)
    {
    }
//    customAlert(NO_USER_GROUP_SPECIFIED);
    fieldValidator(null, NO_USER_GROUP_SPECIFIED, "absolute", true);
    return false;
}
function setFilter(ref)
{
    var rowID=0;
    var filter='';
    var filtertemp;
    var uniqId='';
    try
    {
        var nodeChkBox=document.getElementById("QueueMgmtForm:UGLists:0:chkBoxUG");
        var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length;
        if(rowCount<1)
        {
            fieldValidator(null, NO_USER_SPECIFIED, "absolute", true);
            //alert(NO_USER_SPECIFIED);
            return false;
        }
        for(iCount = 0; iCount < rowCount;iCount++)
        {
            if(document.getElementById("QueueMgmtForm:UGLists:"+iCount +":chkBoxUG").checked)
            {   
                rowID=iCount;
                filter=document.getElementById("QueueMgmtForm:UGLists:" + rowID + ":UGFilter").innerHTML;
                filtertemp= encode_utf8(document.getElementById("QueueMgmtForm:UGLists:" + rowID + ":hidugfilter").value);
                uniqId=document.getElementById("QueueMgmtForm:UGLists:" + rowID + ":uniqId").value
                
                var sURL="/webdesktop/components/queue/setfilter.app?";
                sURL=sURL+"Row="+rowID+"&Filter="+encode_utf8(filtertemp)+"&uniqId="+uniqId+"&WD_SID="+WD_SID;
                var posLeft = findAbsPosX(ref);
                var posTop = findAbsPosY(ref);
                window.parent.popupIFrameOpenerWrapper(this, "filterWindow",sURL, 350, 200, posLeft,posTop, false, false, false, true);
                return false;
                /*var ScreenHeight=screen.height;
                var ScreenWidth=screen.width;
                var WindowHeight=windowH;
                var WindowWidth=windowW;
                var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
                var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
                Url = appendUrlSession(Url);

                var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

                var listParam=new Array();
                listParam.push(new Array("Row",encode_ParamValue(rowID)));
                listParam.push(new Array("Filter",encode_ParamValue(filtertemp)));
                listParam.push(new Array("uniqId",encode_ParamValue(uniqId)));

                var win = openNewWindow(Url,"setfilter"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
                addWindows(win);
                return false;*/
            }
        }
    }
    catch(e)
    {
    }
    
    fieldValidator(null, NO_USER_GROUP_SPECIFIED, "absolute", true);
    //alert(NO_USER_GROUP_SPECIFIED);
    return false;
}
                
function saveFilter(row,filter,selectedRow)
{
    document.getElementById("QueueMgmtForm:UGLists:" + row + ":UGFilter").innerHTML=encode_ParamValue(filter);
    document.getElementById("QueueMgmtForm:m_strFilterIndex").value=row;
    document.getElementById("QueueMgmtForm:m_strUserFilter").value=encode_utf8(filter);
    document.getElementById("QueueMgmtForm:m_strSetFilterIndex").value=selectedRow;
    var toclickid='QueueMgmtForm:cmdlink_SaveFilter';
    funOk();
    document.getElementById("QueueMgmtForm:UserID").value='';
    document.getElementById("QueueMgmtForm:GroupID").value='';
    clickLink(toclickid);
}
                
function saveQueryPreview(previewObj)
{    
    var refId=previewObj.id;
    refId=refId.substring(0,refId.lastIndexOf(":")); 
    document.getElementById(refId+":hidqpreview").value="Y"; 
}

function saveEditWIStatus(previewObj)
{    
    var refId=previewObj.id;
    refId=refId.substring(0,refId.lastIndexOf(":")); 
    document.getElementById(refId+":hideEditwi").value="Y"; 
}

function funOk(){
   if(document.getElementById("QueueMgmtForm:UGLists") && m_strQueueType == 'Q'){
        var table = document.getElementById("QueueMgmtForm:UGLists");
        var rowCount = table.rows.length;
        rowCount=rowCount-1;
        var strXml='<Qpreviews>';
        var strEditWIXml = '<Eworkitems>';
        for(var iCount = 0; iCount <rowCount;iCount++)
        {
            var modifyFlag=document.getElementById("QueueMgmtForm:UGLists:"+iCount+":hidqpreview").value;
            var modifyFlagEditWI = document.getElementById("QueueMgmtForm:UGLists:"+iCount+":hideEditwi").value;
            if(modifyFlag=="Y"){
                var preview='';
                if(document.getElementById("QueueMgmtForm:UGLists:"+iCount+":qpreview").checked)
                    preview="true";
                else
                    preview="false";
                strXml=strXml+"<Qpreview><Index>"+iCount+"</Index><Preview>"+preview+"</Preview></Qpreview>";
            }
            if(modifyFlagEditWI=="Y"){
                var editWI='';
                if(document.getElementById("QueueMgmtForm:UGLists:"+iCount+":editwi").checked)
                    editWI="true";
                else
                    editWI="false";
                strEditWIXml=strEditWIXml+"<Eworkitem><Index>"+iCount+"</Index><EditWorkitem>"+editWI+"</EditWorkitem></Eworkitem>";
            }
        }
        strXml=strXml+'</Qpreviews>';
        strEditWIXml=strEditWIXml+'</Eworkitems>';
        document.getElementById("QueueMgmtForm:m_strPreviewXml").value=strXml;
        document.getElementById("QueueMgmtForm:m_strEditWIXml").value=strEditWIXml;
    }
    return true;
}
/*-----------------------------------ACTIVITY TAB----------------------------------------*/
function setValuesStream()
{
    if(bDisableModifyWS =="true")
    {
        document.getElementById("QueueMgmtForm:cmdRemoveBtn").disabled=true;
    }
}

function addStream()
{
    try
    {
        var nodeChkBox=document.getElementById("QueueMgmtForm:streamLists:0:chkBox");
        var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length;
        if(rowCount<1)
        {
            fieldValidator(null, SELECT_WORKSTEPS, "absolute", true);
            //alert(SELECT_WORKSTEPS);
            return false;
        }
        for(iCount = 0; iCount < rowCount;iCount++)
        {
            if(document.getElementById("QueueMgmtForm:streamLists:"+iCount +":chkBox").checked)
            {
                document.getElementById("QueueMgmtForm:m_strRemoveIndex").value=iCount;
                return true;
            }
        }
    }
    catch(e)
    {
    }
    fieldValidator(null, SELECT_WORKSTEPS, "absolute", true);
    //alert(SELECT_WORKSTEPS);
    return false;
}

function removeStream()
{
    try
    {
        var nodeChkBox=document.getElementById("QueueMgmtForm:WorkLists:0:chkBoxST");
        var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length;
        if(rowCount<1)
        {
            fieldValidator(null, SELECT_WORKSTEPS, "absolute", true);
            //alert(SELECT_WORKSTEPS);
            return false;
        }
        for(iCount = 0; iCount < rowCount;iCount++)
        {
            if(document.getElementById("QueueMgmtForm:WorkLists:"+iCount +":chkBoxST").checked)
            {

                document.getElementById("QueueMgmtForm:m_strRemoveIndex").value=iCount;
                return true;
            }
        }
    }
    catch(e)
    {
    }
    fieldValidator(null, SELECT_WORKSTEPS, "absolute", true);
    //alert(SELECT_WORKSTEPS);
    return false;
}
function getWorkstepList()
{
    try
    {
        var toclickid='QueueMgmtForm:cmdlink_Go';
        clickLink(toclickid);
    }
    catch(e)
    {
    }
}
/*--------------------------QUEUE PROCESS AUTHORIZATION---------------------------------------------------------*/
function DisableQueueControls() {
    if(ActiveTab == 'GeneralTab') {
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][0].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][1].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch1"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch2"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWipfetch3"].disabled=true;
        }catch(e){}
        try{
        document.getElementById("QueueMgmtForm:chkAllowReassignment").disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_All"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_Equal"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWorkitem_NotEqual"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:queuefilter"].disabled=true;
        }catch(e){}
        try{
        document.getElementById("QueueMgmtForm:cmbEqualTo").disabled=true;
        }catch(e){}
        try{
        document.getElementById("QueueMgmtForm:cmbNotEqualTo").disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifo"].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optWip"].disabled=true;
        }catch(e){}
        try{
        document.getElementById("QueueMgmtForm:txtQueueName").disabled=true;
        }catch(e){}
        try{
        document.getElementById("QueueMgmtForm:txtDescription").disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][0].disabled=true;
        }catch(e){}
        try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:optFifofetch"][1].disabled=true;
        }catch(e){}
         try{
        document.forms["QueueMgmtForm"]["QueueMgmtForm:chkProce"].disabled=true;
        }catch(e){}
    }
    else if(ActiveTab == 'UserTab') {

        try{
            document.getElementById("QueueMgmtForm:cmdRemove").disabled=true;
        }catch(e){}
        try{
            document.getElementById("QueueMgmtForm:cmdSetFilter").disabled=true;
        }catch(e){}
        try{
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optGroup:0"].disabled=true;
        }catch(e){}
        try{
            document.forms["QueueMgmtForm"]["QueueMgmtForm:optGroup:1"].disabled=true;
        }catch(e){}
        try{
            document.getElementById("QueueMgmtForm:cmdAdd").disabled=true;
        }catch(e){}
        try{
            document.getElementById("QueueMgmtForm:cmdPicklist_Group").disabled=true;
        }catch(e){}
        try{
            document.getElementById("QueueMgmtForm:cmdPicklist_User").disabled=true;
        }catch(e){}
    }

    else if(ActiveTab == 'ActivityTab') {

        try{
            document.getElementById("QueueMgmtForm:cmdRemoveBtn").disabled=true;
        }catch(e){}

        try{
            document.getElementById("QueueMgmtForm:cmdAddBtn").disabled=true;
        }catch(e){}

        try{
            
            document.getElementById("QueueMgmtForm:cmdPicklist_Queue").disabled=true;
        }catch(e){}
       }
       else if(ActiveTab == 'MobileConfigurationsTab') {
           
       }
}

function QueuepropertiesOnLoad()
{var arrPendingActions;
   if(PendingAction != "" && PendingAction.length>0)
     {     
            arrPendingActions = PendingAction.split(",");
            if(ActiveTab=='GeneralTab')
            {
                for(iCount=0;iCount<arrPendingActions.length;iCount++)
                {
                    if(arrPendingActions[iCount]=='51')
                        {
                            DisableQueueControls();
                            break;
                        }
                }
            }
            else if(ActiveTab=='UserTab')
            { 
              for(iCount=0;iCount<arrPendingActions.length;iCount++)
                {
                    if(arrPendingActions[iCount]=='60' ||arrPendingActions[iCount]=='61' ||arrPendingActions[iCount]=='77')
                        {
                            DisableQueueControls();
                            break;
                        }
                }
            }
            else if(ActiveTab=='ActivityTab')
            {
               for(iCount=0;iCount<arrPendingActions.length;iCount++)
                {
                    if(arrPendingActions[iCount]=='62' || arrPendingActions[iCount]=='63')
                        {
                            DisableQueueControls();
                            break;
                        }
                }
            }
            else if(ActiveTab=='MobileConfigurationsTab')
            {
               /*for(iCount=0;iCount<arrPendingActions.length;iCount++)
                {
                    if(arrPendingActions[iCount]=='62' || arrPendingActions[iCount]=='63')
                        {
                            DisableQueueControls();
                            break;
                        }
                }*/
            }
    }
}

function UserListCallBack(jsonString)
{
    var userJson;
    var unameMsg="";
    var userFlag=false;
    var userNameArr=new Array();
    userJson = JSON.parse(jsonString);
    if(userJson.UserInfoList.length > 0) {
        for(var Count=0;Count<userJson.UserInfoList.length;Count++)
        {
            userFlag=false;
            var uname = userJson.UserInfoList[Count].UserName;
            table = document.getElementById("QueueMgmtForm:UGLists");
            if (table){
                    rowCount = table.tBodies[0].rows.length; 
                    //rowCount=rowCount-1;
                    for(var iCount = 0; iCount <rowCount; iCount++)
                    {
                        userexistid =  document.getElementById("QueueMgmtForm:UGLists:"+iCount +":UGName").innerHTML;
                        if (uname==userexistid)
                        {
                            userFlag=true;
                            unameMsg += ","+ uname;
                        }
                    }
                    if(userFlag==false){
                        userNameArr.push(uname);
                    } else{
                        delete userJson.UserInfoList[Count];
                    }
                }
                else
                {
                    userNameArr.push(uname);   
                }
        }
        document.getElementById("QueueMgmtForm:m_strUserJson").value=JSON.stringify(userJson);
        document.getElementById("QueueMgmtForm:UserName").value=userNameArr;        
        document.getElementById("QueueMgmtForm:UserName").title=userNameArr;        
        if(unameMsg!=""){
            fieldValidator(null, unameMsg.substring(1,unameMsg.length) + " " + TEXT_ALREADY_ADDED, "absolute", true);
            return false;
        }
    }
    else
    {
        fieldValidator("QueueMgmtForm:UserName", NO_USER_SELECTED, "absolute", true);
        return(false);
    }
    return true;
   }
   
   function HandleProgressBarWrapper(data){
       
       HandleProgressBar(data);
       
       if(data.status=="suucess"){
           if(typeof resizeContainers!="undefined")
              resizeContainers();
       }
       
   }