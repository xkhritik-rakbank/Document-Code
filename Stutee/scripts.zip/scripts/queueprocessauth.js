/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
var tableID="";
function SelectDeselectAllAuthCheckBox(ref)
{var id=ref.id;
    id=id.substring(0,id.lastIndexOf(":"));
    tableID=id;
    try 
    {
        var noofrows = document.getElementById(tableID).tBodies[0].rows.length;
        var flag=0;
        for (var i=0;i< noofrows ;i++)
        {
          id=tableID+':'+i+':checkBox';
            document.getElementById(id).checked=ref.checked;
			var authId = document.getElementById(tableID+':'+i+':hidAuthorizationID').value;
			if(ref.checked){
				addRemoveAllIdsToArray(authId,"ADD");
			} else{
				addRemoveAllIdsToArray(authId,"REMOVE");
			}
			
        }
        
    }
    catch(e){}
     UpdateAuthOperationsOnCheckBoxClick();
    return false;
}
function UpdateAuthOperationsOnCheckBoxClick(ref)
{
    if(ref!=undefined && ref!=""){
        var id=ref.id;
        id=id.substring(0,id.lastIndexOf(":"));
        id=id.substring(0,id.lastIndexOf(":"));
        tableID=id;
    }
	
    var chkboxName=":checkBox";
    var noOfSelectedRows=0;    
    var operationFlag="";
    var selectedTab=document.getElementById("queueprocessauth:hidSelTab").value;
	 
	// checkbox should be selected on batching 
if(ref!=undefined && ref!=""){
            try{
					var arr = ref.id.split(":");
					var iArrLength = arr.length ;    
					var selectedRow = arr[iArrLength-2];
					var AuthorizationID= document.getElementById(tableID+":" + selectedRow +":hidAuthorizationID").value;
               if(document.getElementById(tableID+":" + selectedRow +":checkBox").checked){
                   for(i=0;i<selectedIdsArray.length;i++){
                        if(AuthorizationID == selectedIdsArray[i]){
                            break;
                        }
                    }
                    if(i == selectedIdsArray.length){
                        selectedIdsArray[selectedIdsArray.length] = AuthorizationID;
                    }
                }else{
                    var i=0;
                    for(i=0;i<selectedIdsArray.length;i++){
                        if(AuthorizationID == selectedIdsArray[i]){
                            break;
                        }
                    }
                    if(i < (selectedIdsArray.length)){
                         selectedIdsArray.splice(i, 1)
                    }                       
                }
            } catch(e){
                customAlert(e)
            }
			}
	
     try
    {
        var rowCount=document.getElementById(tableID).tBodies[0].rows.length ;
        for (var iCount=0;iCount < rowCount ;iCount++)
        {
            var currentChkBoxID=tableID+":" + iCount +chkboxName ;
            var operationFlagID=tableID+":" + iCount +":hidOperationFlag";            
            
            try 
            {
               // alert("count:"+iCount+"currentChkBoxID.checked:"+document.getElementById(currentChkBoxID).checked);
                if(document.getElementById(currentChkBoxID).checked)
                {                    
                    noOfSelectedRows++;
                    if(operationFlag=="")
                    {
                        operationFlag=document.getElementById(operationFlagID).value;
                    }    
                    else if(operationFlag!=document.getElementById(operationFlagID).value)
                    {
                        operationFlag="000";
                    }    
                }
                else 
                    {var chkid=tableID+":HeadchkBox";
                          document.getElementById(chkid).checked=ref.unchecked;
                    }
            }
            catch(e)
            {}
        }
        
        if((noOfSelectedRows) == rowCount){//Bug 73921
            var headerChkId=tableID+":HeadchkBox";
            document.getElementById(headerChkId).checked = true;
        }
            
       if(selectedTab=="1")
       {
            var cmdApproveImg=document.getElementById("queueprocessauth:cmdapprove");
         
            var cmdRejectImg=document.getElementById("queueprocessauth:cmdreject");
            var cmdDismissImg=document.getElementById("queueprocessauth:cmddismiss");
            if(operationFlag=="110")
            {
                cmdApproveImg.disabled=false;
                cmdRejectImg.disabled=false;
                cmdDismissImg.disabled=true;
            }
            else if(operationFlag=="001")
            {
                cmdApproveImg.disabled=true;
                cmdRejectImg.disabled=true;
                cmdDismissImg.disabled=false;
            }
            else
            {
                cmdApproveImg.disabled=true;
                cmdRejectImg.disabled=true;
                cmdDismissImg.disabled=true;
            }
      }
      else if(selectedTab=="2")
      {
        var cmdReinitiateImg=document.getElementById("queueprocessauth:cmdReinitiate");
        var cmdDiscardImg=document.getElementById("queueprocessauth:cmdDiscard");
        if(noOfSelectedRows>0)
         {
            cmdReinitiateImg.disabled=false;
            cmdDiscardImg.disabled=false;
         }
        else
        {
            cmdReinitiateImg.disabled=true;
            cmdDiscardImg.disabled=true;
        }
      }
    }
    catch(e){}
   return false;
}

function clickOkWithComments()
{
    if(isIE()){
        clickLink('queueprocessauth:btnOk');
    } else {
        clickLinkSafari('queueprocessauth:btnOk');
    }
}

function AuthorizationOnClick(Operation,ref,COperation){
   document.getElementById("queueprocessauth:hidSelectedOperation").value=Operation;
   document.getElementById("queueprocessauth:hidOperation").value=COperation;   
   CommentDiv(ref,'clickOkWithComments','submitAuthValues','queueprocessauth:hidActionComments');
}
function submitAuthValues()
{   
    var chkboxName=":checkBox";
    var noOfSelectedRows=0;   
    var AuthorizationIDs="";
    
    try
    {
       /* var rowCount=document.getElementById(tableID).rows.length ;
        for (var iCount=0;iCount < (rowCount-1) ;iCount++)
        {
            var currentChkBoxID=tableID+":" + iCount +chkboxName ;
            var hidAuthorizationIDId=tableID+":" + iCount +":hidAuthorizationID";
            try 
            {
                if(document.getElementById(currentChkBoxID).checked)
                {
                    noOfSelectedRows++;
                    AuthorizationIDs=AuthorizationIDs+document.getElementById(hidAuthorizationIDId).value+",";
                }
            }
            catch(e)
            {}
        }
		*/		
        if(selectedIdsArray.length<=0)
        {
            customAlert("Please select some Entity");
            return false;
        }else{
            //AuthorizationIDs=AuthorizationIDs.substring(0,AuthorizationIDs.length-1);
			
			for(var i=0;i < selectedIdsArray.length;i++){
				AuthorizationIDs=AuthorizationIDs+selectedIdsArray[i]+",";
			}
			//alert(AuthorizationIDs);
            document.getElementById("queueprocessauth:hidSelectedAuthorizationIDs").value=AuthorizationIDs;
            return true;
        }
        
    }
    catch(e){}
    
}

function ShowActionDetail(AuthorizationId,entityName)
 {
    var selectedTab = document.getElementById("queueprocessauth:hidSelTab").value;   
    var url= "/webdesktop/components/adminoptions/showauthdetails.app";
    var WindowHeight=windowH+40;
    var WindowWidth=windowW+30;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("AuthorizationID",encode_ParamValue(AuthorizationId)));
    listParam.push(new Array("SelectedTab",encode_ParamValue(selectedTab)));
    listParam.push(new Array("EntityName",encode_ParamValue(entityName)));
    var win = openNewWindow(url,'actionDetail_'+AuthorizationId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}

 }
 function NewSubmit(item,containerId)
{       
       
        resultContainerId='';

	if(containerId != undefined)
        {
            resultContainerId = containerId;
        }

	sub(item);
	return false;

}


function sub(item) 
{ 
    var file = item.form.action;
   var time=new Date();
   var tempurl;

   if(file.indexOf("?")>0)
	{
		tempurl=file + "&time="+ time.getTime();
	}
	else
	{
		tempurl=file + "?time="+ time.getTime();
	}

	file=tempurl;
        if(file.indexOf("userviewlist.faces")!=-1) {
        tempurl = file + "&userType=s";
        file = tempurl;
        }
    var str = getFormValues(item,"validate"); 
 	
   xmlReq = getXML(file,str); 
} 

function  addRemoveAllIdsToArray(authId,option){
	if(option == "REMOVE"){
		for(var i=0;i < selectedIdsArray.length;i++){
			if(authId == selectedIdsArray[i]){
				selectedIdsArray.splice(i,1);				
			}				
		}
	} else if(option == "ADD"){
		var flag = true;
		for(i=0;i < selectedIdsArray.length;i++){
			if(authId == selectedIdsArray[i]){
				flag=false;
				break;		
			}				
		}
		if(flag){
			selectedIdsArray[selectedIdsArray.length]=authId;
		}
	}
	
}
