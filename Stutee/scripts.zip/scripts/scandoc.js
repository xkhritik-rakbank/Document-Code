
var WD_SID;
function openScanInterface()
{
    var isInstalled = false;
    var isNetscape = (navigator.appName.indexOf("Netscape") !=-1)?true:false;
    
    if(isNetscape)
        isInstalled = (typeof navigator.mimeTypes["application/x-scanupld"] == 'undefined')?false:true;
    else
        isInstalled = (typeof document.all.WebScan.ServerName == 'undefined')?false:true;

    if( !isInstalled)
    {
        var url = "toinstallws.app?Option=New";
        url = appendUrlSession(url);
        var win = window.open(url,"Webscan","resizable=no,scrollbars=yes,status=yes,top=50,left=50,width=300,height=300");
        
        try{
            win.focus();
        } catch(e){}
        return false;
    }

    var docListVal = document.getElementById('scanForm:addForm:docListMenu');
    if(docListVal != null && docListVal != 'null' && typeof docListVal != 'undefined')
        docListVal = document.getElementById('scanForm:addForm:docListMenu').value;
    else
        docListVal = 'ScannedDocument';
    var Name = docListVal;
    var DocumentId='';
    var wid = window.wid;
    var pid = window.pid;
    var taskid = window.taskid;
    
    var Pages = (window.document.getElementById("scanForm:addForm:Pages:0").checked)?0:1;
    var window_workdesk="";
        if(typeof window.top.document.forms['wdesk'] == 'undefined')
            window_workdesk = window.top.opener;
        else
            window_workdesk = window.top;
        if(window_workdesk.for_save('dummysave') == 'failure')
            return false;

    var DocId="-1";
    var siteId="-1"
    var option="new";
    var newRadio = document.getElementById("scanForm:addMode:0");
    var versionRadio = document.getElementById("scanForm:addMode:1");
    var deleatRadio = document.getElementById("scanForm:addMode:2");
    if(versionRadio.checked){
        option="newversion"
        DocumentId=document.getElementById('scanForm:addForm:docListName').value;
    }
    if(deleatRadio.checked){
        option="deleteadd"
        DocumentId=document.getElementById('scanForm:addForm:docListName').value;
    }
    
    if( isNetscape )
    {
        var DocumentInfo    = "<DocName>" + Name + "</DocName><FolderID>" + window.top.folderId + "</FolderID><UploadLimit>" + uploadLimit + "</UploadLimit><DocumentId>"+DocumentId+"</DocumentId>";
        url = "scanforne.jsp?Pages=" + Pages + "&Protocol=1&DocumentInfo=" + encode_utf8(DocumentInfo);
        url = appendUrlSession(url);
        window.parent.frames["scan_bottom"].location = url;
        return true;
    }
    var ctrl = document.all.WebScan;
    ctrl.ServerName = location.host;
    ctrl.ServerObject = sContextPath+"/servlet/ScanUploadServlet?WD_SID="+WD_SID+"&WD_RID="+getRequestToken('/webdesktop/servlet/ScanUploadServlet');
    ctrl.Pages = Pages;
    ctrl.DocumentInfo = "<Document><DocName>" + encode_utf8(Name) + "</DocName><FolderID>" + window.top.folderId + "</FolderID><UploadLimit>" + uploadLimit + "</UploadLimit><Browser>IExplorer</Browser><Option>"+option+"</Option><DocIndex>"+DocId+"</DocIndex><ISIndex>"+siteId+"</ISIndex><PID>"+pid+"</PID><WID>"+wid+"</WID><TaskID>"+taskid+"</TaskID><DocumentId>"+DocumentId+"</DocumentId></Document>";

    if (ctrl.SelectScanner() == false)
    {
        customAlert(ALERT_RETRY_SEL_SCANNER);
        return false;
    }

    ctrl.Scan();
    var errorMsg = ctrl.ReturnStatus;
    errorMsg = Trim(errorMsg);

    var err=ALERT_SCAN_ERROR;
    if (errorMsg.indexOf("<Status>0</Status>") == -1)
    {
        if (errorMsg.indexOf("<Status>-1</Status>") != -1)
        {
            errorMsg=errorMsg.substring(errorMsg.indexOf("<Error>")+"<Error>".length);
            err=errorMsg.substring(0 , errorMsg.lastIndexOf("</Error>"));
        }
        else
        {
            if (errorMsg!="")
                err=errorMsg;
        }
        customAlert(err);
        return false;
    }
	
    var isindex = getVal(errorMsg,'ISIndex');
	
    if(isindex.lastIndexOf('#')==isindex.length-1)
        isindex = isindex.substring(0,isindex.length-1);
    var modifyextdoc=deleatRadio.checked||versionRadio.checked;
    updateDocWindow(errorMsg,modifyextdoc,Name);
    window.top.location.reload();
    return true;
}
function updateDocWindow(errorMsg,modifyextdoc,Name){
    var window_workdesk="";
     
    if(typeof window.top.parent.opener.document.forms['wdesk'] == 'undefined')
        window_workdesk = window.top.parent.top.opener.top.opener;
    else
        window_workdesk = window.top.parent.opener;
    var winList = window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
        
    if(docWindow){
        var docDispName = "";
        if(DocOrgName == 'Y')
            docDispName = decode_utf8(getVal(errorMsg,'DocumentName')) + "(" + decode_utf8(getVal(errorMsg,'Comment')) + "." + decode_utf8(getVal(errorMsg,'CreatedByAppName')) +")";
        else
            docDispName = decode_utf8(getVal(errorMsg,'DocumentName'));
            
        if(modifyextdoc){
            var mindex=getVal(errorMsg,'mindex');
            
            if(getVal(errorMsg,'runScript') == 'true')
            {
                var objCombo = docWindow.document.getElementById('wdesk:docCombo');
                var selectedindex = '';
                for(var count=0;count<objCombo.length;count++)
                {
                    if(objCombo[count].value == mindex)
                    {
                        selectedindex = count;
                        objCombo[count].value = getVal(errorMsg,'DocumentIndex');
                        objCombo[count].text = docDispName;
                        break;
                    }
                }
                  
                objCombo.selectedIndex = selectedindex;
                docWindow.reloadapplet(getVal(errorMsg,'DocumentIndex'));
            }
        }
        else{



            if(getVal(errorMsg,'runScript') == 'true')
            {
                var objCombo = docWindow.document.getElementById('wdesk:docCombo');
                var opt = docWindow.document.createElement("OPTION");
                opt.text = docDispName;
                opt.value = getVal(errorMsg,'DocumentIndex');
                objCombo.add(opt);
                objCombo.selectedIndex = objCombo.options.length-1;
                docWindow.reloadapplet(getVal(errorMsg,'DocumentIndex'));
            }
        }
    }
    
    var formWindow = window_workdesk.getWindowHandler(window_workdesk.windowList,"formGrid");
    var ngformIframe = formWindow.document.getElementById("ngformIframe");	
    if((window_workdesk.wiproperty.formType == "NGFORM") && (window_workdesk.ngformproperty.type == "applet") && !window_workdesk.bDefaultNGForm && !window_workdesk.bAllDeviceForm){       
       if(formWindow){           
           if(ngformIframe != null){
               // parameter passing           
               var ngformIframeWindow = ngformIframe.contentWindow;
               var wiDummySaveStructWinRef = ngformIframeWindow;
                if(formIntegrationApr == "4"){
                    wiDummySaveStructWinRef = window;
                }
                
               wiDummySaveStructWinRef.WiDummySaveStruct.Type = 'UpdateDocWindow';
               wiDummySaveStructWinRef.WiDummySaveStruct.Params.pid = window_workdesk.document.getElementById("wdesk:pid").value;  
               wiDummySaveStructWinRef.WiDummySaveStruct.Params.wid = window_workdesk.document.getElementById("wdesk:wid").value;  
               wiDummySaveStructWinRef.WiDummySaveStruct.Params.taskid = window_workdesk.document.getElementById("wdesk:taskid").value;  
               wiDummySaveStructWinRef.WiDummySaveStruct.Params.Name = Name; 
               
               if(formIntegrationApr == "4"){
                    ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.fireFormValidation('S','Y')");	                                                                
                } else {			
                    ngformIframeWindow.clickLink('cmdNgFormDummySave');
                }
           }
           return false;
       }
   } else {
       if(window_workdesk.bCustomIForm){
           if(formWindow){
               if(ngformIframe != null){                   
                   if(typeof ngformIframe.contentWindow.customIFormHandler != 'undefined'){
                        ngformIframe.contentWindow.customIFormHandler('S','Y');
                    }
               }
           }
       }
       
       commonUpdateDocWindow(window_workdesk,window_workdesk.document.getElementById("wdesk:pid").value, window_workdesk.document.getElementById("wdesk:wid").value, Name,window_workdesk.document.getElementById("wdesk:taskid").value);
   }
   
    /*window_workdesk.for_save('dummysave');
    executeScanAction(window_workdesk,window_workdesk.document.getElementById("wdesk:pid").value,window_workdesk.document.getElementById("wdesk:wid").value,Name);*/
}

function commonUpdateDocWindow(window_workdesk, pid, wid, Name,taskid){
    window_workdesk.for_save('dummysave');
    executeScanAction(window_workdesk,pid,wid,Name,taskid);
}

function getVal(s,tag)
{
    var i1 = s.indexOf('<'+tag+'>');
    var i2 = s.indexOf('</'+tag+'>');

    if(i1==-1 || i2==-1 || i1>i2)
    {
        return '';
    }
    return s.substring(i1+tag.length+2,i2);
}

function setSt()// from waitwin.jsp
{
    window.status=LABEL_STATUS;
}

function yes()
{
    myBrowser = navigator.appName;
    if(myBrowser == "Netscape")
    {       
        if(navigator.javaEnabled()) 
        {
            if(netscape.softupdate == undefined){
                customAlert("This feature is not supported in Firefox")
                return;
            }
            trigger = netscape.softupdate.Trigger;            
            if(trigger.UpdateEnabled()) 
            {
                if(navigator.platform == "Win32") 
                {             
                    trigger.StartSoftwareUpdate(serverPath+sContextPath+"/webtop/scan/webscan.jar", trigger.FORCE_MODE );                 
                }
                else 
                {
                    customAlert(ALERT_PLUGIN_FOR_95_NT)
                    return;
                }
            }
            else
            {     
                customAlert(ALERT_ENABLE_SMARTUPDATE);   
                return;
            }
        }
        else
        {       
            customAlert(ALERT_ENABLE_JAVA);
            return;
        }
    }
    else
    {
        url = "waitwin.app?WebScanIns=N";
        url = appendUrlSession(url);       
        window.location = url;
    }	
}

function findAttachmentIndex(docWindow,docname){
    var objCombo = docWindow.document.getElementById('wdesk:docCombo');
    for(var index2=0;index2<objCombo.length;index2++){
        if(objCombo[index2].text == docname)
            return index2;
    }
    return -1;
}

function ChangeRdbSel(){
    var docListVal = document.getElementById('scanForm:addForm:docListMenu');
    if(docListVal != null && docListVal != 'null' && typeof docListVal != 'undefined')
        docListVal = document.getElementById('scanForm:addForm:docListMenu').value;
    else
        docListVal = 'ScannedDocument';

    var window_workdesk="";
    if(typeof window.top.parent.opener.document.forms['wdesk'] == 'undefined')
        window_workdesk = window.top.parent.top.opener.top.opener;
    else
        window_workdesk = window.top.parent.opener;
   // uploadLimit=getUploadMaxLength(window_workdesk.strprocessname,window_workdesk.stractivityName,docListVal);
    var upLoadLimitUnit="MB";
    var docUploadLimit = getUploadMaxLength(window_workdesk.strprocessname,window_workdesk.stractivityName,docListVal);
    docUploadLimit=docUploadLimit+"";
    if (docUploadLimit.indexOf("_")>-1) {
         if(docUploadLimit.indexOf("_MB")>-1){
                  upLoadLimitUnit="MB";
           }else{ 
                  upLoadLimitUnit="KB";
           }
        docUploadLimit = docUploadLimit.substring(0, docUploadLimit.indexOf("_"));
        uploadLimit = parseInt(docUploadLimit);
         
    } else {
        uploadLimit = parseInt(docUploadLimit);
    }
    document.getElementById("scanForm:addForm:uploadLimitLabel").innerHTML=encode_ParamValue(uploadLimit+upLoadLimitUnit+")");
    
    
    var wid = window_workdesk.document.getElementById('wdesk:wid').value
    var pid = window_workdesk.document.getElementById('wdesk:pid').value
    var taskid = window_workdesk.document.getElementById('wdesk:taskid').value
    var returnval = isDocTypeAddable(pid,wid,docListVal,taskid);
    var newRadio = document.getElementById("scanForm:addMode:0");
    var versionRadio = document.getElementById("scanForm:addMode:1");
    var deleatRadio = document.getElementById("scanForm:addMode:2");
    versionRadio.disabled=true;
    deleatRadio.disabled=true;
    
    if(queuetype != 'I')
    {
        if(returnval == true )
        {
            versionRadio.disabled=false;
            deleatRadio.disabled=false;
        }
    }
    document.getElementById('scanForm:addForm:docPanel').style.display="none";
    document.getElementsByName('scanForm:addMode')[0].checked=true;
    try {
        var docModifyFlagInfo = document.getElementById("scanForm:hidDocModifyFlagInfo").value;
        if (docModifyFlagInfo != undefined && docModifyFlagInfo != '' && docModifyFlagInfo != "") {
            var docModifyFlagInfoJson = JSON.parse(docModifyFlagInfo);
            if (docModifyFlagInfoJson[docListVal] == 'B'|| docModifyFlagInfoJson[docListVal] == 'b'|| docModifyFlagInfoJson[docListVal] == 'A' || docModifyFlagInfoJson[docListVal] == 'a') {
                document.getElementById("scanForm:addMode:1").disabled = true;
                document.getElementById("scanForm:addMode:2").disabled = true;
            }
            else if(docModifyFlagInfoJson[docListVal] == 'M' || docModifyFlagInfoJson[docListVal] == 'm'){
            document.getElementById("scanForm:addMode:0").disabled = true;
            var alreadySelected=false;
//            if(newVersion=='Y'){
                if(document.getElementById("scanForm:addMode:1").click())
                alreadySelected=true;
//            }
        
//            if(overWrite=='Y'){
                if(!alreadySelected)
                document.getElementById("scanForm:addMode:2").click();
//            } 
            }
        }
    } catch (exc) {
    }
}

function isDocTypeAddable(pid,wid,docType,taskid)
{
    //    This function returns whether any doctype is addable or not if docType parameter is blank else it returns is document related to this doctype is present.
    var xbReq;
    if (window.XMLHttpRequest){
        xbReq = new XMLHttpRequest();
    } else if (window.ActiveXObject){
        xbReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
    var url = "/webdesktop/components/workitem/document/ajaxDocTypeObj.app";
    var wd_rid=getRequestToken(url);
    url+="?WD_RID="+wd_rid;
    if (xbReq != null) {
        if (docType == '') {
            url = url + '&wid=' + wid + '&taskid=' + taskid + '&pid=' + encode_utf8(pid) + '&rid=' + MakeUniqueNumber() + "&WD_SID=" + WD_SID;
            url = appendUrlSession(url);
            xbReq.open("GET", url, false);
        }
        else {
            url = url + '&wid=' + wid + '&taskid=' + taskid + '&pid=' + encode_utf8(pid) + '&docType=' + encode_utf8(docType.replace(/\\'/g, "'")) + '&rid=' + MakeUniqueNumber() + "&WD_SID=" + WD_SID;
            url = appendUrlSession(url);
            xbReq.open("GET", url, false);
        }
        xbReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xbReq.send(null);
        var response = "";
        if (xbReq != null && xbReq.readyState == 4 && xbReq.status == 200) {
            response = xbReq.responseText;
        }
    }
        if (response == 'failed' && docType == '')
        {
            customAlert(NO_DOC_TYPE_ADDABLE);
            return false;
        }else if(response == 'failed')
            return false;
        else 
            return true;
//    }
    
}
function radioChange(){  
        
    var newRadio = document.getElementById("scanForm:addMode:0");    
    if(newRadio.checked)
        document.getElementById('scanForm:addForm:docPanel').style.display="none";
    else{
        var objCombo=document.getElementById('scanForm:addForm:docListMenu');
        var docType=objCombo.options[objCombo.options.selectedIndex].text;
        if(docList==''){
            var objCombo=document.getElementById('scanForm:addForm:docListMenu');
            var docType=objCombo.options[objCombo.options.selectedIndex].text;
            var requestString='docType='+encode_utf8(docType)+'&pid='+encode_utf8(pid)+'&wid='+wid+'&taskid='+taskid;
            var ajaxReq;
            if (window.XMLHttpRequest) {
                ajaxReq= new XMLHttpRequest();
            } else if (window.ActiveXObject) {
                ajaxReq= new ActiveXObject("Microsoft.XMLHTTP");
            }
            var url = "ajaxdocList.app";
            url = appendUrlSession(url);
            var wd_rid=getRequestToken(url);
            url+="&WD_RID="+wd_rid;
            ajaxReq.open("POST", url, false);
            ajaxReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            ajaxReq.send(requestString);
            if (ajaxReq != null) {
                if (ajaxReq.status == 200 && ajaxReq.readyState == 4) {
                    docList = ajaxReq.responseText;
                    docList = parseJSON("(" + docList + ")");
                }
                else {
                    if (ajaxReq.status == 400)
                        customAlert(INVALID_REQUEST_ERROR);
                    else if (ajaxReq.status == 12029) {
                        customAlert(ERROR_SERVER);
                    }
                    else
                        customAlert(ERROR_DATA);
                }
            }
        }

        var objCombo1 = document.getElementById('scanForm:addForm:docListName');
        if(objCombo1.options.length!=0){
            var docname=objCombo1.options[objCombo1.options.selectedIndex].text;
            if(docname.indexOf(docType)!=-1){
                document.getElementById('scanForm:addForm:docPanel').style.display="inline";
                return;
            }
        }
        var objCombo = document.getElementById('scanForm:addForm:docListName');
        objCombo.options.length = 0;
        var dName;
        for(var count=0;count<docList.combo.length;count++){
            dName=docList.combo[count].DocName;
            if(dName.indexOf(docType)!=-1){
                var option = new Option(docList.combo[count].DocName,docList.combo[count].DocIndex);
                objCombo.options.add(option,objCombo.options.length);
            }
        }        
        document.getElementById('scanForm:addForm:docPanel').style.display="inline";
    }
}