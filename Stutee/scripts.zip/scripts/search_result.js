	
var WD_SID;
function DocInfoObject()
{
 this.DocName = '';
 this.DocIndex = '';
 this.DocExt = '';
 this.DocISIndex = ''; 
 this.DocFolderId = ''; 
 }

var SelectedDocObject;

function DocSelected(DivId,DocXml)
{
//alert(DivId);
//alert(DocXml);

if(DocXml.length>0)
{
var parser = new WDParser(DocXml);
parser = new WDParser(parser.getStringValueOf("Documents", "", true));
parser = new WDParser(parser.getFirstValueOf("Document",0));

SelectedDocObject = new DocInfoObject();
SelectedDocObject.DocName = parser.getStringValueOf("DocName", "", true);
SelectedDocObject.DocIndex = parser.getStringValueOf("DocIndex", "", true);
SelectedDocObject.DocExt = parser.getStringValueOf("DocExt", "", true);
SelectedDocObject.DocISIndex = parser.getStringValueOf("DocISIndex", "", true);
SelectedDocObject.DocFolderId = parser.getStringValueOf("DocFolderId", "", true);

if(SelectedDocObject.DocIndex.length>0 && SelectedDocObject.DocIndex.length>0 && SelectedDocObject.DocFolderId.length>0)
LoadDocTypeContent(DivId);
else
DivId.innerHTML = "";    
}
else
    {
        DivId.innerHTML = "";
}
}

function FolderSelected(DivId,FolderXml)
{
//alert(DivId);
//alert(FolderXml);
}

function AddDocLinkClicked(doctypes) {    
    addDocToWi(wid,pid,SelectedDocObject.DocIndex,SelectedDocObject.DocName,SelectedDocObject.DocFolderId,doctypes.value,taskid);
}

function addDocToWi(wid,pid,docId,docName,parentFoldId,docType,taskid) {             
    var docIdList = docId + ",";
    var PFIdList = parentFoldId + ",";        
    var url = '/webdesktop/ajaxaddDoc.app?wid='+wid+'&pid='+encode_utf8(pid)+'&taskid='+taskid+'&DocCount=1&DocType0='+encode_utf8(docType)+'&DocName0='+encode_utf8(docName)+'&PFIdList='+encode_utf8(PFIdList)+'&DocIdList='+encode_utf8(docIdList)+"&WD_SID="+WD_SID;
    //alert(url);
    var addDocObj = ContentLoaderWrapper(url,addDocToWiHandler,null,"POST","");
    
    
    function addDocToWiHandler() {
        //alert("Add doc to wi");
        var addResponse = parseJSON("("+this.req.responseText+")");
        if(addResponse[0].status == 'success') {            
            if(DocOrgName == 'Y')
                docName = addResponse[1].docName + "(" + addResponse[1].diskName + ")";
            else
                docName = addResponse[1].docName;
            var docIndex = addResponse[1].docIndex;
            
            var window_workdesk = window;                   
            var winList=window_workdesk.windowList;
            var docWindow=getWindowHandler(winList,"tableGrid");
            var formWindow=getWindowHandler(winList,"formGrid");
            if(docWindow) {
                if(addResponse[0].runScript == 'true') {
                    var objCombo = docWindow.document.getElementById('wdesk:docCombo');
                    var opt = docWindow.document.createElement("OPTION");
                    opt.text = docName;
                    opt.value = docIndex;
                    objCombo.add(opt);
                    objCombo.selectedIndex = objCombo.options.length-1;
                    docWindow.reloadapplet(docIndex,false,"addFromOD");
                }
            } else if(!docWindow && typeof refreshDocPanelWrapper!='undefined' && addResponse[0].runScript == 'true'){                           
                refreshDocPanelWrapper(false,''); 
                customAlert(DOCUMENT_SUCCESSFULLY_ADDED);
            } else{
                customAlert(DOCUMENT_SUCCESSFULLY_ADDED);
            }
            addDocumentPostHook(docIndex, docName, docType, pid, wid);
            executeScanAction(window_workdesk, pid, wid, docType,taskid);
            if(window_workdesk.SharingMode)
                window_workdesk.broadcastAddDocEvent(docIndex, addResponse[1].docName, addResponse[1].diskName, docType, addResponse[0].runScript, DocOrgName);
            if((typeof addDocWin != 'undefined') && (addDocWin!=null) && (closeAddDocWindow == 'Y')){                
                addDocWin.close();
                addDocWin = null;
            }
            //window.parent.close();
        }
    }
}


function LoadDocTypeContent(DivId) {    
    var url = sContextPath+"/components/workitem/document/doc_type_panel.app?wid="+wid+"&pid="+encode_utf8(pid)+"&taskid="+taskid;
    var LoadDocType = ContentLoaderWrapper(url,LoadDocTypeContentHandler,null,"POST","");
    
    function LoadDocTypeContentHandler() {
        
        DivId.innerHTML = encode_ParamValue(this.req.responseText);
    }
    
}




// from file searchresult_batch.jsp
function hitcountUpdate()
{
 	if(window.parent.frames["frmSearchResultMain"].location.pathname.indexOf("jsp")!=-1)
		window.parent.frames["frmSearchResultMain"].hitcountUpdate();
}

// from file  searchresult_maintemp.jsp

 


function SubmitForm()
{	
	thisForm = window.document.forms["resultForm"];

	thisForm.submit();
}

// from file  searchresult_tab.jsp
function showDocList(i)
{
	if(window.parent.selTab==-1)
		return;

	if(window.parent.selTab!=i)
	{
		if(i==1)
		{
			if(typeof window.parent.frames["frmSearchResultMain"].SelId != 'undefined')
			{	
				window.parent.selTab = -1;
				url = 'searchresult_main.jsp?DocListFolderId='+window.parent.frames["frmSearchResultMain"].SelId+'&OpFlag=G';
                                url = appendUrlSession(url);
				window.parent.frames["frmSearchResultMain"].location = url;
                                url = "searchresult_options.jsp?Addable="+window.top.isDocAddable;
                                url = appendUrlSession(url);
				window.parent.frames["frmSearchResultOpt"].location= url;
			}
			else
			{
				customAlert(ALERT_SEL_FOLDER);
				return;
			}
			document.images["fold"].src = sContextPath+"/webtop/"+path+"images/tab_f2.gif";
			document.images["doc"].src = sContextPath+"/webtop/"+path+"images/tab_d1.gif";
		}
		else
		{
			window.parent.selTab = -1;
			window.top.frames["frmSearch"].frames["frmSearchOpt"].Search();
		}
	}
}
  
function addDocCollaborationHandler(addDocJSON) {
    var docName;
    if(addDocJSON.DocOrgName == 'Y')
        docName = addDocJSON.DocName + "(" + addDocJSON.DiskName + ")";
    else
        docName = addDocJSON.DocName;
    var docIndex = addDocJSON.DocIndex;
    var window_workdesk = window;                   
    var winList=window_workdesk.windowList;
    var docWindow=getWindowHandler(winList,"tableGrid");
    var formWindow=getWindowHandler(winList,"formGrid");
    if(docWindow) {
        if(addDocJSON.runscript == 'true') {
            var objCombo = docWindow.document.getElementById('wdesk:docCombo');
            var opt = docWindow.document.createElement("OPTION");
            opt.text = docName;
            opt.value = docIndex;
            objCombo.add(opt);
            objCombo.selectedIndex = objCombo.options.length-1;
            docWindow.reloadapplet(docIndex,false);
        }
    }
    executeScanAction(window_workdesk, pid, wid, addDocJSON.DocType,taskid);
}