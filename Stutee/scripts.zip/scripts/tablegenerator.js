var cols,rows,isDraggedBetweenCells=!1,isMouseDown=!1,mouseDownCell,selectedRowspan,selectedColspan,tableMouseOut=false;
var cellBaseInnerHTML = "<div class='toolbox'><div class='ib'>&nbsp;</div><div class='ib'>&nbsp;</div><div class='ib'>&nbsp;</div></div><div class='content'>&nbsp;</div>";
var SPARE_CELL_WIDTH = 65;
var MINIMUM_COMP_HEIGHT = 275;
var MINIMUM_ROW_HEIGHT =30;
var spareCellBaseInnerHTML = "<div class='contract'></div><div class='spinner'><input class='rowHeightInput' style='margin-left:0px !important;width:45px !important' onkeypress='return (new Validator(event)).isNumber();' type='text' maxlength='4' value='"+MINIMUM_COMP_HEIGHT+"'/>px</div><div class='expand'></div>";
var rspGridInnerHTML = "<span class='collbl'></span><input class='colinp' style='height: 100% !important;text-align:center' onkeypress='return (new Validator(event)).isNumber();' type='text' maxlength='2' value=''/>";

function isInt(a){
    return/^\d+$/.test(a);
}

Array.indexOf||(Array.prototype.indexOf=function(a){
    for(var e=0;e<this.length;e++){
        if(this[e]==a){
            return e;
        }		
    }
    return-1;
});

function RemoveSelection(){
    window.getSelection?window.getSelection().removeAllRanges():document.selection.createRange&&(document.selection.createRange(),document.selection.empty());
}

function getCellRows(a){
    return getCellValue(a,"r");
}
	
function getCellOffset(a){
    return getCellValue(a,"o");
}

function getCellCols(a){
    return getCellValue(a,"c");
}

function getCellValue(a,e){
    var b=$(a).attr("class"),b=b.split(" ");
    allClassesLength=b.length;
    for(var c=0;c<allClassesLength;c++){
        b[c].charAt(0)===e? b[c]=parseInt(b[c].substr(1,b[c].length-1),10): (b.splice(c,1),allClassesLength--,c--);
    }
    return b;
}

function exportHTML(parentId){
    var a=$("#"+parentId +" table tbody").clone();  
    
    var tdObj = $(a).find("tr td.spareCell");
    for(var r=0; r< tdObj.length; r++){
        tdObj[r].parentNode.setAttribute('RowHeight',tdObj[r].children[0].children[1].children[0].value);
    }
    
    $(a).find("tr.n").insertBefore($(a).find("tr:first")); 
    
    var trimRegEx = /(\r\n|\n|\r)/gm; 
    var divArr = $(a).find("tr.n>td>div");
    for(var i=0; i<divArr.length-1; i++){
        divArr[i].innerHTML = divArr[i].children[1].value.replace(trimRegEx, "");
    }
    divArr[i].innerHTML = "";
    
    $(a).find("td>div").children().remove();    
    a=a.html(),a=a.toLowerCase();    
    
    a=a.replace(/(\s|\s\s|\s\s\s|\s\s\s\s)/gi,""),a=a.replace(/rowspan="1"/gi,""),a=a.replace(/colspan="1"/gi,""),a=a.replace(/(class|id|style|title)="([^"]*)"/gi,""),a=a.replace(/rowspan/gi," rowspan"),a=a.replace(/colspan/gi," colspan"),a=a.replace(/RowHeight/gi," RowHeight"),a=a.replace(/&nbsp;/gi,""),a=a.replace(/"/gi,"");
    a=a.replace(/<div>/gi,"<div/>"),a=a.replace(/<\/div>/gi,"");//,a=a.replace(/C\d/gi,"");        
    
    return "<table>"+a+"</table>";
}
	
function reindexTable(parentId, rows, cols){
    for(var a=[],e=[],b=0;b<cols;b++)a[b]="c"+b;
    for(b=0;b<rows;b++)e[b]=a.slice();
    for(var a=$("#"+parentId +" table tr:not(.n)"),c,g,f,i,b=0;b<rows;b++){
        c=a.eq(b).children().not('.n,.spareCell');
        g=c.length;
        for(var j=colOffset=0;j<g;j++){
            if(c.eq(j).hasClass('filledCellCSS')){
                c.eq(j).attr('class', 'filledCellCSS');
            } else {
                c.eq(j).removeClass();
            }
            f=parseInt(c.eq(j).attr("colspan"),10);
            i=parseInt(c.eq(j).attr("rowspan"),10);
            void 0==c.eq(j).attr("colspan")&&(f=1);
            void 0==c.eq(j).attr("rowspan")&&(i=1);
            for(var h=0, m=0;h<i;h++) {
                for(var o=0;o<f;o++){
                    for(var k=0;""===e[b+h][o+colOffset+k];)k++;
                    /*c.eq(j).addClass(e[b+h][o+colOffset+k]+" r"+(b+h));
                    e[b+h].splice(o+k+colOffset,1,"");*/
                    if(h>0){
                        c.eq(j).addClass("r"+(b+h));
                        e[b+h].splice(o+m+colOffset,1,"")
                    } else{
                        c.eq(j).addClass(e[b+h][o+colOffset+k]+" r"+(b+h));
                        e[b+h].splice(o+k+colOffset,1,"")
                        m=k;
                    }	
                }
            }
            colOffset+=f;
        }
    }
}
	
function renderTable(parentId, mergeCtrolId, rows, cols){  
    if(isInt(cols)){
        if(isInt(rows)){
            $("#"+parentId).empty().append("<table><tbody>");
            for(var a=1;a<=rows+1;a++){
                $("#"+parentId +" table").append("<tr></tr>");
                $generatedRow=$("#"+parentId +" table tr").eq(a-1);
                if(a==rows+1){
                    $generatedRow.addClass("n");
                }
                for(var e=1;e<=cols+1;e++){
                    if(e==cols+1 || a==rows+1){						
                        if(a==rows+1){
                            if(e==cols+1){
                                $generatedRow.append("<td class='n' colspan='1' rowspan='1' style='padding:0px;width:100%;height:16px;border:1px solid #A0A0A0 !important;'><div class='cellContainer' style='width:100%;height:16px'>&nbsp;=&nbsp;12</div>")
                            } else {
                                $generatedRow.append("<td class='n' colspan='1' rowspan='1' style='text-align:center;padding-top:0px;padding-bottom:0px;height:16px;border:1px solid #A0A0A0 !important;background-color: #e8e8e8'><div class='cellContainer' style='height:16px;'>"+rspGridInnerHTML+"</div>")                                
                                $generatedRow[0].cells[e-1].firstElementChild.children[0].innerHTML = "C"+e;
                                $generatedRow[0].cells[e-1].firstElementChild.children[1].value = OAPDefaultRSPMap[cols][e-1];                                
                            }
                        } else {							
                            $generatedRow.append("<td class='spareCell' colspan='1' rowspan='1' style='padding-left:0px;padding-right:0px;width:"+SPARE_CELL_WIDTH+"px;'><div class='cellContainer' title='"+SPARE_CELL_TITLE+"'>"+spareCellBaseInnerHTML+"</div>");
                        } 
                    } else {
                        $generatedRow.append("<td class='c"+(e-1)+" r"+(a-1)+"' colspan='1' rowspan='1'><div class='cellContainer'>&nbsp;</div>")						
                    }
                }
            }            
        } else {
            customAlert("Invalid row input");
        }
    } else {
        customAlert("Invalid column input");
    }    
    
    attachTableEvents(parentId);
    attachMergeEvent(parentId, mergeCtrolId);
}
	
function selectCells(a,e){
    for(var b=getCellCols(a),c=getCellRows(a),g=getCellCols(e),f=getCellRows(e),i=b.length,j=c.length,h=g.length,o=f.length,k=100,l=0,m=100,n=0,d=0;d<i;d++)b[d]<k&&(k=b[d]),b[d]>l&&(l=b[d]);
    for(d=0;d<h;d++)g[d]<k&&(k=g[d]),g[d]>l&&(l=g[d]);
    for(d=0;d<j;d++)c[d]<m&&(m=c[d]),c[d]>n&&(n=c[d]);
    for(d=0;d<o;d++)f[d]<m&&(m=f[d]),f[d]>n&&(n=f[d]);
    for(d=m;d<=n;d++)for(c=k;c<=l;c++)$(".c"+c).filter(".r"+d).addClass("s");
    do{
        b=!1;
        f=$(".s");
        i=f.length;
        g=[];
        c=[];
        for(d=0;d<i;d++)g=g.concat(getCellCols(f.eq(d))),
            c=c.concat(getCellRows(f.eq(d)));
        d=Math.max.apply(Math,g);
        g=Math.min.apply(Math,g);
        f=Math.max.apply(Math,c);
        c=Math.min.apply(Math,c);
        d>l&&(l=d,b=!0);
        g<k&&(k=g,b=!0);
        f>n&&(n=f,b=!0);
        c<m&&(m=c,b=!0);
        if(b)for(d=m;d<=n;d++)for(c=k;c<=l;c++)$(".c"+c).filter(".r"+d).addClass("s");else selectedColspan=l-k+1,selectedRowspan=n-m+1
    }while(b)
}

var srcMouseDownElement = null;
function attachTableEvents(parentId){
    $(document).on("mousedown","#"+parentId+" table tr td:not(.n,.spareCell)",function(a){
        removeCSS(document.getElementsByClassName("splitCellCSS")[0], "splitCellCSS");
        
        if(srcMouseDownElement!=null){            
            addCSS(srcMouseDownElement.parentNode, "dragCellSource");
        } else {
            addCSS(this, "splitCellCSS");
        }
        
        1===a.which&&(RemoveSelection(),isMouseDown=!0,mouseDownCell=this)
    });
    $(document).on("mouseover","#"+parentId+" table tr td:not(.n,.spareCell)",function(e){        
        if(srcMouseDownElement != null && srcMouseDownElement.parentNode != this){
            removeCSS(srcMouseDownElement.parentNode, "splitCellCSS");
            addCSS(this, "dragCellTarget");
        }
        if(mouseDownCell){
            removeCSS(mouseDownCell, "splitCellCSS");
        }        
    });
    $(document).on("mouseout","#"+parentId+" table",function(e){
        tableMouseOut=true;
    });
    $(document).on("mouseover","#"+parentId+" table",function(e){
        tableMouseOut=false;
    });
    $(document).on("mouseout","#"+parentId+" table tr td:not(.n,.spareCell)",function(e){
        if(srcMouseDownElement != null && srcMouseDownElement.parentNode!= this){
            removeCSS(this, "dragCellTarget");
        }
    });
    $(document).on("mousemove","#"+parentId+" table tr td:not(.n,.spareCell)",function(e){
        (srcMouseDownElement==null)&&isMouseDown&&mouseDownCell!=this&&(isDraggedBetweenCells=!0,RemoveSelection(),$(".s").removeClass("s"),selectCells(mouseDownCell,this))        
    });
    $(document).on("mouseup","#"+parentId+" table tr td:not(.n,.spareCell)",function(e){
        if(srcMouseDownElement!=null){
            removeCSS(srcMouseDownElement.parentNode, "dragCellSource");
            removeCSS(this, "dragCellTarget");
            onDragMouseUpViewTable(e,this);
        }
    });
    $(document).on("mouseup",function(event){        
        if(tableMouseOut){
            event = event || window.event
            var source = event.target || event.srcElement;
            if(source.nodeName.toUpperCase() != 'INPUT'){
                removeCSS(document.getElementsByClassName("splitCellCSS")[0], "splitCellCSS");
            }
        }
        isMouseDown&&(isMouseDown=!1,mouseDownCell=void 0,isDraggedBetweenCells=!1);        
        srcMouseDownElement = null;
    });
    $("#"+parentId).on("mousedown",function(a){
        1===a.which&&$(".s").removeClass("s")
    });
    $(document).on("click","#"+parentId+" table tr td:not(.n,.spareCell)",function(){
        $(this).children("#"+parentId+" table tr td div").focus();
    });
}

function onDragMouseUpViewTable(e,thisObj){
    if (srcMouseDownElement.id != thisObj.firstElementChild.id) {
        if (thisObj.firstElementChild.id != '') {
            var temp = srcMouseDownElement.id;
            srcMouseDownElement.id = thisObj.firstElementChild.id;
            thisObj.firstElementChild.id = temp;

            temp = srcMouseDownElement.childNodes[1].innerHTML;
            srcMouseDownElement.childNodes[1].title = srcMouseDownElement.childNodes[1].innerHTML = thisObj.firstElementChild.childNodes[1].innerHTML;
            thisObj.firstElementChild.childNodes[1].title = thisObj.firstElementChild.childNodes[1].innerHTML = temp;
        } else {
            var insId = srcMouseDownElement.id.split("#$#$#")[1];
            var insName = srcMouseDownElement.id.split("#$#$#")[0].split("divChild_")[1];
            var childRef = srcMouseDownElement.children[0];
            var child2Ref = srcMouseDownElement.children[1];
            srcMouseDownElement.removeAttribute('id');
            srcMouseDownElement.innerHTML = "&nbsp;";
            thisObj.firstElementChild.className = "cellContainer";
            thisObj.firstElementChild.id = "divChild_" + insName + "#$#$#" + insId;
            thisObj.children[0].innerHTML="";
            thisObj.children[0].appendChild(childRef);
            thisObj.children[0].appendChild(child2Ref);
            
            addCSS(thisObj, 'filledCellCSS');
        }

        if (srcMouseDownElement.id == '') {
            removeCSS(srcMouseDownElement.parentNode, 'filledCellCSS');
            srcMouseDownElement.innerHTML=""
             var divRef = document.createElement('div');
             divRef.className = "toolbox";
             divRef.appendChild(document.createElement('div'));
             divRef.childNodes[0].className += "ib addInterface";
             divRef.childNodes[0].innerHTML = "&nbsp;"
             divRef.childNodes[0].onclick = function (event) {
                showHideInterfacesList(event);
             }
             srcMouseDownElement.appendChild(divRef);
        }
    }
     srcMouseDownElement = null;
}


function getLowestCol(a){
    a=getCellCols(a);
    return Math.min.apply(Math,a)
}
	
function optimiseColspan(parentId){
    var a,e,b=$("#"+parentId+" table tr:not(.n)"),c=b.length,g,f,i,j,h=[];
    for(a=0;a<cols;a++)h[a]=a+1;
    for(e=0;e<c;e++){
        g=b.eq(e).children().not('.n,.spareCell');
        f=g.length;
        for(a=0;a<f;a++)i=getLowestCol(g.eq(a)),j=void 0==g.eq(a).attr("colspan")?1:parseInt(g.eq(a).attr("colspan"),10),-1!==h.indexOf(i+j)&&h.splice(h.indexOf(i+j),1);
        if(1>h.length)break
    }
    cols-=h.length;
    for(a=0;a<h.length;a++){
        b=".c"+(h[a]-1);
        $classArray=$(b);
        $classArrayL=$classArray.length;
        for(c=0;c<$classArrayL;c++)b=parseInt($classArray.eq(c).attr("colspan"),
            10),$classArray.eq(c).attr("colspan",b-1)
    }
}
		
function optimiseRowspan(parentId){    
    for(var a=$("#"+parentId+" table tr:empty:not(.n)"),e=a.length,b,c,g,f,i=0;i<e;i++){
        b=$("#"+parentId+" table tr:not(.n)").index(a.eq(i));
        b=$(".r"+b);
        c=b.length;
        for(f=0;f<c;f++){
            g=b.eq(f).attr("rowspan")-1;
            b.eq(f).attr("rowspan",g)
        }
    }
    rows-=$("#"+parentId+" table tr:empty:not(.n)").length;
    $("#"+parentId+" table tr:empty:not(.n)").remove();
}
	
function mergeCells(parentId){
    var containerDiv = document.getElementById(parentId);
    var tableInfo = getTableInfo(containerDiv.getElementsByTagName('table')[0]);    
    var rows = tableInfo.Rows.Length;
    var cols = tableInfo.Cells.Length;
    
    for(var a=$(".s"),e=a.length,b="",c=0;c<e;c++){
        b+=" "+a.eq(c).attr("class");
    }
    b=b.replace(/s/gi,"");
    //selectedColspan===cols&&(rows=rows-selectedRowspan+1,selectedRowspan=1);
    
    var firstFilledCellRef = getFirstFilledCell(a);
    var containerId = '', rowIndex, cellIndex, containerName;
    if(firstFilledCellRef != null){ 
        containerId = firstFilledCellRef.firstElementChild.id;
        containerName=firstFilledCellRef.firstElementChild.children[1].innerHTML.trim();
        cellIndex = a.eq(0)[0].cellIndex;
        rowIndex = a.eq(0)[0].parentNode.rowIndex;
    }
    
    a.eq(0).before(encode_ParamValue("<td class='"+b+"' colspan='"+selectedColspan+"' rowspan='"+selectedRowspan+"'><div class='cellContainer'><div class='toolbox'><div class='ib addInterface' onclick='showHideInterfacesList(event)'>&nbsp;</div></div></div>"));
    a.remove();
    
    if(firstFilledCellRef != null){
        updateToCellContainer(rowIndex,cellIndex,containerId,containerName);
    }

    selectedColspan===cols&&$("#"+parentId+" table tr:empty:not(.n)").remove();
    reindexTable(parentId, rows, cols);
    /*optimiseRowspan(parentId);
    optimiseColspan(parentId);
    reindexTable(parentId);*/
}

function attachMergeEvent(parentId, mergeCtrolId){    
    $("#"+mergeCtrolId).on("click",function(){
        mergeCells(parentId);
    })
}

function getFirstFilledCell(a){
    for(var i=0; i<a.length; i++){
        if(a.eq(i)[0].firstElementChild.id != ''){
            return a.eq(i)[0];
        }
    }
    
    return null;
}

function initViewTable(tableContainerId, mergeButtonId, colMapping, viewTableStruct, opr){ 
    opr = (typeof opr == 'undefined')? '': opr;
    if(viewTableStruct != null && viewTableStruct.value != ''){
        updateViewTable(tableContainerId, mergeButtonId, viewTableStruct.value, opr);
    } else {        
        var rows=document.getElementById(tableContainerId+'Rows').value-0;
        renderTable(tableContainerId, mergeButtonId, rows, colMapping);   
    }
    
    var viewTableObj = document.getElementById(tableContainerId).getElementsByTagName('table')[0];
    addCSS(viewTableObj, "cursorCell");
    removeMultipleDiv();
}

function removeMultipleDiv(){
    var tblRef=document.getElementById('tableWrap').firstElementChild;
    var rowsRef=tblRef.rows;
    for(var i=0;i<rowsRef.length-1;i++){
        var cellsRef=rowsRef[i].cells;
        for(var j=0;j<cellsRef.length-1;j++){
            var cellRef=cellsRef[j];
            if(cellRef.firstElementChild.childElementCount>2){
                var zeroCell=cellRef.firstElementChild.childNodes[1];
                while(cellRef.firstElementChild.childElementCount>2){
                    zeroCell.innerHTML += ","+ cellRef.firstElementChild.childNodes[2].innerHTML.trim();
                    cellRef.firstElementChild.removeChild(cellRef.firstElementChild.childNodes[2]);
                }
            }
        }
    }
}

function updateViewTable(tableContainerId, mergeButtonId, viewTableStruct, opr){    
    var containerDiv = document.getElementById(tableContainerId); 
    containerDiv.innerHTML = viewTableStruct;
	
    var viewTableRef = containerDiv.getElementsByTagName('table')[0];
    viewTableRef.firstElementChild.appendChild(viewTableRef.rows[0]);    
//    var index=new Array();
//    var cellsRef = viewTableRef.rows[0].cells;
//    for (var i = 0; i < cellsRef.length; i++) {
//        var cell = viewTableRef.rows[0].cells[i];
//        if (cell.firstElementChild.childElementCount > 1) {
//            var cellZero = viewTableRef.rows[0].cells[0].firstElementChild.childNodes[0];
//            for (var i = 1; i < cell.firstElementChild.childElementCount; i++) {
//                cellZero.innerHTML += "," + cell.firstElementChild.childNodes[i].innerHTML;
//            }
//            while(cell.firstElementChild.childElementCount>1){
//                cell.firstElementChild.removeChild(cell.firstElementChild.childNodes[1]);
//            }
//        }
//    }
    var tableInfo = getTableInfo(viewTableRef);    
    var rows = tableInfo.Rows.Length;
    var cols = tableInfo.Cells.Length;
    
    if(opr != 'C'){
        document.getElementById(tableContainerId+'Rows').value = rows;
        document.getElementById(tableContainerId+'Cols').value = cols;
    }
    
    var newRows=document.getElementById(tableContainerId+'Rows').value-0;
    
    var tableRowRef = null, tableCellRef = null, realCols = 0;   
    
    for(var r = 0; r <= rows; r++){
        tableRowRef = viewTableRef.rows[r];
        realCols = tableRowRef.cells.length;
        if(r == rows){                       
            tableRowRef.className += " n";
        }                
        
        for(var c = 0; c < realCols; c++){
            tableCellRef = tableRowRef.cells[c];
            
            if(c==(realCols-1) || r==rows){
                if(r==rows){
                    if(c==(realCols-1)){
                        tableCellRef.className = "n";
                        tableCellRef.setAttribute("style", "padding:0px;width:100%;height:16px;border:1px solid #A0A0A0 !important;");
                        tableCellRef.firstElementChild.className = "cellContainer";
                        tableCellRef.firstElementChild.setAttribute("style", "width:100%;height:16px");
                        tableCellRef.firstElementChild.innerHTML = "&nbsp;=&nbsp;12";
                    } else {
                        tableCellRef.className = "n";
                        tableCellRef.setAttribute("style", "text-align:center;padding-top:0px;padding-bottom:0px;height:16px;border:1px solid #A0A0A0 !important;background-color: #e8e8e8;");
                        tableCellRef.firstElementChild.className = "cellContainer";
                        tableCellRef.firstElementChild.setAttribute("style", "height:16px");
                        var rspGridValue = tableCellRef.firstElementChild.innerHTML;
                        tableCellRef.firstElementChild.innerHTML = rspGridInnerHTML;
                        tableCellRef.firstElementChild.children[0].innerHTML = "C"+(c+1);
                        tableCellRef.firstElementChild.children[1].value = rspGridValue;
                    }
                } else {				
                    tableCellRef.className = "spareCell";
                    tableCellRef.setAttribute("style", "padding-left:0px;padding-right:0px;width:"+SPARE_CELL_WIDTH+"px");
                    tableCellRef.firstElementChild.className = "cellContainer"; 
                    tableCellRef.firstElementChild.title = SPARE_CELL_TITLE; 
                    tableCellRef.firstElementChild.innerHTML = spareCellBaseInnerHTML;
                    if(tableRowRef.getAttribute('RowHeight')){
                        tableCellRef.children[0].children[1].children[0].value = tableRowRef.getAttribute('RowHeight');
                    }
                    tableCellRef.firstElementChild.childNodes[0].onmousedown = function (event){
                        this.parentNode.childNodes[1].childNodes[0].value = this.parentNode.childNodes[1].childNodes[0].value-0-5;
                        stopEventPropagation(event);
                    }
                    
                    tableCellRef.firstElementChild.childNodes[2].onmousedown = function (event){
                        this.parentNode.childNodes[1].childNodes[0].value = this.parentNode.childNodes[1].childNodes[0].value-0+5;
                        stopEventPropagation(event);
                    }
                } 
            } else {        
                tableCellRef.firstElementChild.className = "cellContainer";
                if (tableCellRef.firstElementChild.firstElementChild != null && tableCellRef.firstElementChild.firstElementChild.innerHTML!='') {
                    var val=tableCellRef.firstElementChild.firstElementChild.innerHTML.trim();
                    if(typeof  containerId[val]!="undefined" || containerId[val]!=null)
                      tableCellRef.firstElementChild.id = "divChild_" + tableCellRef.firstElementChild.firstElementChild.innerHTML + "#$#$#Int" + containerId[val];
                    else
                      tableCellRef.firstElementChild.id = "divChild_" + tableCellRef.firstElementChild.firstElementChild.innerHTML + "#$#$#Int" + c;  
                    tableCellRef.firstElementChild.height = tableCellRef.clientHeight - 2 + "px";

                    var childRef = tableCellRef.firstElementChild;
                    var child2Ref = tableCellRef.firstElementChild.firstElementChild;
                    child2Ref.className = "content";
                    var divRef = document.createElement('div');
                    divRef.className = "toolbox";
                    divRef.appendChild(document.createElement('div'));
                    divRef.appendChild(document.createElement('div'));
                    divRef.appendChild(document.createElement('div'));
                    divRef.childNodes[0].className += 'ib move';
                    divRef.childNodes[0].title = DRAG_TO_MOVE_COMP;
                    divRef.childNodes[0].innerHTML = "&nbsp;";
                    divRef.childNodes[0].onmousedown = function (event) {
                        srcMouseDownElement = this.parentNode.parentNode;
                        stopEventPropagation(event);
                    }
                    divRef.childNodes[1].className += 'ib close';
                    divRef.childNodes[1].title = CLICK_TO_CLOSE_COMP;
                    divRef.childNodes[1].innerHTML = "&nbsp;";
                    divRef.childNodes[1].onclick = function (event) {
                        if (this.parentNode.parentNode != null) {
                            var name=this.parentNode.parentNode.children[1].innerHTML.trim();
                            this.parentNode.parentNode.removeAttribute('id');
                            this.parentNode.parentNode.removeChild(this.parentNode.parentNode.childNodes[1]);
                            removeCSS(this.parentNode.parentNode.parentNode, 'filledCellCSS');
                            this.parentNode.removeChild(this.parentNode.firstElementChild);
                            this.parentNode.removeChild(this.parentNode.firstElementChild);
                            showHidePanelOptions();
                            removeMultipane(name);
                        }
                    }
                    divRef.childNodes[2].className += 'ib addInterface';
                    divRef.childNodes[2].title = ADD_INTERFACE;
                    divRef.childNodes[2].innerHTML = "&nbsp;";
                    divRef.childNodes[2].onclick = function (event) {
                       showHideInterfacesList(event);
                    }
                    childRef.insertBefore(divRef, child2Ref);
                    addCSS(tableCellRef, 'filledCellCSS');
                } else {
                    if(tableCellRef.firstElementChild.firstElementChild.innerHTML==''){
                        tableCellRef.firstElementChild.firstElementChild.className = "toolbox";
                        tableCellRef.firstElementChild.firstElementChild.appendChild(document.createElement('div'));
                        tableCellRef.firstElementChild.firstElementChild.childNodes[0].className += "ib addInterface";
                        tableCellRef.firstElementChild.firstElementChild.childNodes[0].innerHTML="&nbsp;"
                        tableCellRef.firstElementChild.firstElementChild.childNodes[0].onclick = function (event) {
                            showHideInterfacesList(event);
                        }
                    }
                }
            }
        }
    }
    
    newRows=(newRows - rows);
    if(newRows>0){        
        addRowToViewTable(tableContainerId,newRows);        
    } else if (newRows<0){
        deleteRowFromViewTable(tableContainerId,-newRows);
    }
        
    //Assign classes to cells
    reindexTable(tableContainerId, rows, cols);
    
    attachTableEvents(tableContainerId);
    attachMergeEvent(tableContainerId, mergeButtonId);
}


function getTableInfo(viewTableRef){
    var tableInfo = {
        Rows: {
            Length: viewTableRef.rows.length-1
        }, 
        Cells: {
            Length: viewTableRef.rows[viewTableRef.rows.length-1].cells.length-1
        }
    };
    
    return tableInfo;
}

function addRowToViewTableWrapper(tableContainerId, nRows){
    addRowToViewTable(tableContainerId, nRows);
    document.getElementById(tableContainerId+'Rows').value = document.getElementById(tableContainerId+'Rows').value - 0 + nRows;
}

function addRowToViewTable(tableContainerId, nRows){
    var viewTableRef = document.getElementById(tableContainerId).getElementsByTagName('table')[0];
    var tableInfo = getTableInfo(viewTableRef);    
    var rows = tableInfo.Rows.Length;
    var cols = tableInfo.Cells.Length;
    var rowHTML = "";
    
    for(var r=0; r<nRows; r++){
        rowHTML += "<tr>";
        for(var c=0; c<=cols; c++){
            if(c<cols){
                rowHTML += "<td class='c"+c+" r"+(rows+r)+"' colspan='1' rowspan='1'><div class='cellContainer'><div class='toolbox'><div class='ib addInterface' onclick='showHideInterfacesList(event)'>&nbsp;</div></div></div></td>";
            } else {
                rowHTML += "<td class='spareCell' colspan='1' rowspan='1' style='padding-left:0px;padding-right:0px;width:"+SPARE_CELL_WIDTH+"px;'><div class='cellContainer'>"+spareCellBaseInnerHTML+"</div></td>";
            }
        }
        rowHTML += "</tr>";
    }
    
    $("#"+tableContainerId +" table tr.n").before(rowHTML); 
}

function deleteRowFromViewTableWrapper(tableContainerId, nRows){
    var actualRowsDeleted = deleteRowFromViewTable(tableContainerId, nRows);
    var totalRows = document.getElementById(tableContainerId+'Rows').value - 0;
    
    if(totalRows>0){
        document.getElementById(tableContainerId+'Rows').value = totalRows - actualRowsDeleted;
    }
}

function deleteRowFromViewTable(tableContainerId, nRows){ 
    nRows = (typeof nRows == 'undefined')?1: nRows;
    var viewTableRef = document.getElementById(tableContainerId).getElementsByTagName('table')[0];
    var tableInfo = getTableInfo(viewTableRef);    
    var rows = tableInfo.Rows.Length;
    var cols = tableInfo.Cells.Length;
    var r, c, rowColSpan;
    
    for(r=rows-nRows; r>=0; r--){
        if((viewTableRef.rows[r].cells.length-1) == cols){
            break;
        } else {
            for(c=0, rowColSpan=0; c<viewTableRef.rows[r].cells.length-1; c++){                    
                rowColSpan += viewTableRef.rows[r].cells[c].colSpan; 
            }

            if(rowColSpan == cols){
                break;
            }
        }
    }
    if(r>0)
        $("#"+tableContainerId +" table tr:not(.n)").slice(r, rows).remove(); 
    else 
       notifierAbs('notifier', LABEL_ROW_NOT_DELETED, "absolute", true);
    return(rows-r);
}

function splitCell(tableContainerId){
    var splitCellObj = document.getElementsByClassName("splitCellCSS")[0];
    
    if((typeof splitCellObj == 'undefined') || splitCellObj.rowSpan==1 && splitCellObj.colSpan==1){
        return;
    }
    
    var viewTableObj = document.getElementById(tableContainerId).firstElementChild;
    var cellObj = null,c=0,rowIndex=splitCellObj.parentNode.rowIndex,cellIndex=splitCellObj.cellIndex,containerId=viewTableObj.rows[rowIndex].cells[cellIndex].firstElementChild.id,containerName;
    if(viewTableObj.rows[rowIndex].cells[cellIndex].firstElementChild.children[1]!=null)
       containerName=viewTableObj.rows[rowIndex].cells[cellIndex].firstElementChild.children[1].innerHTML.trim();
    var cellHTML = "<td colspan='1' rowspan='1'><div class='cellContainer'><div class='toolbox'><div class='ib addInterface' onclick='showHideInterfacesList(event)'></div></div></div></td>";
    
    for(var r=rowIndex; r<rowIndex+splitCellObj.rowSpan; r++){
        if(r==rowIndex){
            cellObj = $(viewTableObj.rows[r].cells[cellIndex]);
            for(c=0; c<splitCellObj.colSpan; c++){            
                cellObj.after(cellHTML);            
            }
        } else {
            cellObj = getCellObject(viewTableObj, splitCellObj, r);
            for(c=0; c<splitCellObj.colSpan; c++){            
                $(cellObj).before(cellHTML);            
            }
        }
    }
    
    $(viewTableObj.rows[rowIndex].cells[cellIndex]).remove();
    
    updateToCellContainer(rowIndex,cellIndex,containerId,containerName);
    
    var tableInfo = getTableInfo(viewTableObj);    
    reindexTable(tableContainerId, tableInfo.Rows.Length, tableInfo.Cells.Length);
}

function getCellObject(viewTableObj, splitCellObj, rowIndex){    
    var c=0,cellMap={},pattern =/c[0-9]*/, cellMapKey = "";
    
    for(var i=0; i<viewTableObj.rows[rowIndex].cells.length-1; i++){   
        cellMapKey = viewTableObj.rows[rowIndex].cells[i].className.match(pattern);
        if(cellMapKey){
            cellMap[cellMapKey[0]] = viewTableObj.rows[rowIndex].cells[i];                
        }
    }
    
    for(c=splitCellObj.cellIndex+1; c<viewTableObj.rows[viewTableObj.rows.length-1].cells.length-1; c++){        
        if(cellMap["c"+c]){            
            return cellMap["c"+c];            
        }
    }
    
    return viewTableObj.rows[rowIndex].cells[viewTableObj.rows[rowIndex].cells.length-1];
}

function addColumnToViewTableWrapper(tableContainerId, nRows){
    var bAdded = addColumnToViewTable(tableContainerId, nRows);
    if(!bAdded){
        return false;
    }
    
    document.getElementById(tableContainerId+'Cols').value = document.getElementById(tableContainerId+'Cols').value - 0 + nRows;
    var tableInfo = getTableInfo(document.getElementById(tableContainerId).getElementsByTagName('table')[0]);    
    reindexTable(tableContainerId, tableInfo.Rows.Length, tableInfo.Cells.Length);
}

function addColumnToViewTable(tableContainerId, nRows){
    var viewTableRef = document.getElementById(tableContainerId).getElementsByTagName('table')[0];
    var tableInfo = getTableInfo(viewTableRef);    
    var rows = tableInfo.Rows.Length;
    var cols = tableInfo.Cells.Length;
    
    if(cols == 12){
        return false;
    }
    
    var cellRef = null,className='';
    for(var r=0; r<rows; r++){             
        if((viewTableRef.rows[r].cells.length-1) == cols){
            className = "c"+(cols)+" r"+r;            
        } else {
            for(var c=0, rowColSpan=0; c<viewTableRef.rows[r].cells.length-1; c++){                    
                rowColSpan += viewTableRef.rows[r].cells[c].colSpan; 
            }
            className = "c"+(rowColSpan)+" r"+r;            
        }
        
        cellRef = viewTableRef.rows[r].insertCell(viewTableRef.rows[r].cells.length-1);
        cellRef.className = className;
        cellRef.colSpan = "1";
        cellRef.rowSpan = "1";
        cellRef.innerHTML = "<div class='cellContainer'><div class='toolbox'><div class='ib addInterface' onclick='showHideInterfacesList(event)'>&nbsp;</div></div></div>";
    }
   
    cellRef = viewTableRef.rows[r].insertCell(cols);
    cellRef.className = "n";
    cellRef.colSpan = "1";
    cellRef.rowSpan = "1";
    cellRef.style = "text-align:center;padding-top:0px;padding-bottom:0px;height:16px;border:1px solid #A0A0A0 !important;background-color: #e8e8e8;";
    cellRef.innerHTML = "<div class='cellContainer' style='height:16px;'>"+rspGridInnerHTML+"</div>";
    
    updateDefaultRSPGrid(viewTableRef, rows, cols+1);
    
    return true;
}

function updateDefaultRSPGrid(viewTableRef, rowIndex, Columns){
    for(var c=0; c<Columns; c++){                     
        viewTableRef.rows[rowIndex].cells[c].firstElementChild.children[0].innerHTML = "C"+(c+1);
        viewTableRef.rows[rowIndex].cells[c].firstElementChild.children[1].value = OAPDefaultRSPMap[Columns][c];
    }
}

function deleteColumnFromViewTableWrapper(tableContainerId, nRows){
    var actualRowsDeleted = deleteColumnFromViewTable(tableContainerId, nRows);
    var totalRows = document.getElementById(tableContainerId+'Cols').value - 0;
    if(totalRows>0){
        document.getElementById(tableContainerId+'Cols').value = totalRows - actualRowsDeleted;
    }
    var tableInfo = getTableInfo(document.getElementById(tableContainerId).getElementsByTagName('table')[0]);    
    reindexTable(tableContainerId, tableInfo.Rows.Length, tableInfo.Cells.Length);
}

function deleteColumnFromViewTable(tableContainerId, nRows){ 
    nRows = (typeof nRows == 'undefined')?1: nRows;
    var viewTableRef = document.getElementById(tableContainerId).getElementsByTagName('table')[0];
    var tableInfo = getTableInfo(viewTableRef);    
    var rows = tableInfo.Rows.Length;
    var cols = tableInfo.Cells.Length;
    var r, c, rowColSpan;
    
    /*var tempColSpan=1, maxColSpan=1;
    for(r=0; r<rows; r++){
        tempColSpan = viewTableRef.rows[r].cells[viewTableRef.rows[r].cells.length-2].colSpan-0;
        if(tempColSpan > maxColSpan){
            maxColSpan = tempColSpan;
        }
    }
    
    var fromCellIndex = cols-maxColSpan;
        
    $("#"+tableContainerId +" table tr:not(.n)").each(function() {
        $(this).children().slice(fromCellIndex,$(this).children().length-1).remove();
    });*/
    
    var rowSpan,lastCellIndex,arrCellToBeDeleted=new Array(),maxCells=0;
    
    for(r=0; r<=rows; r++){
         lastCellIndex = viewTableRef.rows[r].cells.length-2;
         
         if(maxCells < (viewTableRef.rows[r].cells.length-1)){         
            maxCells = viewTableRef.rows[r].cells.length-1;
         }
         
         if(viewTableRef.rows[r].cells[lastCellIndex].colSpan == 1){            
             arrCellToBeDeleted.push(viewTableRef.rows[r].cells[lastCellIndex]);
             
             rowSpan = viewTableRef.rows[r].cells[lastCellIndex].rowSpan;
             if(rowSpan != 1){
                 r += rowSpan-1;
                 continue;
             }             
         } else {
             arrCellToBeDeleted = new Array();
             break;
         }         
    }
    
    if(arrCellToBeDeleted.length > 0){
        if(maxCells > 1){
            while(arrCellToBeDeleted.length > 0){            
                $(arrCellToBeDeleted.pop()).remove();  
            }
            
            tableInfo = getTableInfo(viewTableRef);    
            rows = tableInfo.Rows.Length;
            cols = tableInfo.Cells.Length;
            updateDefaultRSPGrid(viewTableRef, rows, cols);
        }else {
            notifierAbs('notifier', LABEL_COLUMN_NOT_DELETED, "absolute", true);
        }
    } 
    
    return(rows-r);
}

function updateToCellContainer(rowIndex,cellIndex,containerId,containerName){
    var viewTableRef = document.getElementById('tableWrap').firstElementChild;
    var insId=containerId.split("#$#$#")[1];    
    var insName=containerId.split("#$#$#")[0].split("divChild_")[1];
    addToCellContainer(viewTableRef.rows[rowIndex].cells[cellIndex].firstElementChild, insName, insId,containerName);
}

function addToCellContainer(cellContainerRef, name, id,cntName){
    var containerId = 'divChild_'+name+'#$#$#'+id;
    if(document.getElementById(containerId)!=null){
        return false;
    } else{
        resetFieldValidator();
    }
    
    if(typeof name != 'undefined'){         
        cellContainerRef.setAttribute('id', containerId);
        //cellContainerRef.style.height = cellContainerRef.parentNode.clientHeight-2 + "px";
        cellContainerRef.innerHTML = cellBaseInnerHTML;

        var toolboxContRef = cellContainerRef.childNodes[0];
        var contentContRef = cellContainerRef.childNodes[1];

        toolboxContRef.childNodes[0].className += ' move';
        toolboxContRef.childNodes[0].title = DRAG_TO_MOVE_COMP;
        toolboxContRef.childNodes[0].CellContainer = cellContainerRef;
        toolboxContRef.childNodes[0].onmousedown = function (event){
            srcMouseDownElement = this.parentNode.parentNode;
            stopEventPropagation(event);
        }
        
        toolboxContRef.childNodes[1].className += ' close';
        toolboxContRef.childNodes[1].title = CLICK_TO_CLOSE_COMP;
        toolboxContRef.childNodes[1].onclick = function (event) {
            if (this.parentNode.parentNode != null) {
                this.parentNode.parentNode.removeAttribute('id');
                this.parentNode.parentNode.removeChild(this.parentNode.parentNode.childNodes[1]);
                removeCSS(this.parentNode.parentNode.parentNode, 'filledCellCSS');
                this.parentNode.removeChild(this.parentNode.firstElementChild);
                this.parentNode.removeChild(this.parentNode.firstElementChild);
            }
        }
       
        toolboxContRef.childNodes[2].className += ' addInterface';
        toolboxContRef.childNodes[2].title = ADD_INTERFACE;
        toolboxContRef.childNodes[2].onclick = function (event) {
            showHideInterfacesList(event);
        }
        
        if (typeof cntName != 'undefined') {
            if (cntName != '') {
                name = cntName;
            }
        }
        
        contentContRef.title = contentContRef.innerHTML = name;
        addCSS(cellContainerRef.parentNode, 'filledCellCSS');
        return true;
    }
}

var OAPDefaultRSPMap = {1:[12], 
                 2:[6,6],
                 3:[4,4,4],
                 4:[3,3,3,3],
                 5:[2,2,4,2,2],
                 6:[2,2,2,2,2,2],
                 7:[1,2,2,2,2,2,1],
                 8:[1,1,2,2,2,2,1,1],
                 9:[1,1,1,2,2,2,1,1,1],
                10:[1,1,1,1,2,2,1,1,1,1],
                11:[1,1,1,1,1,2,1,1,1,1,1],
                12:[1,1,1,1,1,1,1,1,1,1,1,1]};
