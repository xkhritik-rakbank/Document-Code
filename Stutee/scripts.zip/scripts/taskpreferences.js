/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function UserListCallBack(jsonString)
{
    var userJson;
    var unameMsg="";
    var userFlag=false;
    var userNameArr=new Array();
    var useroperation;
    userJson = JSON.parse(jsonString);
    if(userJson.UserInfoList.length > 0) {
        for(var Count=0;Count<userJson.UserInfoList.length;Count++)
        {
            userFlag=false;
            var uname = userJson.UserInfoList[Count].UserName;
            table = document.getElementById("taskPreferences:panel:UGLists");
            if (table){
                    rowCount = table.tBodies[0].rows.length; 
                    //rowCount=rowCount-1;
                    for(var iCount = 0; iCount <rowCount; iCount++)
                    {
                        userexistid =  document.getElementById("taskPreferences:panel:UGLists:"+iCount +":UGName").innerHTML;
                        useroperation=document.getElementById("taskPreferences:panel:UGLists:"+iCount +":UGOperation").value;
                        if (uname==userexistid&&useroperation!='D')
                        {
                            userFlag=true;
                            unameMsg += ","+ uname;
                        }
                    }
                    if(userFlag==false){
                        userNameArr.push(uname);
                    } else{
                        delete userJson.UserInfoList[Count];
                    }
                }
                else
                {
                    userNameArr.push(uname);   
                }
        }
        document.getElementById("taskPreferences:m_strUserJson").value=JSON.stringify(userJson);
        document.getElementById("taskPreferences:panel:UserName").value=userNameArr;        
        document.getElementById("taskPreferences:panel:UserName").title=userNameArr;        
        if(unameMsg!=""){
            fieldValidator(null, unameMsg.substring(1,unameMsg.length) + " " + TEXT_ALREADY_ADDED, "absolute", true);
            return false;
        }
    }
    else
    {
        fieldValidator("taskPreferences:panel:UserName", NO_USER_SELECTED, "absolute", true);
        return(false);
    }
    return true;
}
   
function clearSavedVales()
{
    if(document.getElementById("taskPreferences:panel:optGroup:0").checked)
        document.getElementById("taskPreferences:UserID").value='';
    if(document.getElementById("taskPreferences:panel:optGroup:1").checked)
        document.getElementById("taskPreferences:GroupID").value='';

}

function removeUser()
{
    try
    {
        var nodeChkBox=document.getElementById("taskPreferences:panel:UGLists:0:chkBoxUG");
        var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length; 
        
        if(rowCount<1)
        {
            fieldValidator(null, NO_USER_SPECIFIED, "absolute", true);
            return false;
        }
        for(iCount = 0; iCount < rowCount;iCount++)
        {
            if(document.getElementById("taskPreferences:panel:UGLists:"+iCount +":chkBoxUG").checked)
            {
                clickLink('taskPreferences:removeUser');
                return true;
            }
        }
    }
    catch(e)
    {
    }
    //alert(NO_USER_GROUP_SPECIFIED);
    return false;
}

function addUser(){
    var groupexistid;
    var iCount;
    var userexistid;
    var groupoperation;
   
    if(document.getElementById("taskPreferences:panel:optGroup:0").checked)
    {
        
        var groupid=document.getElementById("taskPreferences:GroupID").value;
        if(groupid=='' || groupid=='-1' || groupid=='0')
        {
            fieldValidator("taskPreferences:panel:GroupName", NO_GROUP_SELECTED, "absolute", true);    
            
            return(false);
        }
        var table = document.getElementById("taskPreferences:panel:UGLists");
        if (table){
                       
            var rowCount = table.rows.length; 
            rowCount=rowCount-1;
            var gname = document.getElementById("taskPreferences:panel:GroupName").value;
            for(iCount = 0; iCount <rowCount; iCount++)            
            {
                    if(document.getElementById("taskPreferences:panel:UGLists:"+iCount +":UGName")!=null){
                        groupexistid =  document.getElementById("taskPreferences:panel:UGLists:"+iCount +":UGName").innerHTML;
                        groupoperation=document.getElementById("taskPreferences:panel:UGLists:"+iCount +":UGOperation").value;
                        if (gname==groupexistid&&groupoperation!='D')
                        {

                            fieldValidator(null, gname + " " + TEXT_ALREADY_ADDED, "absolute", true);

                            return(false);
                        }
                    }
            }
            
        }
        document.getElementById("taskPreferences:m_strUGIndex").value=groupid;
        document.getElementById("taskPreferences:m_strUGName").value=document.getElementById("taskPreferences:HidGroupName").value;
        document.getElementById("taskPreferences:m_strUGType").value="G";
        document.getElementById("taskPreferences:GroupID").value="0";
        document.getElementById("taskPreferences:panel:GroupName").value="";
        document.getElementById("taskPreferences:m_strUserJson").value="";
    }
    else if(document.getElementById("taskPreferences:panel:optGroup:1").checked)
    {
        var userData=document.getElementById("taskPreferences:panel:UserName").value;
        
        if(userData=="") {
            fieldValidator("taskPreferences:panel:UserName", NO_USER_SELECTED, "absolute", true);
            return(false);
        }
//        var userid=document.getElementById("QueueMgmtForm:UserID").value;
//        if(userid=='' || userid=='-1' || userid=='0')
//        {
//            fieldValidator("QueueMgmtForm:UserName", NO_USER_SELECTED, "absolute", true);
//            //alert(NO_USER_SELECTED);
//            return(false);
//        }
//        table = document.getElementById("QueueMgmtForm:UGLists");
//        if (table){
//            rowCount = table.rows.length; 
//            rowCount=rowCount-1;
//            var uname = document.getElementById("QueueMgmtForm:UserName").value;
//            for(iCount = 0; iCount <rowCount; iCount++)
//            {
//                userexistid =  document.getElementById("QueueMgmtForm:UGLists:"+iCount +":UGName").innerHTML;
//                if (uname==userexistid)
//                {
//                    fieldValidator(null, uname + " " + TEXT_ALREADY_ADDED, "absolute", true);
//                    //alert(uname + " " + TEXT_ALREADY_ADDED);
//                    return(false);
//                }
//            }
//        }
          document.getElementById("taskPreferences:m_strUGIndex").value="";
          document.getElementById("taskPreferences:m_strUGName").value="";
          document.getElementById("taskPreferences:m_strUGType").value="U";
          document.getElementById("taskPreferences:UserID").value="0";
          document.getElementById("taskPreferences:panel:UserName").value="";
    }
    else{
        return false;
    }
    clickLink('taskPreferences:btnAddUser');
    return true;
}
function cancelUserChanges(){
    if(document.getElementById("taskPreferences:panel:UGLists:chkBoxUGAll")!=null)
        document.getElementById("taskPreferences:panel:UGLists:chkBoxUGAll").checked=false;
    clickLink('taskPreferences:cancelUserChanges');
    
}
function saveUserChanges(){
    if(document.getElementById("taskPreferences:panel:UGLists:chkBoxUGAll")!=null)
        document.getElementById("taskPreferences:panel:UGLists:chkBoxUGAll").checked=false;
    clickLink('taskPreferences:saveUserChanges');
    
}
function selectAllUsers(){
    var val=document.getElementById("taskPreferences:panel:UGLists:chkBoxUGAll").checked;
    var table = document.getElementById("taskPreferences:panel:UGLists");
    if (table){           
            var rowCount = table.rows.length; 
            rowCount=rowCount-1;
            for(iCount = 0; iCount <rowCount; iCount++)            
            {
                    var operation=document.getElementById("taskPreferences:panel:UGLists:"+iCount +":UGOperation").value;
                    if(operation!="D"){
                        document.getElementById("taskPreferences:panel:UGLists:"+iCount +":chkBoxUG").checked=val;
                        if(val){
                            table.rows[iCount+1].className="tablecontent row-selector";
                        }
                        else{
                            table.rows[iCount+1].className="tablecontent";
                        }
                    }
            }
    }
}

function checkForSelectAll(){
    var table = document.getElementById("taskPreferences:panel:UGLists");
    if (table){           
            var rowCount = table.rows.length; 
            rowCount=rowCount-1;
            for(iCount = 0; iCount <rowCount; iCount++)            
            {
                    if(!document.getElementById("taskPreferences:panel:UGLists:"+iCount +":chkBoxUG").checked){
                        document.getElementById("taskPreferences:panel:UGLists:chkBoxUGAll").checked=false;
                        return;
                    }
            }
            document.getElementById("taskPreferences:panel:UGLists:chkBoxUGAll").checked=true;
    }
}