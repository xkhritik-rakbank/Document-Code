/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
*/

function changeColor(target){
    target.className = 'oarowstylegray';
}
function changeBack(target){
    target.className = '';
}
function enableOnClick(ref){
    var delLink = document.getElementById("appform:deleteLink");
    var modLink = document.getElementById("appform:modifyLink");
    var delLabel = document.getElementById("appform:deleteLabel");
    var modLabel = document.getElementById("appform:modifyLabel");

    var arr = ref.id.split(":");
    var iArrLength = arr.length ;
    var strName = "";
    var selectedRow = arr[iArrLength-2];

    for (var count=0; count < arr.length-2 ; count++ )    {
        if(count==0)
            strName = arr[count] ;
        else{
            strName=strName + ":" + arr[count] ;
        }
    }
    var nodeChkBox=document.getElementById(strName+":"+selectedRow +":chkBox");
    var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length;
    if(nodeChkBox.checked == true){
        for(iCount = 0; iCount < rowCount;iCount++){
            if(iCount != arr[iArrLength-2]) {
                var el=document.getElementById(strName+":"+iCount +":chkBox");
                el.checked=false;                
            }
        }
        delLabel.style.display = "none";
        modLabel.style.display = "none";
        delLink.style.display = "inline";
        modLink.style.display = "inline";
    }
    else {
        delLabel.style.display = "inline";
        modLabel.style.display = "inline";
        delLink.style.display = "none";
        modLink.style.display = "none";
    }
}

function FAjaxErrorHandler(data){
        if(data.responseCode == '250')
        {
          window.location= "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";
//        createPopUpIFrameWrapper('iFrameId','/omniapp/pages/error/errorpagepopup.app?msgID=-8002&HeadingID=8002',330,450);
//        var screenHeight = window.screen.height;
//        document.getElementById('iFrameId').style.top = screenHeight/6+"px";
        }
        else if(data.responseCode == '310')
    {
        window.location= "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";    
    }
    else if(data.responseCode=='350'){
            createPopUpIFrameWrapper('iFrameId','/webdesktop/error/errorpagepopup.app?msgID=-8002&HeadingID=8002',330,450);
            var screenHeight = window.screen.height;
            document.getElementById('iFrameId').style.top = screenHeight/6+"px";
    }
}

function HandleProgressBar(data){
    if(data.status == "begin"){        
        CreateIndicator("application");        
    }
    else if(data.status == "complete"){
        RemoveIndicator("application");
    }
}

function QListProgressBar(data){
    HandleProgressBar(data);
    if(data.status == "success"){
        loadQueueList();
    }
}
function DashProgressBar(data){
    HandleProgressBar(data);
    if(data.status == "success"){
        loadDashBoard();
    }
}
function CreateIndicator(indicatorFrameId){
    var ParentDocWidth = document.body.clientWidth;
    var ParentDocHeight = document.body.clientHeight;
    var ImgTop=50;
    var ImgLeft=ParentDocWidth/2-40;

    try {
        if(document.getElementById(indicatorFrameId) != null){
            return;
        }
        img = document.createElement("IMG");
        img.setAttribute("src", "/webdesktop/resources/images/progressimg.gif");
        img.setAttribute("name", indicatorFrameId);
        img.setAttribute("id", indicatorFrameId);
        img.style.left = ImgLeft+"px";
        img.style.top = ImgTop+"px";
        img.style.position="absolute";
        img.style.visibility="visible";
        document.body.appendChild(img);
    }
    catch(ex) {}
    document.body.style.cursor='wait';
}

function RemoveIndicator(indicatorFrameId){
    try {
        var img = document.getElementById(indicatorFrameId);
        document.body.removeChild(img);
    }
    catch(ex) {}
    document.body.style.cursor='auto';
}

