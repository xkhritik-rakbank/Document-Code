
var WD_SID;
function assignToArray(versionNo,versionComm)
{
    arrNo[arrNo.length]=versionNo;
    arrComment[arrComment.length]=decodeURIComponent(versionComm);
   
}
function createVersion()
{    
   // var url = "/webdesktop/faces/workitem/document/version/createversion.jsp?DocIndex="+DocId+"&RanId="+MakeUniqueNumber()+"&pid="+pid+"&wid="+wid;
    var url = sContextPath+"/components/workitem/document/version/createversion.app";
    url = appendUrlSession(url);
    var wFeatures ='scrollbars=yes,resizable=no,status=yes,left='+(window1Y+100)+',top='+(window1X+120)+',width='+(window1W-200)+',height='+(windowH-100); 
    var listParam=new Array();
    listParam.push(new Array("DocIndex",encode_ParamValue(DocId)));
    listParam.push(new Array("RanId",encode_ParamValue(MakeUniqueNumber())));
    listParam.push(new Array("pid",encode_ParamValue(pid)));
    listParam.push(new Array("wid",encode_ParamValue(wid)));
    listParam.push(new Array("taskid",encode_ParamValue(taskid)));
    listParam.push(new Array("DocName",encode_ParamValue(DocName)));
    listParam.push(new Array("ISIndex",encode_ParamValue(strISIndex)));
    listParam.push(new Array("DeleteFlag",encode_ParamValue(deleteFlag)));
        
     var win = openNewWindow(url,'CreateVersion',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
   // var win=window.open(url,'CreateVersion','scrollbars=yes,resizable=no,status=yes,left='+(window1Y+100)+',top='+(window1X+120)+',width='+(window1W-200)+',height='+(windowH-100));
    //  addwindow(winArray,win);
}
function changeComments()
{
    if (typeof parent.versionNo == "undefined" || parent.versionNo == "")
    {
            //alert(SELECT_DOC_VERSION_TO_CHANGE_COMMENTS);
            fieldValidator(null, SELECT_DOC_VERSION_TO_CHANGE_COMMENTS, "absolute", true);
            return false;
    }
        
    var url = sContextPath+"/components/workitem/document/version/changeversioncomments.app";
    url = appendUrlSession(url);
    var wFeatures ='scrollbars=yes,resizable=no,status=yes,left='+(window1Y+100)+',top='+(window1X+120)+',width='+(window1W-200)+',height='+(windowH-100);
    var listParam=new Array();
    listParam.push(new Array("DocIndex",encode_ParamValue(DocId)));
    listParam.push(new Array("VersionNo",encode_ParamValue(parent.versionNo)));
    listParam.push(new Array("VersionComment",encode_ParamValue(getComments(parent.versionNo))));
    listParam.push(new Array("RanId",encode_ParamValue(MakeUniqueNumber()))); 
    listParam.push(new Array("pid",encode_ParamValue(pid)));
    listParam.push(new Array("wid",encode_ParamValue(wid)));
    listParam.push(new Array("taskid",encode_ParamValue(taskid)));
    listParam.push(new Array("DocName",encode_ParamValue(DocName)));
    listParam.push(new Array("ISIndex",encode_ParamValue(strISIndex)));
    listParam.push(new Array("DeleteFlag",encode_ParamValue(deleteFlag)));
    
    var win = openNewWindow(url,'ViewComments',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    
    //var url = "/webdesktop/faces/workitem/document/version/changeversioncomments.jsp?DocIndex="+DocId+"&VersionNo="+parent.versionNo+"&VersionComment="+getComments(parent.versionNo)+"&RanId="+MakeUniqueNumber()+"&pid="+pid+"&wid="+wid;
    //var win=window.open(url,'ViewComments','scrollbars=yes,resizable=no,status=yes,left='+(window1Y+100)+',top='+(window1X+120)+',width='+(window1W-200)+',height='+(windowH-100));
    //  addwindow(winArray,win);
}

function getComments(versionNo)
{
    for (var i=0;i<arrNo.length;i++)
    {
        if(arrNo[i]==versionNo)
                break;
    }
    return arrComment[i];
}
function modify()
{
    var versionComment = Trim(document.forms['textForm']["textForm:VComment"].value);
    document.forms['textForm']["textForm:VComment"].value = versionComment;
    var i = 0;
    var len = versionComment.length;
    if(len > 255)
    {
            fieldValidator("textForm:VComment", LENGTH_EXCEEDED_IN_VERSION_COMMENT, "absolute", true);
            //alert(LENGTH_EXCEEDED_IN_VERSION_COMMENT);
            //document.forms['textForm']["textForm:VComment"].focus();
            return false;
    }
    var xbReq;
    if (window.XMLHttpRequest){
        xbReq = new XMLHttpRequest();
    } else if (window.ActiveXObject){
       xbReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
    var url = "/webdesktop/components/workitem/document/ajaxdocVersion.app";
    var wd_rid = getRequestToken(url);
    url+="?WD_RID="+wd_rid;
    url += '&Operation=CC&DocId='+docIndex+'&VersionComment='+encode_utf8(versionComment)+'&VersionNo='+versionNo+'&pid='+encode_utf8(pid)+'&wid='+wid+'&taskid='+taskid;
    url = appendUrlSession(url);
    if (xbReq != null) {
        xbReq.open("GET", url, false);
        xbReq.send(null);

        if (xbReq.status == 200 && xbReq.readyState == 4) {
            var response = xbReq.responseText;
            reloadversionlist();
        }
        else {
            if (xbReq.status == 598)
                customAlert(xbReq.responseText);
            else if (xbReq.status == 599) {
                //url = sContextPath+"/login/logout.jsp?"+"error=4020";
                url = sContextPath + "/error/errorpage.app?msgID=4020";
                url = appendUrlSession(url);
                //window.open(url,reqSession);

                var width = 320;
                var height = 160;
                var left = (window.screen.availWidth - width) / 2;
                var top = (window.screen.availHeight - height) / 2;

                if (window.showModalDialog) {
                    window.showModalDialog(url, '', "dialogWidth:" + width + "px;dialogHeight:" + height + "px;center:yes;dialogleft: " + left + "px;dialogtop: " + top + "px");
                }
            }
            else if (xbReq.status == 310)
            {
                window.location = "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";
            }
            else if (xbReq.status == 400)
                customAlert(INVALID_REQUEST_ERROR);
            else if (xbReq.status == 12029) {
                customAlert(ERROR_SERVER);
            }
            else
                customAlert(ERROR_DATA);
        }
    }
    
}
function loader2(versionNo)
{
    for (var i = 0; i < window.opener.arrNo.length; i++) {
        if (window.opener.arrNo[i] == versionNo) {
            if (window.opener.arrComment[i] == 'undefined') {
                document.forms['textForm']["textForm:VComment"].value = '';
                break;
            } else {
                document.forms['textForm']["textForm:VComment"].value = window.opener.arrComment[i];
                break;
            }

        }
    }

    document.forms['textForm']["textForm:VComment"].focus();
}
function setAsLatest()
{
    if (typeof parent.versionNo == "undefined" || parent.versionNo == "")
    {
        fieldValidator(null, SELECT_DOC_VERSION_FOR_LATEST, "absolute", true);
        //alert(SELECT_DOC_VERSION_FOR_LATEST);
        return false;
    }
    var xbReq;
    if (window.XMLHttpRequest){
        xbReq = new XMLHttpRequest();
    } else if (window.ActiveXObject){
       xbReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
    var url = "/webdesktop/components/workitem/document/ajaxdocVersion.app";
    var wd_rid = getRequestToken(url);
    url += "?WD_RID="+wd_rid;
    url += '&Operation=SL&DocId='+DocId+'&VersionNo='+encode_utf8(versionNo)+'&pid='+encode_utf8(pid)+'&wid='+wid+'&taskid='+taskid;
    url = appendUrlSession(url);
    if (xbReq != null) {
        xbReq.open("GET", url, false);
        xbReq.send(null);
        var response = xbReq.responseText;
    }
    var fromDocListVar = (typeof fromDocList == 'undefined')? 'N': fromDocList;
    var docWindow;
    docWindow = (fromDocListVar=='Y')?getWindowHandler(window.opener.opener.windowList,"tableGrid"):getWindowHandler(window.opener.windowList,"tableGrid");
    if(fromDocListVar == 'Y'){
        if((typeof window.opener != 'undefined') && (typeof window.opener.opener != 'undefined') && (typeof window.opener.opener.reloadapplet != 'undefined') && docWindow){
            window.opener.opener.reloadapplet(DocId, false, 'setAsDefault');  
        } else if(!docWindow && typeof window.opener.opener.refreshDocPanelWrapper!='undefined'){
            window.opener.opener.refreshDocPanelWrapper(false,''); 
        }
        if((typeof window.opener != 'undefined') && (typeof window.opener.refreshDocumentList != 'undefined')){
            window.opener.refreshDocumentList();
        }
    } else {
        if((typeof window.opener != 'undefined') && (typeof window.opener.reloadapplet != 'undefined') && docWindow){
           window.opener.reloadapplet(DocId, false, 'setAsDefault');            
        } else if(!docWindow && typeof window.opener.refreshDocPanelWrapper!='undefined'){
            window.opener.refreshDocPanelWrapper(false,''); 
        }
    }
    
    reloadversionlist1();
}
function createVersion1()
{
    var versionComment = Trim(document.forms["versionForm"]["versionForm:VComment"].value);
    document.forms["versionForm"]["versionForm:VComment"].value = versionComment;
    var i = 0;
    var len = versionComment.length;
    if(len > 255)
    {
        //alert(LENGTH_EXCEEDED_IN_VERSION_COMMENT);
        fieldValidator("versionForm:VComment", LENGTH_EXCEEDED_IN_VERSION_COMMENT, "absolute", true);
        document.forms["versionForm"]["versionForm:VComment"].focus();
        return false;
    }
    var xbReq;
    if (window.XMLHttpRequest){
        xbReq = new XMLHttpRequest();
    } else if (window.ActiveXObject){
       xbReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
    
   var  strURI	= "/webdesktop/components/workitem/document/version/ajaxdocVersion.app";
   var strRID= getRequestToken(strURI);
    var url = 'ajaxdocVersion.app?Operation=C&DocId='+docIndex+'&VersionComment='+encode_utf8(versionComment)+'&pid='+encode_utf8(pid)+'&wid='+wid+'&taskid='+taskid+'&WD_RID='+strRID;
    url = appendUrlSession(url);
    if (xbReq != null) {
        xbReq.open("GET", url, false);
        xbReq.send(null);
        var response = xbReq.responseText;
    }
    //opener.parent.location.reload();
    reloadversionlist();
    window.close();
}

function selectVersion(ref,versionNo)
{
    if(ref.checked)             //Ref BugId-61913
    parent.versionNo = versionNo;
    else
    parent.versionNo ="";
}

function reloadversionlist()
{
//    var temp = self.opener.location;
    var temp2 = self.opener.location.pathname;
    var RID = getRequestToken(temp2);
    temp2=temp2+"?WD_RID="+RID+"&WD_SID="+window.opener.WD_SID;
    
	if(typeof window.opener.fromDocList != "undefined"){
		temp2=temp2+"&fromDocList="+window.opener.fromDocList+"&DocId="+DocId+"&DocName="+encode_utf8(DocName)+"&ISIndex="+encode_utf8(strISIndex)+"&DeleteFlag="+DeleteFlag+"&pid="+encode_utf8(pid)+"&wid="+wid+"&taskid="+taskid;
	}
	else{
		temp2=temp2+"&DocId="+DocId+"&DocName="+encode_utf8(DocName)+"&ISIndex="+encode_utf8(strISIndex)+"&DeleteFlag="+DeleteFlag+"&pid="+encode_utf8(pid)+"&wid="+wid+"&taskid="+taskid;
	}
       
    self.opener.location = temp2;
}

function reloadversionlist1()
{
   var temp = self.parent.location.pathname;  
    var RID = getRequestToken(temp);
    temp=temp+"?WD_RID="+RID;
    temp=temp+"&fromDocList="+fromDocList+"&DocId="+DocId+"&DocName="+encode_utf8(DocName)+"&ISIndex="+encode_utf8(strISIndex)+"&DeleteFlag="+DeleteFlag+"&pid="+encode_utf8(pid)+"&wid="+wid+"&taskid="+taskid+"&WD_SID="+WD_SID;
    self.parent.location = temp;  
}
function downloadVersion(link,isindex,extension,docIndex,docName)
{    
    var strIsIndex=isindex;
    var ImgIndex = "";
    var VolIndex = "";
    if(strIsIndex.indexOf("#") == -1) {
    ImgIndex = strIsIndex;
    VolIndex = "1";
    } else {
        ImgIndex = strIsIndex.substring(0,strIsIndex.indexOf("#"));
        strIsIndex = strIsIndex.substring(strIsIndex.indexOf("#")+1,strIsIndex.length);

        if(strIsIndex.indexOf("#") != -1)
            VolIndex = strIsIndex.substring(0,strIsIndex.indexOf("#"));
        else
            VolIndex = strIsIndex;
    }
    
    var url = sContextPath+"/servlet/getdocument";
    url = appendUrlSession(url);
    url=url+"&WD_RID="+getRequestToken('/webdesktop/servlet/getdocument');
    var listParam=new Array();
    listParam.push(new Array("ImgIndex",encode_ParamValue(ImgIndex)));
    listParam.push(new Array("VolIndex",encode_ParamValue(VolIndex)));
    listParam.push(new Array("DocExt",encode_ParamValue(extension)));
    listParam.push(new Array("DocIndex",encode_ParamValue(docIndex)));    
    listParam.push(new Array("PageNo",encode_ParamValue("1")));
    listParam.push(new Array("pid",encode_utf8(pid)));    //Bug 62239 
    listParam.push(new Array("wid",encode_utf8(wid)));    //Bug 62239
    listParam.push(new Array("DownloadFlag",encode_ParamValue("Y")));
    listParam.push(new Array("DocumentName",encode_ParamValue(docName+'.'+extension)));
    if(typeof documentId!="undefined"&&documentId!="")
        listParam.push(new Array("MainDocId",encode_ParamValue(documentId)));//Bug 78727
    generatePostRequest(window,url,listParam);
    
   /* var url = "/webdesktop/servlet/getdocument?ImgIndex="+ImgIndex+"&VolIndex="+VolIndex+"&DocExt="+extension+"&DocIndex="+ docIndex+"&PageNo=1&DownloadFlag=Y&DocumentName="+encode_utf8(docName+'.'+extension);
    url = appendUrlSession(url);
    link.href = url;*/
}

//Ref BugId-61913
function deleteVersion()
{
   if (typeof parent.versionNo == "undefined" || parent.versionNo == "")
    {
        customAlert(SELECT_DOC_VERSION_TO_DELETE);
        return false;
    }
    var ans = confirm(CONFIRM_DOC_VERSION_DELETION);

    if (ans) {
        var xbReq;
        if (window.XMLHttpRequest) {
            xbReq = new XMLHttpRequest();
        } else if (window.ActiveXObject) {
            xbReq = new ActiveXObject("Microsoft.XMLHTTP");
        }
        var url = '/webdesktop/components/workitem/document/version/ajaxdocVersion.app';
        var wd_rid=getRequestToken(url);
        url += "?WD_RID="+wd_rid;
        url += '&Operation=DV&DocId=' + DocId + '&VersionNo=' + encode_utf8(versionNo) + '&pid=' + encode_utf8(pid) + '&wid=' + wid;
        url = appendUrlSession(url);
        if (xbReq != null) {
            xbReq.open("GET", url, false);
            xbReq.send(null);
            var response = xbReq.responseText;
        }
        if(response == "success")
          reloadversionlist1();
        else
          customAlert(response);  
    }
    else
        return false;
}
function openInDriveVersions(element,ISIndex,docExt,docIndex,docName){
    var windowW = 600;
    var windowH = 600;
    var left = (window.screen.width - windowW) / 2;
    var top = (window.screen.height - windowH) / 2;
    var url = '/webdesktop/components/workitem/document/openInDrive.app';
    var wFeatures = 'status=yes,resizable=no,scrollbars=yes,width=' + windowW + ',height=' + windowH + ',left=' + left + ',top=' + top + ',resizable=yes,scrollbars=yes';
    var listParam = new Array();
    listParam.push(new Array('Action', 1));
    listParam.push(new Array('ImgIndex', encode_ParamValue("")));
    listParam.push(new Array('VolIndex',encode_ParamValue("")));
    listParam.push(new Array('DocOrgName',encode_ParamValue("")));
    listParam.push(new Array('DocExt',encode_ParamValue(docExt)));
    listParam.push(new Array('DocIndex',encode_ParamValue(docIndex)));
    listParam.push(new Array('DocName',encode_ParamValue(docName)));
    listParam.push(new Array('ISIndex',encode_ParamValue(ISIndex)));
    window.opener.openNewWindow(url, 'openInDrive:'+pid, wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", listParam);
}