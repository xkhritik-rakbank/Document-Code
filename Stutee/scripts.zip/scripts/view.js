
function SelectTab(iTabIndex)
{
    var hidAction = '';
    if(iTabIndex=='1')
    {
        hidAction = 'q';
        document.getElementById("ViewTabs:q:hid_selectedqueue").value='1';
        document.getElementById("ViewTabs:q:hidProcessId").value='';
        document.getElementById("ViewTabs:q:hidProcessName").value=AllProcesses;
    }
    else if(iTabIndex=='2')
    {
        hidAction = 'p';
        document.getElementById("ViewTabs:p:hidQueueId").value='0';
        document.getElementById("ViewTabs:p:hidQueueName").value=AllQueues;
    }
    else if(iTabIndex=='3')
    {
        hidAction = 'u';
        document.getElementById("ViewTabs:u:hidProcessID").value='';
        document.getElementById("ViewTabs:u:hidProcessName").value=AllProcesses;

        document.getElementById("ViewTabs:u:hidWorkstepID").value='';
        document.getElementById("ViewTabs:u:hidWorkstepName").value=AllWorksteps;

        document.getElementById("ViewTabs:u:hidGroupID").value='';
        document.getElementById("ViewTabs:u:hidGroupName").value=AllGroups;
    }
    document.getElementById("hidAction").value=hidAction;
    
    try
    {
        document.getElementById("ViewTabs:SelTab").value=iTabIndex;
    }
    catch(e){}
    
	document.forms["ViewTabs"].submit();
}

var ScreenHeight=screen.height;
var ScreenWidth=screen.width;


//purpose : function is called when the header chkBox is selected to check all the check boxes
function SelectAllCheckBoxUserView(ref)
{
    var formid=ref.form.id;
    var tableid=formid+':'+'userLists';
    try 
    {
        var noofrows = document.getElementById(tableid).tBodies[0].rows.length;
        var flag=0;
        for (var i=0;i< noofrows ;i++)
        {
            
            var id=tableid+':'+i+':chkUser';
            document.getElementById(id).checked=ref.checked;
        }
        
        return '';
    }
    catch(e)
    {
        //alert(e);
        return "";
    }
}

function EnableDisableWorkstepButtonUserView()
{
    if(document.getElementById('userview:hidProcessID').value > 0 )
    {
        document.getElementById('userview:panelforuser:cmdPicklist_workstep').disabled=false;
    }
    else
    {
        document.getElementById('userview:panelforuser:cmdPicklist_workstep').disabled=true;
    }

    document.getElementById('userview:hidWorkstepID').value='';
    document.getElementById('userview:hidWorkstepName').value=document.getElementById('userview:hidInitialWorkstep').innerHTML;
    document.getElementById('userview:panelforuser:txtWorkstepName').value=document.getElementById('userview:hidInitialWorkstep').innerHTML;customAlert(document.getElementById('userview:txtWorkstepName').value);customAlert(document.getElementById('userview:hidInitialWorkstep').innerHTML)
}

function SetWorkAudit(ref,id,addurl)
{
    var url='/webdesktop/components/usermgmt/setworkaudit.app';
    url = appendUrlSession(url);

    var listParam=new Array();
    listParam=getSelected(ref);

    if(listParam.length==0)
    {
        notifierAbs('notifier', INVALID_SELECTION_MORE_USER, "absolute", true);    
        //alert(INVALID_SELECTION_MORE_USER);
        return ;
    }
    
    var WindowHeight= window7H+20;
    var WindowWidth=  window7W+50;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,"swa"+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}

function ViewWorkAudit(ref,addurl)
{
    url='/webdesktop/components/usermgmt/viewworkauditdetails.app';
    url = appendUrlSession(url);
    
    var listParam=new Array();
    listParam=getSelected(ref);

    if(listParam.length==0)
    {
        notifierAbs('notifier', INVALID_SELECTION_MORE_USER, "absolute", true);    
        //alert(INVALID_SELECTION_MORE_USER);
        return ;
    }


    var WindowHeight=window1H;
    var WindowWidth=window1W+100;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);


    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,'atq'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }
    catch(e)
    {}
}


function AddToQueue(ref,addurl)
{
    url='/webdesktop/components/usermgmt/addtoqueue.app';
    url = appendUrlSession(url);

    var listParam=new Array();
    listParam=getSelected(ref);

    if(listParam.length==0)
    {
        //alert(INVALID_SELECTION_MORE_USER);
        notifierAbs('notifier', INVALID_SELECTION_MORE_USER, "absolute", true);
        return ;
    }

    
    var WindowHeight= window7H+80;
    var WindowWidth=  window7W+120;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);


    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,'atq'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
    
}

function SetDiversions(ref,id,addurl)
{
    url='/webdesktop/components/usermgmt/setdiversion.app';
    url = appendUrlSession(url);
    
    var listParam=new Array();
    listParam=getSelected(ref);

    if(listParam.length==0)
    {
        notifierAbs('notifier', INVALID_SELECTION_MORE_USER, "absolute", true);    
        //alert(INVALID_SELECTION_MORE_USER);
        return ;
    }
    var WindowHeight= 420;
    var WindowWidth=  600;
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,'sdvr'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}

function getSelected(ref)
{
    var formid='userview';
    var tableid=formid+':'+'userLists';
    var userid="";
    var listParam=new Array();
    var username="";
     var first="";
    var last="";
    try {
        var noofrows = document.getElementById(tableid).tBodies[0].rows.length;
        var flag=0;
        for (var i=0;i< noofrows ;i++)
        {
            
            var id=tableid+':'+i+':chkUser';
            if(document.getElementById(id).checked)
            {
                if(flag!=0)
		{
                    userid+=",";
                    username+=",";            
                     first+=",";
                    last+=",";
		}
		userid+=document.getElementById(tableid+':'+i+':usrID').value;
                username+=document.getElementById(tableid+':'+i+':usrName').value;
                first+=document.getElementById(tableid+':'+i+':firstname').value;
                last+=document.getElementById(tableid+':'+i+':lastname').value;
                flag++;
            }                
        }
        
        if(flag==0)
            return listParam;
        listParam.push(new Array("Action",encode_ParamValue("1")));
        listParam.push(new Array("userids",encode_ParamValue(userid)));
        listParam.push(new Array("usernames",encode_ParamValue(username)));
        listParam.push(new Array("firstname",encode_ParamValue(first)));
        listParam.push(new Array("lastname",encode_ParamValue(last)));
        return listParam;
    }
    catch(e)
    {
        return listParam;
    }
}

function ShowSearchFromUserView(userName,from)              //bug id-3719
{
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    
    var priority = "-1";
    var procId="";
    var procName="";
    var actId="";
    var actName="";
    var userParam="";
    procId  = document.getElementById("userview:hidProcessID").value;   
    procName = document.getElementById("userview:hidProcessName").value;   
    
    actId  = document.getElementById("userview:hidWorkstepID").value;   
    actName = document.getElementById("userview:hidWorkstepName").value;
    if(from == 'F')
        userParam = "FixedAssignedToUser";
    else if(from == 'S')
        userParam = "SystemAssignedToUser";
    else if(from == 'P')
    {
        userParam = "AssignedToUser";
    }
    var Url="../search/searchfromviews.faces";

    Url = appendUrlSession(Url);

    var listParam=new Array();
    listParam.push(new Array("from",encode_ParamValue("Userview")));
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("ProcessId",encode_ParamValue(procId)));
    listParam.push(new Array("ProcessName",encode_ParamValue(procName)));
    listParam.push(new Array("Priority",encode_ParamValue(priority)));
    listParam.push(new Array("ActivityId",encode_ParamValue(actId)));
    listParam.push(new Array("ActivityName",encode_ParamValue(actName)));
    listParam.push(new Array(userParam,encode_ParamValue(userName)));

    if(from == 'P')
        {        
        listParam.push(new Array("state",encode_ParamValue("6")));
        listParam.push(new Array("ProcessWorkitemDate",encode_ParamValue("Y")));
        }
    

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(Url,'SearchFromViews'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    }catch(e){}
}
function OpenCustomURl(Url)
{

    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=window1H;
    var WindowWidth=window1W;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    var win = window.open(Url,'CustomWindow'+UniqueUserId,'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft);
    try
    {
        addWindows(win);
    }catch(e){}
    
    try{
        win.focus();
    } catch(e){}
    return false;
}