
var CollaborationStruct = {    
    SharedUserInfo : {},
    LockInfo : {},
    OwnerInfo: {}        
};

var collabSharedUsersJson = "";
var previousTimeStamp = '';
var glMessageContainer;
var check=0;

function initCollaborationStruct(){
    // Structure for storing currently shared users
    CollaborationStruct.SharedUserInfo = {
        UserList: []
        /*
        UserIndex: "",
        UserName: "",    
        EmailId: "",
        UserType: "",  // CO, CR 
        Status: ""     // SENT, PENDING, ACCEPTED, REJECTED
        */
    };

    // Initially, Owner has default lock
    CollaborationStruct.LockInfo = {
        UserIndex: "",    
        UserName: "",
        LockAction: "",  // REQUEST, RELEASE, GRANT, REVOKE
        LockType: "",         // Scope of lock
        Status: ""     // GRANTED
    };

    // Owner information
    CollaborationStruct.OwnerInfo = {
        UserIndex: "",        
        UserName: ""
    };
}

function initCollaboration(){
    initCollaborationStruct();    
    
    if(collaborationMode == "CR"){
        SharingMode = true;
        joinRoom();
    }
    
    initShare();
}

function initShare(){    
    if(bWIOpenedFrmWList && window.opener.parent.iosocket){        
        if(oldWDJason.WIViewMode == "R"){
            if(collaborationMode == "CR"){
                enableShareOption();
            }
        } else {
            enableShareOption();
        }
        
        if(collaborationMode == "CO"){                    

        } else if(collaborationMode == "CR"){
            
        }
    }
}

function joinRoom(){    
     addToCollabWindow();
     
     var messageContainer = {          
        FromUserIndex: userIndex,
        FromUserName: userName,
        MessageText : '',                        
        TargetComponentHandler : 'joinRoomCB',         
        RoomId : pid+"_"+wid,
        WindowKey: (pid+"_"+wid),
        AppType:'WINDOW',
        TimeStamp: new Date().getTime()
    }  

    window.opener.parent.joinRoom(JSON.stringify(messageContainer), true);
}

function joinRoomCB(message){
     var messageJSON = JSON.parse(message);
    
    var timeStamp = messageJSON.TimeStamp;
    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;    
    
    setOwnerInfo(ownerIndex,ownerName);
    setLockInfo(lockInfo.UserIndex, lockInfo.UserName, lockInfo.LockAction, lockInfo.LockType, lockInfo.Status);
    
    initReceiverRights();
    
    updateWiTitle();    
    
    if(wDeskLayout.WDeskType == 'F'){
        var wDeskInterfaces = wDeskLayout.WDeskFixedLayout.WDeskInterfaces;
        if(wDeskInterfaces.Left.Interfaces.length > 0){
            hideShowInterfaceTab(wDeskInterfaces.Left.Interfaces[0].Interface.DivId, dataJSON.CollabSelectedIntTab.Left);
        }

        if(wDeskInterfaces.Right.Interfaces.length > 0){
            hideShowInterfaceTab(wDeskInterfaces.Right.Interfaces[0].Interface.DivId, dataJSON.CollabSelectedIntTab.Right);
        }    
    }
   
    sendWiAcceptNotification();    
    
    addSharedUserCR();
}

function initReceiverRights(){
    if(SharingMode){
        disableLayout();
        enableShareOption();
    } else {
        enableLayout();
    }
}

function setOwnerInfo(userIndex, userName){
    CollaborationStruct.OwnerInfo.UserIndex = userIndex;
    CollaborationStruct.OwnerInfo.UserName = userName;
}

function setLockInfo(userIndex, userName, lockAction, lockType, status){
    CollaborationStruct.LockInfo.UserIndex = userIndex;
    CollaborationStruct.LockInfo.UserName = userName;
    CollaborationStruct.LockInfo.LockAction = lockAction;
    CollaborationStruct.LockInfo.LockType = lockType;
    CollaborationStruct.LockInfo.Status = status;
}

function sendWiAcceptNotification(){
    var messageContainer = {          
        FromUserIndex: userIndex,
        FromUserName: userName,
        MessageText : userName+' '+HAS_JOINED_WORKITEM+' '+pid,        
        TargetComponentHandler : 'wiAcceptNotificationCB', 
        Notify : 'Y',
        RoomId : pid+"_"+wid,                        
        WindowKey : pid+"_"+wid,                        
        AppType:'WINDOW',
        TimeStamp: new Date().getTime()
    }  
    
    window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);   
}

function wiAcceptNotificationCB(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;
    
    if(previousTimeStamp == timeStamp){
        return;
    }    
    previousTimeStamp = timeStamp;
    
    notificationBeeperBox(messageJSON);    
}

function onShareRejectCB(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;
    
    if(previousTimeStamp == timeStamp){
        return;
    }    
    previousTimeStamp = timeStamp;
    
    notificationBeeperBox(messageJSON);    
}

function addToCollabWindow(){   
    window.opener.parent.addToCollabWindowList(pid+"_"+wid, window);
}

function removeFromCollabWindow(){    
    window.opener.parent.removeFromCollabWindowList(pid+"_"+wid);
}

function shareWorkitemHandler(ref){
    var sharePicklistId = "CollabUserList";
    
    var sharePickListWindow = getPopupIFrameOpenerObj(sharePicklistId);    
    if(sharePickListWindow){        
       return;
    }
    
    var SharedUsersJson = JSON.stringify(collabSharedUsersJson);
    
//    var	url = sContextPath+'/components/workitem/collaboration/wdcollabuserpicklist.app?Action=1&Mode=SP&MultipleSelect=Y&CallBack=shareWICallBack&WD_SID='+WD_SID+'&SharedUsersJson='+SharedUsersJson;
//    url = appendUrlSession(url);
//    
//    var left =  findAbsPosX(ref);
//    var top =  findAbsPosY(ref)-2;
//    popupIFrameOpener(this, sharePicklistId, url, 235, 280, left, top, true, true, false, false, false, false);

    // Bug Id:43181 -> Workitem should not share to the itself.
    // SU => Share User
    ShowUserList(ref, "", "", "", "shareWICallBack", "N", "N", "N", '', '', "Y", "Y", "Y", "Y","SU",SharedUsersJson);

}

function shareWICallBack(jsonString){    
    userListInfoJSON = JSON.parse(jsonString);        
    
    if(userListInfoJSON.UserInfoList.length <1){
        return;
    }
    
    addToCollabWindow();    
    
    var messageContainer = {
        UserInfo : userListInfoJSON.UserInfoList,  		
        FromUserIndex : userIndex,
        FromUserName : userName,   
        TargetComponentDefId : '',        
        TargetComponentHandler : 'shareWICreateRoomCallback',           
        Application : '',  
        RoomId : (pid+"_"+wid),        
        WindowKey: (pid+"_"+wid),
        AppType :'WINDOW',
        TimeStamp: new Date().getTime(),
        Msg :[]
    }           
     
    window.opener.parent.createRoom(JSON.stringify(messageContainer), true);
}

function shareWICreateRoomCallback(message){    
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;
    
    if(previousTimeStamp == timeStamp){
        return;
    }    
    previousTimeStamp = timeStamp;    
    
    wdCollaborationHandler("share", null);
}

function unshareWi(from){
    if(typeof from == 'undefined'){
        from = "";
    }
    
    if(from == "ShareOption"){
        wdCollaborationHandler("unshareCO", null);        
    } else {    
        var roomId = (pid+"_"+wid);    
        var windowKey = (pid+"_"+wid);    
        var messageContainer = {        
            FromUserIndex: userIndex,
            MessageText : userName+' '+HAS_UNSHARED_WORKITEM+' '+pid,
            TargetComponentHandler: 'broadcastUnshareWi',
            RoomId : roomId,         
            Notify:'Y',
            WindowKey: windowKey,
            TimeStamp: new Date().getTime(),
            AppType:'WINDOW' 
        }

        window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);  

        window.opener.parent.leaveRoom(userIndex,roomId);

        SharingMode = false;    
        collabSharedUsersJson = "";
        collaborationMode = "CO";
        setLockInfo("", "","","","");        
        setOwnerInfo("","");
        removeFromCollabWindow();

        initOwnerRights();
        
        shareWiMenu();
        
        updateWiTitle();
    }
}

function broadcastUnshareWi(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;
    
    if(previousTimeStamp == timeStamp){
        return;
    }    
    previousTimeStamp = timeStamp;        
    
    wdCollaborationHandler("unshareCR", messageJSON);
}

/*
function unshareWiHandlerCR(messageJSON){
    var roomId = (pid+"_"+wid);    
    window.opener.parent.leaveRoom(userIndex,roomId);
    
    SharingMode = false;    
    collabSharedUsersJson = "";
    collaborationMode = "CO";
    setLockInfo("", "","","","");        
    setOwnerInfo("","");
    removeFromCollabWindow();
    
    initReceiverRights();
    
    shareWiMenu();    
    updateWiTitle();
    
    notificationBeeperBox(messageJSON);

    launchMessage(OWNER_UNSHARE_MESSAGE, false);
}*/

function unshareWiHandlerCO(){
    SharingMode = false;    
    collabSharedUsersJson = "";
    collaborationMode = "CO";
    setLockInfo("", "","","","");        
    setOwnerInfo("","");
    removeFromCollabWindow();
    
    initOwnerRights();
    bFetchModifiedFVB = true;
    hideShareWiMenu();//Bug 72670
    shareWiMenu();
    
    //render prev-next link
   
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : userName+' '+HAS_UNSHARED_WORKITEM+' '+pid,
        TargetComponentHandler: 'unshareWiHandler',        
        RoomId : roomId,         
        Notify:'Y',
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }
    glMessageContainer = messageContainer;
    if(!(wiproperty.formType=="NGFORM" && ngformproperty.type == "applet" && !bDefaultNGForm && !bAllDeviceForm)){
        broadcastLock(); 
        renderNavigation(oldWDJason.WICount);
        disableChat();
        closeChat();
        window.opener.parent.leaveRoom(userIndex,roomId);
    
    }
    else{
        
        var ngformIframe = document.getElementById("ngformIframe");
        ngformIframe.contentWindow.reqOption = "broadCastUnshareLock";
        ngformIframe.contentWindow.clickLink('cmdNgFormRefresh');
    }
    
    
}

function unshareWiHandler(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;
    
    if(previousTimeStamp == timeStamp){
        return;
    }    
    previousTimeStamp = timeStamp;        
    
    wdCollaborationHandler("unshareCR", messageJSON);
}

function unshareWiHandlerCR(messageJSON){
    var roomId = (pid+"_"+wid);    
    window.opener.parent.leaveRoom(userIndex,roomId);
    
    SharingMode = false;    
    collabSharedUsersJson = "";
    collaborationMode = "CO";
    setLockInfo("", "","","","");        
    setOwnerInfo("","");
    removeFromCollabWindow();
    
    initReceiverRights();
    hideShareWiMenu();//Bug 72670
    shareWiMenu();
    
    // reload workitem data
    updateWidata();
    bFetchModifiedFVB = true;
    // reload workitem interfaces
    RefreshWiInterfaces();    
    
    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
    
    disableChat();
    closeChat();
    
    notificationBeeperBox(messageJSON);

    launchMessage(OWNER_UNSHARE_MESSAGE, false);
}

function unshareReceiver(extra,receiverUserIndex, receiverUserName){
    var receiverInfo = {
        UserIndex: receiverUserIndex,
        UserName: receiverUserName
    };
    
    wdCollaborationHandler("unshareReceiverCO", receiverInfo);
}

function unshareReceiverHandlerCO(thisObj){    
    var collabSharedUsers = parseJSON('(' + decode_utf8(thisObj.req.getResponseHeader("CollabSharedUsersJSON")) + ')');
    var receiverInfo = thisObj.data;
    
    collabSharedUsersJson = collabSharedUsers;
    if(CollaborationStruct.LockInfo.UserIndex == receiverInfo.UserIndex){
        setLockInfo("", "","","",""); 
        hideShareWiMenu();//Bug 72670
        shareWiMenu();

        // reload workitem data
        updateWidata();

        // reload workitem interfaces
        RefreshWiInterfaces();    

        updateWiTitle();    
        // re-initialize menu items
        prepareWdeskDefaultMenu();
    }
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : receiverInfo.UserName+' '+HAS_LEFT_COLLABORATION_ON_WORKITEM+' '+pid,
        TargetComponentHandler: 'unshareReceiverHandler',
        CollabSharedUsersJson: collabSharedUsers,
        ReceiverInfo: receiverInfo,
        RoomId : roomId,         
        Notify:'Y',
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }

    window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);
}

function unshareReceiverHandler(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    if(CollaborationStruct.LockInfo.UserIndex == ""){
        if(messageJSON.ReceiverInfo.UserIndex == userIndex){
            wdCollaborationHandler("unshareReceiverCR", messageJSON);
        } else {
            collabSharedUsersJson = messageJSON.CollabSharedUsersJson;                        
            notificationBeeperBox(messageJSON);  
        }
    } else {
        if(messageJSON.ReceiverInfo.UserIndex == userIndex){            
            wdCollaborationHandler("unshareReceiverCR", messageJSON);            
        } else {
            collabSharedUsersJson = messageJSON.CollabSharedUsersJson;                        
            
            if(messageJSON.ReceiverInfo.UserIndex == CollaborationStruct.LockInfo.UserIndex){
                setLockInfo("", "","","","");
                hideShareWiMenu();//Bug 72670
                shareWiMenu();
                updateWiTitle();
            }
            
            notificationBeeperBox(messageJSON);  
        }
    }
    
}

function unshareReceiverHandlerCR(messageJSON){    
    SharingMode = false;    
    collabSharedUsersJson = "";
    collaborationMode = "CO";
    setLockInfo("", "","","","");        
    setOwnerInfo("","");
    removeFromCollabWindow();
    
    initReceiverRights();
    hideShareWiMenu();//Bug 72670
    shareWiMenu();
    
    // reload workitem data
    updateWidata();
    
    // reload workitem interfaces
    RefreshWiInterfaces();    
    
    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
    
    disableChat();
    closeChat();

    launchMessage(RECEIVER_UNSHARE_MESSAGE, false);
    
    var roomId = (pid+"_"+wid); 
    window.opener.parent.leaveRoom(userIndex,roomId);
}

function leaveSharing(from){
    if(typeof from == 'undefined'){
        from = "";
    }
    
    if(CollaborationStruct.LockInfo.UserIndex == userIndex){
        for_save("dummysave","collabForm");
    }
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : userName+' '+HAS_LEFT_COLLABORATION_ON_WORKITEM+' '+pid,
        TargetComponentHandler: 'broadcastLeaveSharingCO',
        RoomId : roomId,         
        Notify:'Y',
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }

    window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);
    
    
    SharingMode = false;    
    collabSharedUsersJson = "";
    collaborationMode = "CO";
    setLockInfo("", "","","","");        
    setOwnerInfo("","");
    removeFromCollabWindow();
    
    initReceiverRights();
    hideShareWiMenu();//Bug 72670
    shareWiMenu();
    
    updateWiTitle();    
    
    disableChat();
    closeChat();
    
    if(from == "ShareOption"){
        launchMessage(RECEIVER_UNSHARE_MESSAGE, false);
    } else {
        
    }
    
    window.opener.parent.leaveRoom(userIndex,roomId);
}

function broadcastLeaveSharingCO(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    if(CollaborationStruct.OwnerInfo.UserIndex == userIndex){
        wdCollaborationHandler("leaveSharingCO", messageJSON);
    }
}

function leaveSharingHandlerCO(thisObj){
    var messageJSON = thisObj.data;
    
    var collabSharedUsers = parseJSON('(' + decode_utf8(thisObj.req.getResponseHeader("CollabSharedUsersJSON")) + ')');    
    collabSharedUsersJson = collabSharedUsers;
    bFetchModifiedFVB = true;
    if(CollaborationStruct.LockInfo.UserIndex == messageJSON.FromUserIndex){
       setLockInfo("", "","","","");
    }
    hideShareWiMenu();//Bug 72670
    shareWiMenu();

    // reload workitem data
    updateWidata();

    // reload workitem interfaces
    RefreshWiInterfaces();    

    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
    
    notificationBeeperBox(messageJSON);
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex:  messageJSON.FromUserIndex,
        MessageText : messageJSON.MessageText,
        TargetComponentHandler: 'broadcastLeaveSharingCR',
        CollabSharedUsersJson: collabSharedUsersJson,
        RoomId : roomId,         
        Notify:'Y',
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }

    window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);
}

function broadcastLeaveSharingCR(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
    
    if(CollaborationStruct.LockInfo.UserIndex == messageJSON.FromUserIndex){
        setLockInfo("", "","","","");
    }
    hideShareWiMenu();    //Bug 72670
    shareWiMenu();

    updateWiTitle();        
    
    notificationBeeperBox(messageJSON);
}

/*
function leaveSharing(){
    wdCollaborationHandler("leaveSharingCR", null);
}

function broadcastLeaveSharingCR(thisObj){
    var collabSharedUsers = parseJSON('(' + thisObj.req.getResponseHeader("CollabSharedUsersJSON") + ')');
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : userName+' '+"has left collaboration on workitem"+' '+pid,
        TargetComponentHandler: 'leaveSharingHandler',
        CollabSharedUsersJson: collabSharedUsers,
        RoomId : roomId,         
        Notify:'Y',
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }

    window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);
    
    SharingMode = false;    
    collabSharedUsersJson = "";
    collaborationMode = "CO";
    setLockInfo("", "","","","");        
    setOwnerInfo("","");
    removeFromCollabWindow();
    
    initReceiverRights();
    
    shareWiMenu();
    
    // reload workitem data
    updateWidata();
    
    // reload workitem interfaces
    RefreshWiInterfaces();    
    
    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();

    launchMessage(RECEIVER_UNSHARE_MESSAGE, false);
    
    window.opener.parent.leaveRoom(userIndex,roomId);
}

function leaveSharingHandler(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    if(CollaborationStruct.LockInfo.UserIndex == messageJSON.FromUserIndex){
        if(CollaborationStruct.OwnerInfo.UserIndex == userIndex){            
            wdCollaborationHandler("leaveSharingCO", messageJSON);    
        } else {
            setLockInfo("", "","","","");
            collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
            
            shareWiMenu();
            
            updateWiTitle(true);        
            
            notificationBeeperBox(messageJSON);
        }        
    } else {        
        collabSharedUsersJson = messageJSON.CollabSharedUsersJson;        
        
        shareWiMenu();
                
        updateWiTitle(true);    
        
        notificationBeeperBox(messageJSON);
    }
}

function leaveSharingHandlerCO(messageJSON){
    collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
    
    setLockInfo("", "","","","");
    
    shareWiMenu();

    // reload workitem data
    updateWidata();

    // reload workitem interfaces
    RefreshWiInterfaces();    

    updateWiTitle(true);    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
    
    notificationBeeperBox(messageJSON);
}
*/
var bLaunchMessage = false;
function launchMessage(message, bError){
    if(typeof message == 'undefined'){
        message = '';
    }
    
    if(typeof bError == 'undefined'){
        bError = false;
    }
    
    var Url = sContextPath+'/generic/launchmessage.app?CallBack=launchMessageHandler&Target=W&CloseButton=false&MessageType=A&Message='+message+'&Error='+bError+'&WD_SID='+WD_SID;     
    window.parent.popupIFrameOpenerWrapper(this, "unshareMessage", Url, 375, 130, WindowLeft, WindowTop, false, true, false, true, true);
    
    bLaunchMessage = true;
}

function launchMessageHandler(type){
    bLaunchMessage = false;
    
    if((typeof type != 'undefined') ){
        if(type == "ReadOnly"){
            bEscapeSave = true;
        }
    }
}

function wdCollaborationHandler(operation, data)
{   
    var qString = "";
    var reqObj = null;    
    if(operation=="share"){       
        qString = "Action=1&Operation=share&OwnerUserIndex="+userIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
        //reqObj.CollaborationLockType = "Grant"; 
    } else if(operation=="approveLockRequest"){       
        qString = "Action=1&Operation=approveLockRequest&OwnerUserIndex="+userIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&ReceiverUserIndex="+data.params[2]+"&ReceiverUserName="+encode_utf8(data.params[2])+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="requestLock"){       
        qString = "Action=1&Operation=requestLock&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="releaseLockCR"){       
        qString = "Action=1&Operation=releaseLockCR&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="releaseLockCO"){       
        qString = "Action=1&Operation=releaseLockCO&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="revokeLockCO"){       
        qString = "Action=1&Operation=revokeLockCO&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&ReceiverUserIndex="+CollaborationStruct.LockInfo.UserIndex+"&ReceiverUserName="+encode_utf8(CollaborationStruct.LockInfo.UserName)+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="revokeLockCR"){       
        qString = "Action=1&Operation=revokeLockCR&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="unshareCO"){       
        qString = "Action=1&Operation=unshareCO&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="unshareCR"){       
        qString = "Action=1&Operation=unshareCR&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="addSharedUser"){       
        qString = "Action=1&Operation=addSharedUser&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&ReceiverUserIndex="+userIndex+"&ReceiverUserName="+encode_utf8(userName)+"&OwnerUserName="+encode_utf8(CollaborationStruct.OwnerInfo.UserName)+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="grantLockCO"){       
        qString = "Action=1&Operation=grantLockCO&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&ReceiverUserIndex="+data.UserIndex+"&ReceiverUserName="+encode_utf8(data.UserName)+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="grantLockCR"){       
        qString = "Action=1&Operation=grantLockCR&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="leaveSharingCR"){ 
        qString = "Action=1&Operation=leaveSharingCR&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;           
    } else if(operation=="leaveSharingCO"){       
        qString = "Action=1&Operation=leaveSharingCO&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&ReceiverUserIndex="+data.FromUserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="unshareReceiverCO"){       
        qString = "Action=1&Operation=unshareReceiverCO&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&ReceiverUserIndex="+data.UserIndex+"&ReceiverUserName="+encode_utf8(data.UserName)+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    } else if(operation=="unshareReceiverCR"){       
        qString = "Action=1&Operation=unshareReceiverCR&OwnerUserIndex="+CollaborationStruct.OwnerInfo.UserIndex+"&pid="+encode_utf8(pid)+"&wid="+wid+"&WD_SID="+WD_SID;
        reqObj = ContentLoaderWrapper("/webdesktop/components/workitem/collaboration/wdcollabhandler.app", wdcollabhandlerCB, null, "POST",qString, true);            
        reqObj.data = data;    
        reqObj.Operation = operation;    
    }    
}

function wdcollabhandlerCB(){
    if(this.req.getResponseHeader("CallStatus") == 'success'){        
        if(this.Operation == "share"){  
            SharingMode = true;
            
            setOwnerInfo(userIndex, userName);   
            
            if(wDeskLayout.WDeskType == 'E'){
               //show form broadcast link
               showHideFormLink();
            } else {
                // show interface tab menu
                var selectedInterfaceTab = getSelectedInterfaceTab(); 
                hideShowInterfaceTabMenu('', selectedInterfaceTab.CollabSelectedIntTab.Left);
                hideShowInterfaceTabMenu('', selectedInterfaceTab.CollabSelectedIntTab.Right); 
            }
             
             // reload workitem data
            updateWidata();
            // re-initialize menu items
            prepareWdeskDefaultMenu();

            updateWiTitle();
            
            initOwnerRights();          
            
            var roomId = (pid+"_"+wid);    
            var windowKey = (pid+"_"+wid);
            var messageContainer = {
                UserInfo : userListInfoJSON.UserInfoList,        
                FromUserIndex: userIndex,
                MessageText : userName+' '+HAS_SHAERED_WORKITEM+' '+pid,
                Action : [{
                    "ActionLabel":"Ok",
                    "ActionHandler" : "onShareOpenWiWrapperCR",
                    "ActionParams" : [pid,wid,userIndex,userName, CollaborationStruct.LockInfo]
                },{
                    "ActionLabel":"Cancel",
                    "ActionHandler" : "onShareReject",
                    "ActionParams" : [pid,wid,windowKey]            
                }],                
                RoomId : roomId,            
                WindowKey: windowKey,
                TimeStamp: new Date().getTime(),
                AppType:'OAP_CLIENT' 
            }
            
            window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);   
        } else if(this.Operation == "approveLockRequest"){             
            approveLockRequestHandlerCO(this);                    
        } else if(this.Operation == "requestLock"){             
            requestLockHandlerCR(this.data);                    
        } else if(this.Operation == "releaseLockCR"){             
            releaseLockHandlerCR(this);                    
        } else if(this.Operation == "releaseLockCO"){             
            releaseLockHandlerCO(this.data);                    
        } else if(this.Operation == "revokeLockCO"){             
            revokeLockHandlerCO(this);                    
        } else if(this.Operation == "revokeLockCR"){             
            revokeLockHandlerCR(this);                    
        } else if(this.Operation == "unshareCO"){             
            unshareWiHandlerCO();                    
        } else if(this.Operation == "unshareCR"){             
            unshareWiHandlerCR(this.data);                    
        } else if(this.Operation == "addSharedUser"){             
            addSharedUserCRHandler(this);                    
        } else if(this.Operation == "grantLockCO"){             
            broadcastGrantLockCO(this);                    
        } else if(this.Operation == "grantLockCR"){             
            broadcastGrantLockCR(this.data);                    
        } else if(this.Operation == "leaveSharingCR"){             
            broadcastLeaveSharingCR(this);
        } else if(this.Operation == "leaveSharingCO"){             
            //leaveSharingHandlerCO(this.data);
            leaveSharingHandlerCO(this);
        } else if(this.Operation == "unshareReceiverCO"){             
            unshareReceiverHandlerCO(this);
        } else if(this.Operation == "unshareReceiverCR"){             
            unshareReceiverHandlerCR(this.data);
        }
    }
}



function addSharedUserCR(){    
    wdCollaborationHandler("addSharedUser", null);    
}

function addSharedUserCRHandler(thisObj){
    collabSharedUsersJson = parseJSON('(' + decode_utf8(thisObj.req.getResponseHeader("CollabSharedUsersJSON")) + ')');
    enableChat();
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);
    var messageContainer = {
        FromUserIndex: userIndex,        
        TargetComponentHandler: 'broadcastSharedUsers',
        CollabSharedUsersJson: collabSharedUsersJson,
        RoomId : roomId,            
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW'
    }
    
    window.opener.parent.broadcast(JSON.stringify(messageContainer), true);        
}

function broadcastSharedUsers(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
    
    shareWiMenu();
}

function onShareOpenWiWrapperCO(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    //addSharedUser(messageJSON);
           
    var selectedInterfaceTabs = getSelectedInterfaceTab();    

    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);
    var messageContainer = {
        FromUserIndex: userIndex,
        UserInfo : [{UserIndex: messageJSON.FromUserIndex, UserName: messageJSON.FromUserName}],
        TargetComponentHandler: 'onShareOpenWi',        
        params:[pid,wid,userIndex,userName,CollaborationStruct.LockInfo, selectedInterfaceTabs],
        RoomId : roomId,            
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'OAP_CLIENT'
    }
    
    window.opener.parent.BroadCastToUsers(JSON.stringify(messageContainer), true);   
}

function updateWidata(){
    var wdJason = getWiData(pid, wid,"","");    
    reinitWDVariables(wdJason);
    setOldWDJason();                    
}

function initOwnerRights(){
    enableChat();
    
    disablePrevNext();   
    
    if(SharingMode){
        disableLayout();
        enableShareOption();
    } else {
        enableLayout();
    }   
}

function enableShareOption(){
    if((taskid==undefined || taskid=='') && typeof IsHideShareOption!='undefined' && IsHideShareOption!='Y'){ // hiding share option in case of task
        if (bRespWdesk == true) {
            if(typeof enableLinkInMainHeader!="undefined" && enableLinkInMainHeader!=null && enableLinkInMainHeader=='Y'){
            } else {
                removeCSS(document.getElementById("wdesk:shareOption"), "dn");
                document.getElementById("shareSpan").style.display = "block" ;
                addCSS(document.getElementById("wdesk:shareOption"), "db");
            }

        } else {
            document.getElementById("wdesk:shareOption").style.display = "block";
            document.getElementById("wdesk:shareOptionSeparator").style.display = "block";
        }
    }
}

function disableShareOption(){
    if (bRespWdesk == true) {
        if(typeof enableLinkInMainHeader!="undefined" && enableLinkInMainHeader!=null && enableLinkInMainHeader=='Y'){
            
        } else {
            removeCSS(document.getElementById("wdesk:shareOption"), "db");
            document.getElementById("shareSpan").style.display="none";
            addCSS(document.getElementById("wdesk:shareOption"), "dn");
        }
            
    } else {
        document.getElementById("wdesk:shareOption").style.display = "none";
        document.getElementById("wdesk:shareOptionSeparator").style.display = "none";
    }
    
}

function disableLayout(){   //Bug 66049 starts
    if (bRespWdesk) {
        var editSpan= document.getElementById("layoutSpan");
        var editRef = document.getElementById("wdesk:editLayoutlbl");
        if(editSpan!=null &&  editRef!=null){
            removeCSS(editSpan, "db");
            removeCSS(editRef, "db");
            addCSS(editSpan, "dn");
            addCSS(editRef, "dn");
        }
    } else {
        var editRef = document.getElementById("wdesk:editLayoutlbl");
        var navSepRef = document.getElementById("wdesk:navSep");
        if (editRef != null && navSepRef != null) {   //Bug 66049 ends
            document.getElementById("wdesk:editLayoutlbl").style.display = "none";
            document.getElementById("wdesk:navSep").style.display = "none";
        }
    }
    
}

function enableLayout(){ //Bug 66049 starts
    if (bRespWdesk) {
        var editSpan= document.getElementById("layoutSpan");
        var editRef = document.getElementById("wdesk:editLayoutlbl");
        if(editSpan!=null &&  editRef!=null){
            removeCSS(editRef, "dn");
            editSpan.style.display="block";
            addCSS(editRef, "db");
        }
    } else {
        var editRef = document.getElementById("wdesk:editLayoutlbl");
        var navSepRef = document.getElementById("wdesk:navSep");
        if (editRef != null && navSepRef != null) {   //Bug 66049 ends
            document.getElementById("wdesk:editLayoutlbl").style.display = "block";
            document.getElementById("wdesk:navSep").style.display = "block";
        }
    }
    
}

function disablePrevNext(){
    if(document.getElementById("wdesk:PrevLink")!=null){
        document.getElementById("wdesk:PrevLink").style.display = "none";
    }                        
    if(document.getElementById("wdesk:PrevSep") != null){
        document.getElementById("wdesk:PrevSep").style.display = "none";
    }
    if(document.getElementById("wdesk:navSeparator")!=null){
        document.getElementById("wdesk:navSeparator").style.display = "none";
    }
    
    if(document.getElementById("wdesk:NextSep") != null){
        document.getElementById("wdesk:NextSep").style.display = "none";
    }
    if(document.getElementById("wdesk:NextLink")!=null){
        document.getElementById("wdesk:NextLink").style.display = "none";
    }
}

var emitterUserInfoList = [];

function broadcastEvent(data,targetHandlerMethod){
    var messageContainer = {
        UserInfo : emitterUserInfoList,
        FromUserIndex : userIndex,
        FromUserName : userName,   
        TargetComponentHandler : targetHandlerMethod,        
        RoomId : (pid+"_"+wid),
        WindowKey: (pid+"_"+wid),
        SaveConversation : "Y",
        AppType:'WINDOW' ,
        TimeStamp: new Date().getTime(),
        Msg : data
    }

    window.opener.parent.broadcast(JSON.stringify(messageContainer), true);
}

function updateWiTitle(){
    var titleObj = document.getElementById("wdesk:title");
    var title = "";
     if(titleObj){
        title = stractivityName+" : "+pid;
        
        if(SharingMode){
            title += " "+LEFT_BRACKET+SHARED;
        }
        
        if(oldWDJason.WIViewMode=="R"){
            if(SharingMode){
                 title += ", "+READONLY_LABEL;
                 if(CollaborationStruct.LockInfo.UserName != ""){
                    title += ", "+LOCKED_BY+": "+CollaborationStruct.LockInfo.UserName+RIGHT_BRACKET;
                 } else {
                    title += RIGHT_BRACKET ;
                 }
            } else {
                title += " "+LEFT_BRACKET+READONLY_LABEL+RIGHT_BRACKET;
            }
        } else {
            if(SharingMode){
                if(CollaborationStruct.LockInfo.UserName != ""){
                    title += ", "+LOCKED_BY+": "+CollaborationStruct.LockInfo.UserName+RIGHT_BRACKET;
                } else {
                    title += RIGHT_BRACKET ;
                }
            }
        }
        
        titleObj.innerHTML = encode_ParamValue(title);
        if(document.title != undefined){
            document.title = title;
        }
    }
}

function shareWiMenu(event){
    var menuContent = "";
    
    
    if(collaborationMode == "CO"){
        //menuContent += "<td nowrap>";
//            if(!SharingMode){
            menuContent += "<div title='"+CLICK_TO_SHARE_WORKITEM+"' onmousedown='shareWorkitemHandler(this);hideShareWiMenu()'>"+SHARE+"</div>";//Bug 72671
//            }//menuContent += "</td>";       
        
        if(SharingMode){
            //menuContent += "<td nowrap>";
                menuContent += "<div title='"+CLICK_TO_UNSHARE_WORKITEM+"' onmousedown='unshareWi(\"ShareOption\");hideShareWiMenu()'>"+UNSHARE+"</div>";//Bug 72671
            //menuContent += "</td>";  
            
            if((collabSharedUsersJson != "") && (collabSharedUsersJson.CollabSharedUsers.length >0)){
                if(CollaborationStruct.LockInfo.UserIndex == ""){
                    //menuContent += "<td nowrap>";
                        menuContent += "<div title='"+CLICK_TO_GRANT_LOCK+"' onmousedown='grantLock(this);hideShareWiMenu()'>"+GRANT_LOCK+"</div>";//Bug 72671
                    //menuContent += "</td>";    
                } else {        
                    //menuContent += "<td nowrap>";
                        menuContent += "<div title='"+CLICK_TO_REVOKE_LOCK+"' onmousedown='revokeLock();hideShareWiMenu()'>"+REVOKE_LOCK+"</div>";//Bug 72671
                    //menuContent += "</td>";     
                }
            }
        }
    }
    
    if(collaborationMode == "CR"){
        if(SharingMode){
            //menuContent += "<td nowrap>";
                menuContent += "<div title='"+CLICK_TO_LEAVE_SHARING+"' onmousedown='leaveSharing(\"ShareOption\");hideShareWiMenu()'>"+LEAVE_SHARING+"</div>";//Bug 72671
            //menuContent += "</td>";                    
        
            if(CollaborationStruct.LockInfo.UserIndex == ""){
                //menuContent += "<td nowrap>";
                    menuContent += "<div title='"+CLICK_TO_REQUEST_LOCK+"' onmousedown='requestLock();hideShareWiMenu()'>"+REQUEST_LOCK+"</div>";//Bug 72671
                //menuContent += "</td>";
            } else if(CollaborationStruct.LockInfo.UserIndex == userIndex){
                //menuContent += "<td nowrap>";
                    menuContent += "<div title='"+CLICK_TO_RELEASE_LOCK+"' onmousedown='releaseLock();hideShareWiMenu()'>"+RELEASE_LOCK+"</div>";//Bug 72671
                //menuContent += "</td>";
            }
        }
    }
    menuContent+='<a style="width:0px;height:0px" id="wdsubmenuproxy" onblur="hideShareWiMenu();shareWiMenu(event)" href="about:blank"></a>';//Bug 72671 Bug 75323
    menuContent += "";
    menuobj.innerHTML = encode_ParamValue(menuContent);
     var widthforarabic = window.innerWidth
|| document.documentElement.clientWidth
|| document.body.clientWidth;
    var wdsubmenu = document.getElementById("wdsubmenu");
    if((menuContent.length>0) && wdsubmenu){
        event = event || window.event|| Event;
        if(event!=undefined){//Bug 75323
            var source = event.target || event.srcElement || EventSource;
            var childs = wdsubmenu.getElementsByTagName("div");
            if(childs){
                wdsubmenu.style.display = "block";
                if(childs.length > 10){
                    var childsHeight = childs[0].clientHeight * 10;
                    wdsubmenu.style.height = childsHeight - 10 + "px";
                } else {
                    wdsubmenu.style.height = "";
                }
            }
        
            if(strLocale=='ar-SA' || strLocale=='ar'){
                if(bRespWdesk){
                    wdsubmenu.style.right =(findAbsPosX(source)- getRealDimension(document.getElementById("MoreOptDiv")).Width -75) + "px";
                    wdsubmenu.style.top =(source.offsetTop + getRealDimension(document.getElementById("wdesk:placeHolder").Height)) + "px";
                }   else {
                    wdsubmenu.style.right = widthforarabic-70-findAbsPosX(source) + "px";
                }
                

            }
            else{
                if(bRespWdesk){
                    wdsubmenu.style.left =(findAbsPosX(source) - getRealDimension(document.getElementById("MoreOptDiv")).Width - 75) + "px";
                    wdsubmenu.style.top =(source.offsetTop + getRealDimension(document.getElementById("wdesk:placeHolder")).Height) + "px";
                }   else {
                    wdsubmenu.style.left = findAbsPosX(source) + "px"; 
                }
            }
       
        var viewport = isElementInViewport(wdsubmenu);
        if(!viewport.IsInHView){
             if(strLocale=='ar-SA' || strLocale=='ar'){
          wdsubmenu.style.right = widthforarabic-70-findAbsPosX(source) - wdsubmenu.clientWidth + source.clientWidth + 10 + "px";    
    }
    else{
         wdsubmenu.style.left = findAbsPosX(source) - wdsubmenu.clientWidth + source.clientWidth + 10 + "px";    
    }
        }              
        }
        if(check == 1) {
                wdsubmenu.style.display = "none";
                check = 0;
            }
    }
    //Bug 72671 Start
    var wdsubmenuproxy = document.getElementById("wdsubmenuproxy");
    if(wdsubmenuproxy){
        wdsubmenuproxy.focus();
    }
    ////Bug 72671 Ends
}

function hideShareWiMenu(){
    check = 1;
}

/* Chat Management */

function enableChat(){
    if (bRespWdesk == true) {
        removeCSS(document.getElementById("wdesk:chatLink"),"dn");
        document.getElementById("chatSpan").style.display="block";
        addCSS(document.getElementById("wdesk:chatLink"), "db");
    } else {
        document.getElementById("wdesk:chatLink").style.display = "block";
        document.getElementById("wdesk:chatLinkSeparator").style.display = "block";
    }
        
}

function disableChat(){
    if (bRespWdesk == true) {
        removeCSS(document.getElementById("wdesk:chatLink"),"db");
        document.getElementById("chatSpan").style.display="none";
        addCSS(document.getElementById("wdesk:chatLink"), "dn");
    } else {
        document.getElementById("wdesk:chatLink").style.display = "none";
        document.getElementById("wdesk:chatLinkSeparator").style.display = "none";
    }
    
}

function openChat(ref, data){
    var roomId = (pid+"_"+wid); 
    var windowKey = (pid+"_"+wid);   
    var chatTitle = (pid+"_"+wid);   
        
    if((typeof data == 'undefined') || (data == null)){
        data = "{}";
    }
    if(typeof ref == 'undefined'){
        ref = null;
    }
        
    var left = 0;
    var top = 0;
    var height = 307;
    
    if(ref) {
        left =  findAbsPosX(ref);
        top =  findAbsPosY(ref)-2;
    } else {  
        left = 10;
        top = document.documentElement.clientHeight-height-30;
    }
    
    var iFrame = document.getElementById("popupIFrame_"+roomId);
    
    if(iFrame == null) {
        var Url = "/webdesktop/chat/chatapp.app?data="+encode_utf8(data)+"&AppType=WINDOW&WindowKey="+windowKey+"&UserIndex="+userIndex+"&UserName="+userName+"&ChatTitle="+chatTitle+"&RoomId="+roomId+"&WD_SID="+WD_SID;           
        iFrame = popupIFrameOpenerWrapper(this,roomId,Url,300,height, left,top,true,true,true,false);
        try{
            iFrame.style.position = "fixed";
        }catch(e){}
    }
}

function closeChat(){
    var roomId = (pid+"_"+wid);  
    removeIFramePopup(roomId);  
}

function broadcastMessage(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;    
    var roomId = (pid+"_"+wid);
    var chatIframeObj =  getPopupIFrameOpenerObj(roomId);
    
    if(chatIframeObj){
       var chatWindow = chatIframeObj.contentWindow;
       chatWindow.fedContent(message);
    } else {
        openChat(null, message);
    }
}

/* Chat Management */


/* Lock Management */

function requestLock(){
     if((CollaborationStruct.LockInfo.UserIndex != "") && (CollaborationStruct.LockInfo.UserIndex != userIndex)){
        var message = LOCK_ON_WORKITEM+" " + pid +" "+ALREADY_GRANTED_TO+" " +CollaborationStruct.LockInfo.UserName;
        customAlert(message);        
        return;
    }
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : userName+' '+REQUESTS_LOCK_ON_WORKITEM+' '+pid,
        TargetComponentHandler: 'requestLockHandler',
        params:[pid,wid,userIndex,userName],
        RoomId : roomId,    
        Notify: 'Y',
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }

    window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);   
}

function requestLockHandler(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    if(CollaborationStruct.OwnerInfo.UserIndex == userIndex){
        requestLockHandlerCO(messageJSON);
    } else {        
        notificationBeeperBox(messageJSON);        
    }
}

function requestLockHandlerCO(messageJSON){
    var actionArray = [{
        "ActionLabel":"Grant",
        "ActionHandler" : "requestLockAcceptHandler",
        "ActionParams" : [messageJSON.params[0],messageJSON.params[1],messageJSON.params[2],messageJSON.params[3]]
    },{
        "ActionLabel":"Deny",
        "ActionHandler" : "requestLockRejectHandler",
        "ActionParams" : [messageJSON.params[0],messageJSON.params[1]]            
    }];
    
    notificationBeeperBox(messageJSON,actionArray);
}

function requestLockAcceptHandler(message){
    var messageJSON = JSON.parse(message);    
    wdCollaborationHandler("approveLockRequest", messageJSON);    
}

function approveLockRequestHandlerCO(thisObj){    
    var collabSharedUsers = parseJSON('(' + decode_utf8(thisObj.req.getResponseHeader("CollabSharedUsersJSON")) + ')');
    
    collabSharedUsersJson = collabSharedUsers;
    
    setLockInfo(thisObj.data.params[2], thisObj.data.params[3],"REQUEST","","GRANTED");
    hideShareWiMenu();      //Bug 69080
    shareWiMenu();
    
    
    bFetchModifiedFVB = true;
    
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : userName+' '+HAS_GRANTED_LOCK_ON_WORKITEM+' '+pid +" "+MSG_TO+" "+thisObj.data.params[3],
        TargetComponentHandler: 'approveLockRequestHandlerCR',        
        CollabSharedUsersJson: collabSharedUsers,
        LockInfo: CollaborationStruct.LockInfo,
        Notify: 'Y',
        RoomId : roomId,                    
        WindowKey: windowKey,        
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }
    glMessageContainer = messageContainer;
    if(!(SharingMode && wiproperty.formType=="NGFORM" && ngformproperty.type == "applet" && !bDefaultNGForm && !bAllDeviceForm)){
        broadcastLock(); 
    }
    else{
        var ngformIframe = document.getElementById("ngformIframe");
        ngformIframe.contentWindow.reqOption = "broadCastLock";
        ngformIframe.contentWindow.clickLink('cmdNgFormRefresh');
    }
}

function approveLockRequestHandlerCR(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    if(messageJSON.LockInfo.UserIndex == userIndex){
        wdCollaborationHandler("requestLock", messageJSON);    
    } else {
        collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
        setLockInfo(messageJSON.LockInfo.UserIndex, messageJSON.LockInfo.UserName, "REQUEST", "", "GRANTED");
        hideShareWiMenu();//Bug 72670
        shareWiMenu();
        updateWiTitle();    
        
        notificationBeeperBox(messageJSON);   
    }
}

function requestLockHandlerCR(messageJSON){
    collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
    
    setLockInfo(userIndex, userName, "RELEASE", "", "GRANTED");
    hideShareWiMenu();//Bug 72670
    shareWiMenu();
    bFetchModifiedFVB = true;
    // reload workitem data
    updateWidata();    
    
    // Reload workitem interfaces
    RefreshWiInterfaces(); 
    
    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
    enableShareOption();
    
    notificationBeeperBox(messageJSON);    
}

function requestLockRejectHandler(){
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : userName+' '+HAS_DENY_LOCK_ON_WORKITEM+' '+pid,
        TargetComponentHandler: 'requestLockRejectHandlerCR',        
        Notify: 'Y',
        RoomId : roomId,            
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }

    window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);   
}

function requestLockRejectHandlerCR(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    notificationBeeperBox(messageJSON);    
}

function releaseLock(){
    wdCollaborationHandler("releaseLockCR", null);      
}

function releaseLockHandlerCR(thisObj){
    var collabSharedUsers = parseJSON('(' + decode_utf8(thisObj.req.getResponseHeader("CollabSharedUsersJSON")) + ')');
    
    collabSharedUsersJson = collabSharedUsers;
    bFetchModifiedFVB = true;
    setLockInfo("", "", "REQUEST", "", "");
    hideShareWiMenu();//Bug 72670
    shareWiMenu();
       
    
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : userName+' '+RELEASES_LOCK_ON_WORKITEM+' '+pid,
        TargetComponentHandler: 'releaseLockHandler',
        CollabSharedUsersJson: collabSharedUsersJson,
        params:[pid,wid,userIndex,userName],
        RoomId : roomId,         
        Notify:'Y',
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }
    glMessageContainer = messageContainer;

    if(!(SharingMode && wiproperty.formType=="NGFORM" && ngformproperty.type == "applet" && !bDefaultNGForm && !bAllDeviceForm)){
        broadcastLock(); 
    }
    else{
        var ngformIframe = document.getElementById("ngformIframe");
        ngformIframe.contentWindow.reqOption = "broadCastLock";
        ngformIframe.contentWindow.clickLink('cmdNgFormRefresh');
    }
}

function releaseLockHandler(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    if(CollaborationStruct.OwnerInfo.UserIndex == userIndex){
        wdCollaborationHandler("releaseLockCO", messageJSON);    
    } else {
        collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
        setLockInfo("", "", "", "", "");
        hideShareWiMenu();//Bug 72670
        shareWiMenu();    
        
        // reload workitem data
        //updateWidata();    

        // Reload workitem interfaces
        //RefreshWiInterfaces(); 

        updateWiTitle();    
        // re-initialize menu items
        //prepareWdeskDefaultMenu();
        enableShareOption();
        notificationBeeperBox(messageJSON);   
    }
}

function releaseLockHandlerCO(messageJSON){
    collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
    
    setLockInfo("", "", "", "", "");
    hideShareWiMenu();//Bug 72670
    shareWiMenu();
    
    // reload workitem data
    updateWidata();    
    bFetchModifiedFVB = true;
    // Reload workitem interfaces
    RefreshWiInterfaces(); 
    
    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
    enableShareOption();
    notificationBeeperBox(messageJSON);    
}

function grantLock(ref){        
    var SharedUsersJson = JSON.stringify(collabSharedUsersJson);
    /*var	url = sContextPath+'/components/workitem/collaboration/wdcollabuserpicklist.app?Action=1&Mode=GL&MultipleSelect=N&CallBack=grantLockHandler&WD_SID='+WD_SID+'&SharedUsersJson='+SharedUsersJson;
    url = appendUrlSession(url);
    
    var left =  findAbsPosX(ref);
    var top =  findAbsPosY(ref)-2;
    popupIFrameOpener(this, "CollabUserList", url, 235, 280, left, top, true, true, false, false, false, false);*/
    ShowUserList(ref, "", "", "", "grantLockHandler", "N", "N", "N", '', '', "N", "N", "N", "N","GL",SharedUsersJson);
}

function grantLockHandler(jsonString){
    var userListInfoJSON = JSON.parse(jsonString);        
    
    if(userListInfoJSON.UserInfoList.length <1){
        return;
    }
    
    var lockInfo = {
        UserIndex: userListInfoJSON.UserInfoList[0].UserIndex,        
        UserName: userListInfoJSON.UserInfoList[0].UserName,
        LockAction: "GRANT",
        LockType: "",
        Status:'GRANTED'
    }
    
    wdCollaborationHandler("grantLockCO", lockInfo);
}

function broadcastGrantLockCO(thisObj){
    var collabSharedUsers = parseJSON('(' + decode_utf8(thisObj.req.getResponseHeader("CollabSharedUsersJSON")) + ')');
    bFetchModifiedFVB = true;
    collabSharedUsersJson = collabSharedUsers;
    setLockInfo(thisObj.data.UserIndex, thisObj.data.UserName, thisObj.data.LockAction, thisObj.data.LockType, thisObj.data.Status);        
    hideShareWiMenu();      //Bug 69080
    shareWiMenu();
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    
    var messageContainer = {         		
        FromUserIndex : userIndex,
        FromUserName : userName,   
        MessageText : userName+" "+HAS_GRANTED_LOCK_ON_WORKITEM+" " + pid +" "+MSG_TO+" "+thisObj.data.UserName,           
        TargetComponentHandler : 'broadcastGrantLockHandler',  
        CollabSharedUsersJson: collabSharedUsers,
        Notify:'Y',
        LockInfo: thisObj.data,
        RoomId : roomId,
        WindowKey: windowKey,
        AppType :'WINDOW',
        TimeStamp: new Date().getTime()
    }     
    glMessageContainer = messageContainer;

    if(!(SharingMode && wiproperty.formType=="NGFORM" && ngformproperty.type == "applet" && !bDefaultNGForm && !bAllDeviceForm)){
        broadcastLock(); 
    }
    else{
        var ngformIframe = document.getElementById("ngformIframe");
        ngformIframe.contentWindow.reqOption = "broadCastLock";
        ngformIframe.contentWindow.clickLink('cmdNgFormRefresh');
    }
}

function broadcastLock(){
    for_save("dummysave","collabForm");
    // reload workitem data
    updateWidata();
    // reload workitem interfaces
    RefreshWiInterfaces();    
    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
    enableShareOption();
    window.opener.parent.sendNotification(JSON.stringify(glMessageContainer), true);  
}
function broadcastGrantLockHandler(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    
    if(messageJSON.LockInfo.UserIndex == userIndex){
        wdCollaborationHandler("grantLockCR", messageJSON);    
    } else {
        collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
        setLockInfo(messageJSON.LockInfo.UserIndex, messageJSON.LockInfo.UserName, messageJSON.LockInfo.LockAction, messageJSON.LockInfo.LockType, messageJSON.LockInfo.Status);
        hideShareWiMenu();//Bug 72670
        shareWiMenu();
        
        // reload workitem data
        //updateWidata();

        // reload workitem interfaces
        //RefreshWiInterfaces();    

        updateWiTitle();    
        // re-initialize menu items
        //prepareWdeskDefaultMenu();
        enableShareOption();
        notificationBeeperBox(messageJSON);   
    }
     
}

function broadcastGrantLockCR(messageJSON){
    collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
    
    setLockInfo(messageJSON.LockInfo.UserIndex, messageJSON.LockInfo.UserName, messageJSON.LockInfo.LockAction, messageJSON.LockInfo.LockType, messageJSON.LockInfo.Status);
    hideShareWiMenu();//Bug 72670
    shareWiMenu();
    
    // reload workitem data
    updateWidata();   
    bFetchModifiedFVB = true;
    // Reload workitem interfaces
    RefreshWiInterfaces(); 
    
    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
    enableShareOption();
    notificationBeeperBox(messageJSON);    
}

function revokeLock(){
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : userName+' '+REVOKES_LOCK_ON_WORKITEM+' '+pid+' '+FROM+' '+CollaborationStruct.LockInfo.UserName,
        TargetComponentHandler: 'broadcastRevokeLockHandlerCO',
        params: [userIndex],
        RoomId : roomId,         
        Notify:'Y',
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }

    window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);
}

function broadcastRevokeLockHandlerCO(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
     
    if(CollaborationStruct.LockInfo.UserIndex == userIndex){
        wdCollaborationHandler("revokeLockCR", messageJSON);    
    } else {
        
    }
}

function revokeLockHandlerCR(thisObj){
    var collabSharedUsers = parseJSON('(' + decode_utf8(thisObj.req.getResponseHeader("CollabSharedUsersJSON")) + ')');
    collabSharedUsersJson = collabSharedUsers;    
    var messageJSON = thisObj.data;
    
    setLockInfo("", "", "", "", "");
    hideShareWiMenu();//Bug 72670
    shareWiMenu();
    bFetchModifiedFVB = true;
    
    
    notificationBeeperBox(messageJSON);   
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : messageJSON.MessageText,
        TargetComponentHandler: 'broadcastRevokeLockHandlerCR',        
        CollabSharedUsersJson: collabSharedUsers,
        RoomId : roomId,         
        Notify:'Y',
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }
    glMessageContainer = messageContainer;
   if(!(SharingMode && wiproperty.formType=="NGFORM" && ngformproperty.type == "applet" && !bDefaultNGForm && !bAllDeviceForm)){
        broadcastLock(); 
    }
    else{
        var ngformIframe = document.getElementById("ngformIframe");
        ngformIframe.contentWindow.reqOption = "broadCastLock";
        ngformIframe.contentWindow.clickLink('cmdNgFormRefresh');
    }  
}

function broadcastRevokeLockHandlerCR(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
     
    if(CollaborationStruct.OwnerInfo.UserIndex == userIndex){
        wdCollaborationHandler("revokeLockCO", messageJSON);    
    } else {
        collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
        setLockInfo("", "", "", "", "");
        hideShareWiMenu();//Bug 72670
        shareWiMenu();
        updateWiTitle();    
        enableShareOption();
        notificationBeeperBox(messageJSON);   
    }
}

function revokeLockHandlerCO(thisObj){
    var messageJSON = thisObj.data;
    
    collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
    
    setLockInfo("", "", "", "", "");
    hideShareWiMenu();//Bug 72670
    shareWiMenu();
    bFetchModifiedFVB = true;
    // reload workitem data
    updateWidata();    
    
    // Reload workitem interfaces
    RefreshWiInterfaces(); 
    
    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
    enableShareOption();
    notificationBeeperBox(messageJSON);   
}

/*
function revokeLock(){
    wdCollaborationHandler("revokeLockCO", null);      
}

function revokeLockHandlerCO(thisObj){
    for_save("dummysave");
    
    var collabSharedUsers = parseJSON('(' + thisObj.req.getResponseHeader("CollabSharedUsersJSON") + ')');
    collabSharedUsersJson = collabSharedUsers;
    
    var roomId = (pid+"_"+wid);    
    var windowKey = (pid+"_"+wid);    
    var messageContainer = {        
        FromUserIndex: userIndex,
        MessageText : userName+' '+"revokes lock on workitem"+' '+pid+' '+'from'+' '+CollaborationStruct.LockInfo.UserName,
        TargetComponentHandler: 'revokeLockHandlerCR',
        LockInfo: CollaborationStruct.LockInfo,
        CollabSharedUsersJson: collabSharedUsers,
        RoomId : roomId,         
        Notify:'Y',
        WindowKey: windowKey,
        TimeStamp: new Date().getTime(),
        AppType:'WINDOW' 
    }

    window.opener.parent.sendNotification(JSON.stringify(messageContainer), true);
    
    
    setLockInfo("", "", "", "", "");    
    shareWiMenu();
    
    // reload workitem data
    updateWidata();    
    
    // Reload workitem interfaces
    RefreshWiInterfaces(); 
    
    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
}

function revokeLockHandlerCR(message){
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
     
    if(messageJSON.LockInfo.UserIndex == userIndex){
        wdCollaborationHandler("revokeLockCR", messageJSON);    
    } else {
        collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
        setLockInfo("", "", "", "", "");
        
        shareWiMenu();
        
        // reload workitem data
        updateWidata();    

        // Reload workitem interfaces
        RefreshWiInterfaces(); 

        updateWiTitle();    
        // re-initialize menu items
        prepareWdeskDefaultMenu(); 
        
        notificationBeeperBox(messageJSON);   
    }
}

function revokeLockHandler(messageJSON){
    collabSharedUsersJson = messageJSON.CollabSharedUsersJson;
    
    setLockInfo("", "", "", "", "");
    shareWiMenu();
    
    // reload workitem data
    updateWidata();    
    
    // Reload workitem interfaces
    RefreshWiInterfaces(); 
    
    updateWiTitle();    
    // re-initialize menu items
    prepareWdeskDefaultMenu();
    
    notificationBeeperBox(messageJSON);  
}*/

/* Lock Management */


/* Notification */

function notificationBeeperBox(messageJSON, actionArray){
    var iframeMask = document.getElementById("notifyIframe"); 
    var notificationHeader = document.getElementById("wdesk:notificationHeader");
    var notificationContent = document.getElementById("wdesk:notificationContent");
    
    notificationHeader.style.cursor = "pointer";
    notificationHeader.style.display = "block";
    notificationHeader.style.left = (window.screen.width/2)-65+"px"; 
    notificationHeader.style.zIndex = "2000";

    notificationContent.style.height = window.innerHeight - 50 +"px";
    notificationContent.style.overflow = 'auto';
    notificationHeader.onclick = function(){
        if(notificationContent.style.display == "block"){
            notificationContent.style.display = "none";
            iframeMask.style.display = "none";
        }else{
            iframeMask.style.display = "block";
            notificationContent.style.display = "block";            
            notificationContent.style.left = notificationHeader.style.left;
            notificationContent.style.top = parseInt(notificationHeader.style.top)+30+"px";            
            
            iframeMask.style.top = notificationContent.style.top;
            iframeMask.style.left = notificationHeader.style.left;

            iframeMask.style.height = notificationContent.offsetHeight +"px";
            iframeMask.height = notificationContent.offsetHeight +"px";        

            iframeMask.style.width = notificationContent.offsetWidth +"px";
            iframeMask.width = notificationContent.offsetWidth +"px";
        }
    };   
    
    
    var span = document.getElementById("wdesk:notificationContentMsg");    
    var notificationCount = span.getElementsByTagName("div").length;    
    notificationCount += 1;
    
    var spanCount = document.getElementById("wdesk:notificationHeaderMsg");    
    spanCount.innerHTML = NOTIF_FIRST+notificationCount+NOTIF_SECOND;//Bug 75319
    spanCount.style.color = "red";
    
    
    var span1 = document.createElement("div");
    span1.innerHTML = encode_ParamValue(messageJSON.MessageText);
    span1.style.marginBottom = "3px";
    span1.className="blueName";    
    span1.id  = "msgDiv_"+notificationCount;
    span.appendChild(span1);
    
    var span2 = null;
    if((typeof actionArray != 'undefined') &&  actionArray.length > 0){        
        for(var j=0;j<actionArray.length;j++)
        {
            span2 = document.createElement("span");
            if(actionArray[j].ActionLabel=="Grant")//Bug 75319 Start
                span2.innerHTML=LABEL_GRANT;
            else if(actionArray[j].ActionLabel=="Deny")
                span2.innerHTML=LABEL_DENY;
            else if(actionArray[j].ActionLabel=="Cancel")
                span2.innerHTML=LABEL_CANCEL;
            else if(actionArray[j].ActionLabel=="Ok")
                span2.innerHTML=LABEL_OK;
            else
                span2.innerHTML = encode_ParamValue(actionArray[j].ActionLabel);//Bug 75319 End
            span2.className = "wdlinkstyle";
            span2.id = "span"+span.getElementsByTagName("div").length+"_"+j;
            span2.style.marginLeft = "15px";
            
            span2.onclick = new Function("onclickFunction('"+actionArray[j].ActionHandler+"','"+ JSON.stringify(messageJSON) + "','"+span1.id+"')");
            
            span1.appendChild(span2);
            span2 = null;
        }
    } else {
        span2 = document.createElement("span");
        span2.innerHTML = CLEAR;//Bug 75319
        span2.className = "wdlinkstyle";
        span2.style.marginLeft = "15px";
        span2.style.fontSize = "11px";
        
        span2.onclick = new Function("removeNotification('"+span1.id+"')");

        span1.appendChild(span2);
        span2 = null;      
    }
    
    var beeperBox_close = document.getElementById("wdesk:beeper_x");
    beeperBox_close.onclick = function(){
        notificationContent.style.display = "none";
        iframeMask.style.display = "none";
    }
    
    if((typeof messageJSON.Notify != 'undefined') && (messageJSON.Notify == "Y")){
        notifier(messageJSON.MessageText);
    }
    
    if(iframeMask){        
        iframeMask.style.top = notificationContent.style.top;
        iframeMask.style.left = notificationHeader.style.left;
        
        iframeMask.style.height = notificationContent.offsetHeight +"px";
        iframeMask.height = notificationContent.offsetHeight +"px";        
        
        iframeMask.style.width = notificationContent.offsetWidth +"px";
        iframeMask.width = notificationContent.offsetWidth +"px";
                        
        //iframeMask.style.border = "1px solid green";
        iframeMask.style.display = "block";
    }
}

function removeNotification(span1Id){    
    var iframeMask = document.getElementById("notifyIframe");                
    var notificationHeader = document.getElementById("wdesk:notificationHeader");
    var notificationContent = document.getElementById("wdesk:notificationContent");    
    var spanCount = document.getElementById("wdesk:notificationHeaderMsg");
    var span = document.getElementById("wdesk:notificationContentMsg");
    var span1 = document.getElementById(span1Id);
    
    var notificationCount = span.getElementsByTagName("div").length -1;
    spanCount.innerHTML = NOTIF_FIRST+(notificationCount)+NOTIF_SECOND;//Bug 75319
    span.removeChild(span1);
    
    if(iframeMask){
        iframeMask.style.height = notificationContent.offsetHeight +"px";
        iframeMask.height = notificationContent.offsetHeight +"px";        
        
        iframeMask.style.width = notificationContent.offsetWidth +"px";
        iframeMask.width = notificationContent.offsetWidth +"px";
    }    
    
    if(notificationCount <= 0){
        notificationContent.style.display = "none";
        notificationHeader.style.display = "none";
        
        if(iframeMask){
            iframeMask.style.display = "none";
        }        
    }
}

function onclickFunction(methodName,message,spanId){
   try{ 
        parseJSON(methodName+"('"+message+"')");
        removeNotification(spanId);
    } catch(ex) {                
    }    
}

function notifier(msg){
    /*jNotify(msg,
            {
                autoHide : true,
                TimeShown : 5000,
                VerticalPosition:'bottom',
                HorizontalPosition : 'right',
                clickOverlay : true,
                ShowTimeEffect : 500,
                HideTimeEffect : 500,
                LongTrip :20,
                ShowOverlay : false,
                ColorOverlay : '#000',
                OpacityOverlay : 0.3
            });*/
    
    dhtmlx.message.position = "bottom";
    
    dhtmlx.message({
        text: msg,
        expire: 5000
    });
}

function showAlert(msg, bParentMask){  
    if(typeof bParentMask == 'undefined'){
        bParentMask = true;
    }
    
    dhtmlx.alert({        
        ok: LABEL_OK,
        text: msg,        
        callback: function() {
            if(bParentMask){
                if(typeof showPopupMask != 'undefined'){
                    showPopupMask();
                }
            }
        }
    })    
}

/* Notification */


/***Collaboration Events ***/

function broadcastDocChangeEvent(docIndex,docName){
    var data = {
        "DocIndex" : docIndex,
        "DocName" : docName,
        "UserName" : userName
    };

    broadcastEvent(data,"docChangeEventHandler");
}

function docChangeEventHandler(message)
{
 var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var docIndex = messageJSON.Msg.DocIndex;
    var window_workdesk="";
    if(windowProperty.winloc == 'M')
        window_workdesk = window;
    else if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else
        window_workdesk = window.opener;
    var winList=window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
    if(docWindow)
    reloadapplet(docIndex,false);
    notifier(messageJSON.Msg.UserName+DOC_CHANGE_MSG+messageJSON.Msg.DocName);
}

function broadcastImportDocEvent(docIndex,docName,diskName,selButton,deldocId,docType,runscript){
    var data = {
        "DocIndex" : docIndex,
        "DocName" : docName,
        "DiskName" : diskName,
        "SelButton" : selButton,
        "DelDocId" : deldocId,
        "DocType" : docType,
        "runscript" : runscript,
        "UserName" : userName
    };

    broadcastEvent(data,"importDocEventHandler");
}

function importDocEventHandler(message)
{
 var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var importDocJSON = messageJSON.Msg;
    var window_workdesk="";
    if(windowProperty.winloc == 'M')
        window_workdesk = window;
    else if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else
        window_workdesk = window.opener;
    var winList=window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
    if(docWindow)
    openNewDocWrapper(importDocJSON,false);
    notifier(importDocJSON.UserName+DOC_IMPORT_MSG+importDocJSON.DocName);
}

function broadcastCheckOutDocEvent(docName,docType){
    var data = {
        "DocName" : docName,
        "DocType" : docType,
        "UserName" : userName
    };
    broadcastEvent(data,"checkOutDocEventHandler");
}

function checkOutDocEventHandler(message)
{
 var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var checkOutDocJSON = messageJSON.Msg;
    //onCheckOutDivInterchange();
    notifier(checkOutDocJSON.UserName+DOC_CHECKOUT_MSG+checkOutDocJSON.DocName);
}

function broadcastCheckInDocEvent(docIndex,docName,diskName){
    var data = {
        "DocIndex" : docIndex,
        "DocName" : docName,
        "DiskName" : diskName,
        "UserName" : userName
    };

    broadcastEvent(data,"checkInDocEventHandler");
}

function checkInDocEventHandler(message)
{
 var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var checkInDocJSON = messageJSON.Msg;
    var window_workdesk="";
    if(windowProperty.winloc == 'M')
        window_workdesk = window;
    else if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else
        window_workdesk = window.opener;
    var winList=window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
    if(docWindow)
    checkInCollaborationHandler(checkInDocJSON);
    notifier(checkInDocJSON.UserName+DOC_CHECKED_IN+checkInDocJSON.DocName);
}

function broadcastAddDocEvent(docIndex,docName,diskName,docType,runscript,docOrgName){
    var data = {
        "DocIndex" : docIndex,
        "DocName" : docName,
        "DiskName" : diskName,
        "DocType" : docType,
        "runscript" : runscript,
        "DocOrgName" : docOrgName,
        "UserName" : userName
    };

    broadcastEvent(data,"addDocEventHandler");
}

function addDocEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var addDocJSON = messageJSON.Msg;
    var window_workdesk="";
    if(windowProperty.winloc == 'M')
        window_workdesk = window;
    else if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else
        window_workdesk = window.opener;
    var winList=window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
    if(docWindow)
    addDocCollaborationHandler(addDocJSON);
    notifier(addDocJSON.UserName+DOC_ADDED_MSG+addDocJSON.DocName);
}

function broadcastToDoChangeEvent(toDoIndex,toDoName,toDoValue){
    var data = {
        "toDoIndex" : toDoIndex,
        "toDoName" : toDoName,
        "toDoValue" : toDoValue,
        "UserName" : userName
    };

    broadcastEvent(data,"toDoChangeEventHandler");
}

function toDoChangeEventHandler(message)
{
 var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var toDoIndex = messageJSON.Msg.toDoIndex;
    var toDoValue = messageJSON.Msg.toDoValue;
    
    var window_workdesk="";
    if(windowProperty.winloc=="M")
        window_workdesk=window;
    else
        window_workdesk=window.opener;

    var winList=window_workdesk.windowList;

    var todoWindow = getWindowHandler(winList,"todoGrid");
    

    if(todoWindow)
    {
        windowReflectTodoSaveFlag(toDoIndex,toDoValue);
    }

    notifier(messageJSON.Msg.UserName+TODO_CHANGE_MSG+messageJSON.Msg.toDoName);
}

function broadcastScanDocEvent(){
    var data = {
        "UserName" : userName
      };
    broadcastEvent(data,"scanDocEventHandler");
}

function scanDocEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var scanDocJSON = messageJSON.Msg;
    var window_workdesk="";
    if(windowProperty.winloc == 'M')
        window_workdesk = window;
    else if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else
        window_workdesk = window.opener;
    var winList=window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
    if(docWindow)
    ReloadDocInterface(false);
    notifier(scanDocJSON.UserName+DOC_SCAN_MSG);
}

function broadcastZoningEvent(X1,Y1,X2,Y2,zone,windowProperty,windowList){
    var data = {
        "X1" : X1,
        "Y1" : Y1,
        "X2" : X2,
        "Y2" : Y2,
        "zone" : zone,
        "UserName" : userName
    };
    broadcastEvent(data,"zoningEventHandler");
}

function zoningEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var zoneJSON = messageJSON.Msg;
    var window_workdesk="";
    if(windowProperty.winloc == 'M')
        window_workdesk = window;
    else if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else
        window_workdesk = window.opener;
    var winList=window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
    if(docWindow)
    ZoneGotFocusCollaboration(zoneJSON.X1, zoneJSON.Y1, zoneJSON.X2, zoneJSON.Y2, zoneJSON.zone);
    notifier(zoneJSON.UserName+DOC_ZONE_MSG+zoneJSON.zone);
}


function broadcastTransformationEvent(docIndex,docName){
    var data = {
        "DocIndex" : docIndex,
        "DocName" : docName,
        "UserName" : userName
    };
    broadcastEvent(data,"transformationEventHandler");
}

function transformationEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var transformationJSON = messageJSON.Msg;
    var window_workdesk="";
    if(windowProperty.winloc == 'M')
        window_workdesk = window;
    else if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else
        window_workdesk = window.opener;
    var winList=window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
    if(docWindow)
    reloadapplet(transformationJSON.DocIndex, false);
    notifier(transformationJSON.UserName+DOC_TRANSFORM_MSG+transformationJSON.DocName);
}

function broadcastConversationEvent(response,addAsNew,docName,docIndex,diskName){
    var data = {
        //"Response" : response,
        "docName" : docName,
        "docIndex" : docIndex,
        "diskName" : diskName,
        "AddAsNew" : addAsNew,
        "UserName" : userName
    };
    broadcastEvent(data,"conversationEventHandler");
}

function conversationEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    var conversationJSON = messageJSON.Msg;
    var window_workdesk="";
    if(windowProperty.winloc == 'M')
        window_workdesk = window;
    else if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else
        window_workdesk = window.opener;
    var winList=window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
    if(docWindow)
    convComboHandlerWrapper(true, conversationJSON);
    notifier(conversationJSON.UserName+CONVERSATION_MSG+conversationJSON.docName);
}

function broadcastToDoSetFormDataEvent(toDoIndex,toDoName,toDoValue,assocField,modelUpdate){
    var data = {
        "toDoIndex" : toDoIndex,
        "toDoName" : toDoName,
        "toDoValue" : toDoValue,
        "assocField" : assocField,
        "modelUpdate" : modelUpdate,
        "UserName" : userName
    };

    broadcastEvent(data,"toDoChangeEventHandler");
}



function broadcastDataEntryEvent(attribData,op){
    var data = {
        "attribData": attribData,
        "op"       : op,
        "UserName" : userName
    };

    broadcastEvent(data,"fireDataEntryEventHandler");
}

function fireDataEntryEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    var attribData = messageJSON.Msg.attribData;
    var op = messageJSON.Msg.op;
    dataEntryHandler(attribData,op);
    notifier(messageJSON.Msg.UserName+DATA_ETRY_TRIGGER_MSG);
}

function broadcastSetDataEvent(trigResponse){
    var data = {
        "trigResponse": JSON.parse(trigResponse),
        "UserName" : userName
    };

    broadcastEvent(data,"fireSetDataEventHandler");
}

function fireSetDataEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    var trigResponse = messageJSON.Msg.trigResponse;
    reflectSetDataEvent(trigResponse)
    notifier(messageJSON.Msg.UserName+SET_DATA_TRIGGER_MSG);
}

function broadcastExpEvent(ExpId,ExpName,calledFrom,expTrigRes){
    
    var data = {
        "ExpId" : ExpId,
        "ExpName" : ExpName,
        "CalledFrom" : calledFrom,
        "ExpTrigRes" : expTrigRes,
        "UserName" : userName
    };
    broadcastEvent(data,"expEventHandler");
}

function expEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    var expJSON = messageJSON.Msg;

    var window_workdesk="";
    if(windowProperty.winloc=="M")
        window_workdesk=window;
    else
        window_workdesk=window.opener;
    var winList=window_workdesk.windowList;
    var excpWindow = getWindowHandler(winList,"exceptionGrid");
    if(excpWindow)
    {
        selectedExpId = expJSON.ExpId;
        expRefreshAction();
        var cnt = 0;
        var expTrigRes = expJSON.ExpTrigRes;
        if(expTrigRes!=undefined){
            for( ; cnt<expTrigRes.length; cnt++){
                if(expTrigRes[cnt] != 'G'){
                    if(expTrigRes[cnt][0].flag=='0')
                    {
//                        if(expTrigRes[cnt][0].TriggerType == 'S')
//                            expSetTrig(expTrigRes[cnt]);
//                        else 
                            if(expTrigRes[cnt][0].TriggerType == 'DE'){
                            expNewDETrig(expTrigRes[cnt],cnt);
                        }
                    }
                    else if(expTrigRes[cnt][0].flag=='-1'){
                        if(expTrigRes[cnt][0].TriggerType == 'M')
                            customAlert(expTrigRes[cnt][0].description);
                    }
                }
            }
        }
    }
    if(expJSON.CalledFrom=='Raise')
        notifier(expJSON.UserName+EXP_RAISE_MSG+expJSON.ExpName);
    else if(expJSON.CalledFrom=='Undo')
        notifier(expJSON.UserName+EXP_UNDO_MSG+expJSON.ExpName);
    else if(expJSON.CalledFrom=='Commit')
        notifier(expJSON.UserName+EXP_COMMIT_MSG+expJSON.ExpName);
    else if(expJSON.CalledFrom=='Modify')
        notifier(expJSON.UserName+EXP_MODIFY_MSG+expJSON.ExpName);
    else if(expJSON.CalledFrom=='Clear')
        notifier(expJSON.UserName+EXP_CLEAR_MSG+expJSON.ExpName);
    else if(expJSON.CalledFrom=='Respond')
        notifier(expJSON.UserName+EXP_RESPOND_MSG+expJSON.ExpName);
    else if(expJSON.CalledFrom=='Reject')
        notifier(expJSON.UserName+EXP_REJECT_MSG+expJSON.ExpName);
}


function broadcastAddGenResponseDocEvent(docName,docIndex,diskName,DocOrgName){
    var data = {
        "docName" : docName,
        "docIndex": docIndex,
        "diskName": diskName,
        "DocOrgName":DocOrgName,
        "UserName" : userName
    };

    broadcastEvent(data,"fireAddGenResponseDocEventHandler");
}

function fireAddGenResponseDocEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var window_workdesk='';
    if(windowProperty.winloc == 'M')
        window_workdesk = window;
    else if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else
        window_workdesk = window.opener;        
    var winList = window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
    addGenResDoc(messageJSON.Msg.docName,messageJSON.Msg.docIndex,messageJSON.Msg.diskName,docWindow,messageJSON.Msg.DocOrgName);
    
    notifier(messageJSON.Msg.UserName+GENERATED_RESPONSE_FOR_MSG+docName);
}

function broadcastSelectExpEvent(ExpId,ExpName,ref,comments){
    var data = {
        "ExpId" : ExpId,
        "ExpName" : ExpName,
        "DivId" : ref.id,
        "Comments" : comments,
        "UserName" : userName
    };

    broadcastEvent(data,"selectExpEventHandler");
}

function selectExpEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    var selectExpJSON = messageJSON.Msg;
    var window_workdesk="";
    if(windowProperty.winloc=="M")
        window_workdesk=window;
    else
        window_workdesk=window.opener;
    var winList=window_workdesk.windowList;
    var excpWindow = getWindowHandler(winList,"exceptionGrid");
    
    var divId = selectExpJSON.DivId;
    var divRef = document.getElementById(divId);
    
    if(excpWindow)
    {
        clkMscExp(selectExpJSON.ExpId, selectExpJSON.ExpName, divRef, selectExpJSON.Comments);
    }
    
    notifier(messageJSON.Msg.UserName+EXP_SELECT_MSG+selectExpJSON.ExpName);
}

function broadcastFormChangeEvent(ref){
    var data = {
        "Id" : ref.id,
        "Value" : ref.value,
        "UserName" : userName
    };
    broadcastEvent(data,"formChangeEventHandler");
}

function formChangeEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    var formChangeJSON = messageJSON.Msg;
    //formChangeJSON
    var formWin = getWindowHandler(windowList,"formGrid");
    if(formWin){
        document.getElementById(formChangeJSON.Id).value = formChangeJSON.Value;
        var subStr = formChangeJSON.Id;
        subStr = subStr.substr(subStr.indexOf(":")+1);
    }
    notifier(messageJSON.Msg.UserName+FORM_CHANGE_MSG+subStr);
}

function broadcastActionEvent(actionResponse){
    var data = {
        "ActionRspnsTxt" : actionResponse,
        "UserName" : userName
    };
    broadcastEvent(data,"actionEventHandler");
}

function actionEventHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;
    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    var actionJSON = messageJSON.Msg;
    actionCollaborationHandler(actionJSON);
}

function broadcastUndoCheckOutDocEvent(docIndex,docName,diskName){
    var data = {
        "DocName" : docName,
        "DocIndex" : docIndex,
        "DiskName" : diskName,
        "UserName" : userName
    };
    broadcastEvent(data,"undoCheckOutDocEventHandler");
}

function undoCheckOutDocEventHandler(message)
{
 var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var undoCheckOutDocJSON = messageJSON.Msg;
    notifier(undoCheckOutDocJSON.UserName+DOC_UNDO_CHECKOUT_MSG+undoCheckOutDocJSON.DocName);
}

function broadcastFormEvents(){
    var data = {
        "UserName" : userName
    };
    
    var formType = "NGHTMLForm";
    
    if(SharingMode && wiproperty.formType=="NGFORM" && ngformproperty.type == "applet" && bDefaultNGForm && oldWDJason.WIViewMode != 'R'){
        formType = "NGForm";
    }    

    if(formType == 'NGForm'){
        for_save("dummysave", "broadCastForm");
        broadcastEvent(data,"formEventsHandler");
    }
    else if(formType == 'NGHTMLForm' && !bAllDeviceForm){
        try{
            var ngformIframe = document.getElementById("ngformIframe");
            ngformIframe.contentWindow.reqOption = 'broadCastForm';
            ngformIframe.contentWindow.clickLink('cmdNgFormRefresh');
        }catch(e){}
        
    }
}

function formEventsHandler(message)
{
 var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    bFetchModifiedFVB = true;

    var wiData = fetchFieldValueBag();  
    var formWin = getWindowHandler(windowList,"formGrid");
    if(formWin)
    formWin.document.wdgc.setFieldValueBag(wiData);
    
    var formJSON = messageJSON.Msg;
    notifier(formJSON.UserName+NGFORM_MSG);
}

function broadcastFormFromWindow(){
    var data = {
        "UserName" : userName
    };
    broadcastEvent(data,"formFromWindowEventsHandler");
}
function formFromWindowEventsHandler(message)
{
 var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    bFetchModifiedFVB = true;
    var formWin = getWindowHandler(windowList,"formGrid");
    if(formWin){
        var wiData = fetchFieldValueBag();  
        formWin.document.wdgc.setFieldValueBag(wiData);
    }
    var formJSON = messageJSON.Msg;
    notifier(formJSON.UserName+NGFORM_MSG);
}
function broadcastSetAsDefaultEvent(docName,docType){
    var data = {
        "DocName" : docName,
        "DocType" : docType,
        "UserName" : userName
    };
    broadcastEvent(data,"setAsDefaultEventHandler");
}

function setAsDefaultEventHandler(message)
{
 var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    var checkOutDocJSON = messageJSON.Msg;
    var window_workdesk='';
    if(windowProperty.winloc == 'M')
        window_workdesk = window;
    else if(windowProperty.winloc == 'T')
        window_workdesk = window.opener.opener;
    else
        window_workdesk = window.opener;        
    var winList = window_workdesk.windowList;
    var docWindow = getWindowHandler(winList,"tableGrid");
    if(docWindow){
        var showDefaultImg =document.getElementById('wdesk:defaultImg');
        var showNonDefaultImg =document.getElementById('wdesk:nonDefaultImg');
        showDefaultImg.style.display="inline";
        showNonDefaultImg.style.display="none";
    }
    notifier(checkOutDocJSON.UserName+SETASDEFAULT_MSG1+checkOutDocJSON.DocName+SETASDEFAULT_MSG2);
}

function broadcastNGHtmlFormEvents(){
    var data = {
        "UserName" : userName
    };
    for_save("dummysave", "broadCastForm");
    broadcastEvent(data,"ngHtmlformEventsHandler");
}

function ngHtmlformEventsHandler(message)
{
 var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;
    bFetchModifiedFVB = true;
    //var wiData = fetchFieldValueBag();  
    formLoaded = false;
    var formWin = getWindowHandler(windowList,"formGrid");
    if(formWin){
        getInterface('form');
    }
    
    var formJSON = messageJSON.Msg;
    notifier(formJSON.UserName+NGFORM_MSG);
}

function broadcastNGHTMLForm(){
    var data1 = {
        "UserName" : userName
    };
    window.parent.broadcastEvent(data1,"ngHtmlformEventsHandler");
}


function fixedWDeskTabChangeEvent(sourceTabId, targetTabId, sourceTabName, targetTabName){
    var data = {
        "SourceTabId" : sourceTabId,
        "TargetTabId" : targetTabId,
        "SourceTabName": sourceTabName,
        "TargetTabName": targetTabName        
    };

    broadcastEvent(data,"fixedWDeskTabChangeHandler");
}

function fixedWDeskTabChangeHandler(message)
{
    var messageJSON = JSON.parse(message);
    var timeStamp = messageJSON.TimeStamp;

    if(previousTimeStamp == timeStamp){
        return;
    }
    previousTimeStamp = timeStamp;

    // hide show interface tab and menu
    hideShowInterfaceTab(messageJSON.Msg.SourceTabId, messageJSON.Msg.TargetTabId);
       
    // toggles interface on tab change
    toggleIntFace(messageJSON.Msg.TargetTabId, messageJSON.Msg.SourceTabId);
                            
    notifier(messageJSON.FromUserName+INTERFACE_CHANGE_MSG+messageJSON.Msg.TargetTabName);
}
function readChatMsgEvent(data,targetHandlerMethod){
    var messageContainer = {
        FromUserIndex : userIndex,
        FromUserName : userName,
        TargetComponentHandler : targetHandlerMethod,
        RoomId : (pid+"_"+wid),
        WindowKey: (pid+"_"+wid),
        fileName: (pid+"_"+wid+"_Chat.json"),
        AppType:'WINDOW' ,
        TimeStamp: new Date().getTime(),
        Msg : data
    }

    window.opener.parent.readChatMsg(JSON.stringify(messageContainer), true);
}
/***Collaboration Events ***/
