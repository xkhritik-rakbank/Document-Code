/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var unlockflag="Y";//if unlockflag is Y then unlock workitem else donot call unlock on close;
var actionFlag="true";//TODO if actionflag is
var confirmSaveFlag=true;
var moreactionString="";
var strRemovefrommap="Y";//to remove workitem from map

var agt=navigator.userAgent.toLowerCase();
var ie = (agt.indexOf("msie") != -1);
var ns = (navigator.appName.indexOf("Netscape") != -1);
var windw = ((agt.indexOf("win")!=-1) || (agt.indexOf("32bit")!=-1));
var mac = (agt.indexOf("mac")!=-1);
var pluginlist = '';

var DATA_TYPE_SYS_OBJECTS=3
var DATA_ATTRIB_READ_ONLY = 1
var DATA_ATTRIB_WRITE_ONLY = 2
var DATA_ATTRIB_READ_WRITE = 3
var NG_VAR_INT = 3
var NG_VAR_LONG = 4
var NG_VAR_FLOAT = 6
var NG_VAR_DATE = 8
var NG_VAR_STRING = 10
var NG_VAR_BOOLEAN = 12
var NG_VAR_SHORTDATE = 15
var NG_VAR_TIME = 16
var NG_VAR_DURATION = 17
var READ_MODE = "R";
var WRITE_MODE = "W";
var NEW_WI_MODE = "N";
var AUDIT_MODE = "A";

var OP_LESSTHAN = 1;            //   <      
var OP_LESSTHANEQUALTO = 2;     //   <=     
var OP_EQUALTO = 3;             //   =      
var OP_NOTEQUALTO = 4;          //   =      
var OP_GREATERTHAN = 5;         //   >      
var OP_GREATERTHANEQUALTO = 6 ; //   >=     
var OP_LIKE = 7;                //   LIKE   
var OP_NOTLIKE = 8;             //   NOTLIKE
var OP_NULL = 9;                //   NULL   
var OP_NOTNULL = 10;            //   NOTNULL

var oldWDJason = null;
var newWDJason = null;
var cal=null;
var CurrentCalenderPicklistField;
var CurrentCalenderPicklistType;
var calFromTextBox=null;
var hiddenCalFromTextBox=null;
var bEscapeSave = false;
var bAllDeviceTaskForm=false;
var wLMode="";
var isEmbd = 'N';  
var myMenu = '';      
var saveTransFor = true;
var SharingMode = false;
var wDeskLayout = null; 
var strSessionStr = '';
    var docViewFlag='';
    var rightWidth=0;
    var newWidth=0;                 

    var strAttribData = '';
    var formBuffer;

    var docLoaded = false;
    var formLoaded = false;
    var isFormLoaded = false;
    var expLoaded = false;
    var todoLoaded = false;
    var taskLoaded = false; //Added for Task
    var sap0Loaded = false;
    var sap1Loaded = false;
    var sap2Loaded = false;
    var sap3Loaded = false;
    var sapLoaded = false;
    var taskStatusLoaded = false; //Added for Case Mgmt
    var caseFlowLoaded = false; //Added for Case Mgmt
    var docListLoaded = false; //Added for Case Mgmt

    var formH = 400;
    var formW = 600;
    var menuobj;
    //var WIObjectSupport = 'N';

    var curPos=0;
    var newPos=0;
    var mouseStatus='up'
    var defaultPrint = false;
            
            
var bRespWdesk=false;
var bWIOpenedFrmWList = false;
var OAP_SESSION_WARN_MARGIN = 20;
var CompAppSessionCheckTimer;
var sessionExpireWarnVisible = false;
var WISessionTimerWindows = new Array();

function checkApplicationSession() {
    var sessionCheckUrl = "/webdesktop/getsessiontime?WD_SID=" + WD_SID + "&sid=" + Math.random() + "&CustomAjax=true";
    ContentLoaderWrapper(sessionCheckUrl, sessionCheckCallback, null, "POST", '', true);
    
    function sessionCheckCallback() {
        var returnxml = this.req.responseText;
        if (returnxml.length > 0 && !isNaN(returnxml) && (returnxml - 0) > 0) {
            var appSessionTime = (returnxml - 0);
            var sessionExpireWarnTimeInSeconds = (SessionExpireWarnTime - 0) * 60 + OAP_SESSION_WARN_MARGIN;
            if (sessionExpireWarnVisible && (appSessionTime - OAP_SESSION_WARN_MARGIN) > 0) {
                hideWISessionTimer();
            }
            if (appSessionTime > 0 && appSessionTime > sessionExpireWarnTimeInSeconds) {
                var timeoutSeconds = appSessionTime - sessionExpireWarnTimeInSeconds;
                clearTimeout(CompAppSessionCheckTimer);
                CompAppSessionCheckTimer = setTimeout("checkApplicationSession()", timeoutSeconds * 1000);
            } else if (appSessionTime <= sessionExpireWarnTimeInSeconds) {
                if ((appSessionTime - OAP_SESSION_WARN_MARGIN) > 0 && SessionExpireWarnTime > 0 && !sessionExpireWarnVisible) {
                    clearTimeout(CompAppSessionCheckTimer);
                    showWISessionTimer(appSessionTime-OAP_SESSION_WARN_MARGIN);
                } else if ((appSessionTime - OAP_SESSION_WARN_MARGIN) > 0) {
                    clearTimeout(CompAppSessionCheckTimer);
                    CompAppSessionCheckTimer = setTimeout("checkApplicationSession()", (appSessionTime - OAP_SESSION_WARN_MARGIN) * 1000);
                } else {
                    window.location= "/webdesktop/error/errorpage.app?msgID=4020";
                }
            }
        } else {
            window.location= "/webdesktop/error/errorpage.app?msgID=4020";
        }
    }
}

function extendApplicationSession() {
    var sessionCheckUrl = "/webdesktop/updatesessiontime?time=" + (SessionWarnExtendTime*60) + "&WD_SID=" + WD_SID + "&sid=" + Math.random() + "&CustomAjax=true";
    ContentLoaderWrapper(sessionCheckUrl, checkApplicationSession, null, "POST", '', true);
}

function showWISessionTimer(remainingTime) {
    for(var i=0; i<WISessionTimerWindows.length; i++) {
        if(WISessionTimerWindows[i].closed) {
            WISessionTimerWindows.splice(i--, 1);
        } else {
            try {
                WISessionTimerWindows[i].showSessionTimer(remainingTime);
            } catch(e) {
                WISessionTimerWindows.splice(i--, 1);
            }
        }
    }
    sessionExpireWarnVisible = true;
}

function hideWISessionTimer() {
    for(var i=0; i<WISessionTimerWindows.length; i++) {
        if(WISessionTimerWindows[i].closed) {
            WISessionTimerWindows.splice(i--, 1);
        } else {
            try {
                WISessionTimerWindows[i].hideSessionTimer();
            } catch(e) {
                WISessionTimerWindows.splice(i--, 1);
            }
        }
    }
    sessionExpireWarnVisible = false;
}

function addToWISessionTimerWindows(win) {
    if(WISessionTimerWindows.length == 0) {
        WISessionTimerWindows[0] = win;
    } else {
        var bWindowExistFlag = false;
        for(var i = 0; i < WISessionTimerWindows.length; i++) {
            if(typeof WISessionTimerWindows[i] == 'object' && WISessionTimerWindows[i].name == win.name) {
                bWindowExistFlag = true;
                break;
            }
        }
        
        if(!bWindowExistFlag) {
            WISessionTimerWindows[WISessionTimerWindows.length] = win;
        }
    }
    
    if (sessionExpireWarnVisible) {
        var remainingtime = getTimerInSeconds();
        if (typeof win == 'object') {
            try {
                win.showSessionTimer(remainingtime - 1);
            } catch (e) {
                WISessionTimerWindows.splice(WISessionTimerWindows.length - 1, 1);
            }
        }
    }
}

function doInit() {
    if(typeof window.opener != 'undefined') {
        try {
            if(window.opener.workitemlist) {
                bWIOpenedFrmWList = true;
            }
        } catch(e) {
            bWIOpenedFrmWList = false;
        }
    }
    
    var oapWinRef = getOAPWindowRef();
    if(oapWinRef == null) {
        addToWISessionTimerWindows(window);
        checkApplicationSession();
    }
    
    if (strWindowResize == 'Y') {        
        //alert(strFinalWidth+":"+strFinalHeight+":"+strFinalTop+":"+strFinalLeft);
        if (strFinalWidth || strFinalHeight || strFinalTop || strFinalLeft) {
            if (navigator.appName == "Microsoft Internet Explorer")
            {
                window.resizeTo(strFinalWidth - 0 - 1, strFinalHeight - 0 + 1);
                window.moveTo(strFinalLeft - 0 - 8, strFinalTop - 0 - 30);
            } else
            {
                window.resizeTo(strFinalWidth - 0 - 1, strFinalHeight - 0 + 1);
                window.moveTo(strFinalLeft - 0 - 8, strFinalTop - 0 - 54);
            }
        } else {
            window.resizeTo(window.screen.availWidth, window.screen.availHeight);
            window.moveTo(0, 0);
        }
    }

    if (typeof customCloseMessage != 'undefined') {
        customCloseMessage();
    }
    var oldWDJason = getWDeskJason();
    wDeskLayout = oldWDJason.WDeskLayout;
    if (wdView != "emwd") {
        if(typeof initCollabServerStatus != 'undefined'){
            initCollabServerStatus();
        }
        
        if (wDeskLayout.WDeskType == 'E') {
            var noOfInterfaces = parseInt(wDeskLayout.InterfacesCount);
            if (noOfInterfaces > 0) {
                document.getElementById("wdesk:editLayoutPG").style.display = "block";
            }
        } else if (wDeskLayout.WDeskType == 'R') { 
            bRespWdesk = true;
        } else {
            var iWDeskInterfaces = wDeskLayout.WDeskFixedLayout.WDeskInterfacesCount;
            if (iWDeskInterfaces > 0) {
                document.getElementById("wdesk:editLayoutPG").style.display = "block";
            }
        }
        //document.getElementById("wdesk:editLayoutPG").style.display = "block";
    }

    initPopUp();

    //var oldWDJason = getWDeskJason();
    //wDeskLayout = oldWDJason.WDeskLayout;

    if (wdView == "emwd") {
        checkIsFormLoaded();
    }

    setOldWDJason();

    reinitFormElement(oldWDJason);

    // Prepares menu items                
    if (wdView == "emwd") {
        displayMenu('myMenuID');
    } else {
        prepareWdeskDefaultMenu();
    }

    if (wDeskLayout.WDeskType == 'E') {
        renderWDesk();
    } else if (wDeskLayout.WDeskType == 'R') {
        renderRespWDesk();
    } else {
        renderFixedWDesk();
    }

    if (wdView != "emwd") {
        initCollaboration();
    }

    setWaitIndicator();

    if (wdView != "emwd") {
        if (strOpenWI != "Y") {
            if (wiMode != 3)
                document.getElementById("wdesk:navigationPG").style.display = "inline-block";
        }

        /* if(!isEnableDownloadFlag(strprocessname,stractivityName)){
         if(document.getElementById('wdesk:downloadDiv'))
         document.getElementById('wdesk:downloadDiv').style.display='none';
         }
         */

        if (!isEnableEditDocFlag(strprocessname, stractivityName)) {
            if (document.getElementById('wdesk:editDocDiv'))
                document.getElementById('wdesk:editDocDiv').style.display = 'none';
        }

        if (strPrintOption == '1')
        {
            if (document.getElementById('wdesk:downloadDiv'))
                document.getElementById('wdesk:downloadDiv').style.display = 'none';
            if (document.getElementById('wdesk:PrintDiv'))
                document.getElementById('wdesk:PrintDiv').style.display = 'none';
            if (document.IVApplet)
                document.IVApplet.enableOrDisablePrinting(false);

        } else if (strPrintOption == '2')
        {
            if (typeof isEnableDownloadPrint != 'undefined' && isEnableDownloadPrint(strprocessname, stractivityName, userName))
            {
                if (document.getElementById('wdesk:downloadDiv'))
                    document.getElementById('wdesk:downloadDiv').style.display = 'inline';
                if (document.getElementById('wdesk:PrintDiv'))
                    document.getElementById('wdesk:PrintDiv').style.display = 'inline';
                if (document.IVApplet)
                    document.IVApplet.enableOrDisablePrinting(true);
            }

        }

        renderNavigation(parseInt(v_wi_count));
        setInterfacePositionInMyMenu();
    }
    renderEditLayout();
    
    setColorForDocumentList();  //bug id 32178
    initPrintScreen();

    if (wdView != "emwd") {
        if (typeof isDocOrgName != 'undefined' && !isDocOrgName(strprocessname, stractivityName))
            displayDocTypeOnly();
    }

    document.onmouseup = function (event) {
        onMouseUpWrapper(event);
    }

    try {
        if (LinkedWorkitem) {
            window.opener.opener.opener.opener.parent.addToOAPSessionTimer(window);
        } else if (CalledFrom != 'M') {
            window.opener.parent.addToOAPSessionTimer(window);
        }
    } catch (e) {
    }

    try {
        initKeyEvent();
    } catch (e) {
    }
    
    window.addEventListener("beforeprint", function(e) {
                    
        if(typeof defaultPrint!='undefined' && !defaultPrint){
            return false;
        }
        var head = document.getElementsByTagName("head")[0];
        var hs = head.getElementsByTagName('style');
        if(hs.length > 0){
            hs[hs.length-1].parentNode.removeChild(hs[hs.length-1]);
        }
        var css = '<style>' + '*{-webkit-print-color-adjust: exact !important;color-adjust: exact !important;}'+'@page{size:landscape;}' + '</style>';
        jQuery(head).append(css);
        var docVref;           
        
        var strLastSelDocIndex = (typeof lastSelDocIndex == 'undefined')? '': lastSelDocIndex;
        
        try{
            var docViewerPaneId = getDocViewerPaneId(strLastSelDocIndex, 'docviewer');
            try{
                docVref = window.frames[docViewerPaneId].contentWindow.document;
            } catch(ex) {
                docVref = window.frames[docViewerPaneId].document;
            }
            if(docVref && opall_toolkit!=null && isOpAll=='Y') {
                var stylesheet = docVref.styleSheets[0];
                var cr = stylesheet.cssRules;
                var i;
                for(i=0; i < cr.length; i++){
                    if(cr[i].type=='4') {
                        if(cr[i].media.mediaText == "print"){
                            mPos=i;
                        }
                    } else if (cr[i].type=='6') {
                        pPos=i;
                    } else {
                        continue;
                    }
                }
                            
                stylesheet.deleteRule(mPos);
                stylesheet.deleteRule(pPos-1);
                            
            } 
        } catch(exp){}                   
    });

    window.addEventListener("afterprint", function(e) {							
        if(typeof defaultPrint!='undefined' && !defaultPrint){
            return false;
        }
        defaultPrint=false;
                    
        var head = document.getElementsByTagName("head")[0];
        var hs = head.getElementsByTagName('style');
        if(hs.length > 0){
            hs[hs.length-1].parentNode.removeChild(hs[hs.length-1]);
        }
                    
        var css = '<style>' + '@page{margin:0;}'+ '@media print{#wdesk{display:none;}}' +  '</style>';
        jQuery(head).append(css);
        var docVref;
        try{
            var strLastSelDocIndex = (typeof lastSelDocIndex == 'undefined')? '': lastSelDocIndex;
            
            var docViewerPaneId = getDocViewerPaneId(strLastSelDocIndex, 'docviewer');
            try{
                docVref = window.frames[docViewerPaneId].contentWindow.document;
            } catch(ex) {
                docVref = window.frames[docViewerPaneId].document;
            }
            if(docVref && opall_toolkit!=null && isOpAll=='Y') {
                var stylesheet = docVref.styleSheets[0];
                var oCss1 = '@media print {*{margin:0px;padding:0px;}	#menu,#TransformationToolbar,#ZoomLens,#PrintDialog,#AnnotationToolbar,#viewArea,#contextMenu,#PropertiesDialog,#hyperLinkDialog,#freetextareaID,#attachNote,#CustomZoomDialog,#annotationGroupDialog,#annotationPropertiesDialog,#License,#modalLoadBar, #transformation_toolbar, #navigation_control, #new_wrapper,#annotation_toolbar,#ul_line_group, #ul_rectangle_group, #ul_transform_group, #ul_resize_group{display:none;visibility:hidden;}	body{background: transparent none;overflow:visible;}	#PrintContainer{display:block;		position:absolute;top:0;left:0;} @page{size:A4;}  #PrintContainer canvas {position: static;top: 0;left: 0;}	.pageCont, .pageCont canvas {		visibility:visible;position:static;}}';
                var oCss2 = '@page{margin:0;marks:none;}';
                stylesheet.insertRule(oCss1, stylesheet.cssRules.length);
                stylesheet.insertRule(oCss2, stylesheet.cssRules.length);
            }
        } catch(exp){}
    });

    try {
        if (window.opener.wLMode)
        {
            wLMode = window.opener.wLMode
        }
    } catch (e) {
    }
    if (typeof isExtDownload != "undefined") {
        if (isExtDownload == 'true') {
            installPlugin();
        }
    } 

    if (wdView == "emwd") {
        if (wiViewMode == "R") {
            window.parent.changePanelTitle(compInsId, stractivityName + " : " + pid + " " + TITLE_READONLY);
        } else {
            window.parent.changePanelTitle(compInsId, stractivityName + " : " + pid);
        }
    } else {
        var onBeforeUnLoadEvent = false;
        window.onunload = window.onbeforeunload = function (e) {
            if (!onBeforeUnLoadEvent) {
                onBeforeUnLoadEvent = true;
                var ref = document.getElementById("wdesk:noNextWIMsg");
                if (ref != null && ref.style.display == "none") {
                    doCleanUp("beforeunload");
                }
            }
        }
    }
    
    refreshWorkitemList();
    
    regEventListener(window);
}

function renderEditLayout(){
    if(wdView!='emwd'){
        var editlytRef = document.getElementById('wdesk:editLayoutlbl');
        var sharingMode = (typeof SharingMode == 'undefined') ? false : SharingMode;
        var showEL = editlytRef && editlayout=='Y' && bTwoColLayout && isDesktopBPforEL() && !sharingMode;
        if(showEL){
            replaceCSS(editlytRef, "dn", "db");
        } else if(hasCSS(editlytRef, "db")){
            replaceCSS(editlytRef, "db", "dn");
        }
    }
}


function initPrintScreen() {
    try {
        var isDisableScreenPrintHook = true;
        if (typeof isDisablePrintScreen != 'undefined')
            isDisableScreenPrintHook = isDisablePrintScreen(strprocessname, stractivityName);
        if (isDisableScreenPrintHook && strIsDisablePrintScreen == "Y")
            document.PrintScreen.runMethod();
    } catch (ex) {
        ;
    }
}

function stopPrintScreen() {
    try {
        var isDisableScreenPrintHook = true;
        if (typeof isDisablePrintScreen != 'undefined')
            isDisableScreenPrintHook = isDisablePrintScreen(strprocessname, stractivityName);
        if (isDisableScreenPrintHook && strIsDisablePrintScreen == "Y")
            document.PrintScreen.stopMethod();
    } catch (ex) {
        ;
    }
}




function getWDeskJason() {
    var wDeskJason = document.getElementById("wdesk:wDeskJason").innerHTML;
    return parseJSON("(" + wDeskJason + ")");
}

function renderNavigation(wiCount) {
    if (bWIOpenedFrmWList && (window.opener != null) && (typeof window.opener.getWiNavigationInfo != 'undefined')) {
        var wiNavJason = window.opener.getWiNavigationInfo();
        var currentBatchSize = parseInt(wiNavJason.CurrentBatchSize);
        var isPrevBatch = wiNavJason.IsPrevBatch;
        var isNextBatch = wiNavJason.IsNextBatch;
        var wi_count = document.getElementById("wdesk:wi_count");
        var currentPage = window.opener.document.getElementById("wlf:page");
        var queueId = parseInt(document.forms["wdesk"].QueueId.value);

        if (document.getElementById("wdesk:navigationPG")) {
            document.getElementById("wdesk:navigationPG").style.display = "";
        }

        var isNext = NextClick();
        var isPrev = PrevClick();
        if ((!isNext && !isPrev) || (strPrevNextUnlock == "Y" && queueId == 0)) {
            document.getElementById("wdesk:navigationPG").style.display = "none";
        } else if (!isPrev) {
            if (document.getElementById("wdesk:PrevLink") != null) {
                document.getElementById("wdesk:PrevLink").style.display = "none";
            }
            if (document.getElementById("wdesk:PrevSep") != null)
                document.getElementById("wdesk:PrevSep").style.display = "none";
            if (document.getElementById("wdesk:navSeparator") != null) {
                document.getElementById("wdesk:navSeparator").style.display = "none";
            }
        } else if (!isNext) {
            if (document.getElementById("wdesk:navSeparator") != null) {
                document.getElementById("wdesk:navSeparator").style.display = "none";
            }
            if (document.getElementById("wdesk:NextSep") != null)
                document.getElementById("wdesk:NextSep").style.display = "none";
            if (document.getElementById("wdesk:NextLink") != null) {
                document.getElementById("wdesk:NextLink").style.display = "none";
            }
        }

        var showNextNav = false;
        if (prevNextUnlock == 'Y') {
            showNextNav = true;
        } else {
            var nextAvailWiCount = window.opener.getWICount('N', wiCount + 1);

            if (nextAvailWiCount > currentBatchSize - 1) {
                showNextNav = false;
                 if(isNextBatch =="true")
                        showNextNav = true;
            } else {
                if (isNext) {
                    showNextNav = true;
                }
            }
        }

        var prevAvailWiCount = window.opener.getWICount('P', wiCount - 1);

        if ((prevAvailWiCount < 0 && (isPrevBatch=="false")) && (prevNextUnlock == 'N')) {
            if (document.getElementById("wdesk:PrevLink") != null) {
                document.getElementById("wdesk:PrevLink").style.display = "none";
            }
            if (document.getElementById("wdesk:PrevSep") != null)
                document.getElementById("wdesk:PrevSep").style.display = "none";
            if (document.getElementById("wdesk:navSeparator") != null) {
                document.getElementById("wdesk:navSeparator").style.display = "none";
            }
        } else {
            if (document.getElementById("wdesk:PrevLink") != null) {
                document.getElementById("wdesk:PrevLink").style.display = "block";
            }
            if (document.getElementById("wdesk:PrevSep") != null)
                document.getElementById("wdesk:PrevSep").style.display = "inline";

            if (!showNextNav) {
                if (document.getElementById("wdesk:navSeparator") != null) {
                    document.getElementById("wdesk:navSeparator").style.display = "none";
                }
            } else {
                if (document.getElementById("wdesk:navSeparator") != null) {
                    document.getElementById("wdesk:navSeparator").style.display = "inline";
                }
            }
        }

        if (!showNextNav) {
            if (document.getElementById("wdesk:NextSep") != null)
                document.getElementById("wdesk:NextSep").style.display = "none";
            if (document.getElementById("wdesk:NextLink") != null) {
                document.getElementById("wdesk:NextLink").style.display = "none";
            }
        } else {
            if (document.getElementById("wdesk:NextSep") != null)
                document.getElementById("wdesk:NextSep").style.display = "inline";
            if (document.getElementById("wdesk:NextLink") != null) {
                document.getElementById("wdesk:NextLink").style.display = "block";
            }
        }
    } else {
        if (document.getElementById("wdesk:navigationPG") != null) {
            document.getElementById("wdesk:navigationPG").style.display = "none";
        }
    }
}


function setWaitIndicator(){
                if(document.getElementById("wdesk:waitIndicator") != null) {
                    var indicatorWidth = document.getElementById("wdesk:waitIndicator").style.width.split('p')[0];
                    var indicatorHeight = document.getElementById("wdesk:waitIndicator").style.height.split('p')[0];                    
                    var indicatorTop = findPosY(document.getElementById("wdesk:indicatorMarker"));                    
                    document.getElementById("wdesk:waitIndicator").style.left = document.body.clientWidth/2-20;
                    document.getElementById("wdesk:waitIndicator").style.top = indicatorTop + "px";
                }
            }
            
            
            function prevNextHandler(navigationType) {
               var bSaveWI = checkSaveWIAlert('Nav', navigationType);
               if(bSaveWI) {
                   return false;
               }
               
               prevNextHandlerMain(navigationType);
           }
           
           function prevNextHandlerMain(navigationType) {
			
               var wiCount = -1;
               if(newWDJason != null) {
                   wiCount = parseInt(newWDJason.WICount);
               } else {
                   wiCount = parseInt(v_wi_count);
               }
               if(isNaN(wiCount)){
                   wiCount = parseInt(document.getElementById("wdesk:wi_count").value);
                   if(isNaN(wiCount)){
                     wiCount=parseInt(v_wi_dummy);
                    }
                  }
               var wdJason = null;
               if(newWDJason == null){
                   wdJason = oldWDJason;
               } else {
                   wdJason = newWDJason;
               }

               if(wiCount > -1){
                   try{
                       var statusInd = document.getElementById("wdesk:waitIndicator");
                       statusInd.style.left=document.body.clientWidth/2-40 + "px";
                       if(navigationType=="P"){
                           statusInd.style.display = "inline";                           
                           
                           if(prevNextUnlock == 'Y'){
                               window.opener.WorkitemEventHandlerWrapper("P",window.name,wdJason);
                           } else {                           
                               var isPrevWi = window.opener.openPrevWorkitem(wiCount,window.name,wdJason);
                               if(!isPrevWi){
                                   if(prevNextUnlock == 'Y'){
                                       //window.opener.WorkitemEventHandlerWrapper("P",wdJason);
                                   } else {
                                       window.opener.bPrevNextOperation = false;
                                       window.opener.workitemNavType="";

                                       doCleanUp();

                                       clearWDeskLayout();
                                   }
                               }
                           }
                       } else if(navigationType=="N"){
                           statusInd.style.display = "inline";    
                           
                           if(prevNextUnlock == 'Y'){
                               window.opener.WorkitemEventHandlerWrapper("N",window.name,wdJason);
                           } else {
                               var isNextWi = window.opener.openNextWorkitem(wiCount,window.name,wdJason);
                               if(!isNextWi){
                                   if(prevNextUnlock == 'Y'){
                                       //window.opener.WorkitemEventHandlerWrapper("N",wdJason);
                                   } else {
                                       window.opener.bPrevNextOperation = false;
                                       window.opener.workitemNavType="";

                                       doCleanUp();

                                       clearWDeskLayout();
                                   }
                               }
                           }
                       }
                   }catch(ex){
                        //alert(ex.description);
                   }
               }
           }
           
           
           function doClear(){
                var statusInd = document.getElementById("wdesk:waitIndicator");
                statusInd.style.display = "none";
           }
           
           function clearWDeskLayout(msg){
               msg = (typeof msg == 'undefined')? null: msg;
               
               doClear();

               // Hiding the content when no workitem is present in the worklist/queue 
               document.getElementById("wdesk:title").style.visibility = "hidden";                           
               document.getElementById("myMenuID").style.display = "none";
               if(document.getElementById("wdesk:navigationPG")){
                    document.getElementById("wdesk:navigationPG").style.display = "none";  
               }
               if (bRespWdesk) {
                   var moreOpt = document.getElementById("menuMoreOpt");
                   var moreOptDiv = document.getElementById("MoreOptDiv");
                   removeCSS(moreOpt, "db");
                   removeCSS(moreOptDiv, "db");
                   addCSS(moreOpt, "dn");
                   addCSS(moreOptDiv, "dn");
                   if(document.getElementById("wdesk:editLayoutlbl"))
                       replaceCSS(document.getElementById("wdesk:editLayoutlbl"), "db", "dn");
                } else {
                  if (document.getElementById("wdesk:editLayoutPG")) {
                    document.getElementById("wdesk:editLayoutPG").style.display = "none";
                  }
                }
               
               if(document.getElementById("wdesk:noIntMsg")){
                    document.getElementById("wdesk:noIntMsg").style.display = "none";                                                  
               }

               // Clearing  the interface layout when no workitem is present in the worklist/queue 
               var contDivRef = null;
               if(wDeskLayout.WDeskType == 'E'){
                   contDivRef = document.getElementById("containerDiv");                           
                   clearEditableLayout(); 
                } else if(wDeskLayout.WDeskType == 'R') {
                    contDivRef = document.getElementsByClassName("bscontwdiv")[0];
                    clearRespLayout();
                } else {
                    contDivRef = document.getElementById("fixedContainerDiv");                           
                    clearFixedLayout();
                }                       

               if(msg){
                   document.getElementById("wdesk:noNextWIMsg").innerHTML = encode_ParamValue(msg);
               } else {
                   document.getElementById("wdesk:noNextWIMsg").innerHTML = msg_nowi;
               }
               
               contDivRef.style.border = "1px solid #A0A0A0";                           
               document.getElementById("wdesk:noNextWIMsg").style.display = "block";
               
               oldWDJason = null;
               newWDJason = null;
           }
           
           
           function getWiData(pid, wid, wiCount,taskid){
                var allowReassignment = document.getElementById('allowReassignment').value;
                var batchFlag = document.getElementById('wdesk:batchflag').value;
                var CalledFrom = document.getElementById('CalledFrom').value;
                var LinkedWorkitem = document.getElementById('LinkedWorkitem').value;
                var QueueType = document.getElementById('QueueType').value;
                var InstrumentListCallFlag = document.getElementById('InstrumentListCallFlag').value;
                
                var q = "Action=getwijason&pid="+encode_utf8(pid)+"&wid="+wid+"&taskid="+taskid+"&wi_count="+wiCount+"&allowreassignment="+allowReassignment+"&wdesk:batchflag="+batchFlag+"&CalledFrom="+CalledFrom+"&LinkedWorkitem="+LinkedWorkitem+"&QueueType="+QueueType+"&InstrumentListCallFlag="+InstrumentListCallFlag;
                var url = sContextPath+"/components/workitem/view/getwidata.app";
                var reqRef = ContentLoaderWrapper(url, null, null, "POST", q, false);
                if(reqRef.req.status == 200) {
                    var respText = reqRef.req.responseText;
                    respText = respText.substring(respText.indexOf('<jasoncont>')+11,respText.lastIndexOf('</jasoncont>'));
                    return parseJSON("(" + respText + ")");
                } else {
                    return null;
                }
           }
           
           // Getting next workitm when standard workdesk is opened in embedded view
           function getNextWi(){
               var wiCount = parseInt(document.forms["wdesk"]["wdesk:wi_count"].value);               
               var ref = window.parent.getComponentRef(sourceInsId).contentWindow;
             
               if(ref != null){
                   var i = ref.openNextEmbWorkitem(wiCount);
                   if(i < 0){                       
                       // Hiding the content when no workitem is present in the worklist/queue 
                       document.getElementById("wdesk:title").style.visibility = "hidden";                       
                       document.getElementById("myMenuID").style.display = "none";                                              
                       document.getElementById("wdesk:noIntMsg").style.display = "none";                                              

                       // Clearing  the interface layout when no workitem is present in the worklist/queue 
                       var contDivRef = null;
                       if(wDeskLayout.WDeskType == 'E'){
                           contDivRef = document.getElementById("containerDiv");                           
                           clearEditableLayout(); 
                       } else {
                           contDivRef = document.getElementById("fixedContainerDiv");                           
                           clearFixedLayout();
                       }                                              
                       
                       document.getElementById("wdesk:placeHolder").style.display = "none";
                       document.getElementById("wdesk:messagePG").style.display = "";
                   }
               }               
           }
            
           function introduceNDoneWIHandlerWrapper(data){
                if(data.status == 'begin'){
                    showMasking();
                } 
                if(data.status == 'success') {
                    hideMasking();
                }
                introduceNDoneWIHandler(data);
            }
            
           function introduceNDoneWIHandler(data){
               if(data.status == "success"){                   
                   hideProcessing();

                var actionStatus = document.getElementById("wdesk:actionStatus").value;
				var refCase = null;
					if((typeof window!='undefined' && window!=null) && (typeof window.opener!='undefined' && window.opener!=null))
					refCase = window.opener.document.getElementById("mytasks:hidIsOpFromCaseBasket");
				
				var IsWIOpenFromCaseBasket=false;
				if(typeof refCase!=null && refCase!=undefined){
							IsWIOpenFromCaseBasket = refCase.value;
				}
                   //if(actionStatus != "error"){
                     //  hideWIFromList(sourceInsId);
                  // }
                  
                  if(typeof wiOperationPostHook != 'undefined') {
                       var opr = document.forms["wdesk"].Option.value;
                       var oprStatus = (actionStatus == "error") ? "error" : "success";
                       var errorMsg = "";
                       if(oprStatus == "error") {
                           errorMsg = document.getElementById("wdesk:errorMsg").value;
                       }
                       wiOperationPostHook(opr, oprStatus, errorMsg);
                   }
                   
                   var ngParam = document.getElementById("ngParam");
                   if(ngParam != null){
                       ngParam.value = "";
                   }
                  
                   if(wdView == "emwd"){
                       // Standard workdesk in Embedded view
                       
                       if(actionStatus == "clickNextWI") {
                            getNextWi();                       
                       } else if(actionStatus == "error") {
                            var statusCode = document.getElementById("wdesk:errorMsg").value;
                            if(statusCode == "11"){
                                url = sContextPath+"/error/errorpage.app?msgID=4020";
                                url = appendUrlSession(url);

                                var width = 320;
                                var height = 160;
                                var left = (window.screen.availWidth-width)/2;
                                var top = (window.screen.availHeight-height)/2;
                                if (window.showModalDialog){
                                    window.showModalDialog(url,'',"dialogWidth:"+width +"px;dialogHeight:"+height+"px;center:yes;dialogleft: "+left+"px;dialogtop: "+top+"px");
                                }
                            } else {
                                var errormsg=document.getElementById("wdesk:errorMsg").value;
                                if(errormsg!=""){
                                    setmessageinDiv(errormsg, "true", 3000);
                                }
                            }
                            
                            if((typeof window.opener != 'undefined') && (window.opener != null) && (typeof window.opener.bPrevNextOperation != 'undefined')){
                               window.opener.bPrevNextOperation = false;
                               window.opener.workitemNavType="";
                            }
                       }
                   } else {
                       // Standard workdesk
                       if(bWIOpenedFrmWList && (typeof window.opener != 'undefined') && (window.opener != null)){
                            if(CalledFrom != 'M'){
                                if(typeof window.opener.bPrevNextOperation != 'undefined'){
                                    window.opener.bPrevNextOperation = false;
                                    window.opener.workitemNavType=""; 
                                }
                            }
                           
                           /*if(strPrevNextUnlock=="Y"){
                               var wiCount = parseInt(document.getElementById("wdesk:wi_count").value);
                               var nextWiCount = window.opener.getWICount('N', wiCount);
                               var currentBatchSize = parseInt(window.opener.document.getElementById("wlf:currentBatchSize").value);
                               if(nextWiCount >= currentBatchSize){                                   
                                   actionStatus = "noWILeft";
                               }
                           }*/
                       }
                       
                       if(actionStatus == "getNextWI") {
                           var pid = document.getElementById("wdesk:pid").value;
                           var wid = document.getElementById("wdesk:wid").value;
                           var taskid = document.getElementById("wdesk:taskid").value;

                           var wiCount = parseInt(document.getElementById("wdesk:wi_count").value);
                        //   var wdJason = getWiData(pid, wid, wiCount,taskid);
                           
                           if(bWIOpenedFrmWList && closeDuplicateWi == "Y"){       
                               try{
                                    var wiWinInfo = window.opener.getNextWiWinInfo(pid, wid);
                                    if(wiWinInfo !=null){
                                        setOldWDJason();                        
                                        reinitWDVariables(wdJason);
                                        initDefaultValues();
                                        
                                        wiWinInfo.WinRef.focus();
                                        window.close();
                                        return;
                                    }
                               } catch(e){}
                            }
                           var TargetActivityType = document.getElementById("wdesk:TargetActivityType").value;
                           var strCallCase =document.getElementById("wdesk:CallCaseRedirect").value;
                          // initNLoadWorkitem(wdJason);
                           if(strCallCase=="Y"){
                               getCaseWorkdesk(pid, wid, wiCount,taskid,TargetActivityType);
                           }
                           else{
                              var wdJason = getWiData(pid, wid, wiCount,taskid);
                              initNLoadWorkitem(wdJason); 
                           }
                           document.getElementById("wdesk:CallCaseRedirect").value="N";
                       }else if(actionStatus == "getNextBlockWI") {
                           var pid = document.getElementById("wdesk:pid").value;
                           var wid = document.getElementById("wdesk:wid").value;
                           var taskid = document.getElementById("wdesk:taskid").value;
                           var wiCount = parseInt(document.getElementById("wdesk:wi_count").value);
                           var TargetActivityType = document.getElementById("wdesk:TargetActivityType").value;
                         //  var wdJason = getWiData(pid, wid, wiCount,taskid);
                          // initNLoadWorkitem(wdJason);
                          var prevActId=document.getElementById("wdesk:PrevActId").value;
                          //if(TargetActivityType!=prevActId){
                               getCaseWorkdesk(pid, wid, wiCount,taskid,TargetActivityType);
                          //  }
                          //  else{
                          //      var wdJason = getWiData(pid, wid, wiCount,taskid);
                          //      initNLoadWorkitem(wdJason);
                          //  }
                       } else if(actionStatus == "noWILeft") {
                           doCleanUp();
                           
                           //hideWIFromList(sourceInsId);

                           // Hiding the content when no workitem is present in the worklist/queue 
                           document.getElementById("wdesk:title").style.visibility = "hidden";                           
                           document.getElementById("myMenuID").style.display = "none";
                           document.getElementById("wdesk:navigationPG").style.display = "none"; 
                           if(bRespWdesk){
                               var moreOpt=document.getElementById("menuMoreOpt");
                               var moreOptDiv=document.getElementById("MoreOptDiv");
                               removeCSS(moreOpt,"db");
                               removeCSS(moreOptDiv,"db");
                               addCSS(moreOpt,"dn");
                               addCSS(moreOptDiv,"dn");
                               if(document.getElementById("wdesk:editLayoutlbl"))
                                    replaceCSS(document.getElementById("wdesk:editLayoutlbl"), "db", "dn");
                           } else {
                              document.getElementById("wdesk:editLayoutPG").style.display = "none"; 
                           }
                                                  
                           document.getElementById("wdesk:noIntMsg").style.display = "none";                                                  

                           // Clearing  the interface layout when no workitem is present in the worklist/queue 
                           var contDivRef = null;
                           if(wDeskLayout.WDeskType == 'E'){
                               contDivRef = document.getElementById("containerDiv");                           
                               clearEditableLayout(); 
                           } else if(wDeskLayout.WDeskType == 'R') {
                               contDivRef = document.getElementsByClassName("bscontwdiv")[0];
                                if(wiproperty.formType == "NGFORM" && ngformproperty.type == "applet" && bDefaultNGForm) {
                                   contDivRef.style.display = "none";
                               } else {
                                   clearRespLayout();
                               }
                           } else {
                               contDivRef = document.getElementById("fixedContainerDiv");                           
                               clearFixedLayout();
                           }                       
                           //contDivRef.innerHTML = "";

                           contDivRef.style.border = "1px solid #A0A0A0";                           
                           document.getElementById("wdesk:noNextWIMsg").style.display = "block";
                                                      
                           oldWDJason = null;
                           newWDJason = null;
                           
                           if((prevNextUnlock == 'N') && (CalledFrom != 'NEW')){
                               var wiCount = parseInt(document.getElementById("wdesk:wi_count").value);
                               if(bWIOpenedFrmWList && (typeof window.opener.updateWiListMessage != 'undefined')){
                                   window.opener.updateWiListMessage(wiCount);
                               }
                           }

                           var option = document.forms["wdesk"].Option.value;
                           var queueType = document.forms["wdesk"].QueueType.value;
                           if(createNewWI == "Y" && queueType=="I"){
                                window.opener.newWorkitemClickWrapper();
                                self.close();
                           }
                       } else if(actionStatus == "referFromMail") {
                           doCleanUp();                           
                           
                           // Hiding the content when no workitem is present in the worklist/queue 
                           document.getElementById("myMenuID").style.display = "none";
                           document.getElementById("wdesk:navigationPG").style.display = "none";  
                           if(bRespWdesk){
                               var moreOpt=document.getElementById("menuMoreOpt");
                               var moreOptDiv=document.getElementById("MoreOptDiv");
                               removeCSS(moreOpt,"db");
                               removeCSS(moreOptDiv,"db");
                               addCSS(moreOpt,"dn");
                               addCSS(moreOptDiv,"dn");
                               if(document.getElementById("wdesk:editLayoutlbl"))
                                    replaceCSS(document.getElementById("wdesk:editLayoutlbl"), "db", "dn");
                           } else {
                              document.getElementById("wdesk:editLayoutPG").style.display = "none"; 
                           }
                                                  
                           document.getElementById("wdesk:noIntMsg").style.display = "none";                                                                             

                           // Clearing  the interface layout when no workitem is present in the worklist/queue                                
                           var contDivRef = null;
                           if(wDeskLayout.WDeskType == 'E'){
                               contDivRef = document.getElementById("containerDiv");                           
                               contDivRef.style.display = "none";
                               document.getElementById("wdesk:referSuccessMsg").style.display = "block";   
                               clearEditableLayout(); 
                           } else if(wDeskLayout.WDeskType == 'R') {
                               contDivRef = document.getElementsByClassName("bscontwdiv")[0];
                               document.getElementById("wdesk:referSuccessMsg").style.display = "block"; 
                               clearRespLayout();
                           } else {
                               contDivRef = document.getElementById("fixedContainerDiv");                           
                               contDivRef.style.display = "none";
                               document.getElementById("wdesk:referSuccessMsg").style.display = "block";   
                               clearFixedLayout();
                           }       
                       } else if(actionStatus == "revokeFromMail") {
                           doCleanUp();                           
                           
                           // Hiding the content when no workitem is present in the worklist/queue 
                           document.getElementById("myMenuID").style.display = "none";
                           document.getElementById("wdesk:navigationPG").style.display = "none";
                           if(bRespWdesk){
                               var moreOpt=document.getElementById("menuMoreOpt");
                               var moreOptDiv=document.getElementById("MoreOptDiv");
                               removeCSS(moreOpt,"db");
                               removeCSS(moreOptDiv,"db");
                               addCSS(moreOpt,"dn");
                               addCSS(moreOptDiv,"dn");
                               if(document.getElementById("wdesk:editLayoutlbl"))
                                    replaceCSS(document.getElementById("wdesk:editLayoutlbl"), "db", "dn");
                           } else {
                               document.getElementById("wdesk:editLayoutPG").style.display = "none";                       
                           }
                           document.getElementById("wdesk:noIntMsg").style.display = "none";                                                                             

                           // Clearing  the interface layout when no workitem is present in the worklist/queue                                
                           var contDivRef = null;
                           if(wDeskLayout.WDeskType == 'E'){
                               contDivRef = document.getElementById("containerDiv");
                               contDivRef.style.display = "none";
                               document.getElementById("wdesk:revokeSuccessMsg").style.display = "block";   
                               clearEditableLayout(); 
                           } else if(wDeskLayout.WDeskType == 'R') {
                               contDivRef = document.getElementsByClassName("bscontwdiv")[0];
                               document.getElementById("wdesk:revokeSuccessMsg").style.display = "block";
                               clearRespLayout();
                           } else {
                               contDivRef = document.getElementById("fixedContainerDiv");                           
                               contDivRef.style.display = "none";
                               document.getElementById("wdesk:revokeSuccessMsg").style.display = "block";   
                               clearFixedLayout();
                           }
                       } else if(actionStatus == "closeNRefreshWI" && bWIOpenedFrmWList) {
                           if((typeof window!='undefined' && window!=null) && (typeof window.opener!='undefined' && window.opener!=null)){
						   if(IsWIOpenFromCaseBasket!=undefined && IsWIOpenFromCaseBasket){
								window.opener.reloadCaseBasket();
						   }else{
								window.opener.reloadWlistWrapper();
						   }
						   }
                            handleWindowClose();
                       } else if(actionStatus == "closeWI") { 
                           if(CalledFrom == 'M'){
                               // Hiding the content when no workitem is present in the worklist/queue 
                               document.getElementById("wdesk:title").style.visibility = "hidden";                           
                               document.getElementById("myMenuID").style.display = "none";
                               document.getElementById("wdesk:navigationPG").style.display = "none";
                               if (bRespWdesk) {
                                   var moreOpt = document.getElementById("menuMoreOpt");
                                   var moreOptDiv = document.getElementById("MoreOptDiv");
                                   removeCSS(moreOpt, "db");
                                   removeCSS(moreOptDiv, "db");
                                   addCSS(moreOpt, "dn");
                                   addCSS(moreOptDiv, "dn");
                                   if(document.getElementById("wdesk:editLayoutlbl"))
                                        replaceCSS(document.getElementById("wdesk:editLayoutlbl"), "db", "dn");
                                } else {
                                    document.getElementById("wdesk:editLayoutPG").style.display = "none";
                                }
                                                      
                               document.getElementById("wdesk:noIntMsg").style.display = "none";                                                  

                               // Clearing  the interface layout when no workitem is present in the worklist/queue 
                               var contDivRef = null;
                               if(wDeskLayout.WDeskType == 'E'){
                                   contDivRef = document.getElementById("containerDiv");                           
                                   clearEditableLayout(); 
                               } else if(wDeskLayout.WDeskType == 'R') {
                                  contDivRef = document.getElementsByClassName("bscontwdiv")[0];
                                 clearRespLayout();
                               } else {
                                   contDivRef = document.getElementById("fixedContainerDiv");                           
                                   clearFixedLayout();
                               }                       
                               //contDivRef.innerHTML = "";

                               contDivRef.style.border = "1px solid #A0A0A0";                           
                               document.getElementById("wdesk:noNextWIMsg").style.display = "block";
                               
                               oldWDJason = null;
                               newWDJason = null;
                           } else {
                               if(taskid!=''){                               
                                   try{
                                        hideTaskFromList(sourceInsId);
                                        if (typeof window.opener.parent.iFrameCaseCalenderRef != 'undefined') {
                                            window.opener.parent.iFrameCaseCalenderRef.compRefresh();
                                        }
                                        if (typeof window.opener.parent.iFrameTaskListRef != 'undefined') {
                                            window.opener.parent.iFrameTaskListRef.compRefresh();
                                        }
                                        if(window.opener==window.opener.parent.iFrameCaseCalenderRef){
                                            window.opener.parent.iFrameCaseBasketRef.compRefresh();
                                        }
                                    } catch (e) {}
                               }
							   if((typeof window!='undefined' && window!=null) && (typeof window.opener!='undefined' && window.opener!=null)){
								if(IsWIOpenFromCaseBasket!=undefined && IsWIOpenFromCaseBasket){
									window.opener.reloadCaseBasket();
								}
							   }
                           }
                           if(typeof introduceNDonePostHook != 'undefined'){
                               var option = document.forms["wdesk"].Option.value;
                               introduceNDonePostHook('closeWI',option);
                           }
                           handleWindowClose();
                       } else if(actionStatus == "error") {
                            var statusCode = document.getElementById("wdesk:errorMsg").value;
                            if(typeof data.requestObject != 'undefined' && (data.requestObject != null)){
                                var mainCode = data.requestObject.getResponseHeader("MainCode");
                                if(mainCode == "810_957"){
                                    //var desc = data.requestObject.getResponseHeader("Description");
                                    var msg = msg_nowi2;
                                    clearWDeskLayout(msg); 
                                    return;
                                }
                            }
                            
                            if(statusCode == "11"){
                                url = sContextPath+"/error/errorpage.app?msgID=4020";
                                url = appendUrlSession(url);

                                var width = 320;
                                var height = 160;
                                var left = (window.screen.availWidth-width)/2;
                                var top = (window.screen.availHeight-height)/2;
                                if (window.showModalDialog){
                                    window.showModalDialog(url,'',"dialogWidth:"+width +"px;dialogHeight:"+height+"px;center:yes;dialogleft: "+left+"px;dialogtop: "+top+"px");
                                }
                            }else{
                                var errormsg=document.getElementById("wdesk:errorMsg").value;
                                if(errormsg!=""){
                                    setmessageinDiv(errormsg, "true", 3000);
                                }
                            }                            
                        }
                        if (actionStatus != "error" && bWIOpenedFrmWList) {
                        if (typeof window.opener != 'undefined')
                                pwRef = window.opener;
                                if (pwRef != null && typeof pwRef.showWorkitemCount != 'undefined' && typeof pwRef.openWIInNewWindow != 'undefined') {
                        if (pwRef.showWorkitemCount && pwRef.openWIInNewWindow == "N") {
                        //pwRef.compRefresh(sourceInsId);
                        }
                        }
                        }
                   } 
               }
           }
           
           function getCaseWorkdesk(TargetPid,TargetWid,TargetTaskId,TargetActivityId){
                //var q = "Action=1&pid="+encode_utf8(TargetPid)+"&wid="+TargetWid+"&Option=OPENWI"+"&taskid="+TargetTaskId+"&wi_count="+wiCount+"&ActivityType="+strTargetActivityType+"&QueueId="+strBlockQueueId+"&QueueType="+strBlockQueueType;
                //var url = sContextPath+"/components/workitem/view/workdesk.app";
                var url=document.getElementById("wdesk:GrpBoxRedirectUrl").value;
                if(bWIOpenedFrmWList) {
                  window.opener.TargetActivityTypeWin=true;
                }
                window.location = url;
                document.getElementById("wdesk:GrpBoxRedirectUrl").value='';
               
           
           }
           
           function setOldWDJason(){
               oldWDJason = {
                    "PId" : pid,
                    "WId" : wid,                    
                    "taskid" : taskid,
                    "TaskName" : strtaskName,
                    "WDeskLayout" : wDeskLayout,
                    "MenuInfo" : myMenu,
                    "WindowProperty" : windowProperty,
                    "Wiproperty" : wiproperty,
                    "FormIndex" : strFormIndex,
                    "NGFormproperty" : ngformproperty,
                    "ActivityName" : stractivityName,
                    "RouteId" : strRouteId,
                    "ActivityId" : stractivityId,
                    "ActivityType" : stractivityType,
                    "Processname" : strprocessname,
                    "GeneralData" : strGeneralData,
                    "ShowNgAttribute" : showNgAttribute,
                    "AttType" : attType,
                    "NGAttribute" : ngattribute,
                    "DocOrgName" : DocOrgName,
                    "CheckAnnotRights" : checkAnnotRights,
                    "ConfirmAnnotationSave" : confirmAnnotationSave,
                    "RemoteIp" : strRemoteIp,
                    "DocCheckOut" : docCheckOut,
                    "Left" : strLeft,
                    "BatchFlag" : batchFlag,
                    "WICount" : v_wi_count,
                    "IsCustomWdesk" : false,
                    "WIViewMode": wiViewMode,
                    "QueueType" : queueType,
                    "DefaultNGForm" : bDefaultNGForm,
                    "AllDeviceForm" : bAllDeviceForm,
                    "AllDeviceTaskForm" : bAllDeviceTaskForm,
                    "subTaskId":subTaskId
                }

                if(newWDJason != null) {
                    oldWDJason.WICount = newWDJason.WICount;
                }
           }

           function reinitWDVariables(wdJason){
                pid = wdJason.PId;
                wid = wdJason.WId;
                taskid = wdJason.taskid;
                if(taskid==null || taskid==undefined || taskid=='')
                    winname = pid+"_"+wid;
                else
                    winname = pid+"_"+wid+"_"+taskid;
                
                subTaskId=wdJason.subTaskId;
                strtaskName=wdJason.TaskName;
                
                resetFixedWDeskInfo();
                wDeskLayout = wdJason.WDeskLayout;
                                
                if(wdView == "emwd"){
                    myMenu = parseJSON("("+wdJason.EmbMenuInfo+")");
                } else{
                    myMenu = parseJSON("("+wdJason.MenuInfo+")");
                }
                
                bDefaultNGForm = parseJSON("("+wdJason.DefaultNGForm+")");
                bAllDeviceForm = parseJSON("("+wdJason.AllDeviceForm+")");
                bAllDeviceTaskForm = parseJSON("("+wdJason.AllDeviceTaskForm+")");
                windowProperty = parseJSON("("+wdJason.WindowProperty+")");
                wiproperty = parseJSON("("+wdJason.Wiproperty+")");
                ngformproperty = parseJSON("("+wdJason.NGFormproperty+")");
                taskngformproperty = parseJSON("("+wdJason.TaskNGFormproperty+")");
                queueType = wdJason.QueueType;
                
                strGeneralData = wdJason.GeneralData;
                strFormIndex = wdJason.FormIndex;
                strRouteId = wdJason.RouteId;
                stractivityName = wdJason.ActivityName;
                stractivityId = wdJason.ActivityId;
                stractivityType = wdJason.ActivityType;
                strprocessname = wdJason.Processname;
                DocOrgName = wdJason.DocOrgName;
                checkAnnotRights = wdJason.CheckAnnotRights;
                confirmAnnotationSave = wdJason.ConfirmAnnotationSave;
                strRemoteIp = wdJason.RemoteIp;
                docCheckOut = parseInt(wdJason.DocCheckOut);
                strLeft = wdJason.Left;
                batchFlag = wdJason.BatchFlag;

                wiViewMode = wdJason.WIViewMode;
                showNgAttribute = wdJason.ShowNgAttribute;
                attType = wdJason.AttType;

                if(wiproperty.locked=="Y") {
                    saveTransFor = false;
                }

                ngattribute = "";
                if(wdJason.ShowNgAttribute == true || wdJason.ShowNgAttribute == "true") {
                    ngattribute = decode_utf8(wdJason.AttType);
                }
                
               if(wdJason.WDeskLayout.WDeskType == 'R'){
                    if(wdJason.WDeskLayout.InterfacesTabs){
                        /*
                            "WDeskLayout": {"InterfacesTabs": 
                                { "SAPGUIAdapter": {"SAP0": "SAPDefId1", "SAP1": "SAPDefId2"}},
                                { "TaskView": {"TaskView": "TaskView", "CaseView": "CaseView"}}
                            }
                        */

                        var interfaces = wdJason.WDeskLayout.InterfacesTabs["SAPGUIAdapter"];
                        if(interfaces){
                            interfaces = getObjectValues(interfaces);

                            if(interfaces[0]){
                                sapDefName0 = interfaces[0];
                            }
                            if(interfaces[1]){
                                sapDefName1 = interfaces[1];
                            }
                            if(interfaces[2]){
                                sapDefName2 = interfaces[2];
                            }
                            if(interfaces[3])
                                sapDefName3 = interfaces[3];
                        }
                    }
                }           
           }

           function initDefaultValues() {
                strSessionStr = '';
                docViewFlag = '';
                rightWidth = 0;
                newWidth = 0;
                
                if(wdView == "emwd"){
                    isEmbd = 'Y';
                } else {
                    isEmbd = 'N';
                }
                
                strAttribData = '';

                saveTransFor = true;
                docLoaded = false;
                formLoaded = false;
                isFormLoaded = false;
                expLoaded = false;
                todoLoaded = false;
                taskLoaded = false;
	        isTaskFormLoaded = true;
                sap0Loaded = false;
                sap1Loaded = false;
                sap2Loaded = false;
                sap3Loaded = false;
                sapLoaded = false;
                saveCalled=false;
                ngfrmBuffer="";
                showHide='Y';
                customChildCount=-1;
                changeEvt="";
                saveCheck=false;
                selectedExpId=null;
                unlockflag="Y"; //if unlockflag is Y then unlock workitem else donot call unlock on close;
            //    actionFlag="true";//TODO if actionflag is
            //    confirmSaveFlag=true;
            //    moreactionString="";
            //    strRemovefrommap="Y"; //to remove workitem from map
                
                formH = 400;
                formW = 600;
                //WIObjectSupport = 'N';
                curPos = 0;
                newPos = 0;
                mouseStatus = 'up'

                /*left = 400;
                if(strLeft=='')
                    strLeft="400";
                try {
                    left=strLeft;
                    if(left>(tableWidth-160))
                     left=tableWidth-160;
                } catch(e){
                    left=800;
                }*/

               heightH = wiHeight-150-23;
               //leftW = left;
              // thresholdWidth = 150;
               //marginLeft = 0;
               //leftW = parseInt(leftW) + marginLeft;
               /*if(interFace1 == "")
                   leftW=tableWidth/2-60;
               rightW = tableWidth-leftW-(60-marginLeft);

                formH = heightH+10;
                rightWid = rightW;
                leftWid=leftW;
                */
           }
           
           
           function initNLoadWorkitem(wdJason, bPrevNext,bloadCase) {
               bPrevNext = (typeof bPrevNext == 'undefined')? false: bPrevNext; 
               bloadCase = (typeof bloadCase == 'undefined')? false: bloadCase; 
               repositionCollapsedInterface();
                var oldNoNextWiMsg = false;
                var ref = document.getElementById("wdesk:noNextWIMsg");               
                if(ref.style.display != "none"){
                    oldNoNextWiMsg = true;
                }                
               
               // Hiding previous messages
                document.getElementById("wdesk:waitIndicator").style.display = "none";                
                document.getElementById("wdesk:noNextWIMsg").style.display = "none";                                
                document.getElementById("wdesk:messagedivPG").style.display = "none";
                
                initDocInterface();                
                
                var option = document.getElementById("Option").value;
                if(!bloadCase){
                    if(wdJason.taskid==null || wdJason.taskid==undefined || wdJason.taskid==''){
                        if(newWDJason != null) {
                            if((wdJason.PId == newWDJason.PId) && (wdJason.WId == newWDJason.WId) && (wdJason.ActivityId == newWDJason.ActivityId) && (wdJason.taskid == newWDJason.taskid) && (option != "REVOKESAVE") && (option != "REFERSAVE"))
                                return;
                        } else if((oldWDJason != null) && (wdJason.PId == oldWDJason.PId) && (wdJason.WId == oldWDJason.WId) && (wdJason.ActivityId == oldWDJason.ActivityId) && (wdJason.taskid == oldWDJason.taskid) && (option != "REVOKESAVE") && (option != "REFERSAVE")){
                            return;
                        }
                    }else{
                        if(newWDJason != null) {
                            if((wdJason.PId == newWDJason.PId) && (wdJason.WId == newWDJason.WId) && (wdJason.taskid == newWDJason.taskid) && (wdJason.ActivityId == newWDJason.ActivityId) && (wdJason.taskid == newWDJason.taskid) && (option != "REVOKESAVE") && (option != "REFERSAVE"))
                                return;
                        } else if((oldWDJason != null) && (wdJason.PId == oldWDJason.PId) && (wdJason.WId == oldWDJason.WId) && (wdJason.taskid == oldWDJason.taskid) && (wdJason.ActivityId == oldWDJason.ActivityId) && (wdJason.taskid == oldWDJason.taskid) && (option != "REVOKESAVE") && (option != "REFERSAVE")){
                            return;
                        }
                    }
                }
                if(!bloadCase){
                    if(wdView == "emwd"){
                        doCleanUpEmWd("UnloadWIEvent");
                    } else {
                        if(wdJason != null && wdJason != undefined) {                         
                            if(typeof wdJason.ErrorDesc != 'undefined' && wdJason.ErrorDesc != null && (typeof wdJason.MainCode != 'undefined') && wdJason.MainCode != null) {
                                if(wdJason.MainCode == "18"){
                                    if(prevNextUnlock == 'Y'){
                                        if(bPrevNext){
                                            doCleanUp('UnloadWIEvent', bPrevNext);
                                        } else {
                                            doCleanUp('UnloadWIEvent', false);
                                        }
                                    }
                                } else if(wdJason.MainCode == "810_957"){
                                    if(prevNextUnlock == 'N'){
                                        if(bPrevNext){
                                            doCleanUp('UnloadWIEvent', bPrevNext);
                                        } else {
                                            doCleanUp('UnloadWIEvent', false);
                                        }
                                    }
                                }
                            } else {

                                if(!oldNoNextWiMsg){  
                                    if(bPrevNext){
                                        doCleanUp('UnloadWIEvent', bPrevNext);
                                    } else {
                                        doCleanUp('UnloadWIEvent', false);
                                    }
                                }
                            }                         
                        }
                    }
                }

                if(wdJason != null && wdJason != undefined) {
                     if(wdView != "emwd"){                                              
                        if(wdJason.ErrorDesc != null && wdJason.ErrorDesc != undefined && wdJason.MainCode != null && wdJason.MainCode != undefined) {
                            if(wdJason.MainCode == "18"){
                               clearWDeskLayout();                               
                            } else if(wdJason.MainCode == "810_957"){
                                // WorkItem has already been processed
                                
                                var msg = msg_nowi2;
                                clearWDeskLayout(msg); 
                            } else {                                
                                setmessageinDiv(wdJason.ErrorDesc, "false", 3000);
                            }
                                                        
                           if((typeof window.opener != 'undefined') && (window.opener != null) && (typeof window.opener.bPrevNextOperation != 'undefined')){
                               window.opener.bPrevNextOperation = false;
                               window.opener.workitemNavType="";
                           }
                            
                           return;
                        } else if(wdJason.ErrorDesc != null && wdJason.ErrorDesc != undefined) {
                            setmessageinDiv(wdJason.ErrorDesc, "false", 3000);
                            
                            if((typeof window.opener != 'undefined') && (window.opener != null) && (typeof window.opener.bPrevNextOperation != 'undefined')){
                               window.opener.bPrevNextOperation = false;
                               window.opener.workitemNavType="";
                            }
                            
                            return;
                        }
                     }
                    
                    if(bNgFormRefresh){
                        tempWdJason = wdJason;
                    } else {
                        setOldWDJason();                        
                        reinitWDVariables(wdJason);
                        
                        if(wdView != "emwd"){ 
                            renderNavigation(wdJason.WICount);
                        }
                        
                        initDefaultValues();       
                        
                        if(wdView == "emwd"){ 
                            checkIsFormLoaded();
                        }

                        newWDJason = wdJason;
                        
                        if(wdJason.WDeskLayout.WDeskType == 'E'){
                            adjustInterfaces(wdJason, oldNoNextWiMsg);
                        } else if(wdJason.WDeskLayout.WDeskType == 'R'){
                            adjustRespInterfaces(wdJason, oldNoNextWiMsg);
                        } else {
                            adjustFixedInterfaces(wdJason, oldNoNextWiMsg);
                        }
                        
                        newWDJason.IsCustomWdesk = false;
                        
                        var URNorPid=wdJason.PId;
                        if(isURNEnable && wdJason.URN!=null && wdJason.URN!=''){
                             URNorPid=wdJason.URN;
                        }
                        
                        if(wdView == "emwd"){                                  
                            displayMenu('myMenuID');
                            document.getElementById("myMenuID").style.display = "block";
                        }
                        reinitFormElement(wdJason);
                        
                        if(wdView == "emwd"){
                           if(wdJason.WIViewMode=="R"){
                               window.parent.changePanelTitle(compInsId, stractivityName + " : "+URNorPid+" "+TITLE_READONLY);
                           } else {
                               window.parent.changePanelTitle(compInsId, stractivityName + " : "+URNorPid);
                           }
                        }
                        
                        if(wdView != "emwd"){
                            // re-initialize menu items
                            prepareWdeskDefaultMenu();
                            document.getElementById("myMenuID").style.display = "block";
                        
                            if(!isEnableDownloadFlag(strprocessname,stractivityName)){
                                if(document.getElementById('wdesk:downloadDiv'))
                                   document.getElementById('wdesk:downloadDiv').style.display='none';
                            }

                            if(!isEnableEditDocFlag(strprocessname,stractivityName)){
                                 if(document.getElementById('wdesk:editDocDiv'))
                                    document.getElementById('wdesk:editDocDiv').style.display='none';
                            }
                        }
                    }
                }
           }
           
           function ngRefreshCallback(){
                var wdJason = tempWdJason;                
                setOldWDJason();
                reinitWDVariables(wdJason);
                
                if(wdView != "emwd"){ 
                    renderNavigation(wdJason.WICount);
                }

                initDefaultValues();       
                
                if(wdView == "emwd"){ 
                    checkIsFormLoaded();
                }

                newWDJason = wdJason;
                
                if(wdJason.WDeskLayout.WDeskType == 'E'){
                    adjustInterfaces(wdJason);
                } else {
                    adjustFixedInterfaces(wdJason);
                }
                
                newWDJason.IsCustomWdesk = false;

                if(wdView == "emwd"){                                  
                    displayMenu('myMenuID');
                    document.getElementById("myMenuID").style.display = "block";
                }
                
                reinitFormElement(wdJason);
                
                if(wdView == "emwd"){
                       if(wdJason.WIViewMode=="R"){
                       window.parent.changePanelTitle(compInsId, stractivityName + " : "+wdJason.PId+" "+TITLE_READONLY);
                   } else {
                       window.parent.changePanelTitle(compInsId, stractivityName + " : "+wdJason.PId);
                   }
                }

                if(wdView != "emwd"){
                    // re-initialize menu items
                    prepareWdeskDefaultMenu();
                    document.getElementById("myMenuID").style.display = "block";
                    
                    if(!isEnableDownloadFlag(strprocessname,stractivityName)){
                        if(document.getElementById('wdesk:downloadDiv'))
                           document.getElementById('wdesk:downloadDiv').style.display='none';
                    }

                    if(!isEnableEditDocFlag(strprocessname,stractivityName)){
                         if(document.getElementById('wdesk:editDocDiv'))
                            document.getElementById('wdesk:editDocDiv').style.display='none';
                    }
                }
                
                bNgFormRefresh = false;
           }
           
           function resizeCompWH(height,width){ 
                compHeight = height;
                compWidth = width;
                
                if(wDeskLayout.WDeskType == 'E'){
                    renderWDesk();
                } else {
                    renderFixedWDesk();
                }
                
                resizeWiInterfaces(wdView);
           }
           
           function ReloadWorkitem(processInstanceID, workitemID, wi_count, Option, QueueId, QueueType, allowreassignment, InstrumentListCallFlag, InstrumentListSortOrder, InstrumentListOrderBy, ArchivalMode, srcInsId){
                if(processInstanceID=="" && workitemID==""){
                    window.parent.changePanelTitle(compInsId, "");
                    window.location = "/webdesktop/components/workitem/view/workdesk.app?Action=1&wdView=em&WD_SID="+WD_SID+"&Comp_width="+compWidth+"&Comp_height="+compHeight+"&wi_count="+wi_count+"&Option="+Option+"&InstrumentListSortOrder="+InstrumentListSortOrder+"&InstrumentListOrderBy="+InstrumentListOrderBy+"&allowreassignment="+allowreassignment+"&InstrumentListCallFlag="+InstrumentListCallFlag+"&QueueId="+QueueId+"&Comp_ins_id="+compInsId+"&QueueType="+QueueType+"&FormView="+formView+"&TodoListView="+todoListView+"&TaskView="+taskView+"&DocumentView="+documentView+"&ExceptionView="+exceptionView+"&ArchivalMode="+ArchivalMode;
                    return ;
               }
               
               var qString  = "Action="+encode_ParamValue('1') + "&ProcessInstanceID="+encode_utf8(processInstanceID)+"&WorkitemID="+workitemID+"&wdView="+wdView+ "&FormView=Y&TodoListView=Y&TaskView=Y&DocumentView=Y&ExceptionView=Y&ArchivalMode="+ArchivalMode;
               var wdJason = getWDJason(qString, 'N');
               
               if(wdJason != null && wdJason != undefined) {
                    if(wdJason.ErrorDesc != null && wdJason.ErrorDesc != undefined) {
                        //setmessageinDiv(wdJason.ErrorDesc, "false", 3000);                        
                        window.parent.parent.initPopUp();
                        window.parent.parent.setPopupMask();
                        window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe','/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message='+wdJason.ErrorDesc,140,280);
                        window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 201;
                        return;
                    }
               }
               
               // Hiding previous messages               
               document.getElementById("wdesk:messagePG").style.display = "none";
               
               // Showing content holder
               document.getElementById("wdesk:placeHolder").style.display = "block";
               
               sourceInsId = srcInsId;
               // Setting this window reference in workitemlist component window for other event handling
               srcCompWinRef = window.parent.getComponentRef(sourceInsId).contentWindow;	
               srcCompWinRef.targetEmbdWIRef = window;	
               
               // Updating workitem count
               if(wdJason != null && wdJason != undefined) 
                    wdJason.WICount = wi_count;
               
               // Delegating the initialization and Loading of workitem task to Standard workdesk renderer
               initNLoadWorkitem(wdJason);
            }
            
            function doCleanUpEmWd(from){
                if(typeof from == 'undefined'){
                    from = '';
                }
                
                if(navigator.appName.indexOf("Netscape") != -1 && wiproperty.formType=="NGFORM" && ngformproperty.type=="applet"){
                } else if(wiproperty.formType=="CUSTOMFORM") {
                    saveCalled=true;
                } else if(wiproperty.formType=="NGFORM" && saveCalled!=true) {
                    var formBuffer1;
                    
                   if(!(ngformproperty.type=="applet"))
                   {
                       if(document.wdgc){
                            var MAIN_SEPARATOR = "\u00B6";
                            formBuffer1 = new String(document.wdgc.FieldValueBag);
                            var tempArray = formBuffer.split(MAIN_SEPARATOR);
                            var formArray = formBuffer1.split(MAIN_SEPARATOR);
                            for ( var i=0;i<formArray.length;i++) {
                               if(formArray[i]!=tempArray[i])
                                  saveCalled=true;
                            }
                       }
                   } else {
                       if(!bDefaultNGForm){     
                            var ngformIframe = document.getElementById("ngformIframe");	
                            if(ngformIframe != null){
                                var isValueChanged = false;
                                try{
                                    if(bAllDeviceForm){
                                        isValueChanged = ngformIframe.contentWindow.eval("isValueChanged()");
                                    } else {
                                        isValueChanged = ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.isValueChanged()");
                                    }
                                }catch(e){}
                                
                                if(isValueChanged){
                                    saveCalled=true;
                                }
                            }                               
                       } else {
                           if(document.wdgc){
                              formBuffer1=document.wdgc.getFieldValueBagEx();
                              //formBuffer1=formBuffer1+"";
                               if(formBuffer1!=formBuffer && formBuffer!=undefined)
                                  saveCalled=true;
                           }
                       }
                   }
                    
                }

                //if(window.top.toUnlock==true)
                freeWorkitem('',from);
                //window.top.toUnlock=true;
                closewindows(windowList);
                try{
                   SetCookies();
                   if(window.opener)
                        removeFromArray(window.opener.workitemList,winname);

                    removeIFramePopup('MoreAct');

               } catch(e){;}       
                              
               if(from == "beforeunload"){        
                    srcCompWinRef.afterWIDoCleanup(null, true);
               }
               
               stopPrintScreen();
            }
            function stopBackspace(e){
                var t=e.target.type;
                var kc=e.keyCode;
                if(e.which==119){
                 if(typeof ToggleFocus != 'undefined' && typeof isEmbd != 'undefined' && isEmbd=="N" && e.altKey)
                     ToggleFocus("F");
                }
                else if (e.which == 109) {
                if(typeof ToggleFocus != 'undefined' && typeof isEmbd != 'undefined' && isEmbd=="N" && e.altKey)
                     ToggleFocus("D");
               } else if(kc == 116) {
                   var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1;
                   var isNetscape = navigator.appName.toLowerCase().indexOf('netscape') > -1;

                    if(isSafari || isNetscape) {
                        e.keyCode = 0; //Bug 56898
                        return false;
                    }else {
                        e.cancelBubble = true;
                        return false;
                    }
                }
                else if ((window.event.keyCode != 8) || ( t == 'text' ) || (t == 'textarea') || ( t == 'submit') || (t == 'password')){                    
                    return true;
                }
                else{
                    if(e.stopPropogation)
                        e.stopPropogation(true);
                    if(e.preventDefault)
                        e.preventDefault(true);
                    e.cancelBubble = true;
                    return false;
                }               
            }
            
            function RefreshNCloseWorklist()
            {
                if(bWIOpenedFrmWList) {
                window.opener.reloadWlistWrapper();
                }
                self.close();
            }
            
            function disableCtrlKeyCombination(e) {                        
                        var forbiddenKeys = new Array('u','r');   // list all CTRL + key combinations you want to disable
                        var key;
                        var isCtrl;
                        if(window.event)
                        {
                            key = window.event.keyCode;     //IE
                            if(window.event.ctrlKey)
                                isCtrl = true;
                            else
                                isCtrl = false;
                        }
                        else
                        {
                            key = e.which;     //firefox
                            if(e.ctrlKey)
                                isCtrl = true;
                            else
                                isCtrl = false;
                        }
                        
                        if(isCtrl) //if ctrl is pressed check if other key is in Forbidden Keys array
                        {
                            for(i=0; i <forbiddenKeys.length; i++)
                            {
                                //case-insensitive comparation
                                if(forbiddenKeys[i].toLowerCase() == String.fromCharCode(key).toLowerCase())
                                {
                                    return false;
                                }
                            }
                        }
                        return true;
               }
               
        var UAString = navigator.userAgent;
        var isFirefox = navigator.userAgent.toLowerCase().indexOf("firefox") > 0;
        if (((navigator.appName=='Netscape' ) &&  !(UAString.indexOf("Trident") !== -1 && UAString.indexOf("rv:11") !== -1)?false:true) || window.chrome || isFirefox){ //Works for IE and Chrome
                document.onkeydown = function(e) 
            {
                var t=event.srcElement.type;
                var kc=event.keyCode;   
                if(isFirefox) {
                    if((event.keyCode==112 || event.which==112 || event.keyCode==80 || event.which==80) && event.ctrlKey){    
                        //Ctl+P (Print)
                        defaultPrint = true;
                    }   
                } else {
                    if((event.keyCode==80 || event.which==80) && event.ctrlKey){    
                        //Ctl+P (Print)
                        defaultPrint = true;
                    }  
                }
                 if (121 == kc || 116 == kc) {
                        event.keyCode = 0;
                        return false;
		}
                if( disableCtrlKeyCombination(e)==false) {
                        return false;
		}
                if(event.keyCode==69 && event.altKey){                    
                   if(typeof isEmbd != 'undefined' && isEmbd=="N" ){
                    if(document.getElementById('wdesk:enexp') || document.getElementById('wdesk:disexp')){                    
                    if(typeof  interFace0!='undefined'){
                        if(interFace0=="exp" && interFace2!=""){
                            toggleIntFace("exp",interFace2);
                        }
                        else if(interFace1=="exp" && interFace3!=""){
                            toggleIntFace("exp",interFace3);
                        }
                        else if(interFace2=="exp" && interFace0!=""){                            
                            toggleIntFace("exp",interFace0);
                        }
                        else if(interFace3=="exp" && interFace1!=""){
                            toggleIntFace("exp",interFace1);
                        }
                    }
                   try{
                       document.getElementById('enexp').focus();
                     }catch(ex){
                      }

                    }
                     ToggleFocus("E");
                   }
               }

               else if(event.keyCode==84 && event.altKey){
                   if(typeof isEmbd != 'undefined' && isEmbd=="N" ){
                       if(document.getElementById('wdesk:entodo') || document.getElementById('wdesk:distodo')){
                        if(typeof  interFace0!='undefined'){
                            if(interFace0=="todo" && interFace2!=""){
                                toggleIntFace("todo",interFace2);
                            }
                            else if(interFace1=="todo" && interFace3!=""){
                                toggleIntFace("todo",interFace3);
                            }
                            else if(interFace2=="todo" && interFace0!=""){
                                toggleIntFace("todo",interFace0);
                            }
                            else if(interFace3=="todo" && interFace1!=""){
                                toggleIntFace("todo",interFace1);
                            }
                        }
                        try{
                           document.getElementById('entodo').focus();
                        }catch(ex){
                      }
                   }
                       ToggleFocus("T");
                }
               }

                else if(event.keyCode==70 && event.altKey){
                   if(typeof isEmbd != 'undefined' && isEmbd=="N" ){
                      if(document.getElementById('wdesk:enform') || document.getElementById('wdesk:disform')){
                        if(typeof  interFace0!='undefined'){
                            if(interFace0=="form" && interFace2!=""){
                                toggleIntFace("form",interFace2);
                            }
                            else if(interFace1=="form" && interFace3!=""){
                                toggleIntFace("form",interFace3);
                            }
                            else if(interFace2=="form" && interFace0!=""){
                                toggleIntFace("form",interFace0);
                            }
                            else if(interFace3=="todo" && interFace1!=""){
                                toggleIntFace("form",interFace1);
                            }
                        }
                     }
                    
                      try{
                          if((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm){
                            var ngformIframe = document.getElementById("ngformIframe");	
                            if(ngformIframe != null){
                                try{
                                    ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.focus()");	
                                } catch(e){                                    
                                }
                            }
                         } else {
                             if((typeof document.wdgc != 'undefined') && document.wdgc)
                             {
                                document.wdgc.NGFocus();
                             }
                         }
                         }catch(ex){
                          }
                        ToggleFocus("F");
                     }
                   }
                else if(event.keyCode==87 && event.altKey){
                 if(typeof ToggleFocus != 'undefined' && typeof isEmbd != 'undefined' && isEmbd=="N" ){
                    if(document.getElementById('wdesk:endoc') || document.getElementById('wdesk:disdoc')){
                        if(typeof  interFace0!='undefined'){
                            if(interFace0=="doc" && interFace2!=""){
                                toggleIntFace("doc",interFace2);
                            }
                            else if(interFace1=="doc" && interFace3!=""){
                                toggleIntFace("doc",interFace3);
                            }
                            else if(interFace2=="doc" && interFace0!=""){
                                toggleIntFace("doc",interFace0);
                            }
                            else if(interFace3=="doc" && interFace1!=""){
                                toggleIntFace("doc",interFace1);
                            }
                        }
                     }
                      if(document.IVApplet)
                      {
                       try{
                            document.IVApplet.setIVFocus();
                         }catch(ex){
                            }
                      }
                      ToggleFocus("D");
                 }
                }
                else if(event.keyCode==83 && event.altKey){
               workdeskOperations('S');
                }
                else if(event.keyCode==73 && event.altKey){
                workdeskOperations('I');
                }
                else if (kc == 116) {
                    window.event.keyCode = 0;
                    return false;
                }
                else
                    {                        
                        return ((kc != 8 ) || ( t == 'text') || (t == 'textarea') || ( t == 'submit') ||  (t == 'password'));
                    }
            }
        }
        else{
             document.onkeypress = function(e)  // FireFox/Others
            {      
                var t=e.target.type;
                var kc=e.keyCode;
                 if ((121 == kc || 116 == kc) && ( navigator.userAgent.toString().toLowerCase().indexOf("mozilla") == -1 && navigator.userAgent.indexOf("Safari") == -1 )) {
                            e.keyCode = 0;
                            return false;
                }
                if( disableCtrlKeyCombination(e)==false) {
                            return false;
		}
                if(e.which==119){
                 if(typeof ToggleFocus != 'undefined' && typeof isEmbd != 'undefined' && isEmbd=="N" && e.altKey)
                     ToggleFocus("F");
                }
                else if (e.which == 109) {
                if(typeof ToggleFocus != 'undefined' && typeof isEmbd != 'undefined' && isEmbd=="N" && e.altKey)
                     ToggleFocus("D");
               } else if(kc == 116) {
                   var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1; 
                   var isNetscape = navigator.appName.toLowerCase().indexOf('netscape') > -1;

                    if(isSafari || isNetscape) {
                        e.cancelBubble = true;
                        return true;
                    }else {
                        e.cancelBubble = true;
                        return false;
                    }
                }
                else if ((e.which != 8) || ( t == 'text' ) || (t == 'textarea') || ( t == 'submit') || (t == 'password')){                    
                    return true;
                }
                else{
                    if(e.stopPropogation)
                        e.stopPropogation(true);
                    if(e.preventDefault)
                        e.preventDefault(true);
                    e.cancelBubble = true;
                    return false;
                }                
           }
        }
            
function refreshWorkitemList(){   
    extSourceType = (typeof extSourceType == 'undefined')? '': extSourceType;       
    
    if(extSourceType == 'QL'){
        var qid = document.getElementById("QueueId").value;
        var qType = document.getElementById("QueueType").value;
        var wlistRef = window.opener;
        if(typeof wlistRef != 'undefined'){
            if(typeof wlistRef.parent != 'undefined'){
                if(typeof wlistRef.parent.iFrameWorkitemListRef != 'undefined'){
                    var wlistQId = wlistRef.parent.iFrameWorkitemListRef.document.getElementById("wlf:hidQueueId").value;
                    var wlistQType = wlistRef.parent.iFrameWorkitemListRef.document.getElementById("wlf:hidQueueType").value;
                    if((wlistQId == qid) && (wlistQType == qType)){
                        wlistRef.parent.iFrameWorkitemListRef.compRefresh();
                    }
                }                
            }
        }
    }
}           

function resizeWorkdeskWindow() {
    var oldWDJason = getWDeskJason();
    wDeskLayout = oldWDJason.WDeskLayout;
    
    if(wDeskLayout.WDeskType == 'E'){
        renderWDesk();
    } else {
        renderFixedWDesk();
    }
    
    resizeWiInterfaces("Resize");
    updateCustomFormScroller();
    
    if(isOpAll == "Y" && opall) {
        var cHeight = document.getElementById('docDiv').style.height.split('p')[0];
        document.getElementById('wdesk:ifrm').style.height = cHeight + 'px';
        document.getElementById('docviewer').height = (cHeight -30) + 'px';
    }
}
function reloadCaseWI(){
    var pid = encode_ParamValue(document.getElementById("wdesk:pid").value);
    var wid = encode_ParamValue(document.getElementById("wdesk:wid").value);
    var wiCount = parseInt(encode_ParamValue(document.getElementById("wdesk:wi_count").value));
    var qString  = "Action="+encode_ParamValue('1') + "&ProcessInstanceID="+encode_utf8(pid)+"&WorkitemID="+wid+"&wdView="+wdView+ "&FormView=Y&TodoListView=Y&TaskView=Y&DocumentView=Y&ExceptionView=Y&ArchivalMode="+ArchivalMode;
    var wdJason = getWDJason(qString, 'N');
    if(wdJason != null && wdJason != undefined) {
        if(wdJason.ErrorDesc != null && wdJason.ErrorDesc != undefined) {
            //setmessageinDiv(wdJason.ErrorDesc, "false", 3000);                        
            window.parent.parent.initPopUp();
            window.parent.parent.setPopupMask();
            window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe','/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message='+wdJason.ErrorDesc,140,280);
            window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 201;
            return;
        }
    }
    // Hiding previous messages               
    document.getElementById("wdesk:messagePG").style.display = "none";
    
    // Showing content holder
    document.getElementById("wdesk:placeHolder").style.display = "block";
    
    // Updating workitem count
    //wdJason.WICount = wi_count;
    
    initNLoadWorkitem(wdJason,false,true);
}