

var windowH = 360;
var windowW = 480;
var windowX = (window.screen.availHeight - windowH)/2;
var windowY = (window.screen.availWidth - windowW)/2;

var window1H = 480;
var window1W = 640;
var window1X = (window.screen.availHeight - window1H)/2-30;
var window1Y = (window.screen.availWidth - window1W)/2;

var window2H = 260;
var window2W = 250;
var window2X = (window.screen.availHeight - window2H)/2;
var window2Y = (window.screen.availWidth - window2W)/2;

var window3H = 490;
var window3W = 640;
var window3X = (window.screen.availHeight - window3H)/2-30;
var window3Y = (window.screen.availWidth - window3W)/2;

var window4H = 160;
var window4W = 210;
var window4X = (window.screen.availHeight - window4H)/2;
var window4Y = (window.screen.availWidth - window4W)/2;

var window5H = 500;
var window5W = 760;
var window5X = (window.screen.availHeight - window5H)/2 - 10;
var window5Y = (window.screen.availWidth - window5W)/2 - 5;

var windowVH = 180;
var windowVW = 280;

var window6H = 530;
var window6W = 640;
var window6X = (window.screen.availHeight - window6H)/2-30;
var window6Y = (window.screen.availWidth - window6W)/2;

var window7H = 384;
var window7W = 512;
var window7X = (window.screen.availHeight - window7H)/2-30;
var window7Y = (window.screen.availWidth - window7W)/2;

var window8H = 444;
var window8W = 690;
var window8X = (window.screen.availHeight - window8H)/2-30;
var window8Y = (window.screen.availWidth - window8W)/2;

var winH=window.screen.availHeight;
var iframeChildren = new Array();
var hexArr = new Array('0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F');

var ScreenHeight=screen.height;
var ScreenWidth=screen.width;
var tempAdhocStatus=1;
var tempLockStatus=1;
var allWindows = new Array();
var GLRowCount=0;

document.oncontextmenu = checkContextMenu; //Disable Right Click

window.onkeydown = handleBackPress1;
 
function handleBackPress1(e) {
	var targetType = e.target.type;
	if(typeof targetType == 'undefined' || targetType == null) {
		targetType = "";
	} else {
		targetType = targetType.toLowerCase();
	}

    if (e.keyCode == 8 && targetType != 'text' && targetType != 'textarea') {
        e.preventDefault();
        return false;
    }
}

function checkContextMenu(e)
{
    var element='';
    if (typeof window.event != 'undefined')
    {
        element= event.srcElement;
    }
    else
    {
        element=e.target;
    }
    return isInvaildKeyForElement(element);
}
if (typeof window.event != 'undefined'){ // IE
    document.onkeydown = function(e) // IE
    {
        var t=event.srcElement.type;
        var kc=event.keyCode;
        if (kc == 116) {
            window.event.keyCode = 0;
            return false;
        }
        else
            return ((kc != 8 ) || isInvaildKeyForElement(event.srcElement))
    }
}
else{
    document.onkeypress = function(e)  // FireFox/Others
    {
        var t=e.target.type;
        var kc=e.keyCode;
        if(kc == 116) {
            var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1; 
            var isNetscape = navigator.appName.toLowerCase().indexOf('netscape') > -1;

            if(isSafari || isNetscape) {
                e.cancelBubble = true;
                return true;
            }else {
                e.cancelBubble = true;
                return false;
            }
        }
        else if ((kc != 8) || isInvaildKeyForElement(e.target))
            return true;
        else
            return false;
    }
}


function isInvaildKeyForElement(element)
{
    var type=element.type;
    if( type == 'submit')
    {
        return true;
    }
    else if(( type == 'text' ) || (type == 'textarea') || (type == 'password'))
    {
        if(element.readOnly)
            return false;
        else
            return true;
    }else
    {
        return false;
    }
}

function StyleRowLink(ref)
{
    ref.className = 'wdSelected';

}
function StyleRowNormal(ref)
{
     ref.className = 'wdSimple';
}

function getShortNameTest(Name,size)
{
    if (Name.length > size + 5)
    {
        var Temp1 = replace(Name, ">", "&gt;");
        Temp1 = replace(Temp1, "<", "&lt;");
        Temp1 = replace(Temp1, "\"", "&quot;");
        tempName = Name.substring(0, size);
        tempName = replace(tempName, ">", "&gt;");
        tempName = replace(tempName, "<", "&lt;");
        tempName = replace(tempName, "\"", "&quot;");

        Name1 = tempName + "...";
        return Name1;
    }
    else
    {
        Temp1 = replace(Name, ">", "&gt;");
        Temp1 = replace(Temp1, "<", "&lt;");
        Temp1 = replace(Temp1, "\"", "&quot;");
        return Temp1;
    }
}

function replace(str, oldStr, newStr)
{
	var iPos = 0;
	var tempStr = "";
	var iOldStrLen = oldStr.length;
	str += '';
	while ((iPos = str.indexOf(oldStr)) != -1)
    {
    	tempStr = tempStr + str.substring(0, iPos) + newStr;
		str = str.substring(iPos + iOldStrLen);
	}
	tempStr = tempStr + str;
	return tempStr;
}

function selectOneCheckBox(ref, checkBoxId)
{
    var arr = ref.id.split(":");
    var iArrLength = arr.length ;
    var strName = "";
    var selectedRow = arr[iArrLength-2];

    for (var count=0; count < arr.length-2 ; count++ )
    {
        if(count==0)
            strName = arr[count] ;
        else
        {
            strName=strName + ":" + arr[count] ;
        }
    }
    var nodeChkBox=document.getElementById(strName+":"+selectedRow +":"+checkBoxId);
    var rowCount = nodeChkBox.parentNode.parentNode.parentNode.rows.length;
    if(nodeChkBox.checked == true)
    {
        for(iCount = 0; iCount < rowCount;iCount++)
        {
            if(iCount != arr[iArrLength-2])
            {
                var el=document.getElementById(strName+":"+iCount +":"+checkBoxId);
                el.checked=false;

            }
        }
    }
}

function createPopUpIFrameWrapper(IFrameId,srcUrl,scrollFlag,frameHeight,frameWidth,objFrameParent) {
    
    var trui= getActionUrlFromURL(srcUrl);
    var servletUrl = sContextPath+"/secuidsv";
    (typeof WD_SID != 'undefined' && WD_SID != null) && (servletUrl += "?WD_SID=" + WD_SID);
            
    var xhReq = createXMLHttpRequest();
    //createIndicator(indicatorid);
    xhReq.open("POST", servletUrl, true);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhReq.onreadystatechange = onResponse;
    xhReq.send("T-URI="+trui);
   // xhReq.send();
    
    function onResponse() {        
        try {
            
            var mdm_rid;
            
            if (xhReq.readyState==4) { 
                if (xhReq.status==200) {

                   mdm_rid =  xhReq.getResponseHeader("WD_RID");                   
                    
                    createPopUpIFrame(IFrameId,srcUrl+"&WD_RID="+mdm_rid,frameHeight,frameWidth)
                } 
            }
            
        } catch(e) {
            alert(ERROR_FETCHING_DATA);
        }
    }
}


function createPopUpIFrame(IFrameId,srcUrl,height,width)
{
    var ParentDocWidth = document.body.clientWidth;
    var ParentDocHeight = document.body.clientHeight;
    var IFrameTop=ParentDocHeight/2-height/2;
    var IFrameLeft=ParentDocWidth/2-width/2;
    try
    {
        var finalWindow=window;
        if(finalWindow.document.getElementById(IFrameId) != null)
            return;

        iframe=finalWindow.document.createElement("IFRAME");
        iframe.style.zIndex = "1001";

        iframe.setAttribute("allowtransparency","true");
        iframe.allowtransparency="true";
        iframe.style.allowtransparency="true";

        iframe.setAttribute("src",srcUrl);
        iframe.setAttribute("name", IFrameId);
        iframe.setAttribute("id", IFrameId);

        iframe.frameBorder="0";
        iframe.style.frameBorder="0";

        iframe.scrolling="no";
        iframe.style.scrolling="no";

        iframe.style.visibility="visible";
        iframe.style.position="absolute";

        iframe.style.width= width+"px";
        iframe.style.height=height+"px";
        iframe.className = "iframeShadow ";

        iframe.style.left = IFrameLeft+"px";
        iframe.style.top = IFrameTop+"px";
        // iframe.style.backgroundColor="gray";

        refFrame=finalWindow.document.body.appendChild(iframe);
        refFrame.parent=finalWindow;
    }
    catch(ex)
    {
    //alert("exception= "+ex);
    }
}

function removeIFrame(IFrameId)
{
    try
    {
        var  parent = window.parent;
        //alert(parent);
        var iframe= parent.document.getElementById(IFrameId);
        //alert(iframe);
        // alert(IFrameId);
        //parent.document.body.removeChild(iframe);
        iframe.parentNode.removeChild(window.parent.document.getElementById(IFrameId));
    }
    catch(ex){
    //alert("Exception -...++++..." + ex);
    }
}
function ClickAnotherLink(ref,toclick)
{
    var formid="";

    try
    {
        var formid=ref.form.id;
    }
    catch(e)
    {
        formid=document.forms[0].id;
    }
    var toclickid=formid+':'+toclick;

    clickLink(toclickid);
    
}

function isChromium() { 
    // Actually, isWithChromiumPDFReader : detects chrome against chromium browser
    for (var i=0; i<navigator.plugins.length; i++)
        if (navigator.plugins[i].name == 'Chromium PDF Viewer') return true;
    return false;
}

function clickLink(linkId)
{    
    if(!linkId)
    {
        return false;
    }
        
//    if(typeof window.chrome != 'undefined'){
//        // !isChrome() is fallback condition of chromium for clickLinkSafari
//        if(isChromium()){
//           clickLinkSafari(linkId);
//           return;
//        }
//    }

    var fireOnThis = document.getElementById(linkId);
    
    if(fireOnThis != null && (fireOnThis.nodeName.toUpperCase() == "A")){
        if(fireOnThis.href.lastIndexOf("#") > -1){
            fireOnThis.href = "javascript:void(0)";
        }
    }
    if (fireOnThis != null) {
        if (document.createEvent)
        {
            //var evObj = document.createEvent('MouseEvents') ;
            //evObj.initEvent( 'click', true, false ) ;
            //fireOnThis.dispatchEvent(evObj) ;
            var evObj = document.createEvent('MouseEvents');
            evObj.initMouseEvent("click", false, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
            fireOnThis.dispatchEvent(evObj);
        }
        else if (document.createEventObject)
        {
            fireOnThis.click();

        }
    }
    return ;
}

function onmouseoverEvent(ref, imageURL)
{
    ref.src = "/omniapp/resources/images/"+imageURL;
}

function onmouseoutEvent(ref, imageURL)
{
    ref.src = "/omniapp/resources/images/"+imageURL;
}



function PrevBatch(){
    clickLink("wlf:prevLink");
}
function NextBatch(){
    clickLink("wlf:nextLink");
}

function ReloadSetFilter(queueId,queuename)
{
    if(queueId!=undefined){
        document.getElementById('filterWorkItemList:queueid').value=queueId;
    }

    if(queuename!=undefined)
    {
        document.getElementById('filterWorkItemList:queuename').value=queuename;
    }

    clickLink("filterWorkItemList:reloadSetFilter");

}

function getValueFromPX(pxValue) {
    var intValue;
    intValue = pxValue.substring(0, pxValue.indexOf("px")) - 0
    return intValue;
}

function adjustCustomWL(containerDiv, iframeRef) {
    if (typeof containerDiv != 'undefined' && containerDiv != null && typeof iframeRef != 'undefined' && iframeRef != null)
    {
        $(iframeRef).width($(containerDiv).width() + 'px');
        $(iframeRef).height(($(containerDiv).height() - 24) + 'px');

    }

}

var showSave="Y";
var timeOutId='';
function ReloadWorkitemList(queueId,queuename,queuetype,allowReassign,order,sortingorder,batchSize,batchingFlag){
    try{  
        var wlscrollleft = document.getElementById("wlf:wlscrollleft");
        if (wlscrollleft) {
            if(pageDirection == "rtl")
                         wlscrollleft.value  = window.outerWidth + 36;
            else                   
                         wlscrollleft.value = "";
        }
        var openFrom = document.getElementById('wlf:OpenFrom');                
        if((typeof openFrom == 'undefined') || (openFrom == null) || (typeof CurrentlyProcessing == 'undefined') || CurrentlyProcessing) {
            //alert(WORKITEM_LIST_CURRENTLY_LOADING);
            //var ref = document.getElementById("wlf:messagePanel:genMessageLabel");
            //showGenMessage(ref, WORKITEM_LIST_CURRENTLY_LOADING, 270, 80);
            return false;
        }
        CurrentlyProcessing=true;
    
        hidePopupMask();
    
        showSave="Y";
        
        WICountCallCheck="N";
        //alert(queueId);
        if(queueId!=undefined){
            document.getElementById('wlf:hidQueueId').value=queueId;
            document.getElementById('wlf:hidOrigQueueId').value=queueId;
        }else{
            document.getElementById('wlf:hidQueueId').value=queueId;
            document.getElementById('wlf:hidOrigQueueId').value=queueId;
        }
        if(queuetype!=undefined)
        {
            if(queuetype.indexOf(":")>0){
                var index=queuetype.indexOf(":");
                var qType=queuetype.substring(0, index);
                var refreshInterval=queuetype.substring(index+1);
    //            alert('refreshInterval-'+refreshInterval);
                document.getElementById('wlf:hidQueueType').value=qType;
                document.getElementById('wlf:hidRefreshInterval').value=refreshInterval;
            }else{
                document.getElementById('wlf:hidQueueType').value=queuetype;
                document.getElementById('wlf:hidRefreshInterval').value='';
            }
        }else{
            document.getElementById('wlf:hidQueueType').value=queuetype;
        }
        if(queuename!=undefined && queuename!="")
        {
            document.getElementById('wlf:hidQueueName').value=queuename;
            document.getElementById('wlf:hidOrigQueueName').value=queuename;
        }

        

        if(order!=undefined){
            document.getElementById('wlf:hidOrderBy').value=order;
        }else{
            document.getElementById('wlf:hidOrderBy').value="";
        }

    /*    if(batchSize!=undefined && batchSize!=""){
            document.getElementById('wlf:hidBatchSize').value=batchSize;
        }*/
        if(batchingFlag!=undefined && batchingFlag!=""){
            if(batchingFlag.toUpperCase()=='N'){
                document.getElementById('wlf:hidBatchingFlag').value=false;
            }else
            if(batchingFlag.toUpperCase()=="Y"){
                document.getElementById('wlf:hidBatchingFlag').value=true;
            }
            else{
                document.getElementById('wlf:hidBatchingFlag').value=true;
            }
        }
        if(sortingorder!=undefined && sortingorder!=""){
            document.getElementById('wlf:hidSortOrder').value=sortingorder;
        }

        if(allowReassign!=undefined && allowReassign!=""){
             document.getElementById('wlf:hidAllowReassignment').value=allowReassign;
        } else {
            document.getElementById('wlf:hidAllowReassignment').value="N";
        }

        document.getElementById('wlf:hidFlag').value="1";
        document.getElementById('wlf:hidAdhocRoutingFlag').value="N";
        document.getElementById('wlf:hidUnlockFlag').value="N";
        document.getElementById('wlf:hidSearch').value=false;


        //document.getElementById("wlf:quickSearchLoaded").value = "N";
        document.getElementById("wlf:queueProcessLoaded").value = "N";
        
        if(document.getElementById("wlf:hidArchivalMode") != null){
            document.getElementById("wlf:hidArchivalMode").value = "N";
        }
        
        document.getElementById("wlf:hidSelectedQueryIndex").value="";
        document.getElementById('wlf:hidClientSorting').value=false;
        
        var ref = document.getElementById('wlf:cid');
        if(ref){
            ref.value = "";
        }
        ref = document.getElementById('wlf:fid');
        if(ref){
            ref.value = "";
        }
     
        clickLink("wlf:reloadLink");
     }catch(e){        
        CurrentlyProcessing=false;        
     }
          document.getElementById('wlf:hidClientSorting').value=false;
}

function HashMap(){ 
    this.hashArray = new Array();
    this.getIterator = function (){
        return this.hashArray;
    }
}

HashMap.prototype.put = function (key, value){
    var jasonObj = this.get(key);
    if(jasonObj.value == null){
        this.hashArray[this.hashArray.length] = {"key":key, "value":value};
    } else {
        this.hashArray[jasonObj.index].value = value;
    }
}

HashMap.prototype.get = function (key){
    var value = null;
    var index = 0;
    for(index; index<this.hashArray.length; index++){
        if(this.hashArray[index].key == key){
            value = this.hashArray[index].value;
            break;
        }
    }

    if(index == this.hashArray.length){
        index = -1;
    }

    return {"value":value, "index":index};
}

HashMap.prototype.remove = function (key){
    var value = null;
    var index = 0;
    for(index; index<this.hashArray.length; index++){
        if(this.hashArray[index].key == key){
            value = this.hashArray[index].value;
            this.hashArray.splice(index, 1);            
            break;
        }
    }

    if(index == this.hashArray.length){
        index = -1;
    }

    return {"value":value, "index":index};
}

HashMap.prototype.clear = function (){
    this.hashArray = new Array();
}

function WorkitemEventHandler(eventDefId,frmName,rowcount,eventName,objJsonOutput,archiveMode){
    var callFlag=encode_ParamValue(document.getElementById(frmName+":hidInstrumentListCallFlag").value);
    var isSearch=document.getElementById(frmName+":hidFlag").value;
    var isArchivalMode = 'N';
    
    if (frmName=="wlf" && document.getElementById(frmName + ":hidArchivalMode"))
    {
        isArchivalMode = document.getElementById(frmName + ":hidArchivalMode").value;
    }
    else if(frmName=="frmlinkedworkitemlist" && archiveMode!= undefined){
        if(archiveMode=="Y" || archiveMode=="y"){
            isArchivalMode="Y";
        }
    }
    workitemNavType=document.getElementById(frmName+":workitemNavType").value;
    var openFrom = document.getElementById(frmName+":OpenFrom").value;
    
    var pDefId = "";
    var qDefId = "";
    var activityId = "";
    var jsonOutput= JSON.parse(objJsonOutput);
    var listParam=new Array();
    var processName="";
    var activityName="";
    var queueType="";
    var activityType="";
    var URN="";
    var wlSortLastValue = "";

        var arrobjJsonOutput= jsonOutput.Outputs;
        for(var i=0;i<arrobjJsonOutput.length;i++){
            var outputJson=arrobjJsonOutput[i];
            var objJson=outputJson.Output;
            if(objJson.Name=='ProcessInstanceID'){
                listParam.push(new Array('ProcessInstanceID',encode_utf8(objJson.Value)));
                pid = objJson.Value;
            }
            if(objJson.Name=='URN'){
                listParam.push(new Array('URN',encode_utf8(objJson.Value)));
                URN = objJson.Value;
            }
            if(objJson.Name=='ProcessInstanceIDEnc'){
                listParam.push(new Array('ProcessInstanceIDEnc',encode_ParamValue(objJson.Value)));                
            }
            if(objJson.Name=='WorkitemID'){
                listParam.push(new Array('WorkitemID',encode_ParamValue(objJson.Value)));
                wid = objJson.Value;
            }
            if(objJson.Name=='RouteId'){
                pDefId = objJson.Value;
            }
            if(objJson.Name=='WorkstageId'){
                activityId = objJson.Value;
            }
            if(objJson.Name=='QueueId'){
                qDefId = objJson.Value;
            }
            if(objJson.Name=='RouteName'){
                processName = objJson.Value;
            }
            if(objJson.Name=='ActivityName'){
                activityName = objJson.Value;
            }
            if(objJson.Name=='QueueType'){
                queueType = objJson.Value;
            }
            if(objJson.Name=='ActivityType'){
                activityType = objJson.Value;
            }
            if(objJson.Name=='wlSortLastValue'){
            wlSortLastValue = encode_utf8(objJson.Value);
        }
    }
    
    if(typeof beforeWorkitemOpen != 'undefined'){
        try{
            beforeWorkitemOpen(pid,wid,pDefId,activityId,qDefId,activityType,queueType,processName,activityName);
        } catch(e){}
    }
    
    //if(!(callFlag=='L' && isSearch=='3')){ // Bug 39024: remove check for opening workitem from search in workdesk
        if((embeddedView == 'Y') || (embeddedView == 'y')){
            embeddedWorkitemEventHandler(eventDefId,rowcount,eventName,objJsonOutput);
            return;
        }

        var wiWindowRef = null;
        var orderBy=document.getElementById(frmName+":hidOrderBy").value;
        var queueId=document.getElementById(frmName+":hidQueueId").value;
        var sortOrder=document.getElementById(frmName+":hidSortOrder").value;
        var allowReassignment=document.getElementById(frmName+":hidAllowReassignment").value;
        var allowReassign="N";
        var instrumentListCallFlag='Q';
        var filterstring = "";
        var decodeflag = "";
        var isFilterSearch = false;
        if(isSearch=='3' || isSearch=='4'  || callFlag=='L'){
            instrumentListCallFlag='S';
        }
        if(openFrom == '4' && isSearch=='2' && document.getElementById(frmName+":hidFilterString") && document.getElementById(frmName+":encodeFlag")){
            filterstring = document.getElementById(frmName+":hidFilterString").value;
            decodeflag = document.getElementById(frmName+":encodeFlag").value;
            isFilterSearch = true;
        }
        if(allowReassignment=="Y" || queueId=="0"){
            allowReassign="Y";
        }
        
        var lastProcessInstanceId;
        var lastWorkitemId;
        if(bPrevNextOperation){
            if (oldWdJason != null) {
                lastProcessInstanceId = oldWdJason.PId;
                lastWorkitemId = oldWdJason.WId;
            }
        }
        
        var isDefaultDoc="Y";
        if (typeof strDefaultDocument != 'undefined') {
            if (strDefaultDocument != "Y") {
                isDefaultDoc = "N";
            } else if (strDefaultDocument == "Y") {
                if (typeof isDefaultDocument != 'undefined' && !isDefaultDocument(processName, activityName)) {
                    isDefaultDoc = "N";
                }
            }
        }
        
        //Bug 59916 
        var isDefaultDocType="";
        if(typeof isDefaultDocumentType!='undefined')
        isDefaultDocType=isDefaultDocumentType(processName,activityName);  
     //Bug 59916 
     
        var CustomNoOfRecordsToFetchCount = "";
        if(typeof CustomNoOfRecordsToFetch != 'undefined'){
            CustomNoOfRecordsToFetchCount = CustomNoOfRecordsToFetch(processName,activityName);
	}
        var scrHeight;
        var WinHeight = window.screen.availHeight-60.01;

        var url='/webdesktop/components/workitem/view/workdesk.app';
        var wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+window.screen.availWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
        var winWidth;
        var retWinWidth = "";
        if(typeof DualMonitorWidth != 'undefined') {
            retWinWidth = DualMonitorWidth();
        }
        
        if(retWinWidth != "" && retWinWidth != null && retWinWidth != undefined){
            winWidth = retWinWidth;
        } 
        else {
            winWidth = window.screen.availWidth-10.01;
        }
        var wdWidth=0;
        if(wdWidth!='0' && wdWidth<=window.screen.availWidth){
            scrHeight=window.screen.availHeight-15;
            winWidth = wdWidth;
            wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+winWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
        }
        else
        {
            scrHeight = window.screen.availHeight;
            wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+winWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
        }
        if(callFlag=="L") {
            listParam.push(new Array('wi_count',encode_ParamValue("-1")));
        }else{
            listParam.push(new Array('wi_count',encode_ParamValue(rowcount)));
        }
        
        
         var comInsId='',comInsType='1';
        
        var winLoc = window;
        if(typeof window.opener!='undefined'){
            winLoc = (typeof window != 'undefined' ? window : (typeof window.opener.opener.opener==null ? window.opener.opener.opener : window.opener.opener));
        }
        if(typeof winLoc!='undefined' && typeof winLoc.comp_ins_id!='undefined'){
            comInsId=winLoc.comp_ins_id;
            
            if(typeof winLoc.parent.getInstanceInfo!='undefined' && winLoc.parent.getInstanceInfo('Int'+comInsId)!=null){
            
            if(winLoc.parent.getInstanceInfo('Int'+comInsId).Instance!=null){
                comInsType=winLoc.parent.getInstanceInfo('Int'+comInsId).Instance.Type;
            }
            else{
                comInsType='2';
            }
        }
	}
        
        listParam.push(new Array('QueueId',encode_ParamValue(queueId)));
        listParam.push(new Array('Comp_height',encode_ParamValue(scrHeight)));
        listParam.push(new Array('Comp_width',encode_ParamValue(winWidth)));
        listParam.push(new Array('Option',encode_ParamValue('OPENWI')));
        listParam.push(new Array('wdView',encode_ParamValue('N')));
        listParam.push(new Array('InstrumentListSortOrder',encode_ParamValue(sortOrder)));
        listParam.push(new Array('InstrumentListOrderBy',encode_ParamValue(orderBy)));
        listParam.push(new Array('wlSortLastValue',encode_ParamValue(wlSortLastValue)));
        listParam.push(new Array('allowreassignment',encode_ParamValue(allowReassign)));
        listParam.push(new Array('InstrumentListCallFlag',encode_ParamValue(instrumentListCallFlag)));
        listParam.push(new Array('ArchivalMode',encode_ParamValue(isArchivalMode)));
        listParam.push(new Array('QueueType',encode_ParamValue(queueType)));
        listParam.push(new Array('ActivityType',encode_ParamValue(activityType)));
        listParam.push(new Array("IsDefaultDocType",encode_ParamValue(isDefaultDocType))); //Bug 59916 
        listParam.push(new Array('LinkedWorkitem',callFlag));
        listParam.push(new Array("PrevNextOperation",encode_ParamValue(bPrevNextOperation)));//Bug 71286
        listParam.push(new Array("Comp_ins_id",encode_ParamValue(comInsId)));
        listParam.push(new Array("Comp_ins_type",encode_ParamValue(comInsType)));
        if(bPrevNextOperation){
        listParam.push(new Array("lastProcessInstanceId",encode_ParamValue(lastProcessInstanceId)));
        listParam.push(new Array("lastWorkitemId",encode_ParamValue(lastWorkitemId)));
        listParam.push(new Array("workitemNavType",encode_ParamValue(workitemNavType)));
        }
        listParam.push(new Array("NoOfRecordsToFetch",encode_ParamValue(CustomNoOfRecordsToFetchCount)));
        if(isFilterSearch){
            listParam.push(new Array("FilterString",encode_ParamValue(filterstring)));
            listParam.push(new Array("decodeFlag",encode_ParamValue(decodeflag)));
        }
        
        if(typeof getCustomFeatureForWIWindow != 'undefined') {
            var cFeatures = getCustomFeatureForWIWindow(processName, activityName, pDefId, qDefId, queueType);
            if(typeof cFeatures != 'undefined' && cFeatures != '') {
                wFeatures = cFeatures;
            }
        }

        /***************** Linked workitem Open Case Starts****************/
        if(callFlag=="L") {
            openLinkedWiWindow(listParam,wFeatures);
            return;
        }
        /***************** Linked workitem Open Case Ends****************/

        var bCustomWdesk = false;
        var strCustomWorkdeskFlag = ajaxGetCustomWorkdeskFlag(pDefId,activityId);
        //alert(strCustomWorkdeskFlag);
        if(strCustomWorkdeskFlag == "true")
        {            
            bCustomWdesk = true;            
        }
        if(strCustomWorkdeskFlag == "error")
        {
            fieldValidator(null, ERROR_TEMPLATE_INFO, "absolute", true);
            return;
        }

        //if(bCustomWdesk)
        listParam.push(new Array('IsDefaultDoc',encode_ParamValue(isDefaultDoc)));

        
        clearGarbageRef();


        var wiWinInfo = null;
        var uniqueId = null;
        var winObj = null;     
         var saMeProcessWinRef=null;

        if(!bPrevNextOperation){
            // If same workitem is clicked.
            wiWinInfo = getNextWiWinInfo(pid, wid);
        }
        
         if(typeof openSingleWorkitem!='undefined' && openSingleWorkitem(pDefId)){
        
        if(openWIInNewWindow=="Y"){
            
            saMeProcessWinRef = findSameProcessWinInfo(pDefId);
        }
    }

        //Prev Next Case
        if(bPrevNextOperation){
            if ((!oldWdJason.IsCustomWdesk && !bCustomWdesk) || (oldWdJason.IsCustomWdesk && bCustomWdesk && oldWdJason.RouteId == pDefId && oldWdJason.ActivityId == activityId)) {
            // If previous and current workdesk are default OR If custom workdesk has same pdefid and activity id as previous.
            {
                var winInfoJason = wiWinInfoMap.get(wdWinUId);
            }
                if(winInfoJason.index > -1){
                    // Check if workitem with given pid and wid exists. If exists then focus on its window
                    wiWinInfo = getNextWiWinInfo(pid, wid);
                    if(wiWinInfo != null){
                        // if workitem with given pid and wid exists, then before setting focus on new window, doClear() method is called on old window
                        if(typeof winInfoJason.value.WinRef.doClear != 'undefined'){
                            winInfoJason.value.WinRef.doClear();
                        }
                    }
                    if(wiWinInfo == null){
                        wiWinInfo = winInfoJason.value;
                    }
                }
            } else {
                wiWinInfo = getNextWiWinInfo(pid, wid);
            }
        }        
      
        if(wiWinInfo == null)
        {
            // If workitem is clicked and this workitem is previously not opened, then find the current window info.
            if (openWIInNewWindow == "N" && wiWinInfoMap.hashArray.length > 0) {
                // If Open Workitem in new window is disabled then load the next workitem in same window.
                if (!bCustomWdesk) {
                    wiWinInfo = findDefaultWdeskWinInfo();
                }
                else {
                    wiWinInfo = findCustomWdeskWinInfo(pDefId, activityId);
                }
                if(wiWinInfo) {
                    customAlert(PROCESS_OPENED_WORKITEM ,"focusWorkitemWindow()");
                    return;
                }
            }
        }

        //alert(wiWinInfo);

        if(wiWinInfo!=null){    
            /*if(wiWinInfo.ActType != activityType && (activityType == '32' || wiWinInfo.ActType == '32')){ //Handling to render case view/ workitem view at same window on workitem toggle
                listParam.push(new Array('Action', encode_ParamValue('1')));
                uniqueId = wiWinInfo.WinName;
                wiWindowRef = openNewWindow(url, uniqueId, wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", listParam);

                wiWinInfo = {
                    "PId": pid,
                    "WId": wid,
                    "ActId": activityId,
                    "PDefId": pDefId,
                    "QueueId": qDefId,
                    "WinName": uniqueId,
                    "WinRef": wiWindowRef,
                    "CustomWorkdesk": bCustomWdesk,
                    "ActType": activityType,
                    "OpenFrom": openFrom
                };

                wiWinInfoMap.put(uniqueId, wiWinInfo);
                wiWindowRef.focus();
                wdWinUId = null;
                oldWdJason = null;
                bPrevNextOperation = false;
                workitemNavType="";
                
            } else */
            
            if(openWIInNewWindow== "Y" && saMeProcessWinRef!=null){
                saMeProcessWinRef.focus();
            } else {
                wiWinInfo.PId = pid;
                wiWinInfo.WId = wid;
                wiWinInfo.ActId = activityId;
                wiWinInfo.PDefId = pDefId;
                wiWinInfo.QueueId = qDefId;
                wiWinInfo.OpenFrom = openFrom;
                winObj = wiWinInfo.WinRef;

                var queryString = "";
                for(var iCount=0;iCount<listParam.length;iCount++) {
                    var param = listParam[iCount];
                    queryString += param[0] + "=" + encode_utf8(param[1]) + "&";
                }            
                queryString += "Action="+encode_ParamValue('1');            

                winObj.focus();
                
                if(bCustomWdesk) {
                    winObj.location = url + '?' + queryString + '&WD_SID=' + WD_SID + '&WD_RID=' + getRequestToken(url);
                } else {
                    if(activityType == '32'){
                        //Bug 78161 - Case workitems are getting locked on prev-next operation in workdesk window
                        winObj.initNLoadWorkitem(getWDJason(queryString), "N");
                    } else {                
                        winObj.initNLoadWorkitem(getWDJason(queryString), bPrevNextOperation);
                    }
                }

                wdWinUId = null;
                oldWdJason = null;
                bPrevNextOperation = false;
                workitemNavType="";
          }
        } else {            
            listParam.push(new Array('Action',encode_ParamValue('1')));
            uniqueId = MakeUniqueNumber();
            wiWindowRef = openNewWindow(url, uniqueId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);

            wiWinInfo = {
                "PId" : pid,
                "WId" : wid,
                "ActId" : activityId,
                "PDefId" : pDefId,
                "QueueId" : qDefId,
                "WinName" : uniqueId,
                "WinRef" : wiWindowRef,
                "CustomWorkdesk" : bCustomWdesk,
                "ActType" : activityType,
                "OpenFrom" : openFrom
            };

            wiWinInfoMap.put(uniqueId, wiWinInfo);
            wiWindowRef.focus();
            wdWinUId = null;
            oldWdJason = null;
            bPrevNextOperation = false;
            workitemNavType="";
        }
    //}    
    window.parent.setSessionCheckTimeout((window.parent.SessionWarnExtendTime-0)*60);
}

function focusWorkitemWindow() {
    var wiWinInfo = findDefaultWdeskWinInfo();
    if(typeof wiWinInfo != 'undefined' && wiWinInfo != null) {
        wiWinInfo.WinRef.focus();
    }
}

function findSameProcessWinInfo(pdefId){
    var i;
    var tempWiWinInfo = null;
    for(i=0; i<wiWinInfoMap.hashArray.length; i++){
        tempWiWinInfo = wiWinInfoMap.hashArray[i].value;
        if(tempWiWinInfo.PDefId == pdefId){
            if(isWindowOpened(tempWiWinInfo.WinRef)){
                // If window is opened then return its reference
                return tempWiWinInfo.WinRef;
            }else{
                return null;
            }
        }
    }
    return null;
}

function openTask(pid,wid,taskid,subtaskid,pDefId,activityId,taskName,bFromCaseFile,readUnreadFlag,rowIndex){
     if (readUnreadFlag == "N")
    {
        document.getElementById("mytasks:hidCheckedIndexes").value = rowIndex;  // Bug 66872
        setReadStatus(1);
    }
    if(bFromCaseFile == 'true'){
        if(typeof window.parent.opener.TaskWorkitemEventHandler!='undefined'){
		 window.parent.opener.TaskWorkitemEventHandler(pid,wid,taskid,subtaskid,pDefId,activityId,taskName);
	}
	else{
             TaskWorkitemEventHandler(pid,wid,taskid,subtaskid,pDefId,activityId,taskName);
         }
    }else{
        TaskWorkitemEventHandler(pid,wid,taskid,subtaskid,pDefId,activityId,taskName);
    }   
}

function checkAndShowConstant(elem,bFocus){
    if(elem!=null && elem.selectedIndex!=-1){
        var valObj = elem.value;
        if(valObj=='<None>'){
            if(elem.clientWidth==0)
                document.getElementById(elem.id+'Const').style.width = '90%';
            else if(elem.clientWidth<=21)
                document.getElementById(elem.id+'Const').style.width = '42px';
            else
                document.getElementById(elem.id+'Const').style.width = (elem.clientWidth-18)+'px';
            document.getElementById(elem.id+'Const').style.visibility='visible';
            if(typeof isChrome != 'undefined'){
            var ver = parseInt(window.navigator.appVersion.match(/Chrome\/(\d+)\./)[1], 10);
            if(ver>37)
            document.getElementById(elem.id+'Const').style.top='-21px';
            else
            document.getElementById(elem.id+'Const').style.top='-25px';
            }
            if(navigator.appName =='Netscape'){
                 var elemname=elem.title;
                 document.getElementById(elem.id+'Const').style.top='-26px';
                 if(elemname=="Day(s)")
                 document.getElementById(elem.id+'Const').style.left='0px'
                 else if(elemname=="Hour(s)")
                 document.getElementById(elem.id+'Const').style.left='0px'
                else if(elemname=="Min(s)")
                 document.getElementById(elem.id+'Const').style.left='0px'
                else if(elemname=="Sec(s)")
                 document.getElementById(elem.id+'Const').style.left='0px'
             }
            if(bFocus){
                document.getElementById(elem.id+'Const').value = '';
                document.getElementById(elem.id+'Const').focus();
            }
        }
        else{
            document.getElementById(elem.id+'Const').blur();
            document.getElementById(elem.id+'Const').style.visibility='hidden';
        }
    }
}
function constantEscalateToDateConst(data)
{
    if(data.status == "success")
    {
        var elem = document.getElementById(data.source.id);
        if(elem!=null && elem.selectedIndex!=-1)
        {
            var valObj = elem.value;
            if(valObj == "<None>")
            {
                if(elem.clientWidth==0)
                    document.getElementById(elem.id+'Const').style.width = '90%';
                else
                    document.getElementById(elem.id+'Const').style.width = (elem.clientWidth-22)+'px';
                document.getElementById(elem.id+'Const').style.visibility='visible';
                document.getElementById(elem.id+'Const').value = '';
                document.getElementById(elem.id+'Const').focus();
            }
            else{
                document.getElementById(elem.id+'Const').blur();
                document.getElementById(elem.id+'Const').style.visibility='hidden';
            }
        }
       hidePopupMask();
    }
}

function openTriggerPropertyPage(triggerTypes,triName,mode,prcName,prcId,readOnly,source){
    var urlForTriggerType="";
    var WindowLeft=parseInt(ScreenWidth/2);
    var WindowTop=parseInt(ScreenHeight/2);
    var WindowHeight;
    var WindowWidth;
    var wFeatures;
    var win;
    var listParam=new Array();
    urlForTriggerType += '/webdesktop/components/task/mailTriggerProperty.app';
    urlForTriggerType=appendUrlSession(urlForTriggerType);
    WindowHeight=windowH+134;
    var isChrome = window.chrome; 
    if(isChrome != null){
        if(source == undefined)
            WindowWidth=windowW+25;
        else
            WindowWidth=windowW+11;
    }
    else
        WindowWidth=windowW+10;
    WindowLeft=WindowLeft-parseInt(WindowWidth/2);
    WindowTop=WindowTop-parseInt(WindowHeight/2);
    wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;
    win = openNewWindow(urlForTriggerType,'WDMailTrigger',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
}

function validateMailFields(subject,errorLabel,from,to,cc,bcc)
{
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1; 
    if(errorLabel=='mailTrigger:error'){
            document.getElementById(errorLabel).innerHTML='';
            document.getElementById('mailTrigger:mailTrigDiv').className='';
            document.getElementById('mailTrigger:mailtrigIcn').className='';
    }
    var KeyID;
    var bCharValidate=true;
    var sValue;
    var iLength;
    if(document.getElementById(subject).value=="")
    {
        document.getElementById(errorLabel).innerHTML=MAIL_SUBJECT;
        if(errorLabel=='mailTrigger:error'){
            document.getElementById('mailTrigger:mailTrigDiv').className='errorMsgdiv';
            document.getElementById('mailTrigger:mailtrigIcn').className='errorIcondiv';
        }
        return false;
    }
    if(document.getElementById(from).value=="")
    {
        document.getElementById(errorLabel).innerHTML=MAIL_FROM;
         if(errorLabel=='mailTrigger:error'){
            document.getElementById('mailTrigger:mailTrigDiv').className='errorMsgdiv';
            document.getElementById('mailTrigger:mailtrigIcn').className='errorIcondiv';
        }
        return false;
    }
    else if(document.getElementById(from).value=="<Constant>")
    {
        if(document.getElementById("mailTrigger:cmb_FromStringFromVarsConst").value=="")
        {
            document.getElementById(errorLabel).innerHTML=MAIL_FROM;
             if(errorLabel=='mailTrigger:error'){
             document.getElementById('mailTrigger:mailTrigDiv').className='errorMsgdiv';
             document.getElementById('mailTrigger:mailtrigIcn').className='errorIcondiv';
            }
            if(isSafari){
                document.getElementById("mailTrigger:cmb_FromStringFromVarsConst").select();
            } else {
                document.getElementById("mailTrigger:cmb_FromStringFromVarsConst").focus();
            }
            return false;
        }
         if(typeof sLocale == 'undefined'){
        sLocale = 'en_us';}  
        if(sLocale=='en_us'){
        if (!filter.test(document.getElementById("mailTrigger:cmb_FromStringFromVarsConst").value)) {
            document.getElementById(errorLabel).innerHTML="Enter a valid Email Id";
             if(errorLabel=='mailTrigger:error'){
             document.getElementById('mailTrigger:mailTrigDiv').className='errorMsgdiv';
             document.getElementById('mailTrigger:mailtrigIcn').className='errorIcondiv';
            }
            if(isSafari){
                document.getElementById("mailTrigger:cmb_FromStringFromVarsConst").select();
            } else {
                document.getElementById("mailTrigger:cmb_FromStringFromVarsConst").focus();
            } 
            return false;
        }
    }
    }
    if(document.getElementById(to).value=="")
    {
        document.getElementById(errorLabel).innerHTML=MAIL_TO;
         if(errorLabel=='mailTrigger:error'){
            document.getElementById('mailTrigger:mailTrigDiv').className='errorMsgdiv';
            document.getElementById('mailTrigger:mailtrigIcn').className='errorIcondiv';
        }
        return false;
    }
    else if(document.getElementById(to).value=="<Constant>")
    {
        if(document.getElementById("mailTrigger:cmb_ToStringVarsConst").value=="")
        {
            document.getElementById(errorLabel).innerHTML=MAIL_TO;
             if(errorLabel=='mailTrigger:error'){
             document.getElementById('mailTrigger:mailTrigDiv').className='errorMsgdiv';
             document.getElementById('mailTrigger:mailtrigIcn').className='errorIcondiv';
           }
            if(isSafari){
                document.getElementById("mailTrigger:cmb_ToStringVarsConst").select();
            } else {
                document.getElementById("mailTrigger:cmb_ToStringVarsConst").focus();
            }
            return false;
        }     
    }
    
    //clickLink('mailTrigger:validationOk');
    return true;
}
function focusInputText(ref){
    ref.selectedIndex = -1;
}
function HandleProgressBarWrapper(data){
    HandleProgressBar(data);
    if(data.status=='success'){
        
    }
}

//Added for Task
function TaskWorkitemEventHandler(pid,wid,taskid,subtaskid,pDefId,activityId,taskName){
//    var callFlag=document.getElementById(frmName+":hidInstrumentListCallFlag").value;
//    var isSearch=document.getElementById(frmName+":hidFlag").value;
//    var isArchivalMode = 'N';
    
//    if (frmName=="wlf" && document.getElementById(frmName + ":hidArchivalMode"))
//    {
//        isArchivalMode = document.getElementById(frmName + ":hidArchivalMode").value;
//    }
//    else if(frmName=="frmlinkedworkitemlist" && archiveMode!= undefined){
//        if(archiveMode=="Y" || archiveMode=="y"){
//            isArchivalMode="Y";
//        }
//    }
    //var openFrom = document.getElementById(frmName+":OpenFrom").value;
    
    //if(!(callFlag=='L' && isSearch=='3')){ // Bug 39024: remove check for opening workitem from search in workdesk
        //if((embeddedView == 'Y') || (embeddedView == 'y')){
        //    embeddedWorkitemEventHandler(eventDefId,rowcount,eventName,objJsonOutput);
      //      return;
      //  }

        var wiWindowRef = null;
     //   var orderBy=document.getElementById(frmName+":hidOrderBy").value;
    //    var queueId=document.getElementById(frmName+":hidQueueId").value;
    //    var sortOrder=document.getElementById(frmName+":hidSortOrder").value;
   //     var allowReassignment=document.getElementById(frmName+":hidAllowReassignment").value;
   //     var allowReassign="N";
   //     var instrumentListCallFlag='Q';
    //    if(isSearch=='3'  || callFlag=='L'){
   //         instrumentListCallFlag='S';
  //      }
        
 //       if(allowReassignment=="Y" || queueId=="0"){
  //          allowReassign="Y";
  //      }

//        var pDefId = "";
//        var qDefId = "";
//        var activityId = "";
//        var jsonOutput= parseJSON("("+objJsonOutput+")");
        var listParam=new Array();
//        var processName="";
//        var activityName="";
//
//        var arrobjJsonOutput= jsonOutput.Outputs;
//        for(var i=0;i<arrobjJsonOutput.length;i++){
//            var outputJson=arrobjJsonOutput[i];
//            var objJson=outputJson.Output;
//            if(objJson.Name=='ProcessInstanceID'){
//                listParam.push(new Array('ProcessInstanceID',encode_ParamValue(objJson.Value)));
//                pid = objJson.Value;
//            }
//            if(objJson.Name=='ProcessInstanceIDEnc'){
//                listParam.push(new Array('ProcessInstanceIDEnc',encode_ParamValue(objJson.Value)));                
//            }
//            if(objJson.Name=='WorkitemID'){
//                listParam.push(new Array('WorkitemID',encode_ParamValue(objJson.Value)));
//                wid = objJson.Value;
//            }
//            if(objJson.Name=='RouteId'){
//                pDefId = objJson.Value;
//            }
//            if(objJson.Name=='WorkstageId'){
//                activityId = objJson.Value;
//            }
//            if(objJson.Name=='QueueId'){
//                qDefId = objJson.Value;
//            }
//            if(objJson.Name=='RouteName'){
//                processName = objJson.Value;
//            }
//            if(objJson.Name=='ActivityName'){
//                activityName = objJson.Value;
//            }
//        }
        
        var isDefaultDoc="Y";
        //if(typeof isDefaultDocument!='undefined' && !isDefaultDocument(processName,activityName))
          //  isDefaultDoc="N";
           
        var scrHeight;
        var WinHeight = window.screen.availHeight-60;

        var url='/webdesktop/components/workitem/view/workdesk.app';
        var wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+window.screen.availWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
        var winWidth = window.screen.availWidth-10;
        var wdWidth=0;
        if(wdWidth!='0' && wdWidth<=window.screen.availWidth){
            scrHeight=window.screen.availHeight-15;
            winWidth = wdWidth;
            wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+winWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
        }
        else
        {
            scrHeight = window.screen.availHeight;
            wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+winWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
        }
    
//        if(callFlag=="L") {
//            listParam.push(new Array('wi_count',encode_ParamValue("-1")));
//        }else{
//            listParam.push(new Array('wi_count',encode_ParamValue(rowcount)));
//        }
        var queueId = "1";
        var sortOrder = "A";
        var orderBy = "10";
        var allowReassign = "N";
        var instrumentListCallFlag = "Q";
        var isArchivalMode = 'N';
        var qDefId = "1";
        var openFrom = "1";
        
       // listParam.push(new Array('ProcessInstanceID',encode_ParamValue(pid))); //bug 76023
        listParam.push(new Array('WorkitemID',encode_ParamValue(wid)));
        listParam.push(new Array('QueueId',encode_ParamValue(queueId)));
        listParam.push(new Array('QueueType',encode_ParamValue('M')));
        listParam.push(new Array('ActivityType',encode_ParamValue('32')));
        listParam.push(new Array('Comp_height',encode_ParamValue(scrHeight)));
        listParam.push(new Array('Comp_width',encode_ParamValue(winWidth)));
        listParam.push(new Array('Option',encode_ParamValue('OPENWI')));
        listParam.push(new Array('wdView',encode_ParamValue('N')));
        listParam.push(new Array('InstrumentListSortOrder',encode_ParamValue(sortOrder)));
        listParam.push(new Array('InstrumentListOrderBy',encode_ParamValue(orderBy)));
        listParam.push(new Array('allowreassignment',encode_ParamValue(allowReassign)));
        listParam.push(new Array('InstrumentListCallFlag',encode_ParamValue(instrumentListCallFlag)));
        listParam.push(new Array('ArchivalMode',encode_ParamValue(isArchivalMode)));
        listParam.push(new Array('IsDefaultDoc',encode_ParamValue(isDefaultDoc)));
        listParam.push(new Array('taskid',encode_ParamValue(taskid)));
        listParam.push(new Array('subtaskid',encode_ParamValue(subtaskid)));
        listParam.push(new Array('TaskName',encode_ParamValue(taskName)));
        //listParam.push(new Array('wi_count','0'));
//        /***************** Linked workitem Open Case Starts****************/
//        if(callFlag=="L") {
//            openLinkedWiWindow(listParam,wFeatures);
//            return;
//        }
        /***************** Linked workitem Open Case Ends****************/

        var bCustomWdesk = false;
//        var strCustomWorkdeskFlag = ajaxGetCustomWorkdeskFlag(pDefId,activityId);
//        //alert(strCustomWorkdeskFlag);
//        if(strCustomWorkdeskFlag == "true")
//        {            
//            bCustomWdesk = true;            
//        }
//        if(strCustomWorkdeskFlag == "error")
//        {
//            alert(ERROR_TEMPLATE_INFO);
//            return;
//        }

        //if(bCustomWdesk)
        

        clearGarbageRef();

        var wiWinInfo = null;
        var uniqueId = null;
        var winObj = null;     

        if(!bPrevNextOperation){
            // If same workitem is clicked.
            wiWinInfo = getNextWiWinInfoForTask(pid, wid,taskid);
        }
        //Prev Next Case
        if(bPrevNextOperation){
            if((!oldWdJason.IsCustomWdesk && !bCustomWdesk) || (oldWdJason.IsCustomWdesk && oldWdJason.RouteId==pDefId && oldWdJason.ActivityId==activityId)){                
                // If previous and current workdesk are default OR If custom workdesk has same pdefid and activity id as previous.
                var winInfoJason = wiWinInfoMap.get(wdWinUId);
                if(winInfoJason.index > -1){
                    // Check if workitem with given pid and wid exists. If exists then focus on its window
                    wiWinInfo = getNextWiWinInfoForTask(pid, wid,taskid);
                    if(wiWinInfo != null){
                        // if workitem with given pid and wid exists, then before setting focus on new window, doClear() method is called on old window
                        if(typeof winInfoJason.value.WinRef.doClear != 'undefined'){
                            winInfoJason.value.WinRef.doClear();
                        }
                    }
                    if(wiWinInfo == null){
                        wiWinInfo = winInfoJason.value;
                    }
                }
            } else {
                wiWinInfo = getNextWiWinInfoForTask(pid, wid,taskid);
            }
        }        
        var openWIInNewWindow = "N";
        if(wiWinInfo == null)
        {
            // If workitem is clicked and this workitem is previously not opened, then find the current window info.
            if(openWIInNewWindow == "N" && wiWinInfoMap.hashArray.length > 0 && !bCustomWdesk){
                // If Open Workitem in new window is disabled then load the next workitem in same window.                
                wiWinInfo = findDefaultWdeskWinInfo();                
            }

            if(openWIInNewWindow == "N" && wiWinInfoMap.hashArray.length > 0 && bCustomWdesk){
                wiWinInfo = findCustomWdeskWinInfo(pDefId, activityId);                
            }
        }

        //alert(wiWinInfo);
        if(wiWinInfo!=null){  
            listParam.push(new Array('ProcessInstanceID', encode_utf8(pid))); //bug 76023
            wiWinInfo.PId = pid;
            wiWinInfo.WId = wid;
            wiWinInfo.ActId = activityId;
            wiWinInfo.PDefId = pDefId;
            wiWinInfo.QueueId = qDefId;
            wiWinInfo.OpenFrom = openFrom;
            wiWinInfo.taskid = taskid;
            winObj = wiWinInfo.WinRef;

            var queryString = "";
            for(var iCount=0;iCount<listParam.length;iCount++) {
                var param = listParam[iCount];
                queryString += param[0] + "=" + encode_utf8(param[1]) + "&";
            }            
            queryString += "Action="+encode_ParamValue('1');            

            winObj.focus();
            winObj.initNLoadWorkitem(getWDJason(queryString), bPrevNextOperation);
                
                
            wdWinUId = null;
            oldWdJason = null;
            bPrevNextOperation = false;
        } else {     
            listParam.push(new Array('ProcessInstanceID', encode_ParamValue(pid)));//bug 76023
            listParam.push(new Array('Action',encode_ParamValue('1')));
            uniqueId = MakeUniqueNumber();
            wiWindowRef = openNewWindow(url, uniqueId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);

            wiWinInfo = {
                "PId" : pid,
                "WId" : wid,
                "ActId" : activityId,
                "PDefId" : pDefId,
                "QueueId" : qDefId,
                "WinName" : uniqueId,
                "WinRef" : wiWindowRef,
                "CustomWorkdesk" : bCustomWdesk,
                "OpenFrom" : openFrom,
                "taskid" : taskid
            };

            wiWinInfoMap.put(uniqueId, wiWinInfo);
            wiWindowRef.focus();
            
        }
}
//Added for Task
function openLinkedWiWindow(listParam,wFeatures)
{
    var url='/webdesktop/components/workitem/view/workdesk.app';
    listParam.push(new Array('Action',encode_ParamValue('L')));
    var wiWindowRef = openNewWindow(url,'LaunchLinkedWorkitem',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    wiWindowRef.focus();
}

function getRequestToken(url){
    var trui = getActionUrlFromURL(url);
    var servletUrl = "/webdesktop/secuidsv";
    (typeof WD_SID != 'undefined' && WD_SID != null) && (servletUrl += "?WD_SID=" + WD_SID);
            
    var xhReq = createXMLHttpRequest();
    //createIndicator(indicatorid);
    xhReq.open("POST", servletUrl, false);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    var wd_rid;
    xhReq.onreadystatechange = onResponse;
    
    xhReq.send("T-URI="+trui);
   
    function onResponse() {        
        try {
            
            if (xhReq.readyState==4) { 
                if (xhReq.status==200) {
                   wd_rid =  xhReq.getResponseHeader("WD_RID");
                } 
            }       
        } catch(e) {
            alert(ERROR_FETCHING_DATA);
        }
    }
     return wd_rid;
}


function ajaxGetCustomWorkdeskFlag(routeId, workstageId){
    var url = "/webdesktop/ajaxgetcwdeskflag.app?RouteId="+routeId+"&WorkstageId="+workstageId;    
    url = appendUrlSession(url);
    var wd_rid=getRequestToken(url);
    var reqRef = new net.ContentLoader(url+"&WD_RID="+wd_rid, null, null, "GET", '', false);    
    if(reqRef.req.status == 200) {        
        if(reqRef.req.getResponseHeader("CallStatus") == "success"){            
            if(reqRef.req.getResponseHeader("IsCustomWorkdesk") == "true")
            return "true";
            else
            return "false";
        } else {
            return "error";
        }
    }
}

function getNextWiWinInfo(pid, wid){
    var i;
    var tempWiWinInfo = null;
    for(i=0; i<wiWinInfoMap.hashArray.length; i++){
        tempWiWinInfo = wiWinInfoMap.hashArray[i].value;
        if((tempWiWinInfo.PId == pid) && (tempWiWinInfo.WId == wid)){
            if(isWindowOpened(tempWiWinInfo.WinRef)){
                // If window is opened then return its reference
                return tempWiWinInfo;
            }/* else {
                // If window is closed then remove the entry
                wiWinInfoMap.hashArray.splice(i, 1);                
                return null;
            }*/
        }
    }
    return null;
}
//Added for task
function getNextWiWinInfoForTask(pid, wid,taskid){
    var i;
    var tempWiWinInfo = null;
    for(i=0; i<wiWinInfoMap.hashArray.length; i++){
        tempWiWinInfo = wiWinInfoMap.hashArray[i].value;
        if((tempWiWinInfo.PId == pid) && (tempWiWinInfo.WId == wid) && (tempWiWinInfo.taskid == taskid)){
            if(isWindowOpened(tempWiWinInfo.WinRef)){
                // If window is opened then return its reference
                return tempWiWinInfo;
            }/* else {
                // If window is closed then remove the entry
                wiWinInfoMap.hashArray.splice(i, 1);                
                return null;
            }*/
        }
    }
    return null;
}
//Added for task
function findCustomWdeskWinInfo(pdefId, actId){
    var i;
    var tempWiWinInfo = null;
    for(i=0; i<wiWinInfoMap.hashArray.length; i++){
        tempWiWinInfo = wiWinInfoMap.hashArray[i].value;
        if((tempWiWinInfo.PDefId == pdefId) && (tempWiWinInfo.ActId == actId)){
            if(isWindowOpened(tempWiWinInfo.WinRef)){
                // If window is opened then return its reference
                return tempWiWinInfo;
            }/* else {
                // If window is closed then remove the entry
                wiWinInfoMap.hashArray.splice(i, 1);
                return null;
            }*/
        }
    }
    return null;
}

function findDefaultWdeskWinInfo(){
    var i;
    var tempWiWinInfo = null;
    for(i=0; i<wiWinInfoMap.hashArray.length; i++){
        tempWiWinInfo = wiWinInfoMap.hashArray[i].value;        
        if(tempWiWinInfo.CustomWorkdesk == false){
            return tempWiWinInfo;
        }
    }
    
    if(i == wiWinInfoMap.hashArray.length){
        return null;
    }
}

function clearGarbageRef(){
    var tempWiWinInfo = null;
    for(var i=0; i<wiWinInfoMap.hashArray.length; i++){
        tempWiWinInfo = wiWinInfoMap.hashArray[i].value;
        if(!isWindowOpened(tempWiWinInfo.WinRef)){
            // If window is closed then remove the entry
            wiWinInfoMap.hashArray.splice(i, 1);            
        }
    }
}

/*function getWindowHandlerByUId(windowList, wdWinName){
    for(var i=0; i<windowList.length; i++) {
        if(windowList[i].handler.name == wdWinName) {
            return windowList[i].handler;
        }
    }
    return null;
}*/

function isWindowOpened(windowRef) {    
    return (windowRef != null && !windowRef.closed);
}

function prepareWDModel(url, queryString){
    url = appendUrlSession(url);
    var wd_rid=getRequestToken(url);
    var reqRef = new net.ContentLoader(url+"&WD_RID="+wd_rid, null, null, "POST", queryString, false);    
    
    if(reqRef.req.status == 200) {
        if(reqRef.req.getResponseHeader("CallStatus") == "success"){
            if(prevNextUnlock=="Y")
            {
             var wiData = parseJSON("(" + reqRef.req.getResponseHeader("wiData") + ")");
             return {"CallStatus": "success","nextPid":wiData.processInstanceId,"nextWid":wiData.wid};   
            }
            else
            return {"CallStatus": "success"};
        }else {            
            return {"CallStatus": "failure", "Description": reqRef.req.getResponseHeader("Description"), "MainCode": reqRef.req.getResponseHeader("MainCode")};
        }
    }
}

function getWDJason(queryString, isEmbd){
    var url = "/webdesktop/components/workitem/view/preparewdmodel.app";
    url = appendUrlSession(url);
    var jason = prepareWDModel(url, queryString);
    if(typeof jason != 'undefined' && jason && jason.CallStatus == "success") {
        url = "/webdesktop/components/workitem/view/getwidata.app";
        url = appendUrlSession(url);
        var ajaxReq = null;

        if (window.XMLHttpRequest) {
            ajaxReq= new XMLHttpRequest();
        }else if (window.ActiveXObject) {
            ajaxReq= new ActiveXObject("Microsoft.XMLHTTP");
        }
        
        if(isEmbd!=undefined && isEmbd=='Y'){
            queryString += "&IsEmbd=Y";
        }

        if (prevNextUnlock == "Y")
        {
            queryString += "&nextPid=" + jason.nextPid + "&nextWid=" + jason.nextWid;
        }
         var wd_rid=getRequestToken(url);
        url += "&WD_RID=" + wd_rid;
        if (ajaxReq != null) {
            ajaxReq.open("POST", url, false);
            ajaxReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            ajaxReq.send(queryString);

            if (ajaxReq.status == 200 && ajaxReq.readyState == 4) {
                var respText = ajaxReq.responseText;
                respText = respText.substring(respText.indexOf('<jasoncont>') + 11, respText.lastIndexOf('</jasoncont>'));
            }
            else if (ajaxReq.status == 12029) {
                fieldValidator(null, ERROR_SERVER, "absolute", true);
            }
        }
        return parseJSON("(" + respText + ")");
    } else if(jason.CallStatus == "failure"){
        var maincode = (typeof jason.MainCode == "undefined")? "": jason.MainCode;
        return {"ErrorDesc": jason.Description, "MainCode": maincode};
    }
}


     
var operationData='';
function SearchWorkitem(queueId,processDefId,mode,orderBy,filterString,strData){
    if (typeof strData == "undefined") {
        operationData = '';
    }
    else {
        operationData = strData;
    }
    var wlscrollleft = document.getElementById("wlf:wlscrollleft");
    if (wlscrollleft) {
        wlscrollleft.value = "";
    }
     hidePopupMask();
     window.parent.allowCustomWL=false;
     if(typeof isShowCustomWorklist !='undefined' && isShowCustomWorklist=='Y'){
            if(typeof window.parent.document.getElementById("customWLIframe") !='undefined' && window.parent.document.getElementById("customWLIframe")!=null){
               if(window.parent.document.getElementById("customWLIframe").style.visibility="visible"){
                   window.parent.document.getElementById("customWLIframe").style.display = "none";
               }
           }
           
      }
      if (window.parent.iFrameCustomWLRef != null && typeof window.parent.iFrameCustomWLRef != 'undefined') {

            if (window.parent.iFrameCustomWLRef.style.display = "none") {
                window.parent.iFrameCustomWLRef.style.display = "";
            }
        }
//    if(CurrentlyProcessing)
//        {
//            alert(WORKITEM_LIST_CURRENTLY_LOADING);
//            return ;
//        }
//     CurrentlyProcessing=true;
     document.getElementById("wlf:hidQueueType").value="";
    //    alert(queueId);alert(processDefId);alert(mode);alert(filterString);
    if(queueId!=undefined && queueId!=""){
        document.getElementById('wlf:hidQueueId').value=queueId;
        document.getElementById('wlf:hidProcessDefId').value="";
    }else if(processDefId!=undefined && processDefId!=""){
        document.getElementById('wlf:hidQueueId').value="";
        document.getElementById('wlf:hidProcessDefId').value=processDefId;
    }else{
        document.getElementById('wlf:hidQueueId').value="";
        document.getElementById('wlf:hidProcessDefId').value="";
    }
    
    //hidFlag --> 1 when queueclick ; 2 when filterclick; 3 when advancesearchclick; 4 when quicksearch;
    if(queueId!=undefined && queueId!="" && queueId!="0"){
        document.getElementById('wlf:hidFlag').value="1";
    }else{
        document.getElementById('wlf:hidFlag').value="3";
    }

    if(orderBy!=undefined && orderBy!=""){
        document.getElementById('wlf:hidOrderBy').value=orderBy;
    }
    document.getElementById('wlf:hidSearch').value=true;
    document.getElementById('wlf:hidWListMode').value=mode;
    
    if(mode=='PM'){
        document.getElementById('wlf:hidAdhocRoutingFlag').value="Y";
        document.getElementById('wlf:hidUnlockFlag').value="Y";
    }
    
    filterString = decodeURIComponent(filterString);
	filterString = filterString.replace(/\\&#39;/g, "&apos;");
    document.getElementById('wlf:hidAllowReassignment').value="N";
    document.getElementById('wlf:hidFilterString').value=filterString;
    document.getElementById('wlf:hidClientSorting').value=false
    document.getElementById("wlf:hidSelectedQueryIndex").value="";
     document.getElementById('wlf:hidClientSorting').value=false;
    
    var ref = document.getElementById('wlf:cid');
    if(ref){
        ref.value = "";
    }
    ref = document.getElementById('wlf:fid');
    if(ref){
        ref.value = "";
    }
    
    clickLink("wlf:searchWorkitem");
    }

function FilterWorkitem(queueId,queuename,filterString){
    if(queueId!=undefined && queueId!=""){
        document.getElementById('wlf:hidQueueId').value=queueId;
    }else{
        document.getElementById('wlf:hidQueueId').value='0';
    }

    if(queuename!=undefined && queuename!="")
    {
        document.getElementById('wlf:hidQueueName').value=queuename;
    }else{
        document.getElementById('wlf:hidQueueName').value='MyQueue';
    }

    document.getElementById('wlf:hidFlag').value="2";
    document.getElementById('wlf:hidFilterString').value=filterString;
    document.getElementById('wlf:hidSearch').value=false;
    
    var ref = document.getElementById('wlf:cid');
    if(ref){
        ref.value = "";
    }
    ref = document.getElementById('wlf:fid');
    if(ref){
        ref.value = "";
    }
    
    if(isIE()){
        clickLink("wlf:fetchWorkitem");
    }else {
        clickLinkSafari("wlf:fetchWorkitem");
    }
}

function sbf(ref,setOrderBy){
    var divScroll = document.getElementById("scroll");
    var wlscrollleft = document.getElementById("wlf:wlscrollleft");
    if(wlscrollleft) {
        wlscrollleft.value = divScroll.scrollLeft;
    }
    var id=ref.id;
    //var formid=id.substring(0,id.lastIndexOf(":"));
    
    var formid="wlf";
    
    var formRef = document.getElementById("wlf");
    if(formRef != null){
        formid = "wlf";
    } else {
        formRef = document.getElementById("frmlinkedworkitemlist");
        if(formRef != null){
            formid = "frmlinkedworkitemlist";
        }
    }
    
    var searchFlag=document.getElementById(formid+":hidFlag").value;
	sortOrder = document.getElementById(formid+':hidSortOrder').value;	 
    if(orderBy==setOrderBy){
        sortOrder = (sortOrder=="A")?"D":"A";
    }else{
        orderBy = setOrderBy;
        sortOrder = (sortOrder=="A")?"D":"A";
    }
    //document.getElementById('blankPanel:bluePanel:wlf:hidSortingEnabled').value=true;
    document.getElementById(formid+':hidOrderBy').value=orderBy;
    document.getElementById(formid+':hidSortOrder').value=sortOrder;
    document.getElementById(formid+':hidClientSorting').value=true;
    document.getElementById(formid+':hidRetainOldBatchInfo').value=false;

    /** support of client sorting ***/
    if(searchFlag!=2 && searchFlag!=3 && searchFlag!=4){
        document.getElementById(formid+":hidClientSorting").value=true;
    }
    /** support of client sorting ***/

    var hidCtrSrch = document.getElementById(formid+':hidCtrSrch').value;
    if(hidCtrSrch=='true'){
        clickLink(formid+":searchCriteria");
    } else {
        clickLink(formid+":lnkSortData");
    }
   // onloadInit();
}

function sbfa(ref,setOrderBy,queueVar){
    var divScroll = document.getElementById("scroll");
    var wlscrollleft = document.getElementById("wlf:wlscrollleft");
    if (wlscrollleft) {
        wlscrollleft.value = divScroll.scrollLeft;
    }
    var id=ref.id;
    var formid=id.substring(0,id.lastIndexOf(":"));
    if(orderBy==setOrderBy){
        sortOrder = (sortOrder=="A")?"D":"A";
    }else{
        orderBy = setOrderBy;
        sortOrder = "A";
    }

    document.getElementById(formid+':hidOrderBy').value=orderBy;
    document.getElementById(formid+':hidSortOrder').value=sortOrder;
    document.getElementById(formid+':hidQueueVarName').value=queueVar;
    document.getElementById(formid+':hidClientSorting').value=true;
    document.getElementById(formid+':hidRetainOldBatchInfo').value=false;
    var hidCtrSrch = document.getElementById(formid+':hidCtrSrch').value;
    
    if(hidCtrSrch=='true'){
        clickLink(formid+":searchCriteria");
    } else {
        clickLink(formid+":lnkSortData");
    }
    
    //onloadInit();
}
function RefreshWorklist(width,height){
    if(width!=undefined && width!="")
        document.getElementById('wlf:hidWidth').value=width;
    if(height!=undefined && height!="")
        document.getElementById('wlf:hidHeight').value=height;
    
    var hidCtrSrch = document.getElementById('wlf:hidCtrSrch').value;
    if(hidCtrSrch=='true'){
        clickLink("wlf:searchCriteria");
    } else {
        clickLink("wlf:lnkSortData");
    }
    
    handleMoreOption();
}

function RefreshWorklistWrapper(opr){
    if(typeof opr!='undefined' && opr!=null){
        document.getElementById('wlf:hidOprFlag').value=true;
        document.getElementById('wlf:hidOprPerf').value=opr;
     }
     else{
        document.getElementById('wlf:hidOprFlag').value=false;
        document.getElementById('wlf:hidOprPerf').value="";
        }
        RefreshWorklist();
}

function onloadInit(){
    try{
        if(typeof window.parent.showHideNotification!='undefined'){
            window.parent.showHideNotification(true);
        }
        var oper=document.getElementById('wlf:hidFlag').value;

        var ref = document.getElementById("wlf:pqks:searchPrefix");
        if(ref == null){
            ref = document.getElementById("wlf:searchPrefix");
        }
        if(ref != null){
            var quickSearchVar=ref.value;
            if(quickSearchVar!=""){
                //document.getElementById("wlf:pqks:Prefix").value=quickSearchVar;
                changeimage(2);
            }
        }

        var queueId=document.getElementById('wlf:hidQueueId').value;
        var processDefId=document.getElementById('wlf:hidProcessDefId').value;
        var processName=document.getElementById('wlf:hidPName').value;
        var strWiCount=document.getElementById('wlf:countFromSearch').value;
        var qtype = document.getElementById('wlf:hidQueueType').value;
        var srchRef = document.getElementById('frmworkitemlist:hidSearch');
        var fromSearch = ((srchRef != null) && (srchRef.value == 'true'));
        var queueName;
        if(queueId=="0"){
            queueName=MY_QUEUE;
            if (showWorkitemCount && (strWiCount != '')) {
                if (qtype != 'F') {
                    queueName = queueName + " [" + strWiCount + "]";
                }
            }
        }else if(queueId=="" && (oper=="4" || oper=="3")){
            queueName=LABEL_MYSEARCHQUEUE;
            if (showWorkitemCount && (strWiCount != '')) {
                if (qtype != 'F') {
                    queueName = queueName + " [" + strWiCount + "]";
                }
            }
        }else if(queueId==""){
            queueName=AUTHORIZED_QUEUE;
        }else{
            queueName=document.getElementById('wlf:hidQueueName').value;
            if (queueName.length > 0){
                if (showWorkitemCount && (strWiCount != '')){
                    if (qtype != 'F'){
                        queueName = queueName + " [" + strWiCount + "]";
                    }
                }
            }
        }
        //alert("onloadInit=="+comp_ins_id+"--"+queueName);
        if(typeof wLMode!='undefined' && wLMode=='CM') {
            window.parent.changePanelTitle(comp_ins_id,"");
        } else {
            window.parent.changePanelTitle(comp_ins_id,queueName);
        }
        
        var ctrlTableId="wlf:pnlResult";
        renderButtons(ctrlTableId,"wlf");
        createFixedTableHeader(ctrlTableId,'wlf');
        
        handleMoreOption();
        preHandleOptionsHook(queueId,queueName,processDefId,oper);
        if(oper=="4") {
            document.getElementById("wlf:lblWI1").style.display="none";
        }   
        //Bug 71038
         try{
                    if(timeOutId!=''){
                        window.clearTimeout(timeOutId);
                    }
                    var refInterval=document.getElementById('wlf:hidRefreshInterval').value;
                    refInterval=refInterval-0;
                    if(refInterval > 0){
                        var rtime=(refInterval-0)*60*1000;
                        timeOutId=setTimeout("autoRefreshWorklist()",rtime);
                    }
                }catch(e){
                
            }
        
        CurrentlyProcessing=false;
    } catch(e){
        CurrentlyProcessing=false;
    }
}

var lastPanelTitle = "";
var height = ""; 
function onloadInitWorklistAjax(data){
 //   var isPop = document.getElementById('wlf:hidRefreshFlag').value;
    HandleProgressBar(data);
    if(data.status == "complete" && document.getElementById("scroll")!= null)
       height =  document.getElementById("scroll").style.height;
        
    
    if(data.status == "success"){
        try{
            loadReminderCount();
            var ctrSrchRef = document.getElementById('wlf:hidCtrSrch');
            if(ctrSrchRef){
                var optRef = null;
                if(ctrSrchRef.value == 'true'){
                    optRef = document.getElementById('wlf:setFilter');
                    if(optRef){
                        optRef.style.display='none';
                    }
                    optRef = document.getElementById('wlf:lblWI1');
                    if(optRef){
                        optRef.style.display='none';
                    }
                } else {
                    optRef = document.getElementById('wlf:setFilter');
                    if(optRef){
                        optRef.style.display='';
                    }
                    optRef = document.getElementById('wlf:lblWI1');
                    if(optRef){
                        optRef.style.display='';
                    }
                }
            }
            
            var WorkListHeaderTitle = "";
            var oper=document.getElementById('wlf:hidFlag').value;            

            var quickSearchVar=document.getElementById("wlf:pqks:searchPrefix");
            if(quickSearchVar == null){
                quickSearchVar=document.getElementById("wlf:searchPrefix");
            }
            
            quickSearchVar = quickSearchVar.value;
            
            if(quickSearchVar!=""){
                var ref = document.getElementById("wlf:pqks:Prefix");
                if(ref == null){
                    ref = document.getElementById("wlf:Prefix");
                }
                ref.value=quickSearchVar;
            }

            var queueId=document.getElementById('wlf:hidQueueId').value;
            var processDefId=document.getElementById('wlf:hidProcessDefId').value;
            var processName=document.getElementById('wlf:hidPName').value;
            var strWiCount=document.getElementById('wlf:countFromSearch').value;
            var qtype = document.getElementById('wlf:hidQueueType').value;
            var srchRef = document.getElementById('wlf:hidSearch');
            var fromSearch = ((srchRef != null) && (srchRef.value == 'true'));
            var queueName;
            if(queueId=="0"){
                queueName=MY_QUEUE;
                WorkListHeaderTitle = MY_QUEUE;
                if (showWorkitemCount && (strWiCount != '')) {
                    if (qtype != 'F') {
                        WorkListHeaderTitle = queueName + " [" + strWiCount + "]";
                    }
                }
            }else if(oper=="4" || oper=="3"){//else if(queueId=="" && (oper=="4" || oper=="3")){ //Bug Id: 38552
                queueName=LABEL_MYSEARCHQUEUE;
                WorkListHeaderTitle = LABEL_MYSEARCHQUEUE;
                if (showWorkitemCount && (strWiCount != '')) {
                    if (qtype != 'F'  && oper !="4") {
                        WorkListHeaderTitle = WorkListHeaderTitle + " [" + strWiCount + "]";
                        optRef = document.getElementById('wlf:lblWI1');
                        if (optRef) {
                            optRef.style.display = '';
                        }
                    } else {
                        optRef = document.getElementById('wlf:lblWI1');
                        if (optRef) {
                            optRef.style.display = 'none';
                        }
                    }
                    
                } 
            }else if(queueId==""){
                queueName=AUTHORIZED_QUEUE;
                WorkListHeaderTitle = AUTHORIZED_QUEUE;
            }else{
                queueName=document.getElementById('wlf:hidQueueName').value;
                if((queueName.length > 0) && !fromSearch){
                    WorkListHeaderTitle = queueName;
                    if(showWorkitemCount && (strWiCount != '')){
                        if(qtype != 'F'){
                            WorkListHeaderTitle=queueName+" ["+strWiCount+"]";
                        }
                    }
                } else if(oper=="1" && fromSearch){
                    queueName=LABEL_MYSEARCHQUEUE;
                    WorkListHeaderTitle = LABEL_MYSEARCHQUEUE;
                }
            }
            
            if(oper=="5"){
                queueName=document.getElementById('wlf:hidQueueName').value;
                WorkListHeaderTitle = queueName;
                if (showWorkitemCount && (strWiCount != '')) {
                    if (qtype != 'F') {
                        WorkListHeaderTitle = queueName + " [" + strWiCount + "]";
                    }
                }
            }
            
            if(data.source.id.indexOf("searchWorkitem") >= 0){
                WorkListHeaderTitle = LABEL_MYSEARCHQUEUE;
                if (showWorkitemCount && (strWiCount != '')) {
                    if (qtype != 'F') {
                        WorkListHeaderTitle = WorkListHeaderTitle + " [" + strWiCount + "]";
                    }
                } 
            }    
            if(data.source.id.indexOf("fetchWorkitem") >= 0)
            {
                WorkListHeaderTitle = LABEL_SETFILTERFORQUEUE + queueName;
                if (showWorkitemCount && (strWiCount != '')) {
                    if (qtype != 'F') {
                        WorkListHeaderTitle = WorkListHeaderTitle + " [" + strWiCount + "]";
                    }
                }       

            }
            if(data.source.id.indexOf("fetchWorkitemBasedOnQueryList") >= 0){
                WorkListHeaderTitle = LABEL_MYSEARCHQUEUE;
                
                if (showWorkitemCount && (strWiCount != '')) {
                    if (qtype != 'F') {
                        WorkListHeaderTitle = WorkListHeaderTitle + " [" + strWiCount + "]";
                    }
                    optRef = document.getElementById('wlf:lblWI1');
                    if(optRef){
                        optRef.style.display='none';
                    }
                } 
            }
            if(data.source.id.indexOf("wlf:cmdBtn") >= 0){
                WorkListHeaderTitle = LABEL_MYSEARCHQUEUE;
                
                if (showWorkitemCount && (strWiCount != '')) {
                    if (qtype != 'F') {
                        WorkListHeaderTitle = WorkListHeaderTitle + " [" + strWiCount + "]";
                    }
                    optRef = document.getElementById('wlf:lblWI1');
                    if(optRef){
                        optRef.style.display='none';
                    }
                } 
            }
            
            if(WorkListHeaderTitle == ""){
               WorkListHeaderTitle = queueName; 
            }

            
            if(!(data.source.id.indexOf("nextCmdLink")>0||data.source.id.indexOf("prevCmdLink")>0)){//Bug 74298 Start
                if(typeof wLMode!='undefined' && wLMode=='CM') {
                    window.parent.changePanelTitle(comp_ins_id,"");
                } else {
                    window.parent.changePanelTitle(comp_ins_id,WorkListHeaderTitle);
                }
                
                lastPanelTitle = WorkListHeaderTitle;
            } else {
                if(lastPanelTitle != ''){
                    window.parent.changePanelTitle(comp_ins_id,lastPanelTitle);
                }
            }
                ////Bug 74298 End
            //alert("onloadInitWorklistAjax="+comp_ins_id+"--"+WorkListHeaderTitle)
            
            var ctrlTableId="wlf:pnlResult";
            renderButtons(ctrlTableId,"wlf");
            createFixedTableHeader(ctrlTableId,'wlf');
            if (window.parent.iFrameSearchBarRef && oper == "4") {
                window.parent.iFrameSearchBarRef.SaveRecentSearch();
            }
            handleMoreOption();
            preHandleOptionsHook(queueId,queueName,processDefId,oper);

            try{
                    if(timeOutId!=''){
                        window.clearTimeout(timeOutId);
                    }
                    var refInterval=document.getElementById('wlf:hidRefreshInterval').value;
                    refInterval=refInterval-0;
                    if(refInterval > 0){
                        var rtime=(refInterval-0)*60*1000;
                        timeOutId=setTimeout("autoRefreshWorklist()",rtime);
                    }
                }catch(e){
                
            }
            
            CurrentlyProcessing=false;
            if(typeof window.parent.workitemListReloadHandlerCallback != 'undefined'){
                window.parent.workitemListReloadHandlerCallback(queueId,queueName,processDefId,oper);//Bug 79693
            }
            
        } catch(e){
            CurrentlyProcessing=false;
            if(typeof window.parent.workitemListReloadHandlerCallback != 'undefined'){
            window.parent.workitemListReloadHandlerCallback(queueId,queueName,processDefId,oper);//Bug 79693
           }
        }
        
        if(document.getElementById("scroll")!= null && height != "")
         document.getElementById("scroll").style.height = height;
    }
    var divScroll = document.getElementById("scroll");
    var nScrollLeftPos = document.getElementById("wlf:wlscrollleft").value;
    divScroll.scrollLeft = parseInt(nScrollLeftPos);
 //   if (isPop == 'N') {
        if (window.parent.popoutMode) {
            document.getElementById("wlf:popoutIcon").style.display = "none";
            document.getElementById("wlf:popinIcon").style.display = "";
            window.parent.popoutMode = true;
        } else {
            document.getElementById("wlf:popoutIcon").style.display = "block";
            document.getElementById("wlf:popinIcon").style.display = "none";
            window.parent.popoutMode = false;
        }
//    }
}

function autoRefreshWorklist(){
    compRefresh();
}

function createFixedTableHeader(tableId,formId){
    //To create Header(not scrolling) of the table
        iColNos=document.getElementById(formId+":NoOfCols").value;
        var pgData=document.getElementById(tableId);
        var headerRow=pgData.rows[0];
        headerRow.style.display="none";
        var header=pgData.createTHead();
        var tbody=pgData.tBodies[0];
        var trElement = document.createElement('tr');
        header.appendChild(trElement);
        trElement.className="wdheaderclass wdAlignleft";
        var Count=tbody.rows.length;
        var strWLMode = (typeof wLMode == 'undefined')? 'PM':wLMode;
        var c=' toolbarbgcolor ';
        
        //alert("createFixedTableHeader"+Count);
        if(Count!=1){
            for(iCount=0;iCount<=iColNos;iCount++){
                var thElement = document.createElement('th');
                //thElement.className = tbody.rows[0].cells[iCount].className;
                thElement.className = "wdwidth1"+c+"tableheader";
                for (var i = 0; i < tbody.rows[0].cells[iCount].childNodes.length; i++) {
                    thElement.appendChild(tbody.rows[0].cells[iCount].childNodes[i]);
                    if(hasCSS(thElement.children[0], 'np')){
                        thElement.className += ' np';
                    }
                }
               trElement.appendChild(thElement);
           }
           
           var thElement = document.createElement('th');
           thElement.className = "wdwidth100"+c+"tableheader";
           trElement.appendChild(thElement);
        }
        
    initTableHeaderFix();
}

function cbc(ref,value){
    var id=ref.id;
    var formId=id.substring(0,id.lastIndexOf(":"));

    var tempCtrl=ref.lastChild;
    if(tempCtrl==null)
        tempCtrl=ref;

    var index = tempCtrl.id.lastIndexOf(':');
    var arr=tempCtrl.id.split(":");
    var iArrLength = arr.length ;
    var strName="";
    var selectedRow=arr[iArrLength-1];
    selectedRow=selectedRow.substring(selectedRow.lastIndexOf("_")+1, selectedRow.length)
    for (var count=0; count < arr.length-1 ; count++ )
    {
        if(count==0)
            strName = arr[count];
        else
        {
            strName=strName + ":" + arr[count] ;
        }
    }
    strName=strName+":cb";
    var nodeChkBox=document.getElementById(strName+"_"+selectedRow);
    var tableTR=ref.parentNode.parentNode;
    
    if(!nodeChkBox.checked)
    {
        //tableTR.className='wdSimple';
       // tableTR.style.backgroundColor = "#FFFFFF";
       // tableTR.style.color = "#008000";
       // nodeChkBox.checked=false;
    }
    else
    {
        //tableTR.className='oarowstyle';
       // tableTR.style.backgroundColor = "#EEF3E2";
        //tableTR.style.color = "#B50000";
        //nodeChkBox.checked=true;
    }

    var ctrlTableId=formId+":pnlResult";
    if(formId!='frmlinkedworkitemlist')
        renderButtons(ctrlTableId,formId);
    SelectDeselectHeader(ctrlTableId,formId);
}
var prevpDefId = "";
var currpDefId = "";
function renderButtons(ctrlTableId,formid){
    prevpDefId = "";
    currpDefId = "";
//alert(ctrlTableId);
    var checkboxId=formid+":cb_";
    var ctrlTable=document.getElementById(ctrlTableId);
//alert(ctrlTable);
    var bInitiate = false;
    var bNew = true;
    var bDone=false;
    var bReminder=false;
    var bRefer=false;
    var bReassign = false;
    var bProperty =false;
    var bLockforMe=false;
    var bRelease=false;
    var bRevoke=false;
    var bPriority=false;
    var bDelete=false;
    var bUnAssign=false;
    var EffAdhocStatus=0;
    var EffLockStatus=0;
    var selectetdRowCount=0;
    var checkedStatus=0;
    var bHold = false;
    var bUnhold = false;
    tempAdhocStatus=1;
    tempLockStatus=1;
    var separatorQueue="";    
    var queueType = "";
	var arrworkitemData = [];
    var arrProcessDefId =[];
    var arrActivityId = [];
    var arrWINum = [];
    var enableReassign="N";
    var k=1;
    if(typeof document.getElementById("wlf:hidQueueType") != 'undefined'){
        queueType=document.getElementById("wlf:hidQueueType").value;
    }    
    
    var queueID=document.getElementById("wlf:hidQueueId").value;
    var fromFlag=document.getElementById('wlf:hidFlag').value;//Bug 68249
    fromFlag = (fromFlag == null || fromFlag == "")? 1: fromFlag;
    var queueName=document.getElementById("wlf:hidQueueName").value;
    var isFromSearch = document.getElementById('wlf:hidSearch').value;
    var allowReassign=document.getElementById('wlf:hidAllowReassignment').value;        
    if(queueID==0 || isFromSearch == 'true'){
       allowReassign="Y";
    }
    var strfrom;
    if (fromFlag == "1") {
        strfrom = "W"
    } else if (fromFlag == "2") {
        strfrom = "F";
    } else if (fromFlag == "3" || fromFlag == "4") {
        strfrom = "S";
    }
    var isFromFilterSearch = document.getElementById('wlf:hidIsFilterSearch').value;
   var bShowNewBtn = document.getElementById("wlf:bShowNewBtn").value;   
   var isNewbtn = enableWLNew(queueName,username);     //87680
    if(queueType=="I" && bShowNewBtn=="true" && isFromSearch != "true" && isNewbtn){
       bNew =true;
    }else{
       bNew = false;
    }
        try
    {
        if(ctrlTable!=null)
        {

            var rowCount = ctrlTable.tBodies[0].rows.length;            
            GLRowCount=rowCount;            
            if(rowCount>0) {
                for(var iCount = 0; iCount < rowCount-1;iCount++)
                {
                    var el=document.getElementById(checkboxId+iCount);
                    var jsonOutput=document.getElementById("wlf:hop"+(iCount+1)).innerHTML;
                    //Bug 72743 Start
                    var jsonOutputWorkItemData=document.getElementById("wlf:hjn"+(iCount+1)).innerHTML;
                    //jsonOutputWorkItemData=jsonOutputWorkItemData.replace(/\'/g,"\\'");
                    //jsonOutputWorkItemData =JSON.parse(jsonOutputWorkItemData);
                    jsonOutputWorkItemData = jsonOutputWorkItemData.split(SEPERATOR1+SEPERATOR4);
                    //Bug 72743 End
                    
                    /*jsonOutput= JSON.parse(jsonOutput);
                    var objJsonObj= jsonOutput.Options;*/
                    
                    var objJsonObj= jsonOutput.replace(/(\r\n|\n|\r)/gm, "");
                    
                    if(el.checked)//Bug 72743 
                    {
                        checkedStatus=1;
                        selectetdRowCount++;
						
                        arrWINum[i] = jsonOutputWorkItemData[1];
                        arrProcessDefId[i] = jsonOutputWorkItemData[5] ;
                        arrActivityId[i] = jsonOutputWorkItemData[9];
                        arrworkitemData.push({WINumber : arrWINum[i] ,ProcessDefId: arrProcessDefId[i], ActivityId: arrActivityId[i]});
                            
						if(arrworkitemData.length >1){
							for(var i=0; i<arrworkitemData.length; i++)  {
								if(k<arrworkitemData.length){
									if((arrworkitemData[i].ActivityId == arrworkitemData[k].ActivityId)&&(arrworkitemData[i].ProcessDefId == arrworkitemData[k].ProcessDefId)){
										document.getElementById("wlf:hidActivityId").value = arrworkitemData[i].ActivityId;
										document.getElementById("wlf:hidProcessDefId").value = arrworkitemData[i].ProcessDefId;
										enableReassign="Y";
									
									}else{
										enableReassign="N"; 
										document.getElementById("wlf:hidActivityId").value = "";
										document.getElementById("wlf:hidProcessDefId").value = "";
									}
									k++;
								}
							}
						}else{
                            if(selectetdRowCount==1 && jsonOutputWorkItemData[8]!="1" && jsonOutputWorkItemData[8]!="2" && jsonOutputWorkItemData[14]!="E" && jsonOutputWorkItemData[14]!="Z"){
								enableReassign="Y";
								document.getElementById("wlf:hidProcessDefId").value = jsonOutputWorkItemData[5];
								document.getElementById("wlf:hidActivityId").value = jsonOutputWorkItemData[9];
                            }
                       }
                        var assignmentType="";// Bug 72743 Start
//                        for(var jsonCount=0;jsonCount<jsonOutputWorkItemData.Outputs.length;jsonCount++){
//                            if(jsonOutputWorkItemData.Outputs[jsonCount].Output.Name=="AssignmentType"){
                                assignmentType=jsonOutputWorkItemData[14];
//                                break;
//                            }
//                        }//Bug 72743 End
                        if(selectetdRowCount==1&&assignmentType!='R'){//Bug 72743,Bug 73705
                            bReminder=true;
                            bProperty = true;
                            
                            if(objJsonObj[Initiate]=="1")
                                bInitiate=true;
                            if(objJsonObj[Done]=="1")
                                bDone=true;
                            if(objJsonObj[Delete]=="1")
                                bDelete=true;
                            if(objJsonObj[Reassign]=="1" && allowReassign=="Y" && enableReassign=="Y")
                                bReassign=true;
                            if(objJsonObj[Refer]=="1")
                                bRefer=true;
                            if(objJsonObj[Revoke]=="1")
                                bRevoke=true;
                            if(objJsonObj[Priority]=="1")
                                bPriority=true;
                            if(objJsonObj[Reminder]=="1")
                                bReminder=true;
                            if(objJsonObj[LockForMe]=="1" && allowReassign=="Y" && queueID != '0') //Bug 90500
                                bLockforMe=true;
                            if(objJsonObj[UnAssign]=="1")
                                bUnAssign=true;  
                            if(objJsonObj[Hold]=="1")
                                bHold=true;
                            if(objJsonObj[Unhold]=="1")
                                bUnhold=true;
                        }
                        else{
                            bProperty=true;//Bug 73705
                        }
                        if(selectetdRowCount>1){
                            bReminder=false;
                            bProperty = false;
                            bHold=false;
                            bUnhold=false;
                            if( bInitiate && objJsonObj[Initiate]=="0")
                                bInitiate=false;
                            if(bDone && objJsonObj[Done]=="0")
                                bDone=false;
                            if(bDelete && objJsonObj[Delete]=="0")
                                bDelete=false;
                            if((bReassign && objJsonObj[Reassign]=="0" && allowReassign=="Y") ||(arrworkitemData.length>1 && enableReassign=="N"))
                                bReassign=false;
                            if(bRefer && objJsonObj[Refer]=="0")
                                bRefer=false;
                            if(bRevoke && objJsonObj[Revoke]=="0")
                                bRevoke=false;
                            if(bPriority && objJsonObj[Priority]=="0")
                                bPriority=false;
                            if(objJsonObj[LockForMe]=="1" && allowReassign=="Y" && queueID != '0'|| (EnableAssignMeSearchWIList=='Y' && isFromSearch == "true" && assignmentType!='E' && assignmentType!='Z')) //Bug 95296
                                bLockforMe=true;
                            if(bUnAssign && objJsonObj[UnAssign]=="0")
                                bUnAssign=false;
                         }
                         
                        renderAdhocRouting(iCount+1);
                        renderUnlock(iCount+1);
                        
                        
                        prevpDefId=currpDefId;
                        if (isFromSearch == 'true' && jsonOutputWorkItemData[12] != '0' && jsonOutputWorkItemData[11] != '') {
                            separatorQueue += jsonOutputWorkItemData[11] + ",";
                        }
                        if (isFromSearch == 'true' && jsonOutputWorkItemData[12] == '0' && jsonOutputWorkItemData[13] == username) {
                            separatorQueue += "My Queue,";
                            
                        }
                        if (isFromSearch == 'true' && jsonOutputWorkItemData[12] == '0' && jsonOutputWorkItemData[13] != username) {
                            separatorQueue += ',';
                        }
                    }
                    
                }
            }
                        /*if (rowCount == 1) {
                var jsonOutputWorkItemData = document.getElementById("wlf:hjn" + (iCount + 1)).innerHTML;
                jsonOutputWorkItemData = jsonOutputWorkItemData.split(SEPERATOR1);
                var el = document.getElementById(checkboxId + iCount);
                if (e1.checked) {
                    if (isFromSearch == 'true' && jsonOutputWorkItemData[12] != '0' && jsonOutputWorkItemData[11] != '') {
                        separatorQueue= jsonOutputWorkItemData[11] + ",";
                    }
                    if (isFromSearch == 'true' && jsonOutputWorkItemData[13] == username && queueID == 0) {
                        separatorQueue = "My Queue,";
                    }
                    if (isFromSearch == 'true' && jsonOutputWorkItemData[13] != username && queueID == 0) {
                        separatorQueue = '';
                    }
                }
            }*/
            
        }


        /***************Client.js enabling disabling checks*****************/
        if (isFromSearch == 'true' && separatorQueue != '') {
             if (!enableInitiate(separatorQueue.substring(0,separatorQueue.length - 1), isFromSearch, bInitiate, "S"))
                bInitiate = false;

            if (!enableDone(separatorQueue.substring(0,separatorQueue.length - 1), isFromSearch, bDone, "S"))
                bDone = false;

        } else if(isFromFilterSearch == 'true'){
            if (!enableInitiate(queueName, isFromFilterSearch, bInitiate, "F"))
                bInitiate = false;

            if (!enableDone(queueName, isFromFilterSearch, bDone, "F"))
                bDone = false;
        } else {
            if (!enableInitiate(queueName, isFromSearch, bInitiate, "W"))
                bInitiate = false;

            if (!enableDone(queueName, isFromSearch, bDone, "W"))
                bDone = false;
        }
        



        /***************Client.js enabling disabling checks*****************/


        var NewInitiate;
        var disNewInitiate;
        var NewShow;
        var NewDone;
        var NewRelease;
        NewInitiate=document.getElementById("wlf:NewInitiate");
        disNewInitiate=document.getElementById("wlf:disNewInitiate");
        if(NewInitiate!=undefined){// && disNewInitiate!=undefined){
            if(bInitiate){
                // alert("33");

                NewInitiate.style.display="inline-block";
                //disNewInitiate.style.display="none";
            }else{
                // alert("44");
                NewInitiate.style.display="none";
                //disNewInitiate.style.display="inline-block";
            }
        }else{
            NewInitiate=document.getElementById("wlf:NewInitiate");
            disNewInitiate=document.getElementById("wlf:disNewInitiate");
            if(NewInitiate!=undefined && disNewInitiate!=undefined){
                if(bInitiate){
                    // alert("33");

                    NewInitiate.style.display="inline-block";
                    //disNewInitiate.style.display="none";
                }else{
                    // alert("44");
                    NewInitiate.style.display="none";
                    //disNewInitiate.style.display="inline-block";
                }
            }
        }
        if (typeof showHideWorkitemOption != 'undefined') {
            if (!showHideWorkitemOption('Initiate', operationData)) {
                if (NewInitiate != null)
                    NewInitiate.style.display = "none";
                if (disNewInitiate != null)
                    disNewInitiate.style.display = "inline-block";
            }
        }
        NewShow=document.getElementById("wlf:NewShow");
        var disNewShow=document.getElementById("wlf:disNewShow");
        if(NewShow!=undefined){// && disNewShow!=undefined){
            if(bNew){
                //alert("33");

                NewShow.style.display="inline-block";
                //disNewShow.style.display="none";
            }else{
                //alert("44");
                NewShow.style.display="none";
                //disNewShow.style.display="inline-block";
            }
        }else{
             NewShow=document.getElementById("wlf:NewShow");
            disNewShow=document.getElementById("wlf:disNewShow");
            if(NewShow!=undefined && disNewShow!=undefined){
                if(bNew){
                    //alert("33");

                    NewShow.style.display="inline-block";
                    //disNewShow.style.display="none";
                }else{
                    //alert("44");
                    NewShow.style.display="none";
                    //disNewShow.style.display="inline-block";
                }
            }
        }
        
        if (typeof showHideWorkitemOption != 'undefined') {
            if (!showHideWorkitemOption('New', operationData)) {
                if (NewShow != null)
                    NewShow.style.display = "none";
                if (disNewShow != null)
                    disNewShow.style.display = "inline-block";
            }
        }
        NewDone=document.getElementById("wlf:NewDone");
        var disNewDone=document.getElementById("wlf:disNewDone");
        if(NewDone!=undefined){// && disNewDone!=undefined){
            if(bDone){
                NewDone.style.display="inline-block";
                //disNewDone.style.display="none";
            }else{
                NewDone.style.display="none";
                //disNewDone.style.display="inline-block";
            }
        }else{
            NewDone=document.getElementById("wlf:NewDone");
            disNewDone=document.getElementById("wlf:disNewDone");
            if(NewDone!=undefined){// && disNewDone!=undefined){
                if(bDone){
                    NewDone.style.display="inline-block";
                    disNewDone.style.display="none";
                }else{
                    NewDone.style.display="none";
                    disNewDone.style.display="inline-block";
                }
            }
        }
        
        if (typeof showHideWorkitemOption != 'undefined') {
            if (!showHideWorkitemOption('Done', operationData)) {
                if (NewDone != null)
                    NewDone.style.display = "none";
                if (disNewDone != null)
                    disNewDone.style.display = "inline-block";
            }
        }
        var eRefer;
        var disRefer;
        disRefer=document.getElementById("wlf:disableRefer");
        eRefer=document.getElementById("wlf:Refer");
        var referPattern = oprPattern.Refer;//Bug 68249
        if(eRefer!=undefined && referPattern!=undefined){
            if(bRefer && referPattern[fromFlag-1]=="1"){
                eRefer.style.display="inline-block";
                //disRefer.style.display="none";
            }else{
                eRefer.style.display="none";
                //disRefer.style.display="inline-block";

            }
        }else{
             disRefer=document.getElementById("wlf:disableRefer");
             eRefer=document.getElementById("wlf:Refer");
              if(eRefer!=undefined && referPattern!=undefined){
                if(bRefer && referPattern[fromFlag-1]=="1"){
                    eRefer.style.display="inline-block";
                    //disRefer.style.display="none";
                }else{
                    eRefer.style.display="none";
                    //disRefer.style.display="inline-block";

                }
            }
        }
        if (typeof showHideWorkitemOption != 'undefined') {
            if (!showHideWorkitemOption('Refer', operationData)) {
                if (eRefer != null)
                    eRefer.parentNode.style.display = "none";
            }
        }
        
        if (typeof enableReferHook != 'undefined' && bRefer) {
            if (!enableReferHook(queueName,strfrom)) {
                if (eRefer != null)
                    eRefer.style.display = "none";
                if (disRefer != null)
                    disRefer.style.display = "inline-block";
            }else {
                if (eRefer != null)
                    eRefer.style.display = "inline-block";
                if (disRefer != null)
                    disRefer.style.display = "none";
            }
        }
        
        var eRevoke;
        var disrevoke;
        disrevoke=document.getElementById("wlf:disableRevoke");
        eRevoke=document.getElementById("wlf:Revoke");
        var revokePattern = oprPattern.Revoke;//Bug 68249
        if(eRevoke!=undefined && revokePattern!=undefined){
            if(bRevoke && revokePattern[fromFlag-1]=="1"){
                eRevoke.style.display="inline-block";
                //disrevoke.style.display="none";
            }else{
                eRevoke.style.display="none";
                //disrevoke.style.display="inline-block";
            }
        }else{
              disrevoke=document.getElementById("wlf:disableRevoke");
              eRevoke=document.getElementById("wlf:Revoke");
              if(eRevoke!=undefined && revokePattern!=undefined){
                if(bRevoke && revokePattern[fromFlag-1]=="1"){
                    eRevoke.style.display="inline-block";
                    //disrevoke.style.display="none";
                }else{
                    eRevoke.style.display="none";
                    //disrevoke.style.display="inline-block";
                }
            }
        }
        if (typeof showHideWorkitemOption != 'undefined') {
            if (!showHideWorkitemOption('Revoke', operationData)) {
                if (eRevoke != null)
                    eRevoke.style.display = "none";
                if (disrevoke != null)
                    disrevoke.style.display = "inline-block";
            }
        }
        //alert("Assign"+bUnAssign);
        var unRelease;
        unRelease=document.getElementById("wlf:disNewRelease");
        NewRelease=document.getElementById("wlf:NewRelease");
        var releasePattern = oprPattern.Release;//Bug 68249
        if(NewRelease!=undefined && releasePattern!=undefined){
            if(bUnAssign && releasePattern[fromFlag-1]=="1"){
                //alert("33");
                NewRelease.style.display="inline-block";
                //unRelease.style.display="none";
            }else{
                //alert("44");
                NewRelease.style.display="none";
                //unRelease.style.display="inline-block";
            }
        }else{
            unRelease=document.getElementById("wlf:disNewRelease");
            NewRelease=document.getElementById("wlf:NewRelease");
            if(unRelease!=undefined && releasePattern!=undefined){
                if(bUnAssign && releasePattern[fromFlag-1]=="1"){
                    //alert("33");
                    NewRelease.style.display="inline-block";
                    //unRelease.style.display="none";
                }else{
                    //alert("44");
                    NewRelease.style.display="none";
                    //unRelease.style.display="inline-block";
                }
            }
        }
        if (typeof showHideWorkitemOption != 'undefined') {
            if (!showHideWorkitemOption('Release', operationData)) {
                if (NewRelease != null)
                    NewRelease.style.display = "none";
                if (unRelease != null)
                    unRelease.style.display = "inline-block";
            }
        }
       var reassign;
       var disressign;
       disressign=document.getElementById("wlf:disableReassign");
       reassign=document.getElementById("wlf:Reassign");
       var reassignPattern = oprPattern.Reassign;//Bug 68249
        if(reassign!=undefined && reassignPattern!=undefined){
            if(bReassign && reassignPattern[fromFlag-1]=="1" && enableReassign=="Y"){
                reassign.style.display="inline-block";
                //disressign.style.display="none";
            }else{
                reassign.style.display="none";
                //disressign.style.display="inline-block";
            }
        }else{
             disressign=document.getElementById("wlf:disableReassign");
            reassign=document.getElementById("wlf:Reassign");
            if(disressign!=undefined && reassignPattern!=undefined){
                if(bReassign && reassignPattern[fromFlag-1]=="1" && enableReassign=="Y"){
                    reassign.style.display="inline-block";
                    //disressign.style.display="none";
                }else{
                    reassign.style.display="none";
                    //disressign.style.display="inline-block";
                }
            }
        }

        if (typeof customEnable == 'undefined' || customEnable == 'N') {
            if (typeof showHideWorkitemOption != 'undefined') {
                if (!showHideWorkitemOption('Reassign', operationData)) {
                    if (reassign != null)
                        reassign.style.display = "none";
                    if (disressign != null)
                        disressign.style.display = "inline-block";
                }
        }            
        if (typeof forcedReassign != 'undefined') {
                if (!bReassign && selectetdRowCount > 0) {
                    if (forcedReassign(bReassign)) {
                        reassign.style.display = "inline-block";
                        disressign.style.display = "none";
                    }
                }
            }
        } else if(customEnable == 'Y' && selectetdRowCount>0) {
            if(reassign!=null)
                reassign.style.display="inline-block";
            if(disressign!=null)
                disressign.style.display="none";
        }
        
        if (typeof showHideWorkitemOption != 'undefined') {
            if (!showHideWorkitemOption('Reassign', operationData)) {
                if (reassign != null)
                    reassign.style.display = "none";
                if (disressign != null)
                    disressign.style.display = "inline-block";
            }
        }
        
        if (typeof enableReassignHook != 'undefined' && bReassign) {
            if (!enableReassignHook(queueName,strfrom)) {
                if (reassign != null)
                    reassign.style.display = "none";
                if (disressign != null)
                    disressign.style.display = "inline-block";
            }else {
                if (reassign != null)
                    reassign.style.display = "inline-block";
                if (disressign != null)
                    disressign.style.display = "none";
            }
        }
        
        var edelete;
        var disdelete;
        disdelete=document.getElementById("wlf:disableDelete");
        edelete=document.getElementById("wlf:Delete");
        //alert("Delete"+bDelete);

        if(edelete!=undefined){
            if(bDelete){
                edelete.style.display="";
                //disdelete.style.display="none";
            }else{
                edelete.style.display="none";
                //disdelete.style.display="inline-block";
            }
        }else{
            disdelete=document.getElementById("wlf:disableDelete");
            edelete=document.getElementById("wlf:Delete");
            if(edelete!=undefined){
                if(bDelete){
                    edelete.style.display="inline-block";
                    //disdelete.style.display="none";
                }else{
                    edelete.style.display="none";
                    //disdelete.style.display="inline-block";
                }
            }
        }
        if (typeof showHideWorkitemOption != 'undefined') {
            if (!showHideWorkitemOption('Delete', operationData)) {
                if (edelete != null)
                    edelete.style.display = "none";
                if (disdelete != null)
                    disdelete.style.display = "inline-block";
            }
        }
        var ePriority;
        var disPriority;
        disPriority=document.getElementById("wlf:disablePriority");
        ePriority=document.getElementById("wlf:Priority");
        //alert("Priority"+bPriority);

        if(ePriority!=undefined){
            if(bPriority){
                ePriority.style.display="inline-block";
                //disPriority.style.display="none";

            }else{
                ePriority.style.display="none";
                //disPriority.style.display="inline-block";
            }
        }else{
             disPriority=document.getElementById("wlf:disablePriority");
            ePriority=document.getElementById("wlf:Priority");
            if(disPriority!=undefined && ePriority!=undefined){
                if(bPriority){
                    ePriority.style.display="inline-block";
                    //disPriority.style.display="none";

                }else{
                    ePriority.style.display="none";
                    //disPriority.style.display="inline-block";
                }
            }
        }
        
        if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('Priority',operationData)){
                if(ePriority!=null)
                   ePriority.style.display="none";
                if(disPriority!=null)
                   disPriority.style.display="inline-block";
            }
        }
        var eProperty;
        var disProperty;
        disProperty=document.getElementById("wlf:disableProperty");
        eProperty=document.getElementById("wlf:Property");
        //alert("Property"+bProperty);

        if(eProperty!=undefined){
            if(bProperty){
                eProperty.style.display="inline-block";
                //disProperty.style.display="none";

            }else{
                eProperty.style.display="none";
                //disProperty.style.display="inline-block";
            }
        }else{
               disProperty=document.getElementById("wlf:disableProperty");
            eProperty=document.getElementById("wlf:Property");
            if(disProperty!=undefined && eProperty!=undefined){
                if(bProperty){
                    eProperty.style.display="inline-block";
                    //disProperty.style.display="none";

                }else{
                    eProperty.style.display="none";
                    //disProperty.style.display="inline-block";
                }
            }
        }
         if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('Property',operationData)){
                if(eProperty!=null)
                  eProperty.style.display="none";
                if(disProperty!=null)
                  disProperty.style.display="inline-block";  
            }
        }       

        var eReminder;
        var disReminder;
        disReminder=document.getElementById("wlf:disableReminder");
        eReminder=document.getElementById("wlf:Reminder");
        // alert("Reminder"+bReminder);

         if(eReminder!=undefined){
            if(bReminder){
                eReminder.style.display="inline-block";
                //disReminder.style.display="none";
            }else{
                eReminder.style.display="none";
                //disReminder.style.display="inline-block";
            }
        }else{
            disReminder=document.getElementById("wlf:disableReminder");
            eReminder=document.getElementById("wlf:Reminder");
            if(disReminder!=undefined && eReminder!=undefined){
                if(bReminder){
                    eReminder.style.display="inline-block";
                    //disReminder.style.display="none";
                }else{
                    eReminder.style.display="none";
                    //disReminder.style.display="inline-block";
                }
            }
        }
         if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('Reminder',operationData)){
                if(eReminder!=null)
                  eReminder.style.display="none";
                if(disReminder!=null)
                   disReminder.style.display="inline-block"; 
            }
        }       
        var eLockForMe;
        var disLockForMe;
        disLockForMe=document.getElementById("wlf:disableGetLock");
        eLockForMe=document.getElementById("wlf:GetLock");
        var assignToMePattern = oprPattern.AssignToMe;//Bug 68249

        if(eLockForMe!=undefined && assignToMePattern!=undefined){
            if(bLockforMe && assignToMePattern[fromFlag-1]=="1"){
                eLockForMe.style.display="inline-block";
                //disLockForMe.style.display="none";
            }else{
                eLockForMe.style.display="none";
                //disLockForMe.style.display="inline-block";
            }
        }else{
             disLockForMe=document.getElementById("wlf:disableGetLock");
            eLockForMe=document.getElementById("wlf:GetLock");
            if(eLockForMe!=undefined && disLockForMe!=undefined && assignToMePattern!=undefined){
                if(bLockforMe && assignToMePattern[fromFlag-1]=="1"){
                    eLockForMe.style.display="inline-block";
                    //disLockForMe.style.display="none";
                }else{
                    eLockForMe.style.display="none";
                    //disLockForMe.style.display="inline-block";
                }
            }
        }
        if (typeof customAssignEnable == 'undefined' || customAssignEnable == 'N') {
            if (typeof showHideWorkitemOption != 'undefined') {
                if (!showHideWorkitemOption('AssignToMe', operationData)) {
                    if (eLockForMe != null)
                        eLockForMe.style.display = "none";
                    if (disLockForMe != null)
                        disLockForMe.style.display = "inline-block";
                }
            }
        } else if (customAssignEnable == 'Y' && selectetdRowCount > 0 && queueID != 0) {
            if (eLockForMe != null)
                eLockForMe.style.display = "inline-block";
            if (disLockForMe != null)
                disLockForMe.style.display = "none";
        }
            
        if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('AssignToMe',operationData)){
                if(eLockForMe!=null)
                  eLockForMe.style.display="none";
                if(disLockForMe!=null)
                  disLockForMe.style.display="inline-block";  
            }
        }
        var count=rowCount-1;
        var save=document.getElementById("wlf:Save");
        //var disSave=document.getElementById("wlf:disableSave");
        //var saveMenuImg=document.getElementById("wlf:saveSubMenuImg");
        showSave="Y";
        if(save!=undefined){
            if(count==0 || showSave=="N"){
                save.style.display="none";
                /*disSave.style.display="inline-block";
                saveMenuImg.onmouseover = function (e){
                    return;
                }*/
            }else{
                save.style.display="";
                /*disSave.style.display="none";
                saveMenuImg.onmouseover = function (e){
                    showSaveOptions(saveMenuImg);
                }*/
            }
        }else{
            /*save=document.getElementById("wlf:Save");
            disSave=document.getElementById("wlf:disableSave");
            saveMenuImg=document.getElementById("wlf:saveSubMenuImg");
            if(save!=undefined && disSave!=undefined){
                if(count==0 || showSave=="N"){
                    save.style.display="none";
                    disSave.style.display="inline-block";
                    saveMenuImg.onmouseover = function (e){
                        return;
                    }
                }else{
                    save.style.display="inline-block";
                    disSave.style.display="none";
                    saveMenuImg.onmouseover = function (e){
                        showSaveOptions(saveMenuImg);
                    }
                }
            }*/
        }
        
     /* if(count==0) {
            document.getElementById("wlf:wlact").style.display='none';            
        } else {
            document.getElementById("wlf:wlact").style.display='';
        }*/
        if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('Save',operationData)){
                if(save!=null){
                    save.style.display="none";
                }
                if(disSave!=null){
                    disSave.style.display="inline-block";
                }
                saveMenuImg.onmouseover = function (e){
                        return;
                }   
            }
        }
  
        /*if(count==0 && save!=undefined) {
            document.getElementById("wlf:Savetxt").style.display='none';
            document.getElementById("wlf:disableSavetxt").style.display='inline';
        }
        save=document.getElementById("wlf:Savecsv");
        if(count==0 && save!=undefined) {
            document.getElementById("wlf:Savecsv").style.display='none';
            document.getElementById("wlf:disableSavecsv").style.display='inline';
        }
        save=document.getElementById("wlf:Savepdf");
        if(count==0 && save!=undefined) {
            document.getElementById("wlf:Savepdf").style.display='none';
            document.getElementById("wlf:disableSavepdf").style.display='inline';
        }
        save=document.getElementById("wlf:Savexls");
        if(count==0 && save!=undefined) {
            document.getElementById("wlf:Savexls").style.display='none';
            document.getElementById("wlf:disableSavexls").style.display='inline';
        }*/
        if(checkedStatus=="0"){
            EffAdhocStatus=checkedStatus;
            EffLockStatus=checkedStatus
        }else{
            if((typeof wLMode!='undefined' && wLMode=='WD') || (typeof wLMode!='undefined' && wLMode=='PM' && isFromSearch != 'true'))
                tempAdhocStatus = 0;
            
            if((typeof wLMode!='undefined' && wLMode=='WD'))
                tempLockStatus = 0;
            
            EffAdhocStatus=tempAdhocStatus;
            EffLockStatus=tempLockStatus;
        }
          

        var eAdhocRouting;
        var disAdhocRouting;
        disAdhocRouting=document.getElementById("wlf:disableAdhocRouting");
        eAdhocRouting=document.getElementById("wlf:AdhocRouting");
        var adhocRoutingPattern = oprPattern.AdhocRouting;//Bug 68249
        if(eAdhocRouting!=undefined && adhocRoutingPattern!=undefined){
            if(EffAdhocStatus==1 && adhocRoutingPattern[fromFlag-1]=="1"){
                eAdhocRouting.style.display="inline-block";
                //disAdhocRouting.style.display="none";
            }else{
                eAdhocRouting.style.display="none";
                //disAdhocRouting.style.display="inline-block";
            }
        }else{
            disAdhocRouting=document.getElementById("wlf:disableAdhocRouting");
            eAdhocRouting=document.getElementById("wlf:AdhocRouting");
            if(eAdhocRouting!=undefined && disAdhocRouting!=undefined && adhocRoutingPattern!=undefined){
                if(EffAdhocStatus==1 && adhocRoutingPattern[fromFlag-1]=="1"){
                    eAdhocRouting.style.display="inline-block";
                    //disAdhocRouting.style.display="none";
                }else{
                    eAdhocRouting.style.display="none";
                    //disAdhocRouting.style.display="inline-block";
                }
            }
        }
         if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('AdhocRouting',operationData)){
                if(eAdhocRouting!=null)
                   eAdhocRouting.style.display="none";
                if(disAdhocRouting!=null)
                   disAdhocRouting.style.display="inline-block"; 
            }
        }       
        var eUnlock;
        var disUnlock;
        disUnlock=document.getElementById("wlf:disableUnlock");
        eUnlock=document.getElementById("wlf:Unlock");
        if(eUnlock!=undefined){// && disUnlock!=undefined){
            if(EffLockStatus==1){
                eUnlock.style.display="inline-block";
               // disUnlock.style.display="none";
            }else{
                eUnlock.style.display="none";
                //disUnlock.style.display="inline-block";
            }
        }else{
            disUnlock=document.getElementById("wlf:disableUnlock");
            eUnlock=document.getElementById("wlf:Unlock");
            if(eUnlock!=undefined && disUnlock!=undefined){
                if(EffLockStatus==1){
                    eUnlock.style.display="inline-block";
                   // disUnlock.style.display="none";
                }else{
                    eUnlock.style.display="none";
                  //  disUnlock.style.display="inline-block";
                }
            }
        }
        if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('Unlock',operationData)){
                if(eUnlock!=null)
                  eUnlock.style.display="none";
                if(disUnlock!=null)
                  disUnlock.style.display="inline-block";  
            }
        }       
        var eHold;
        var disHold;
        eHold=document.getElementById("wlf:Hold");
        disHold=document.getElementById("wlf:disableHold");
        if(eHold!=undefined){// && disHold!=undefined){
            if(bHold) {
                eHold.style.display="inline-block";
               // disHold.style.display="none";  
            }
            else {
                eHold.style.display="none";
                //disHold.style.display="inline-block";
            }
        } else{
            eHold=document.getElementById("wlf:Hold");
            disHold=document.getElementById("wlf:disableHold");
            if(eHold!=undefined && disHold!=undefined){
                if(bHold) {
                    eHold.style.display="inline-block";
                  //  disHold.style.display="none";  
                }
                else {
                    eHold.style.display="none";
                   // disHold.style.display="inline-block";
                }  
            }
        }
         if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('Hold',operationData)){
                if(eHold!=null)
                   eHold.style.display="none";
                if(disHold!=null)
                   disHold.style.display="inline-block"; 
            }
        }       
        var eUnhold;
        var disUnhold;
        eUnhold=document.getElementById("wlf:Unhold");
        disUnhold=document.getElementById("wlf:disableUnhold");
        if(eUnhold!=undefined){// && disUnhold!=undefined){
            if(bUnhold) {
                eUnhold.style.display="inline-block";
               // disUnhold.style.display="none";  
            }
            else {
                eUnhold.style.display="none";
               // disUnhold.style.display="inline-block";
            }
        } else {
            eUnhold=document.getElementById("wlf:Unhold");
            disUnhold=document.getElementById("wlf:disableUnhold");
            if(eUnhold!=undefined && disUnhold!=undefined){
                if(bUnhold) {
                    eUnhold.style.display="inline-block";
                    //disUnhold.style.display="none";  
                }
                else {
                    eUnhold.style.display="none";
                    //disUnhold.style.display="inline-block";
                }
            }
        }
        if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('Unhold',operationData)){
                if(eUnhold!=null)
                   eUnhold.style.display="none";
                if(disUnhold!=null)
                    disUnhold.style.display="inline-block";
            }
        }
        
        var eReminderList;
        eReminderList=document.getElementById("frmworkitemlist:panel:reminderList");
        if(eReminderList==null){
            eReminderList=document.getElementById("frmworkitemlist:reminderList");
        }
        if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('ReminderList',operationData)){
                if(eReminderList!=null)
                  eReminderList.parentNode.style.display="none";
            }
        }
        var eSetFilter,disSetFilter;
        eSetFilter=document.getElementById("frmworkitemlist:panel:setFilter");
        disSetFilter=document.getElementById("frmworkitemlist:panel:disSetFilter");
        if(eSetFilter==null && disSetFilter==null){
            eSetFilter=document.getElementById("frmworkitemlist:setFilter");
            disSetFilter=document.getElementById("frmworkitemlist:disSetFilter");
        }
            
        if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('SetFilter',operationData)){
                if(eSetFilter!=null)
                    eSetFilter.parentNode.style.display="none";
                if(disSetFilter!=null)
                    disSetFilter.style.display="inline-block";
            }
        }
        
        var ePreferences;
        ePreferences=document.getElementById("frmworkitemlist:panel:Preferences");
        if(ePreferences==null){
            ePreferences=document.getElementById("frmworkitemlist:Preferences");
        }
        if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('Preferences',operationData)){
                if(ePreferences!=null)
                    ePreferences.parentNode.style.display="none";
            }
        }
        var eCount,disCount;
        eCount=document.getElementById("frmworkitemlist:panel:lblWI1");
        disCount=document.getElementById("frmworkitemlist:panel:disCount");
        if(eCount==null && disCount==null){
            eCount=document.getElementById("frmworkitemlist:lblWI1");
            disCount=document.getElementById("frmworkitemlist:disCount");
        }
        if(typeof showHideWorkitemOption!='undefined'){
            if(!showHideWorkitemOption('Count',operationData)){
                if(eCount!=null)
                    eCount.parentNode.style.display="none";
                if(disCount!=null)
                    disCount.style.display="none";
            }
        }
    }catch(e){
        //alert(e.description);
    }
    
    resizeRSWorkList(false);
}

function renderAdhocRouting(count){
    var jsonOutputWI=document.getElementById("wlf:hjn"+(count)).innerHTML;
//    jsonOutputWI=jsonOutputWI.replace(/\'/g,"\\'");//Bug 72614
//    jsonOutputWI=JSON.parse(jsonOutputWI);
    jsonOutputWI = jsonOutputWI.split(SEPERATOR1+SEPERATOR4);
    var piStatus="";
    var lockingStatus="";
    var workitemStatus="";
    var routeid="";
    
    var arrobjJsonOutput= jsonOutputWI;
    //for(var i=0;i<arrobjJsonOutput.length;i++){
        //var outputJson=arrobjJsonOutput[i];
        //var objJson=outputJson.Output;
        //if(objJson.Name=='ProcessInstanceState'){
            piStatus = encode_ParamValue(arrobjJsonOutput[4])
        //}
        //if(objJson.Name=='LockStatus'){
            lockingStatus = encode_ParamValue(arrobjJsonOutput[16])
        //}
        //if(objJson.Name=='WorkitemState'){
            workitemStatus = encode_ParamValue(arrobjJsonOutput[2])
        //}
         //if(objJson.Name=='RouteId'){
            routeid = encode_ParamValue(arrobjJsonOutput[5])
            currpDefId=routeid;
        //}
        
        
    //}
    //alert("piStatus:"+piStatus+"lockingStatus:"+lockingStatus+"workitemStatus:"+workitemStatus);
   /* if(lockingStatus == "Y")
    {
       tempAdhocStatus=0;
    }
    else
    {
        if(piStatus != 2)
        {
            tempAdhocStatus=0;
            if(piStatus != 1){
                tempAdhocStatus=0;
            }
        }
        else if(workitemStatus == 6 || workitemStatus == 5 || workitemStatus == 4 || workitemStatus == 3)
        {
            tempAdhocStatus=0;
        }
    }*/
    
    if(prevpDefId!=currpDefId && prevpDefId != '')
    {
        tempAdhocStatus=0;            
    }

    if(piStatus==6 || piStatus==5 ) {
        if(isAdhocAtExit=='Y') {
            tempAdhocStatus=1;
        } else {
            tempAdhocStatus = 0;
        }
    }
}



function renderUnlock(count){
    var jsonOutputWI=document.getElementById("wlf:hjn"+(count)).innerHTML;
    //jsonOutputWI=jsonOutputWI.replace(/\'/g,"\\'");//Bug 72614
    //jsonOutputWI=JSON.parse(jsonOutputWI); 
    jsonOutputWI = jsonOutputWI.split(SEPERATOR1+SEPERATOR4);

    //jsonOutputWI=parseJSON("("+jsonOutputWI+")");    
    var lockingStatus="";
    var workitemStatus="";
    var routeid="";
    
    var arrobjJsonOutput= jsonOutputWI;
    //for(var i=0;i<arrobjJsonOutput.length;i++){
        //var outputJson=arrobjJsonOutput[i];
        //var objJson=outputJson.Output;
        //if(objJson.Name=='ProcessInstanceState'){
            piStatus = encode_ParamValue(arrobjJsonOutput[4])
        //}
        //if(objJson.Name=='LockStatus'){
            lockingStatus = encode_ParamValue(arrobjJsonOutput[16])
        //}
        //if(objJson.Name=='WorkitemState'){
            workitemStatus = encode_ParamValue(arrobjJsonOutput[2])
        //}
         //if(objJson.Name=='RouteId'){
            routeid = encode_ParamValue(arrobjJsonOutput[5])
            currpDefId=routeid;
        //}
    //}
    //alert("piStatus:"+piStatus+"lockingStatus:"+lockingStatus+"workitemStatus:"+workitemStatus);
    if(lockingStatus == "Y")
    {
        if(workitemStatus == 3|| workitemStatus=="SUSPENDED") 
        { 
            tempLockStatus=0;
        }
    }
    else
    {        
        tempLockStatus=0;       
    }     
}

function SelectDeselectHeader(tableId,formid)
{
    var checkboxId=formid+":cb_";
    var ctrlTableId=tableId;
    var ctrlTable=document.getElementById(ctrlTableId);
    if(ctrlTable==null)
        return;

    var bAllChecked = false;
    var chkCount = 0;
    try
    {
        var rowCount = ctrlTable.tBodies[0].rows.length;
        //alert(rowCount);

        for(var iCount = 0; iCount < rowCount-1;iCount++)
        {
            if(document.getElementById(checkboxId+iCount).checked)
            {
                chkCount++;
            }
        }

        if(chkCount == rowCount-1)
        {
            bAllChecked = true;
        }
        else
        {
            bAllChecked = false;
        }
    }catch(ex){
    // alert("ex");
    }
    // var ss=ctrlTableId.substring(0,ctrlTableId.lastIndexOf(":"));
    //alert(bAllChecked);
    if(bAllChecked)
    {
        if(!document.getElementById(ctrlTableId.substring(0,ctrlTableId.lastIndexOf(":"))+":checkBoxAll").checked)
            document.getElementById(ctrlTableId.substring(0,ctrlTableId.lastIndexOf(":"))+":checkBoxAll").checked=true;
    }
    else
    {
        if(document.getElementById(ctrlTableId.substring(0,ctrlTableId.lastIndexOf(":"))+":checkBoxAll").checked)
            document.getElementById(ctrlTableId.substring(0,ctrlTableId.lastIndexOf(":"))+":checkBoxAll").checked=false;
    }
}

function selectAllCheckbox(ref,value){

    var id=ref.id;
    var formId=id.substring(0,id.lastIndexOf(":"));
    var ctrlTableId=formId+":pnlResult";
    var ctrlTable=document.getElementById(ctrlTableId);
    if(ctrlTable==null)
        return;
    var bChecked=ref.checked;
    var newRowClass='wdSimple';
    if(bChecked)
        newRowClass='oarowstyle';
    try
    {
        var rowCount = ctrlTable.tBodies[0].rows.length;
        for(var iCount = 0; iCount < rowCount-1;iCount++)
        {
            //ctrlTable.tBodies[0].rows[iCount+1].className=newRowClass;
            document.getElementById(formId+":cb_"+iCount).checked=bChecked;
        }
        if(formId!='frmlinkedworkitemlist')
            renderButtons(ctrlTableId,formId);
    }catch(ex){
    //  alert("ex1");
    }
}

function StyleLink(ref)
{
    ref.style.textDecoration='underline';
}

function StyleNormal(ref)
{
    ref.style.textDecoration='none';
}

function ShowMoreOptions(ref){
    var tempRef = document.getElementById('QuickSearchDiv');
    if(tempRef){
        tempRef.style.display = 'none';
    }
    
    tempRef = document.getElementById('MessageDiv');
    if(tempRef){
        tempRef.style.display = 'none';
    }
    
    tempRef = document.getElementById('queryListDiv');
    if(tempRef){
        tempRef.style.display = 'none';
    }
    
     /*if(document.getElementById('MoreDiv2').style.display == 'none'){
        positionmenu(ref.id,'MoreDiv2');
        document.getElementById('MoreDiv2').style.display = 'inline';
    }
    else{
       	document.getElementById('MoreDiv2').style.display = 'none';
        positionmenu(ref.id,'MoreDiv2');
    }*/
    
    if(document.getElementById('MoreDiv').style.display == 'none'){
        positionmenu(ref.id,'MoreDiv');
        document.getElementById('MoreDiv').style.display = 'inline-block';
    }
    else{
       	document.getElementById('MoreDiv').style.display = 'none';
        positionmenu(ref.id,'MoreDiv');
    }

}

var bQuickSearchSent = false;
function setQuickSearchFilterWrapper(){
    if(bQuickSearchSent){
        return false;
    }
    
    var returnVal = setQuickSearchFilter(window.parent);
    if(returnVal){
        bQuickSearchSent = true;
        
        if (window.parent.iFrameSearchBarRef) {
            /*setTimeout(function() {
                window.parent.iFrameSearchBarRef.SaveRecentSearch();
            }, 5000);*/
        }
    } else {
        bQuickSearchSent = false;
    }
    
    document.getElementById("wlf:hidSelectedQueryIndex").value="";
    
    return returnVal;
}

function openQuickSearchWrapper(ref){    
    var quickSearchLoaded = document.getElementById("wlf:quickSearchLoaded").value;  
    quickSearchLoaded = "N";//Bug 64196
    bQuickSearchSent = false;
    if(quickSearchLoaded == "N"){        
        clickLink("wlf:getProcessAndQSVar");           
    } else {
       var quickSearchFilter2 = document.getElementById("wlf:quickSearchFilter2");
       openQuickSearch(quickSearchFilter2);
    }
}

function openQuickSearchWrapperHandler(data){
   HandleProgressBar(data);
   
   if(data.status=='begin'){   
       document.getElementById("wlf:quickSearchLoaded").value = "Y";
   }
   
    if(data.status=='success'){        
       var ref = document.getElementById("wlf:quickSearchFilter2");
        //Bug Id 62561 -- starts
       var errorFlag1=document.getElementById("wlf:hidError").value;
       var mainCode=document.getElementById("wlf:strMainCode").value;
       var errorMsg=document.getElementById("wlf:strErrorMsg").value;
       if(errorFlag1=="true" && mainCode=="11")
           {
             window.parent.setPopupMask();
             window.parent.showPopupAlert("alertDiv", errorMsg, "wp:messageLabel"); 
           }
           else{
               openQuickSearch(ref);
               //70253
               selectDefaultProcess();
           }
         //Bug Id 62561 -- ends       
   }
}

function openQuickSearch(ref){
   document.getElementById('MoreDiv').style.display = 'none';
   //document.getElementById('MoreDiv2').style.display = 'none';
    document.getElementById('MessageDiv').style.display = 'none';
    if(document.getElementById('queryListDiv')){
        document.getElementById('queryListDiv').style.display = 'none';
    }
    //if(document.getElementById('QuickSearchDiv').style.display == 'none'){        //Bug 68033
        positionmenu(ref.id,'QuickSearchDiv');
        document.getElementById('QuickSearchDiv').style.display = 'inline';
        var quickSearchPrefix = document.getElementById("wlf:pqks:searchPrefix");
        if(quickSearchPrefix == null){
            quickSearchPrefix = document.getElementById("wlf:searchPrefix");
        }
        quickSearchPrefix = quickSearchPrefix.value;
        
        var ref2 = document.getElementById("wlf:pqks:Prefix");
        if(ref2 == null){
            ref2 = document.getElementById("wlf:Prefix");
        }
        
        if(quickSearchPrefix!='')
            ref2.value=quickSearchPrefix;
        else
            ref2.value=OP_WI_SEARCH;
        setElementFocus(ref2);//Bug 72759
//    }
//    else{
//        document.getElementById('QuickSearchDiv').style.display = 'none';
//        positionmenu(ref.id,'QuickSearchDiv');
//    }
}

function selectDefaultProcess(){
    var processName = "";
    if(typeof setDefaultProcessonQuickSearch() != 'undefined') {
        processName = setDefaultProcessonQuickSearch();
    }
    
    if(processName != ""){
        var comboObj = document.getElementById("wlf:pqks:processlist");
        if(comboObj == null){
            comboObj = document.getElementById("wlf:processlist");
        }
        if(comboObj != null){
            for(var i=0;i<comboObj.length;i++){
                 if((i!=0) && (comboObj[i].text == processName)) {
                     comboObj.selectedIndex = i;
                     return;
                 }
            }
        }
    }
}

function SaveQueryDiv(ref){
    if(document.getElementById('SaveQuery').style.display == 'none'){
       // positionmenu(ref.id,'SaveQuery');
        document.getElementById('SaveQuery').style.display = 'inline';
    }
    else{
        document.getElementById('SaveQuery').style.display = 'none';
//        positionmenu(ref.id,'SaveQuery');
    }
}

function SaveFilterDiv(ref){
    if(document.getElementById('SaveFilter').style.display == 'none'){
        positionmenu(ref.id,'SaveFilter');
        document.getElementById('SaveFilter').style.display = 'inline';
    }
    else{
        document.getElementById('SaveFilter').style.display = 'none';
        positionmenu(ref.id,'SaveFilter');
    }
}




function showSearchQueryList(ref,divId){
    if(document.getElementById('queryFilterListDiv').style.display == 'none'){
        positionmenu(ref.id,divId);
        document.getElementById('queryFilterListDiv').style.display = 'inline';
    }
    else{
        document.getElementById('queryFilterListDiv').style.display = 'none';
        positionmenu(ref.id,divId);
    }
    
    /*$("#scrollQueryList").mCustomScrollbar("destroy");
    $.mCustomScrollbar.defaults.scrollButtons.enable=true; //enable scrolling buttons by default
    $.mCustomScrollbar.defaults.axis="y";
    $.mCustomScrollbar.defaults.autoHideScrollbar=false;                                
    $("#scrollQueryList").mCustomScrollbar({theme:"dark"});*/
    
}

function showSearchQList(ref,divId){
    if(document.getElementById('queryListDiv').style.display == 'none'){
        positionmenu(ref.id,divId);
        document.getElementById('queryListDiv').style.display = 'inline';
        
        /*$("#scrollQueryList").mCustomScrollbar("destroy");
        $.mCustomScrollbar.defaults.scrollButtons.enable=true; //enable scrolling buttons by default
        $.mCustomScrollbar.defaults.axis="yx";
        $.mCustomScrollbar.defaults.autoHideScrollbar=false;                                
        $("#scrollQueryList").mCustomScrollbar({theme:"dark"});*/
    }
    else{
        document.getElementById('queryListDiv').style.display = 'none';
        positionmenu(ref.id,divId);
    }
}

function showQueryList(ref,divId){
    var refObj = document.getElementById('QuickSearchDiv');
    if(refObj){
        refObj.style.display = 'none';
    }
    document.getElementById('MoreDiv').style.display = 'none';
        //document.getElementById('MoreDiv2').style.display = 'none';
    document.getElementById('MessageDiv').style.display = 'none';
    
    if(document.getElementById('queryListDiv').style.display == 'none'){
        positionmenu(ref.id,divId);
        document.getElementById('queryListDiv').style.display = 'inline';
    }
    else{
        document.getElementById('queryListDiv').style.display = 'none';
        positionmenu(ref.id,divId);
    }
    /*$("#scrollQueryList").mCustomScrollbar("destroy");
    $.mCustomScrollbar.defaults.scrollButtons.enable=true;
    $.mCustomScrollbar.defaults.axis="yx";
    $.mCustomScrollbar.defaults.autoHideScrollbar=false;                                
    $("#scrollQueryList").mCustomScrollbar({theme:"dark"});*/
}

function showPageList(ref,divId){
    if(document.getElementById(divId).style.display == 'none'){
        positionmenu(ref.id,divId);
        document.getElementById(divId).style.display = 'inline';
    }
    else{
        document.getElementById(divId).style.display = 'none';
    }
}

function positionmenu(ref,divId,fromMainPref){
    var fromMainPrefvar;
   
    if(typeof fromMainPref=='undefined'){
        fromMainPrefvar=false;
    }
    else{
        fromMainPrefvar=fromMainPref;
    }
    
    var tempCtrlname=document.getElementById(ref);
    var subMenuObj=document.getElementById(divId);
    
    var posLeft = 0;
    var posTop = 0;    
    var bCenter = false;
    
    if(tempCtrlname){
        posLeft = findPosX(tempCtrlname);
        posTop = findPosY(tempCtrlname);
    } else {        
        if(subMenuObj){
            bCenter = true;
            var docWidth = window.document.body.clientWidth;
            var docHeight = window.document.documentElement.clientHeight;  
        
            var rd = getRealDimension(subMenuObj); 
            
            posLeft=(docWidth-rd.Width)/2 + window.document.documentElement.scrollLeft;
            posTop=(docHeight-rd.Height)/2 + window.document.documentElement.scrollTop;
        }
    }
    
    
    var absoluteleft =0;
    var absolutetop = 0;
    
    if (tempCtrlname && tempCtrlname.offsetParent)
    {
        absoluteleft = tempCtrlname.offsetLeft;
        absolutetop = tempCtrlname.offsetTop;       
    }
    
    if(divId=="MessageDiv" ){
        if( pageDirection == 'rtl')
        {   
            subMenuObj.style.left=absoluteleft+posLeft+"px";
        }
        else{
            if(bCenter){
                subMenuObj.style.left=absoluteleft+posLeft+"px";
            }else {
                subMenuObj.style.left=absoluteleft+posLeft-260+"px";
            }
        }
        
        if(bCenter){
            subMenuObj.style.top=absolutetop+posTop+"px";
        } else {
            subMenuObj.style.top=absolutetop+posTop+15+"px";
        }
   }else if(divId=="MoreDiv"){
        if( pageDirection == 'rtl')
        {
            subMenuObj.style.left = absoluteleft+posLeft+ 145+"px";
        }
        else
        subMenuObj.style.left=absoluteleft+posLeft-125-80-39+"px";
        subMenuObj.style.top=2+"px";
    }else if(divId=="MoreDiv2"){
        if( pageDirection == 'rtl')
        {
            subMenuObj.style.left = absoluteleft+posLeft+ 37+"px";
        }
        else
        subMenuObj.style.left=absoluteleft+posLeft-125+25-34+"px";
        subMenuObj.style.top=2+"px";
    }else if(divId=="NewWorkitem"){
         var widthforarabic = window.innerWidth
|| document.documentElement.clientWidth
|| document.body.clientWidth;
 if(subMenuObj){
        if( pageDirection == 'rtl')
        {
             if(strLocale=='ar-SA' || strLocale=='ar'){
        subMenuObj.style.right=widthforarabic-300-absoluteleft+posLeft-100+"px";
         
    }
    else{
         subMenuObj.style.left=absoluteleft+posLeft-100+"px";
    }
            
        }else{
            if(strLocale=='ar-SA' || strLocale=='ar'){
          subMenuObj.style.right=widthforarabic-300-absoluteleft+posLeft-175+"px";
         
    }
    else{
          subMenuObj.style.left=absoluteleft+posLeft-175+"px";
    }
	      
		}
        subMenuObj.style.top=absolutetop+posTop+15+"px";
        }
    }else if(divId=="pageWiseDiv"){
        posLeft = findPosX(tempCtrlname);
        posTop = findPosY(tempCtrlname);    
        absoluteleft =0;
        absolutetop = 0;
        if (tempCtrlname.offsetParent){
            absoluteleft = tempCtrlname.offsetLeft;
            absolutetop = tempCtrlname.offsetTop;
        }   
        
        var obj = document.getElementById("pageWiseDiv");
        var moreDivWidth = 0;
        if(obj != null){
            moreDivWidth = obj.style.width.split('p')[0]-0;
        }

        if( pageDirection == 'rtl' )
            subMenuObj.style.left=absoluteleft+posLeft+32-2*moreDivWidth+"px";
        else    
            subMenuObj.style.left=absoluteleft+posLeft-moreDivWidth+"px";
            
        subMenuObj.style.top=absolutetop+posTop+15+"px";
    }else if(divId=="SaveQuery"){
        if((absoluteleft+posLeft-250)>=0){        
            subMenuObj.style.left=absoluteleft+posLeft-250+"px";
        } else{
            subMenuObj.style.left = "5px";
        }
        subMenuObj.style.top=absolutetop+posTop+15+"px";
        }
        else if(divId=="SaveFilter"){
            if( pageDirection == 'rtl' )
                subMenuObj.style.left = absoluteleft+posLeft+"px";
            else
                subMenuObj.style.left=absoluteleft+posLeft-250+"px";
        subMenuObj.style.top=absolutetop+posTop+15+"px";
    }else if(divId=="saveDiv"){
       // alert(tempCtrlname.id);
       if(fromMainPrefvar){
            tempCtrlname=document.getElementById("wlf:Save");    
       } else {
            tempCtrlname=document.getElementById("wlf:Save");
       }
        posLeft = findPosX(tempCtrlname);
        posTop = findPosY(tempCtrlname);    
        absoluteleft =0;
        absolutetop = 0;
        if (tempCtrlname.offsetParent){
            absoluteleft = tempCtrlname.offsetLeft;
            absolutetop = tempCtrlname.offsetTop;
        }   
    
        if(tempCtrlname.id=="wlf:Save"){
            var obj = document.getElementById("MoreDiv2");
            var moreDivWidth = 0;
            if(obj != null){
                moreDivWidth = obj.style.width.split('p')[0]-0;
            }
            
            if( pageDirection == 'rtl' )
                subMenuObj.style.left=absoluteleft+posLeft+32-2*moreDivWidth+67+"px";
            else { 
                if(fromMainPrefvar)
                      subMenuObj.style.left=absoluteleft+posLeft-11+moreDivWidth+"px";
                else
                      subMenuObj.style.left=absoluteleft+posLeft-11+moreDivWidth+"px";
            }
            scrollTop = typeof scrollTop == 'undefined'? document.getElementById('scrollMoreDiv2').scrollTop: scrollTop;            
            if(fromMainPrefvar)
                subMenuObj.style.top=absolutetop+posTop-scrollTop+6+"px";
            else
                subMenuObj.style.top=absolutetop+posTop-scrollTop-30+"px";
        }else{
             if(fromMainPrefvar){
                subMenuObj.style.left=absoluteleft+posLeft-12+(tempCtrlname.clientWidth-0)+15+"px";
                subMenuObj.style.top=absolutetop+posTop+5+"px";
            } else {
                subMenuObj.style.left=absoluteleft+posLeft-12+"px";
                subMenuObj.style.top=absolutetop+posTop+15+"px";
            }
        }
      
       
    }else if(divId=="queryFilterListDiv"){
        if( pageDirection == 'rtl' )
                subMenuObj.style.left = absoluteleft+posLeft+"px";
            else
                subMenuObj.style.left=absoluteleft+posLeft-250+"px";
        subMenuObj.style.top=absolutetop+posTop+15+"px";
        
    }else if(divId=="QuickSearchDiv")
     {  
        //subMenuObj.style.left=absoluteleft+posLeft+25+"px";
        if( pageDirection == 'rtl' )
        {  
            if(isIE()){
                subMenuObj.style.left=posLeft-220+60+"px"; 
            }else {
                subMenuObj.style.left=posLeft-280+10+"px"; 
            }
        }
        else
           subMenuObj.style.left=15+"px";
        
        if( pageDirection == 'rtl' )
        {
            if(isIE()){
                subMenuObj.style.top=absolutetop+posTop+15+"px";
            } else {
                subMenuObj.style.top=absolutetop+posTop+7+"px";
            }
        }else {        
            subMenuObj.style.top=absolutetop+posTop+15+"px";
        }
     }else if(divId=="SearchDiv"){
        if( pageDirection == 'rtl' )
        {  
            if(isIE()){
                subMenuObj.style.left=posLeft+"px"; 
            } else {
                subMenuObj.style.left=posLeft+"px"; 
            }
        }
        else
           subMenuObj.style.left=posLeft-265+"px";
        
        if( pageDirection == 'rtl' )
        {
            if(isIE()){
                subMenuObj.style.top=absolutetop+posTop+15+"px";
            } else {
                subMenuObj.style.top=absolutetop+posTop+15+"px";
            }
        } else {        
            subMenuObj.style.top=absolutetop+posTop+15+"px";
        }
     }else if(divId=="ProcessSearchDiv")
     {  
        //subMenuObj.style.left=absoluteleft+posLeft+25+"px";
        if( pageDirection == 'rtl' )
        {  
            if(isIE()){
                //subMenuObj.style.left=posLeft-220+"px"; 
                subMenuObj.style.left=posLeft-220+100+"px"; 
            } else {
                subMenuObj.style.left=posLeft-280+70+"px"; 
            }
        }
        else
           subMenuObj.style.left=15+"px";
        
        if( pageDirection == 'rtl' )
        {
            if(isIE()){
                subMenuObj.style.top=absolutetop+posTop+15+"px";
            } else {
                subMenuObj.style.top=absolutetop+posTop+7+"px";
            }
        } else {        
            subMenuObj.style.top=absolutetop+posTop+15+"px";
        }
     }else if(divId=="UserSearchDiv"){
        if( pageDirection == 'rtl' )
        {  
            if(isIE()){
                subMenuObj.style.left=posLeft+100+"px"; 
            } else {
                subMenuObj.style.left=posLeft-14+"px"; 
            }
        }
        else{
            subMenuObj.style.right= 15+"px";
//           subMenuObj.style.left=(width/2)-125+"px";
    
        if(document.getElementById('userview:popoutIcon')!=null && document.getElementById('userview:popoutIcon').style.display == "none") 
           subMenuObj.style.left=posLeft+"px";
        }
        if( pageDirection == 'rtl' )
        {  
            if(isIE()){
                subMenuObj.style.top=absolutetop+posTop+15+"px";
            } else {
                subMenuObj.style.top=absolutetop+posTop+26+"px";
            }
        }else {        
            subMenuObj.style.top=absolutetop+posTop+15+"px";
        }
    }else{
        if( pageDirection == 'rtl' )
        {  
            if(isIE()){
                subMenuObj.style.left=posLeft-220+"px"; 
            }else {
                subMenuObj.style.left=posLeft-260+"px"; 
            }
        }
        else
           subMenuObj.style.left=15+"px";
        
        if( pageDirection == 'rtl' )
        {  
            if(isIE()){
                subMenuObj.style.top=absolutetop+posTop+15+"px";
            } else {
                subMenuObj.style.top=absolutetop+posTop+"px";
            }
        } else {        
            subMenuObj.style.top=absolutetop+posTop+15+"px";
        }
    }
}



function removeMoreMenu()
{
    if(document.getElementById('MoreDiv').style.display == 'inline'){
         document.getElementById('MoreDiv').style.display = 'none';       
    }
    
     /*if(document.getElementById('MoreDiv2').style.display == 'inline'){
         document.getElementById('MoreDiv2').style.display = 'none';       
    }*/
      
        
}
function FetchProcessList(ref){
    var queueId = ref.value;

    document.getElementById("frmsearchworkitem:hidQueueId").value=queueId;

    // alert(processId)
    if(queueId== -1 || queueId== "")
    {
        var processCombo = document.getElementById("frmsearchworkitem:processId");
        processCombo = processCombo.length;
        for(var i=0; i< processCombo;i++)
        {
            processCombo.remove(0);
        }
        return;
    }
    var QueueName=ref.options[ref.selectedIndex].text;
    if(queueId==0){
        document.getElementById("frmsearchworkitem:hidQueueName").value = "";
    }else{
        document.getElementById("frmsearchworkitem:hidQueueName").value = QueueName;
        document.getElementById("frmsearchworkitem:queueId").value=QueueName;
    }
    document.getElementById("frmsearchworkitem:initpage").value = "FetchProcessList";

}
function FetchActivityList(ref){
    var processId = ref.value;
    if(processId== -1 || processId== "")
    {
        var activityCombo = document.getElementById("frmsearchworkitem:activityId");
        activityCombo = activityCombo .length;
        for(var i=0; i< activityCombo ;i++)
        {
            activityCombo .remove(0);
        }
        return;
    }
    var ProcessName=ref.options[ref.selectedIndex].text;
    if(processId==0){
        document.getElementById("frmsearchworkitem:hidProcessId").value = processId;
    }else{
        document.getElementById("frmsearchworkitem:hidProcessId").value = processId;
        document.getElementById("frmsearchworkitem:processId").value=ProcessName;
    }
    document.getElementById("frmsearchworkitem:initpage").value = "FetchActivityList";
}



function operateOnElement(ref,id){
//    if(id == 'comboPriority'){
//        document.getElementById('frmsearchworkitem:'+id).value = "-1";
//    }
//    else if(id == 'comboLockStatus'){
//        document.getElementById('frmsearchworkitem:'+id).value = "-1";
//    }
//    else if(id == 'comboExcepStatus'){
//        document.getElementById('frmsearchworkitem:'+id).value = "-1";
//    }
//    else
    /*if(id == 'chkSortVersion'){
        document.getElementById('frmsearchworkitem:'+id).checked = false;
    }
    document.getElementById('frmsearchworkitem:'+id).disabled = !document.getElementById(ref).checked;*///chkSortVersion option is commented in code: BugID: 39305
    clickLink("frmsearchworkitem:linkRefresh");    
}


function SetDateOption(value)
{
    var prefix='frmsearchworkitem';

    var dataDiv=document.getElementById("frmsearchworkitem:dateFilterDiv");
    var holdArr=document.getElementsByName("frmsearchworkitem:holdID");
    var holdVal;
    for(var i = 0; i < holdArr.length; i++){
        if(holdArr[i].checked){
            holdVal = holdArr[i].value;
        }
    }
    if(value=='')
    {
        if(holdVal==0 || holdVal==1 || holdVal==6 || holdVal=='T' || holdVal=='A' || holdVal=='B')
        {
            if(document.getElementById('frmsearchworkitem:createdBtwCheckBox')!=undefined && document.getElementById('frmsearchworkitem:createdBtwCheckBox')!=null){
                document.getElementById('frmsearchworkitem:createdBtwCheckBox').checked = false;
                document.getElementById('frmsearchworkitem:completedBtwCheckBox').checked = false;
                 document.getElementById('frmsearchworkitem:introBtwCheckBox').checked = false;
                EnableDisableCreatedDate(false);
                EnableDisableCompletedDate(false);
                EnableDisableIntroDate(false);
            }
            if(document.getElementById('frmsearchworkitem:searchInArchivalCheckBox')!=undefined && document.getElementById('frmsearchworkitem:searchInArchivalCheckBox')!=null){
                document.getElementById('frmsearchworkitem:searchInArchivalCheckBox').checked = false;
            }
            
            var ref = document.getElementById("frmsearchworkitem:excludeExitChkBox");
            var TRef = document.getElementById("frmsearchworkitem:holdID:2");
            var ARef = document.getElementById("frmsearchworkitem:holdID:3");
            var BRef = document.getElementById("frmsearchworkitem:holdID:4");
            if(ref){
                if(holdVal == 1){   
                    //  In Process
                    if(document.getElementById('frmsearchworkitem:hidQid').value != '' ){
                        ref.disabled = true;                
                        ref.checked = false;   
                    } else {
                        ref.disabled = false;                            
                        ref.checked = false;        
                    }
                    TRef.disabled=false;
                    ARef.disabled=false;
                    BRef.disabled=false;
                } else if(holdVal == 6){
                    //  In History
                    ref.disabled = true;                
                    ref.checked = false; 
                    TRef.disabled=true;
                    ARef.disabled=true;
                    BRef.disabled=true;
                } else {                
                    ref.disabled = true;                
                    ref.checked = false;
                    TRef.disabled=false;
                    ARef.disabled=false;
                    BRef.disabled=false;
                }
            }
            if(document.getElementById('frmsearchworkitem:globalqueueChk').value=="true" && typeof ToggleOtherFields != 'undefined'){
                ToggleOtherFields('D');
            } else if(document.getElementById('frmsearchworkitem:globalqueueChk').value=="false" && typeof ToggleOtherFields != 'undefined') {
                ToggleOtherFields('E');
            }
        }
    }
    else if(value==2)
    {
        clearRadioGroup(holdArr);
        
        if(document.getElementById('frmsearchworkitem:createdBtwCheckBox').checked){
        document.getElementById('frmsearchworkitem:createdBtwCheckBox').checked = true;
        EnableDisableCreatedDate(true);
        }else{
        document.getElementById('frmsearchworkitem:createdBtwCheckBox').checked = false;
        EnableDisableCreatedDate(false);
        }
        document.getElementById('frmsearchworkitem:completedBtwCheckBox').checked = false;
        document.getElementById('frmsearchworkitem:introBtwCheckBox').checked = false;
//        EnableDisableCreatedDate(true);
        EnableDisableCompletedDate(false);
        EnableDisableIntroDate(false);
         EnableDisableExcludeExitWorkitem(false);
    }
    else if(value==3)
    {
        clearRadioGroup(holdArr);
        
        document.getElementById('frmsearchworkitem:createdBtwCheckBox').checked = false;
        if(document.getElementById('frmsearchworkitem:completedBtwCheckBox').checked){
        document.getElementById('frmsearchworkitem:completedBtwCheckBox').checked = true;
        EnableDisableCompletedDate(true);
        }else{
        document.getElementById('frmsearchworkitem:completedBtwCheckBox').checked = false;
        EnableDisableCompletedDate(false);
        }
//        document.getElementById('frmsearchworkitem:completedBtwCheckBox').checked = true;
        document.getElementById('frmsearchworkitem:introBtwCheckBox').checked = false;
        
        EnableDisableCreatedDate(false);
//        EnableDisableCompletedDate(true);
        EnableDisableIntroDate(false);
        EnableDisableExcludeExitWorkitem(true);
    }
    else if(value==5)
    {
        clearRadioGroup(holdArr);
        
        document.getElementById('frmsearchworkitem:createdBtwCheckBox').checked = false;
        document.getElementById('frmsearchworkitem:completedBtwCheckBox').checked = false;
        if(document.getElementById('frmsearchworkitem:introBtwCheckBox').checked){
        document.getElementById('frmsearchworkitem:introBtwCheckBox').checked = true;
        EnableDisableIntroDate(true);
        }else{
        document.getElementById('frmsearchworkitem:introBtwCheckBox').checked = false;
        EnableDisableIntroDate(false);   
        }
        
        EnableDisableCreatedDate(false);
        EnableDisableCompletedDate(false);
        
    }
    else if(value==4){
        clearRadioGroup(holdArr);
        if(document.getElementById('frmsearchworkitem:searchInArchivalCheckBox').checked==true)
        document.getElementById('frmsearchworkitem:searchInArchivalCheckBox').checked = true;
        else
            document.getElementById('frmsearchworkitem:searchInArchivalCheckBox').checked = false;
       
    }
}

function clearRadioGroup(radioGroupRef) {
    for (var i = 0; i < radioGroupRef.length; i++) {
        if(radioGroupRef[i].checked) {
            radioGroupRef[i].checked = false;
        }
    }
}

function EnableDisableCreatedDate(value)
{
    if(value){
        document.getElementById("frmsearchworkitem:createddateDiv").style.display="block";
    }else{
        document.getElementById("frmsearchworkitem:createddateDiv").style.display="none"
    }
}

function EnableDisableCompletedDate(value)
{
    if(value){
        document.getElementById("frmsearchworkitem:completeddateDiv").style.display="block";
    }else{
        document.getElementById("frmsearchworkitem:completeddateDiv").style.display="none"
    }
}

function EnableDisableIntroDate(value)
{
    if(value){
        document.getElementById("frmsearchworkitem:introdateDiv").style.display="block";
    }else{
        document.getElementById("frmsearchworkitem:introdateDiv").style.display="none"
    }
}

function TrimLeft(val)
{
	var len = val.length;
	if(len==1 && val == " ")
	{
		val = "";
		return val;
	}
	if(len != 0)
	{
		while(1)
		{
			if(val.charAt(0) != " ")
				return val;
			else
				val = val.substr(1);
		}
	}
	return val;
}


function TrimRight(val)
{
	var len = val.length;
	if(len==1 && val == " ")
	{
		val = "";
		return val;
	}
	if(len != 0)
	{
		while(1)
		{
			if(val.charAt(len - 1) != " ")
			{
				return val;
			}
			else
			{
				len -= 1;
				val = val.substr(0,len);
			}
		}
	}
	return val;
}


function Trim(val)
{
    var len = val.length;
    if(len != 0)
    {
        while(1)
        {
            if(val.charAt(0) != " ")
            {
                break;
            }
            else
            {
                val = val.substr(1);
            }
        }
    }

    len = val.length;
    if(len != 0)
    {
        while(1)
        {
            if(val.charAt(len - 1) != " ")
            {
                return val;
            }
            else
            {
                len -= 1;
                val = val.substr(0,len);
            }
        }
    }

    return val;
}

function ShowValuePickList(ref,nameCtrl,alias,type,qId,procId,Extra1){  //Extra1 parameter is for future use, if extra parameter needed
    var posLeft = findAbsPosX(ref);
    var posTop = findAbsPosY(ref);
    try{
        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){}
    var iFrameHeight = 250;
    var iFrameWidth = 230;
    var formid = ref.form.id;
    var popupDivId = "ValuePickList";

    var arr = ref.id.split(":");
    var len = arr.length;
    var strName = "";
    for(var count=0;count<len-1;count++){
        if(count==0)
            strName = arr[count] ;
        else
        {
            strName=strName + ":" + arr[count] ;
        }
    }
    nameCtrl = strName+":"+nameCtrl;
    //iDCtrl = strName+":"+iDCtrl;
    if(type=='12')
        nameCtrl = strName+":procfilterMenu";
    var tempPrefix = document.getElementById(nameCtrl).value;

    if (type != 10){    //for string type=10
        tempPrefix="";
    }
    else{
        tempPrefix=tempPrefix+"*";
    }
    //  alert(tempPrefix);
    alias = strName+":"+alias;
    type =  strName+":"+type;
    //alert(alias);
    var aliasValue = document.getElementById(alias).value;
    if(aliasValue == undefined){
        aliasValue = document.getElementById(alias).innerHTML;  //when alias is an outputLabel
    }
    var typeValue = document.getElementById(type).value;

    var url="/webdesktop/components/search/picklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&QueueId="+ qId +"&ProcessDefId="+procId+"&AttributeName="+aliasValue+"&AttributeType="+ typeValue+"&Prefix="+tempPrefix +"&PopupDivId=" + popupDivId +"&WD_SID="+WD_SID;
    if(openFrom!=undefined && openFrom=='Link'){
        popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);

    }else{
        window.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);

    }
}
var openFrom="";




function ShowUserPickList(popupWInRef, winRef, ref, title,subtaskid,wItemId,pInsId,taskid,processDefId,activityId,bMandatory,queueType,days,hours,minutes,mode,caseRole,taskType,duedate,priority,assignedTo,DefaultUserName,Scope,approveTask,reassignTask,declineTask,taskMode){
    mode = (typeof mode == 'undefined')?'': mode;
    caseRole = (typeof caseRole == 'undefined')?'': caseRole;
    taskType = (typeof taskType == 'undefined')?'': taskType;
    duedate = (typeof duedate == 'undefined')?'': duedate;
    priority = (typeof priority == 'undefined')?'': priority;
    assignedTo = (typeof assignedTo == 'undefined')?'': assignedTo;
    approveTask = (typeof approveTask == 'undefined')?'': approveTask;
    reassignTask = (typeof reassignTask == 'undefined')?'': reassignTask;
    declineTask = (typeof declineTask == 'undefined')?'': declineTask;
    //Bug 74028 Start
    days=(typeof days == 'undefined')?'0':days;
    hours=(typeof hours == 'undefined')?'0':hours;
    minutes=(typeof minutes == 'undefined')?'0':minutes;
    taskMode=(typeof taskMode == 'undefined')?'':taskMode;
    days=(days == '')?'0':days;
    hours=(hours == '')?'0':hours;
    minutes=(minutes == '')?'0':minutes;
    //Bug 74028 End
    var posLeft = findAbsPosX(ref) + ref.clientWidth + 10;
    var posTop = findAbsPosY(ref);

    try{
        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){

    }
    
    var iFrameHeight = 520;
    var iFrameWidth = 430;
    
    var windowWidth = (popupWInRef.innerWidth || popupWInRef.document.documentElement.clientWidth);
    var horInView = (posLeft >= 0) && ((posLeft + iFrameWidth) <= windowWidth);
    if(!horInView){
        posLeft = posLeft - (iFrameWidth + ref.clientWidth + 15);  
    }
    
    posLeft = posLeft + iFrameWidth;
    
    var popupDivId = "UserPickList";
    //bug 74257
    var url="/webdesktop/components/search/userlist.app?Action=1&Title="+encode_utf8(title)+"&WorkItemId="+wItemId
        +"&ProcessDefId="+processDefId+"&ActivityId="+activityId+"&taskid="+taskid+"&subtaskid="+subtaskid
        +"&ProcessInstanceId="+pInsId+"&Mandatory="+bMandatory+"&QueueType="+queueType+"&Mode="+mode
        +"&Width="+iFrameWidth+"&Height="+iFrameHeight + "&PopupDivId=" + popupDivId +"&WD_SID="+WD_SID
        +"&TATdays="+days+"&TAThours="+hours+"&TATmin="+minutes+"&CaseRole="+caseRole+"&TaskType="+taskType
        +"&DueDate="+encode_utf8(duedate)+"&Priority="+priority+"&AssignedTo="+assignedTo+"&DefaultUserName="+DefaultUserName+"&Scope="+Scope
        +"&ApproveTask="+approveTask+"&ReassignTask="+reassignTask+"&DeclineTask="+declineTask+"&TaskMode="+taskMode;
   popupWInRef.popupIFrameOpenerWrapper(winRef, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
}

function ShowGroupPickList(ref,nameCtrl,iDCtrl,hidNameCtrl,showAllGroupFlag){
    var posLeft = findAbsPosX(ref);
    var posTop = findAbsPosY(ref);
    try{
        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){}
    var iFrameHeight = 245;
    var iFrameWidth = 230;
    var formid = ref.form.id;
    var popupDivId = "GrouppickList";    

    var url="/webdesktop/components/search/grouplist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&PopupDivId=" + popupDivId+"&WD_SID="+WD_SID;

    if(showAllGroupFlag == "Y"){
        url = url+"&AllGroupsFlag=Y" ;
    }
    window.parent.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
}
function ShowQueueList(ref,nameCtrl,iDCtrl,hidNameCtrl,funcName,Extra1,ShowAllQueueFlag,Extra2,Extra3,ShowMyQueueFlag,showLocalizedName,hidOrigNameCtrl,typeCtrl,forglobalqueue,hidProcessDefId,hidQueueType){
    var posLeft = findAbsPosX(ref);
    var posTop;
    if(typeof resizeMode != 'undefined' && resizeMode == 'popout')
    {
        posTop = findPosY(ref);
    }
    else
    {
        posTop = findAbsPosY(ref);
    }
    try{
        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){}
    var iFrameHeight = 245;
    var iFrameWidth = 250;
    var formid = ref.form.id;
    var CallBack = funcName;
    var popupDivId = "QueuePickList";
    var AllQueueFlag = "";
    var queuetype="";
     var processDefId="";
    var hidQProcessName="";
    var MyQueueFlag = "Y";
    var url = "";
    
    if (iframeChildren.contains(popupDivId) == false)
        iframeChildren.push(popupDivId);
	if((posTop>iFrameHeight)||(posLeft>iFrameWidth))
    {
    posLeft += iFrameWidth;   
    posTop += iFrameHeight;
    }
    
    if(ShowAllQueueFlag != undefined || ShowAllQueueFlag != null){
        AllQueueFlag = ShowAllQueueFlag;
    }
     if(hidProcessDefId != undefined || hidProcessDefId != null){
        processDefId = hidProcessDefId;
    }
    if(ShowMyQueueFlag != undefined || ShowMyQueueFlag != null){
        MyQueueFlag = ShowMyQueueFlag
    }
    if(Extra2==undefined){
        Extra2="";
    }
    
    
    if(Extra3==undefined){
        Extra3="";
    }
    var OpenedFor = Extra1;
    if(OpenedFor == "PM" || OpenedFor == "CRM")  //for process manager
    {
        if(forglobalqueue)
            url="/webdesktop/components/queue/globalqueuepicklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&strFormFieldTypeID=" + typeCtrl +"&CallBack="+CallBack+ "&PopupDivId=" + popupDivId +"&MyQFlag="+MyQueueFlag+"&ListType=QP&BatchSize=15&SortOrder=A&OrderBy=2&OpenedFor="+OpenedFor+"&Comp_height=200&Comp_width=200&AllQueueFlag="+AllQueueFlag+"&hidQProcessName="+Extra3+"&queuetype="+Extra2+"&WD_SID="+WD_SID;
        else
            url="/webdesktop/components/queue/queuepicklist.app?Action=1&strFormID=" + formid + "&strQueueType=" + hidQueueType + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&strFormFieldTypeID=" + typeCtrl +"&CallBack="+CallBack+ "&PopupDivId=" + popupDivId +"&MyQFlag="+MyQueueFlag+"&ListType=QP&BatchSize=15&SortOrder=A&OrderBy=2&OpenedFor="+OpenedFor+"&Comp_height=200&Comp_width=200&AllQueueFlag="+AllQueueFlag+"&hidQProcessName="+Extra3+"&queuetype="+Extra2+"&hidProcessDefId="+processDefId+"&WD_SID="+WD_SID;
    }else{
        if(forglobalqueue)
            url="/webdesktop/components/queue/globalqueuepicklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&strFormFieldTypeID=" + typeCtrl + "&CallBack="+CallBack+ "&PopupDivId=" + popupDivId +"&MyQFlag=N&ListType=QP&BatchSize=10&SortOrder=A&OrderBy=2&Comp_height=200&Comp_width=200&AllQueueFlag="+AllQueueFlag+"&hidQProcessName="+Extra3+"&queuetype="+Extra2+"&WD_SID="+WD_SID;
        else 
            url="/webdesktop/components/queue/queuepicklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl + "&strFormFieldTypeID=" + typeCtrl + "&CallBack="+CallBack+ "&PopupDivId=" + popupDivId +"&MyQFlag=N&ListType=QP&BatchSize=10&SortOrder=A&OrderBy=2&Comp_height=200&Comp_width=200&AllQueueFlag="+AllQueueFlag+"&hidQProcessName="+Extra3+"&queuetype="+Extra2+"&hidProcessDefId="+processDefId+"&WD_SID="+WD_SID;
        
    }
    
    if(showLocalizedName != undefined && showLocalizedName != null && showLocalizedName != ""){
        url = url+"&ShowLocalizedName="+showLocalizedName;
    }
    if(hidOrigNameCtrl != undefined && hidOrigNameCtrl!=null && hidOrigNameCtrl!=""){
        url = url+"&strOriginalFormFieldHidden="+hidOrigNameCtrl;
    }
    //alert(url);
    if(openFrom!=undefined && openFrom=='Link'){
        popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);

    }else if(typeof resizeMode != 'undefined' && resizeMode=='popout'){
        popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
    }
    else{
        window.parent.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
    }
    
}


function setMultiQueues(queuelistJson){
    var queueJson;
    var unameMsg="";
    var userFlag=false;
    var userNameArr=new Array();
    queueJson = JSON.parse(queuelistJson);
//    if(queueJson.UserInfoList.length > 0) {
//        for(var Count=0;Count<queueJson.UserInfoList.length;Count++)
//        {
//            userFlag=false;
//            var uname = queueJson.UserInfoList[Count].UserName;
//            table = document.getElementById("QueueMgmtForm:UGLists");
//            if (table){
//                    rowCount = table.tBodies[0].rows.length; 
//                    //rowCount=rowCount-1;
//                    for(var iCount = 0; iCount <rowCount; iCount++)
//                    {
//                        userexistid =  document.getElementById("QueueMgmtForm:UGLists:"+iCount +":UGName").innerHTML;
//                        if (uname==userexistid)
//                        {
//                            userFlag=true;
//                            unameMsg += ","+ uname;
//                        }
//                    }
//                    if(userFlag==false){
//                        userNameArr.push(uname);
//                    } else{
//                        delete userJson.UserInfoList[Count];
//                    }
//                }
//                else
//                {
//                    userNameArr.push(uname);   
//                }
//        }
        document.getElementById("frmcriteriamgmt:hidQListJson").value=JSON.stringify(queueJson);
        
        clickLink('frmcriteriamgmt:setQueueList');
        //document.getElementById("QueueMgmtForm:UserName").value=userNameArr;        
       // document.getElementById("QueueMgmtForm:UserName").title=userNameArr;        
//        if(unameMsg!=""){
//            fieldValidator(null, unameMsg.substring(1,unameMsg.length) + " " + TEXT_ALREADY_ADDED, "absolute", true);
//            return false;
//        }
  //  }
//    else
//    {
//        fieldValidator("QueueMgmtForm:UserName", NO_USER_SELECTED, "absolute", true);
//        return(false);
//    }
    return true;
}

function ShowWorkstepList(ref,txtworkstepName,hidworkstepId,hidWorkstepName,hidProcessName,hidProcessId,hidQueueId,OpenSrc,ActType,disabledActivityName,AllWorkstepFlag,CallbackFunction,showLocalizedName,hidOrigNameCtrl,hidActTypeDB)
{
    var posLeft = findAbsPosX(ref);
    var posTop = findAbsPosY(ref);
    try{
        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){}
    var iFrameHeight = 245;
    var iFrameWidth = 230;
    var formid = ref.form.id;
    var popupDivId = "WorkstepPickList";
    var procID= document.getElementById(hidProcessId).value;
    var procName= document.getElementById(hidProcessName).value;
    var queueID="";
    var ActTypeDB="";
    
    if(hidQueueId != undefined && hidQueueId!="")
        queueID = document.getElementById(hidQueueId).value;
    if(typeof hidActTypeDB!='undefined' && hidActTypeDB!= null){
       ActTypeDB=hidActTypeDB;
    } 
    
    if (iframeChildren.contains(popupDivId) == false)
        iframeChildren.push(popupDivId);
        
    var url="/webdesktop/components/workstep/worksteppicklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + txtworkstepName + "&strFormFieldID=" + hidworkstepId + "&strFormFieldTextHidden=" + hidWorkstepName + "&ProcessDefID=" +procID+ "&ProcessName=" +encode_utf8(procName)+ "&QueueId="+queueID+"&PopupDivId=" + popupDivId +"&WD_SID="+WD_SID;
       
        url=url+"&ActTypeDB="+ActTypeDB;
    
    if(OpenSrc!= undefined && OpenSrc != "")        
        url=url+"&OpenFrom="+OpenSrc;
    
    if(ActType!= undefined && ActType != "")        
        url=url+"&ActivityType="+ActType;
    
    if(disabledActivityName != undefined && disabledActivityName!=""){
        url=url+"&DisabledActivityName="+encode_utf8(disabledActivityName);
    }
    if(AllWorkstepFlag!=undefined && AllWorkstepFlag!=""){
        url=url+"&AllWorkstepFlag="+AllWorkstepFlag;
    }
    if(CallbackFunction!= undefined && CallbackFunction!=""){
        url=url+"&CallBack="+CallbackFunction;
    }
    if(showLocalizedName != undefined && showLocalizedName != null && showLocalizedName != ""){
        url = url+"&ShowLocalizedName="+showLocalizedName;
    }
    if(hidOrigNameCtrl != undefined && hidOrigNameCtrl!=null && hidOrigNameCtrl!=""){
        url = url+"&strOriginalFormFieldHidden="+hidOrigNameCtrl;
    }
    
    if(openFrom!=undefined && openFrom=='Link'){
           popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);

    }else{
           window.parent.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
       }
}

function ShowProcessList(ref,nameCtrl,IdCtrl,hidNameCtrl,queuenamectrl,queueidctrl,funcName,AllProcessFlag,Extra2,Extra3,Extra4,Extra5,Extra6,Extra7,Extra8,showLocalizedName,hidOrigNameCtrl,hidDisplayName,searchBase){
    var posLeft = findAbsPosX(ref);
    var posTop;
    if(typeof resizeMode != 'undefined' && resizeMode == 'popout')
    {
        posTop = findPosY(ref);
    }
    else
    {
        posTop = findAbsPosY(ref);
    }
    try {
        posLeft -= document.getElementById("scroll").scrollLeft;
        posTop -= document.getElementById("scroll").scrollTop;        
    } catch(e){}

    var stateflag="B";

    var CallBack = funcName;

    var iFrameHeight = 245;
    var iFrameWidth = 250;
    var formid = ref.form.id;
    var popupDivId = "ProcessPickList";
    var queueId = "";
    var queueName = "";
    var processprefix="";
    
    if(iframeChildren.contains(popupDivId) == false)
        iframeChildren.push(popupDivId);
    
    if((posTop>iFrameHeight))
    {  
       posTop += iFrameHeight;
    }
    var windowWidth = (window.innerWidth || document.documentElement.clientWidth);
    if(posLeft + iFrameWidth > windowWidth){
        
    }
    else{
        if(typeof pageDirection != 'undefined' && pageDirection != null && pageDirection == 'ltr')
             posLeft += iFrameWidth; 
    }
    if(searchBase==undefined  && queueidctrl != undefined && queueidctrl != "" )
    {
        queueId = document.getElementById(queueidctrl).value;
        queueName = encode_utf8(document.getElementById(queuenamectrl).value);
    }

 
    var latestversionFlag="";
    if(Extra3!=undefined && Extra3!=""){
/* Below lines are commented on comparing from webdesktop 9 */
//       Extra3=document.getElementById('QueueMgmtForm:hidQProcessName').value;

//       processprefix=Extra3;
        latestversionFlag = Extra3;
    }
     if(Extra7!=undefined && Extra7!=""){
      Extra7=encode_utf8(document.getElementById('QueueMgmtForm:hidQProcessName').value);

      processprefix=Extra7;
        
    }
    var hidPrcSuffix;
    var hidPrcPrefix;
    var hidPrcRegLen;
    if(Extra5!=undefined && Extra5!=""){
        hidPrcPrefix=Extra5;
    }

    if(Extra6!=undefined && Extra6!=""){
        hidPrcRegLen =Extra6;
    }
    if(Extra4!=undefined && Extra4!=""){
        hidPrcSuffix =Extra4;
    }
    if(Extra8!=undefined && Extra8!=""){
        stateflag=Extra8;
    }
    
    var OpenedFor = Extra2;
    var url = "/webdesktop/components/process/processpicklist.app?Action=1&strFormID="+formid+"&strFormFieldText="+nameCtrl+"&strFormFieldID="+IdCtrl+"&strFormFieldTextHidden="+hidNameCtrl+"&QueueName="+queueName+"&QueueId="+queueId+"&stateflag="+stateflag+"&CallBack="+CallBack+"&PopupDivId="+popupDivId+"&OpenedFor="+OpenedFor+"&processprefix="+processprefix+"&PrcSuffix="+hidPrcSuffix+"&PrcPrefix="+hidPrcPrefix+"&PrcRegLen="+hidPrcRegLen+"&DisplayName="+hidDisplayName+"&latestversionFlag="+latestversionFlag;
    if(AllProcessFlag != undefined && AllProcessFlag != null && AllProcessFlag != "" && AllProcessFlag == "Y"){
        url = url+"&AllProcessFlag=Y";
    }
    
    if(showLocalizedName != undefined && showLocalizedName != null && showLocalizedName != ""){
        url = url+"&ShowLocalizedName="+showLocalizedName;
    }
    if(hidOrigNameCtrl != undefined && hidOrigNameCtrl!=null && hidOrigNameCtrl!=""){
        url = url+"&strOriginalFormFieldHidden="+hidOrigNameCtrl;
    }
    url = url+"&WD_SID="+WD_SID;
    //alert(url);
    if(openFrom != undefined && (openFrom == "Link" || openFrom == "ArchiveSearch")){
          popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
      }else if(typeof resizeMode != 'undefined' && resizeMode=='popout'){
        popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
      }else{
          window.parent.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
      }
}

function ShowVariantList(ref,nameCtrl,IdCtrl,hidNameCtrl,processnamectrl,processidctrl,funcName,Extra1,Extra2,Extra3,Extra4,Extra5,Extra6,Extra7,Extra8,showLocalizedName,hidOrigNameCtrl){
    var posLeft = findAbsPosX(ref);
    var posTop = findAbsPosY(ref);
    try {
        posLeft -= document.getElementById("scroll").scrollLeft;
        posTop -= document.getElementById("scroll").scrollTop;
    } catch(e){}

    var stateflag="B";

    var CallBack = funcName;

    var iFrameHeight = 245;
    var iFrameWidth = 250;
    var formid = ref.form.id;
    var popupDivId = "variantPickList";
    var processId = "";
    var processName = "";
   
    if (iframeChildren.contains(popupDivId) == false)
        iframeChildren.push(popupDivId);
    
    if(processidctrl != undefined && processidctrl != "")
    {
        processId = document.getElementById(processidctrl).value;
        processName = encode_utf8(document.getElementById(processnamectrl).value);
    }

    var url = "/webdesktop/components/process/variantpicklist.app?Action=1&strFormID="+formid+"&strFormFieldText="+nameCtrl+"&strFormFieldID="+IdCtrl+"&strFormFieldTextHidden="+hidNameCtrl+"&ProcessName="+processName +"&ProcessId="+processId+"&CallBack="+CallBack+"&PopupDivId="+popupDivId;
    
    if(hidOrigNameCtrl != undefined && hidOrigNameCtrl!=null && hidOrigNameCtrl!=""){
        url = url+"&strOriginalFormFieldHidden="+hidOrigNameCtrl;
    }
    url = url+"&WD_SID="+WD_SID;
    //alert(url);
    if(openFrom != undefined && (openFrom == "Link")){
          popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
      }else{
          window.parent.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
      }
}


function ShowVariablePickList(ref,nameCtrl,IdCtrl,hidNameCtrl,procid,procName,funcName,Extra1,Extra2,hidProcVarID,showLocalizedName){
    var posLeft = findAbsPosX(ref);
    var posTop = findAbsPosY(ref);
    try {
        posLeft -= document.getElementById("scroll").scrollLeft;
        posTop -= document.getElementById("scroll").scrollTop;
    }catch(e){}

    var stateflag="B";
    var callBack="";
    if(funcName!=undefined && funcName!=""){
        if(Trim(funcName).length>0)
        {
            callBack="&Callback=" + Trim(funcName);
        }
    }
    if(hidProcVarID==undefined ){
        hidProcVarID="";
    }


    var iFrameHeight = 245;
    var iFrameWidth = 230;
    var formid = ref.form.id;
    var popupDivId = "VariablePicklist";
    var fetchExteralVarOnly="";
    if(Extra1!=undefined && Extra1!=""){
        fetchExteralVarOnly=Extra1;
    }
    var showSysVar="S";
    if(Extra2!=undefined && Extra2!=""){
        showSysVar=Extra2;
    }

   var OpenedFor = Extra2;
   var callFromQM;
		if (formid == 'QueueMgmtForm') {
                    callFromQM = 'Y';
		} else {
                    callFromQM = 'N';
		}
   url="/webdesktop/components/search/variablepicklist.app?Action=1&strFormID=" + formid + "&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + IdCtrl + "&strFormFieldTextHidden=" + hidNameCtrl +  "&ProcessDefID=" +procid+ "&ProcessName=" +procName+ "&PopupDivId=" + popupDivId+"&FetchExternalVarOnly="+fetchExteralVarOnly+"&showSysVar="+showSysVar+callBack+"&hidProcVarID="+hidProcVarID+"&WD_SID="+WD_SID+ "&CallFromQM=" + callFromQM;
   // var url = "/webdesktop/components/process/processpicklist.app?Action=1&strFormID="+formid+"&strFormFieldText="+nameCtrl+"&strFormFieldID="+IdCtrl+"&strFormFieldTextHidden="+hidNameCtrl+"&QueueName="+queueName+"&QueueId="+queueId+"&stateflag="+stateflag+"&CallBack="+CallBack+"&PopupDivId="+popupDivId+"&OpenedFor="+OpenedFor;
    
    if(showLocalizedName != undefined && showLocalizedName != null && showLocalizedName != ""){
        url = url+"&ShowLocalizedName="+showLocalizedName;
    }
    
    if(openFrom!=undefined && openFrom=='Link'){
          popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
      }else{
          window.parent.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
      }
}


function findAbsPosX(obj){
    var curleft = 0;

    if(obj.offsetParent){
        var windowRef = this;
        while(1){
            while(1) {
                if(obj == null){
                    return curleft;
                }
                
                curleft += obj.offsetLeft;
                if(!obj.offsetParent)
                    break;
                obj = obj.offsetParent;
            }

            if(windowRef == windowRef.parent){
                break;
            }

            try
            {
                // Gets the reference of this iframe
                obj = windowRef.parent.document.getElementById(windowRef.name);
            }catch(e){}
            windowRef = windowRef.parent;
        }
    } else if(obj.x) {
        curleft += obj.x;
    }

    return curleft;
}

function findAbsPosY(obj){
    var curtop = 0;
    if(obj.offsetParent){
        var windowRef = this;
        while(1){
            while(1) {
                if(obj == null){
                    return curtop;
                }
                
                curtop += obj.offsetTop;
                if(!obj.offsetParent)
                    break;
                obj = obj.offsetParent;
            }

            if(windowRef == windowRef.parent){
                break;
            }
            try
            {
                if(windowRef && windowRef.name && windowRef.name.length > 0){
                    obj = windowRef.parent.document.getElementById(windowRef.name);
                } else {
                    obj = windowRef.frameElement;
                }             
            }catch(e){}
            windowRef = windowRef.parent;
        }
    }else if(obj.x) {
        curtop += obj.x;
    }

    return curtop;
}

function EnableSetFilterWorkStepButton()
{

if(document.getElementById('filterWorkItemList:hidprocessid').value > 0 )
    {
        document.getElementById('filterWorkItemList:aidBtn').disabled=false;
        document.getElementById('filterWorkItemList:aidtext').disabled=false;
    }
    else
    {
        document.getElementById('filterWorkItemList:aidBtn').disabled=true;
        document.getElementById('filterWorkItemList:aidtext').disabled=true;
    }

/*
    if(!document.getElementById('filterWorkItemList:hidprocessid').value == '' )
    {
        document.getElementById('filterWorkItemList:aidBtn').disabled=false;
    }
    else
    {
        document.getElementById('filterWorkItemList:aidBtn').disabled=true;
    }
*/
    document.getElementById('filterWorkItemList:hidactivityid').value='';
    document.getElementById('filterWorkItemList:hidactivityname').value=document.getElementById('filterWorkItemList:hidInitialWorkstep').innerHTML;
    document.getElementById('filterWorkItemList:aidtext').value=document.getElementById('filterWorkItemList:hidInitialWorkstep').innerHTML;

}
function EnableDisableWorkstepButton()
{

    if(!document.getElementById('frmsearchworkitem:hidPid').value == '' )
    {
        document.getElementById('frmsearchworkitem:aidBtn').disabled=false;
    }
    else
    {
        document.getElementById('frmsearchworkitem:aidBtn').disabled=true;
    }

    document.getElementById('frmsearchworkitem:hidAid').value='';
    document.getElementById('frmsearchworkitem:hidAName').value=document.getElementById('frmsearchworkitem:hidInitialWorkstep').innerHTML;
    document.getElementById('frmsearchworkitem:aidtext').value=document.getElementById('frmsearchworkitem:hidInitialWorkstep').innerHTML;
    EnableDisableSearchOnPrevChkBox();
    //clickLink('frmsearchworkitem:hidQueueClick');
}

function EnableDisableSearchOnPrevChkBox()
{

//    if(document.getElementById('frmsearchworkitem:hidPid').value > 0 )
//    {
//        document.getElementById('frmsearchworkitem:chkPreviousVersion').disabled = false;
//    }
//    else
//    {
//        document.getElementById('frmsearchworkitem:chkPreviousVersion').disabled=true;
//        document.getElementById('frmsearchworkitem:chkSortVersion').checked = false;
//    // EnableDisableSortOnVersionsChkBox();
//    }
    clickLink('frmsearchworkitem:hidQueueClick');    

}



function setProcessValue(){
    //alert(document.getElementById('frmsearchworkitem:hidPid').value);
  //  document.getElementById('frmsearchworkitem:hidPid').value='';    
    document.getElementById('frmsearchworkitem:regNo').value='';
    //document.getElementById('frmsearchworkitem:hidPName').value=document.getElementById('frmsearchworkitem:hidInitialProcess').innerHTML;
   // document.getElementById('frmsearchworkitem:pidtext').value=document.getElementById('frmsearchworkitem:hidInitialProcess').innerHTML;
//    EnableDisableWorkstepButton();
    document.getElementById('frmsearchworkitem:chkPreviousVersion').value = false;
    var holdArr=document.getElementsByName("frmsearchworkitem:holdID");
    if(holdArr){
        // In Process
        holdArr[1].checked = true;
    }
    
    var ref = document.getElementById("frmsearchworkitem:excludeExitChkBox");
    if(ref){
        if(document.getElementById('frmsearchworkitem:hidQid').value != '' ){
            ref.disabled = true;                
            ref.checked = false;   
        } 
    }
    
    EnableDisableSearchOnPrevChkBox();
}
            

function GetTitles(thisEle,Type)//checked
{
    var strTitle;
    //var strType = Type.substring(2);
    var strType = Type;

    switch(strType)
    {
        case "10":
            strTitle = INSERT_STR_VAL;
            break;
        case "B":
            strTitle = INSERT_BOOL_VAL;
            break;
        case "8":
            strTitle = INSERT_DATE_VAL + dateTimeFormat + " hh:mm:ss";
            break;
        case "3":
            strTitle = INSERT_INT_VAL;
            break;
        case "6":
            strTitle = INSERT_DEC_VAL;
            break;
        case "T":
            strTitle = INSERT_RAW_VAL;
            break;
        case "4":
            strTitle = INSERT_INT_VAL;
            break;
        case "12":
            strTitle = INSERT_BOOL_VAL;
            break;
        case "16":
            strTitle = INSERT_TIME_VAL;
            break;
        case "15":
            strTitle = INSERT_DATE_VAL + dateTimeFormat;;
            break;

        default:
    }

    thisEle.title = strTitle;
}

function setRowsToRemove(ref, id){
    var arr = ref.id.split(":");
    var iLength = arr.length ;
    var selectedRowIndex = arr[iLength-2];
    document.getElementById(id).value = selectedRowIndex;

}

function findPosition(ctrlname)
{
         var finalWindow=window;
         bodyCtrlName=finalWindow.document.body;

        var cdRight=cdLeft=cdTop=cdBottom=0;
/*----------------------------------Absolute top-left position of text box--------------------------------------------------*/
        var absoluteleft = absolutetop = 0;
        var tempCtrlname=ctrlname;

        if (tempCtrlname.offsetParent)
        {
            absoluteleft = tempCtrlname.offsetLeft;
            absolutetop = tempCtrlname.offsetTop;
            while (tempCtrlname = tempCtrlname.offsetParent)
            {
                absoluteleft += tempCtrlname.offsetLeft;
                absolutetop += tempCtrlname.offsetTop;
            }
        }
        absoluteleft += 2;
        absolutetop += 2;
/*  to find top ,left ,bottom and right of textbox control . Actual top,left is 2 pixel less then calculated*/

        try
        {
            if(ctrlname.getBoundingClientRect)//internet explorer
            {
                rcts = ctrlname.getBoundingClientRect();
                cdRight = rcts.right ;  //these are relative positions
                cdLeft = rcts.left;
                cdTop = rcts.top;
                cdBottom = rcts.bottom ;
                if(absoluteleft  !=  cdLeft || absolutetop  !=cdTop)   //to change relative to absolute positions
                {
                    absoluteHorizontalDiff=absoluteleft-cdLeft;
                    absoluteVerticalDiff=absolutetop-cdTop;

                    cdTop+=absoluteVerticalDiff;
                    cdBottom+=absoluteVerticalDiff;
                    cdLeft+=absoluteHorizontalDiff;
                    cdRight+=absoluteHorizontalDiff;
                }
            }
            else if(document.getBoxObjectFor) //mozilla
            {
                rcts = document.getBoxObjectFor(ctrlname);
                cdLeft = rcts.x ;
                cdTop = rcts.y ;
                cdRight = rcts.width+ cdLeft;
                cdBottom = rcts.height+cdTop ;
            }
            else
            {

                cdLeft =absoluteleft ;
                cdTop = absolutetop ;
                cdRight = curleft+100;
                cdBottom = curtop+10 ;
            }
        }catch(e){}
/*-------------------------------------to set exact positions-----------------------------------------------------------------*/
       if (cdLeft != 0) {
        cdLeft -= 2;
    }
        if(cdTop !=0)
        cdTop -=2;
        cdRight -=2;
        cdBottom -=2;

        var CRcustomControl = {
	left  : 0,
	top   : 0,
	right : 0,
	bottom :0
        };

    CRcustomControl.top=cdTop;
    CRcustomControl.left=cdLeft;
    CRcustomControl.right=cdRight;
    CRcustomControl.bottom=cdBottom;

    return CRcustomControl;

}

function findPosX(obj){
    var curleft = 0;
    if(obj.offsetParent)
        while(1)
        {
            curleft += obj.offsetLeft;
            if(!obj.offsetParent)
                break;
            obj = obj.offsetParent;
        }
    else if(obj.x)
        curleft += obj.x;
    return curleft;
}

function findPosY(obj){
    var curtop = 0;
    if(obj.offsetParent)
        while(1)
        {
            curtop += obj.offsetTop;
            if(!obj.offsetParent)
                break;
            obj = obj.offsetParent;
        }
    else if(obj.y)
        curtop += obj.y;
    return curtop;
}

function checkQuickSearchVal(ref){
    var selectedQuickSearchVal=ref.value;
    var inpProcessName=document.getElementById('wlf:pidtext');
    var inpPickListBtn=document.getElementById('wlf:btnProcessPicklist');
    if(selectedQuickSearchVal!='0'){
        inpProcessName.style.visibility='hidden';
        inpPickListBtn.style.visibility='hidden';
    }else{
        inpProcessName.style.visibility='visible';
        inpPickListBtn.style.visibility='visible';
    }
}

function setQuickSearchFilter(winref){
    winref = (typeof winref == 'undefined' || (winref == null))? window: winref;
    
    var selectedVar=document.getElementById("wlf:pqks:searchWI");
    if(selectedVar == null){
        selectedVar=document.getElementById("wlf:searchWI");
    }
    selectedVar = selectedVar.value;
    
    var searchPrefix=document.getElementById("wlf:pqks:Prefix");
    if(searchPrefix == null){
        searchPrefix=document.getElementById("wlf:Prefix");
    }
    searchPrefix = searchPrefix.value;
    
    if(typeof CustomQuickSearchPrefix != 'undefined'){
        searchPrefix = CustomQuickSearchPrefix(searchPrefix,selectedVar);//Bug 66126
    }
    if(searchPrefix==OP_WI_SEARCH || searchPrefix==''){
        customAlert(PLEASE_ENTER_SOME_FILTER_STRING);
        return false;
    }
    var val = Trim(searchPrefix);
    if(selectedVar=='0' && val.charAt(0)=="*"){
         if(IsOpSearchFlag=="Y"){
              customAlert(ALERT_NOT_ALLOWED_FIRST_POSTION);
              return false;
        }
    }
    
    document.getElementById('wlf:hidFlag').value="4";
    document.getElementById('wlf:hidSearch').value=true;
    document.getElementById('wlf:inpSearchCriteria').value=selectedVar; //Bug 67945
    
    if (selectedVar == '0' || (selectedVar == '1' && isURNEnable)) {
        var processname=document.getElementById('wlf:pqks:processlist')
        if(processname == null){
            processname=document.getElementById('wlf:processlist');
        }   
        processname=processname.value;
        if((processname=="" || processname=="-1")){
            customAlert(PLEASE_SPECIFY_PROCESS_NAME);
            return false;
        }else{
            //if process is selected - check for variant process and selected type
            var variantRef = document.getElementById('wlf:pqks:VariantList');
            if(variantRef == null){
                variantRef = document.getElementById('wlf:VariantList');
            }
            if(variantRef.style.display != 'none'){
                if(variantRef.value == "-1" || variantRef.value == "" || variantRef.value == -1){
                    customAlert("Please select variant of process");
                    return false;
                }else{
                    document.getElementById('wlf:hidVariantId').value=variantRef.value;
                }
            }
        }
        
        processname=document.getElementById('wlf:pqks:processlist');
        if(processname == null){
            processname=document.getElementById('wlf:processlist');
        }
        setProcessId(processname);
    } else {
        var AliasList=document.getElementById('wlf:pqks:AliasList');
        if(AliasList == null){
             AliasList=document.getElementById('wlf:AliasList');
        }
        
        if(AliasList != null){
            document.getElementById('wlf:hidQSAlias').value=AliasList.value; //Bug 67945
        }        
    }
   if(searchPrefix!=OP_WI_SEARCH){
        var ref = document.getElementById("wlf:pqks:searchPrefix");
        if(ref == null){
            ref = document.getElementById("wlf:searchPrefix");
        }
        ref.value=searchPrefix;
    }
    
    /*
    Orderby flag was 10 here because of which in search query order by is on Entrydatetime, processinstanceid, workitemid.
    It should be passed as 2 for quick search on any queue and in that case orderby will be on processinstanceid, workitemid only on which
    there is a primary index and hence query will run fast.    
     */
    if(document.getElementById('wlf:hidOrderBy') != null){
        document.getElementById('wlf:hidOrderBy').value = "2";
    }
    
    if(document.getElementById("wlf:hidArchivalMode") != null){
        document.getElementById("wlf:hidArchivalMode").value = "N";
    }
    
    ref = document.getElementById('wlf:cid');
    if(ref){
        ref.value = "";
    }
    ref = document.getElementById('wlf:fid');
    if(ref){
        ref.value = "";
    }
    
    return true;
}

function populateFilterfromQuery(queryId,queryName) {

    document.getElementById("filterWorkItemList:selectedQueryId").value=queryId;
    document.getElementById("filterWorkItemList:selectedQueryName").value=queryName;
    
    //document.getElementById("filterWorkItemList:queryName").style.visibility = "visible";
    //document.getElementById("filterWorkItemList:queryName").innerHTML = queryName;
    clickLink('filterWorkItemList:cmdFetchQUery');
}





function populateSearchfromQuery(queryId,globalQueryFlag) {

    document.getElementById("frmsearchworkitem:selectedQueryId").value=queryId;
    if(document.getElementById("frmsearchworkitem:IsSelectedQueryGlobal")!=null)
        document.getElementById("frmsearchworkitem:IsSelectedQueryGlobal").value=globalQueryFlag;    
    clickLink('frmsearchworkitem:linkFetchQuery');
}

function fetchWIBasedFromQueryList(queryId){
    /*var outLabelId=ref.id;
    outLabelId=outLabelId.substring(0,outLabelId.lastIndexOf(":"));
    outLabelId=outLabelId.substring(outLabelId.lastIndexOf(":")+1,outLabelId.length);
    alert(outLabelId);*/
    document.getElementById("wlf:hidSelectedQueryIndex").value=queryId;
    clickLink('wlf:fetchWorkitemBasedOnQueryList');
}

function fetchWIBasedFromQueryListSB(queryId){
    if(window.parent.iFrameWorkitemListRef){
        window.parent.iFrameWorkitemListRef.fetchWIBasedFromQueryList(queryId);
    }
    
    renderQListCss(queryId-0);
}


function encode_ParamValue(param)
{
    return param;
}

function clickLinkFromIFrame(linkId)
{
    if(!linkId)
    {
        return false;
    }
    var fireOnThis = parentWindowRef.document.getElementById(linkId);

    if(fireOnThis != null && (fireOnThis.nodeName.toUpperCase() == "A")){
        if(fireOnThis.href.lastIndexOf("#") > -1){
            fireOnThis.href = "javascript:void(0)";
        }
    }
    if (fireOnThis != null) {
        if (document.createEvent)
        {
            var evObj = document.createEvent('MouseEvents');
            evObj.initMouseEvent("click", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
            fireOnThis.dispatchEvent(evObj);
        }
        else if (document.createEventObject)
        {
            fireOnThis.click();

        }
    }
    return ;
}

function clickLinkFromIFrameWrapper(linkId,opr,from)
{
    
    if(typeof opr!='undefined' && opr!=null){
        window.parent.iFrameWorkitemListRef.document.getElementById('wlf:hidOprFlag').value=true;
        window.parent.iFrameWorkitemListRef.document.getElementById('wlf:hidOprPerf').value=opr;
     }
     else{
        window.parent.iFrameWorkitemListRef.getElementById('wlf:hidOprFlag').value=false;
        window.parent.iFrameWorkitemListRef.getElementById('wlf:hidOprPerf').value="";
        }
        
    var hidCtrSrch = window.parent.iFrameWorkitemListRef.document.getElementById('wlf:hidCtrSrch').value;
    if(hidCtrSrch=='true'){
        clickLinkFromIFrame("wlf:searchCriteria");
    } else {        
        clickLinkFromIFrame(linkId);
    }
}

var ENCODING="UTF-8";
var hexArr = new Array('0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F');

function encode_utf8(ch)
{
    if (ENCODING.toUpperCase() != "UTF-8")
        return escape(ch);
    
    return encodeURIComponent(ch);
    
    var i,bytes;
    var utf8 = new String();
    var temp;

    for(i=0, bytes = 0; i<ch.length; i++)
    {
        temp = ch.charCodeAt(i);
        if(temp < 0x80)
        {
            utf8 += String.fromCharCode(temp);
        }
        else if (temp < 0x0800)
        {
            utf8 += String.fromCharCode((temp>> 6 | 0xC0));
            utf8 += String.fromCharCode((temp & 0x3F | 0x80));
        }
        else
        {
            utf8 += String.fromCharCode((temp>> 12 | 0xE0));
            utf8 += String.fromCharCode((temp>> 6 & 0x3F | 0x80));
            utf8 += String.fromCharCode((temp & 0x3F | 0x80));
        }
    }

    if (navigator.appName.indexOf("Netscape") == -1)
    {
        return escape(utf8);
    }
    var esc = new String();
    for(l=0;l<utf8.length;l++)
    {
        if(utf8.charCodeAt(l)<128)
            esc += escape(utf8[l]);
        else 
        {
            esc += "%";
            esc += hexArr[utf8.charCodeAt(l)>>4];
            esc += hexArr[utf8.charCodeAt(l) & 0xf];
        }
    }
    return esc;
}


function decode_utf8(utftextBytes)
{
    var utftext = unescape(utftextBytes);
    if (ENCODING.toUpperCase() != "UTF-8")
        return utftext;
    var plaintext = "",temp;

    var i=c1=c2=c3=c4=0;

    while(i<utftext.length)
    {
        c1 = utftext.charCodeAt(i);
        temp = '?';

        if (c1<0x80)
        {
            temp = String.fromCharCode(c1);
            i++;
        }
        else if( (c1>>5) ==	6) //2 bytes
        {
            c2 = utftext.charCodeAt(i+1);

            if( !((c2^0x80)&0xC0))
                temp = String.fromCharCode(((c1&0x1F)<<6) | (c2&0x3F));
            i+=2;
        }
        else if( (c1>>4) == 0xE)  //3 bytes
        {
            c2 = utftext.charCodeAt(i+1);
            c3 = utftext.charCodeAt(i+2);

            if( !(((c2^0x80)|(c3^0x80))&0xC0) )
                temp = String.fromCharCode(((c1&0xF)<<12) | ((c2&0x3F)<<6) | (c3&0x3F));
            i+=3;
        }
        else
            i++;
        plaintext += temp;
    }
    return plaintext;
}

function appendUrlSession(url){
    //    if(cookieFlag == 'N' && sessionVal!="" )
    //    {
    //        if(url.indexOf('?') != '-1')
    //            url = url.substring(0,url.indexOf('?'))+sessionVal+url.substring(url.indexOf('?'));
    //        else
    //            url = url + sessionVal;
    //    }
    //    if(typeof url != 'undefined'){
    //        if(url.indexOf('?') != '-1')
    //            url = url + '&wnwd='+ reqSession;
    //        else
    //            url = url + '?wnwd=' + reqSession;
    //    }
    if(url.indexOf("WD_SID") < 0){
        if(url.indexOf("?")>0)
        {
            if(WD_SID != undefined || WD_SID != null)
                url=url + "&WD_SID="+ WD_SID;
        }
        else
        {
            if(WD_SID != undefined || WD_SID != null)
                url=url + "?WD_SID="+ WD_SID;
        }
    }   

    return url;

}


function getIEVersion()
// Returns the version of Windows Internet Explorer or a -1
// (indicating the use of another browser).
{
   var rv = -1; // Return value assumes failure.
   if (navigator.appName == 'Microsoft Internet Explorer')
   {
      var ua = navigator.userAgent;
      var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
      if (re.exec(ua) != null)
         rv = parseFloat( RegExp.$1 );
   }
   return rv;
}

function createIndicator(indicatorFrameId)
{
    //closePicklists();
    try{
    //closePicklistWindows();
    }
    catch(e){}
/*var ParentDocWidth = document.body.clientWidth;
    var ParentDocHeight = document.body.clientHeight;
    var ImgTop=ParentDocHeight/2-10;
    var ImgLeft=ParentDocWidth/2-25;

   try
    {

        if(document.getElementById(indicatorFrameId) != null)
            return;
        img = document.createElement("IMG");
    //    img.setAttribute("src", "/webdesktop/resources/images/progressimg.gif");
        img.setAttribute("name", indicatorFrameId);
        img.setAttribute("id", indicatorFrameId);
        img.style.left = ImgLeft+"px";
        img.style.top = ImgTop+"px";
        img.style.position="absolute";
        img.style.visibility="visible";
        //img.style.width="105px";
        //img.style.height="15px";
        document.body.appendChild(img);

   }
   catch(ex)
   {
       alert("exception= "+ex);
   }*/
}

function appendUrlSessionAjax(url)
{
    return handleJSessionID(url);
}
var cookie = navigator.cookieEnabled;
var sessionVal="";

function handleJSessionID(url)
{
    var cookieFlag = 'Y';


    if(cookie)
        cookieFlag = 'Y';
    else
        cookieFlag = 'N';

    try
    {
        if(cookieFlag == 'N' && SessionVariable!="" )
        {
            if(url.indexOf('?') != '-1')
                url = url.substring(0,url.indexOf('?'))+SessionVariable+url.substring(url.indexOf('?'));
            else
                url = url + SessionVariable;
        }
    }catch(Ex)
    {
        var frmAction = document.forms[0].action;
        if(sessionVal == "" && frmAction.indexOf(";")!="-1")
            sessionVal = frmAction.substring(frmAction.indexOf(";"));

        if(cookieFlag == 'N' && sessionVal!="" )
        {
            if(url.indexOf('?') != '-1')
                url = url.substring(0,url.indexOf('?'))+sessionVal+url.substring(url.indexOf('?'));
            else
                url = url + sessionVal;
        }
    }
    return url;
}


//extra arry function
Array.prototype.append=function(obj,nodup){
    if (!(nodup && this.contains(obj))){
        this[this.length]=obj;
    }
}

/*
return index of element in the array
*/
Array.prototype.indexOf=function(obj){
    var result=-1;
    for (var i=0;i<this.length;i++){
        if (this[i]==obj){
            result=i;
            break;
        }
    }
    return result;
}

/*
return true if element is in the array
*/
Array.prototype.contains=function(obj){
    return (this.indexOf(obj)>=0);
}

/*
empty the array
*/
Array.prototype.clear=function(){
    this.length=0;
}

/*
insert element at given position in the array, bumping all
subsequent members up one index
*/
Array.prototype.insertAt=function(index,obj){
    this.splice(index,0,obj);
}

/*
remove element at given index
*/
Array.prototype.removeAt=function(index){
    this.splice(index,1);
}

/*
return index of element in the array
*/
Array.prototype.remove=function(obj){
    var index=this.indexOf(obj);
    if (index>=0){
        this.removeAt(index);
    }
}
function isUndefined(v) {
    var undef;
    return v===undef;
}

//overridding eval
window.parseJSON_ = window.eval;
//window.eval=function(str)
//{
//    alert("123");
//    return window.parseJSON_(str);
//}

function parseJSON(str){
    str = (typeof str == 'undefined' ? '' : str);
    if(str.length < 1){
        return "";
    }
    
    var invalidString = /[\x00-\x1F]/.test(str);
    if (!invalidString) {
        return parseJSON_(str);
    }else{
        return "";
    }
    //window.parseJSON_(str);
}

function validate_param(par){
    if(par.indexOf("a" , 0) > -1)
        return false;
    else
        return true;
}
//window.open function overridding starts
window.open_=window.open;

window.open=function(m_url,m_name,m_properties)
{   
    var actionURL=getActionUrlFromURL(m_url);
    var listParam=getInputParamListFromURL(m_url);
    var win = openNewWindow(actionURL, m_name, m_properties, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    //addWindows(win);
    return win;
}
var WD_SID;
function openNewWindow(sURL, sName, sFeatures, bReplace, Ext1, Ext2, Ext3, Ext4, listParameters) {
    if (sURL.indexOf("?") > 0) {
        if (sURL.indexOf("WD_SID") == -1 && WD_SID) {
            sURL = sURL + "&WD_SID=" + WD_SID;
        }
    } else {
        if (WD_SID) {
            sURL = sURL + "?WD_SID=" + WD_SID;
        }
    }

    var turi = getActionUrlFromURL(sURL);
    var wd_rid = getRequestToken(turi);

    var popup = window.open_('', sName, sFeatures, bReplace);
    popup.document.open();
    popup.document.write("<HTML><HEAD><TITLE></TITLE></HEAD><BODY onload=\"document.getElementById('postSubmit').submit();\">");
    popup.document.write("<form id='postSubmit' method='post' action='" + sURL + "' enctype='application/x-www-form-urlencoded'>");
    popup.document.write("<input type='hidden' name='WD_RID' value='" + wd_rid + "'/>");
    for (var iCount = 0; iCount < listParameters.length; iCount++) {
        var param = listParameters[iCount];
        popup.document.write(encode_ParamValue("<input type='hidden' id='" + param[0] + "' name='" + param[0] + "'/>"));
        popup.document.getElementById(param[0]).value = param[1]; //handle single quotes etc
    }
    popup.document.write("</FORM></BODY></HTML>");

    //var turi = getActionUrlFromURL(sURL);
    //popup.document.write("<script type='text/javascript' src='/webdesktop/secuidsv?cid="+Math.random()+"&Opt=1&T-URI="+turi+"'></script>");

    popup.document.close();
    try {
        addWindows(popup);
    } catch (e) {}

    return popup;
}

function MakeUniqueNumber()
{
	var tm = new Date();
	var milisecs = Date.parse(tm.toGMTString());
	return milisecs;
}

function addWindows(newWin)
{
	var flag=false;
	var len = allWindows.length;
	for(x=0; x<len;x++)
	{
			if ((allWindows[x] == null) || (allWindows[x].closed == true))
			{
				allWindows[x] = newWin;
				flag = true;
				break;
			}
	}
	if (flag == false)
		allWindows[len] = newWin;
}
/**
 *this function is used to close all child windows of the current window
 */
function closeWindows()
{
	var len = allWindows.length;
	for(x=0; x<len;x++)
	{
		if ((allWindows[x] != null) && (allWindows[x].closed == false))
			allWindows[x].close();
	}
}

function getActionUrlFromURL(sURL)
{
    var ibeginingIndex=sURL.indexOf("?");
    if (ibeginingIndex == -1)
        return sURL;
    else
        return sURL.substring(0,ibeginingIndex);
 }

 function getInputParamListFromURL(sURL)
{
    var ibeginingIndex=sURL.indexOf("?");
    var listParam=new Array();
    if (ibeginingIndex == -1)
        return listParam;
    var tempList=sURL.substring(ibeginingIndex+1,sURL.length);

    if(tempList.length>0)
     {
        var arrValue =tempList.split("&");
        for(var iCount=0;iCount<arrValue.length;iCount++)
        {
            var arrTempParam=arrValue[iCount].split("=");
            try
            {
                listParam.push(new Array(decode_ParamValue(arrTempParam[0]),decode_ParamValue(arrTempParam[1])));
            }catch(ex)
            {

            }
        }
    }
    return listParam;
}

function decode_ParamValue(param)
{
    var tempParam =param.replace(/\+/g,' ');
    tempParam = decodeURIComponent(tempParam);

    return tempParam;
}


function isIE(){
   return ((navigator.appName=='Netscape')?false:true);
}

function isEdge(){
    return ((window.navigator.userAgent.indexOf("Edge") > -1)?true:false);
}

function executeScanAction(loc, pid, wid, docType,taskid)
{
    try{
        var xbReq;
        if (window.XMLHttpRequest){
            xbReq = new XMLHttpRequest();
        } else if (window.ActiveXObject){
            xbReq = new ActiveXObject("Microsoft.XMLHTTP");
        }
        var url = '/webdesktop/components/workitem/view/ajaxscanAction.app';
        url = appendUrlSession(url);
        var wd_rid=getRequestToken(url);
        url+="&WD_RID="+wd_rid;
        var requestString = 'wid='+wid+'&pid='+encode_utf8(pid)+'&taskid='+taskid+'&DocType='+encode_utf8(docType);
        xbReq.open("POST", url, false);
        xbReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xbReq.send(requestString);
        var response = xbReq.responseText;
        var scanAction = parseJSON("("+response+")");
        if(typeof loc !='undefined')
        {
            for(var k =0;k<scanAction.length;k++)
            {
                if(scanAction[k].ScanAct == 'Success')
                {
                    var valSetter = scanAction[k];
                    loc.setFormValue(valSetter.name,valSetter.value,valSetter.type);
                // var dataField = loc.document.getElementById('wdesk:'+valSetter.name);
                //if(dataField)
                //  dataField.value=valSetter.value;
                }
                else if(scanAction[k].ScanAct == 'Failure')
                {
                    customAlert(INCOMPATIBLE_VALUE_ASSIGNMENT_SCAN_ACTION);
                    return;
                }
            }
        }
        /*if((typeof docIndex != 'undefined' && typeof docName != 'undefined') && typeof documentPostHook != 'undefined'){
            documentPostHook(docIndex,docName);
        }*/
    }catch(ex){}
}
//
//function HelpClick(helpname)
//{
//  /*if(helpname=="")
//            return;
//    HelpUrl = sContextPath+"/webtop/en_us/webhelp/"+helpname;
//
//    var left = (window.screen.width - 500)/2;
//    var top = (window.screen.height - 400)/2;
//    
//    win = window.open(HelpUrl,"","scrollbars=yes,resizable=yes,toolbar=no,menubar=no,status=yes,location=no,scrollbars=yes,top="+top+",left="+left+",height=400,width=500");
//    */
//}

function clickWiLink(source,linkId,param)
{
    strRemovefrommap='N';
    if(!linkId)
    linkId="wdesk:controller";
    if(typeof param == 'undefined')
        param = "";
    var optionValue=document.getElementById("Option");
    if(optionValue)
         document.getElementById("Option").value=source;

    var ngParamObj = document.getElementById("ngParam");
    if(ngParamObj)
         document.getElementById("ngParam").value=param;

    var fireOnThis = document.getElementById(linkId);
    if (fireOnThis != null) {
        if ((fireOnThis.nodeName.toUpperCase() == "A")) {
            if (fireOnThis.href.lastIndexOf("#") > -1) {
                fireOnThis.href = "javascript:void(0)";
            }
        }

        if (document.createEvent)
        {
            var evObj = document.createEvent('MouseEvents')
            evObj.initEvent('click', true, false);
            fireOnThis.dispatchEvent(evObj)
        }
        else if (document.createEventObject)
        {
            fireOnThis.fireEvent('onclick');
        }
    }
}

function ShowUserProp(ref,username,userid)
{
    var url="/webdesktop/components/userlist/showuserprop.app";

    var WindowHeight=windowH+70;
    var WindowWidth=windowW+30;

    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("username",encode_ParamValue(username)));
    listParam.push(new Array("userid",encode_ParamValue(userid)));

    var win = openNewWindow(url,'user_'+userid+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}

function SelectAllCheckBoxUserView(ref)
{
    var formid=ref.form.id;
    var tableid=formid+':'+'userLists';
    try
    {
        var noofrows = document.getElementById(tableid).tBodies[0].rows.length;
        var flag=0;
        for (var i=0;i< noofrows ;i++)
        {

            var id=tableid+':'+i+':chkUser';
            document.getElementById(id).checked=ref.checked;
        }

        return '';
    }
    catch(e)
    {
        //alert(e);
        return "";
    }
}

function handleEnterMain(e,id)
{
    var browser=navigator.appName;
    if(browser=="Netscape")
    {

        if(e.which == 13)
        {

            try
            {
                document.getElementById(id).focus();
            }
            catch(e){
            }

        }
    }

    else
    {
        e=window.event;
        if(e.keyCode == 13)
        {
            try
            {
                document.getElementById(id).focus();
            }
            catch(e){
            }
        }

    }
}

function openUserSearch(ref){
    if(document.getElementById('UserSearchDiv').style.display == 'none'){
        positionmenu(ref.id,'UserSearchDiv');
        document.getElementById('UserSearchDiv').style.display = 'inline';
    }
    else{
        document.getElementById('UserSearchDiv').style.display = 'none';
        positionmenu(ref.id,'UserSearchDiv');
    }
}

function openProcessSearch(ref){
    if(document.getElementById('ProcessSearchDiv').style.display == 'none'){
        positionmenu(ref.id,'ProcessSearchDiv');
        document.getElementById('ProcessSearchDiv').style.display = 'inline';
    }
    else{
        document.getElementById('ProcessSearchDiv').style.display = 'none';
        positionmenu(ref.id,'ProcessSearchDiv');
    }
}

function valUploadDocRestriction(FileExt,UplCheck,jsonFileObj)
{
    var bFileExtCheck = true;
    FileExt = Trim(FileExt);
    FileExt = FileExt.toUpperCase();
    if(FileExt.length>0 && UplCheck.toUpperCase() == 'Y' && jsonFileObj && jsonFileObj.Files.length>0)
    {
        bFileExtCheck = false;
        var fExt = "";
        for(var count=0;count<jsonFileObj.Files.length;count++){
            fExt = jsonFileObj.Files[count];
            if(fExt == FileExt)
            {
                bFileExtCheck = true;
                break;
            }
        }
    }
    return bFileExtCheck;
}

function generatePostRequest(winRef,sURL,listParameters)
{
    var formElement=winRef.document.getElementById("postSubmit");
    if(formElement!= undefined)
        winRef.document.body.removeChild(formElement);
    formElement = winRef.document.createElement("form");
    formElement =winRef.document.body.appendChild(formElement);
    formElement.action=sURL;
    formElement.encoding='application/x-www-form-urlencoded';
    formElement.method="post";
    formElement.id='postSubmit';
    for(var iCount=0;iCount<listParameters.length;iCount++)
    {
        var param=listParameters[iCount];
        var srcInput = winRef.document.createElement("input");
        srcInput.setAttribute("type", "hidden");
        srcInput.setAttribute("name", param[0]);
        srcInput.setAttribute("id", param[0]);
        srcInput.setAttribute("value", param[1]);
        formElement.appendChild(srcInput);
    }
    winRef.document.forms['postSubmit'].submit();
}

function textareaLimiter(field, maxlimit) {
       if (field.value.length >= maxlimit){
        customAlert(ALERT_EXCEEDING_COMMENT_LENGTH + " " + maxlimit + " " + CHARS);
        field.value = field.value.substring(0, maxlimit);
    }
}

function setTurnAroundList(data){
                   if(data.status=="success"){
                       window.opener.clickLink('modifyprocessstate:cmdRefresh');

                        self.close();
                   }
               }

function HandleProgressBar(data){
    if(data.status == "begin"){
        CreateIndicator("application");
    }
    else if(data.status == "complete"){
        RemoveIndicator("application");
    }
    else if(data.status == "success"){
        handleFieldFocus(data);
    }
}

function CreateIndicator(indicatorFrameId){
    var ParentDocWidth = document.body.clientWidth;
    var ParentDocHeight = document.body.clientHeight;
    var ImgTop=ParentDocHeight/2-70;
    var ImgLeft=ParentDocWidth/2-25;
    try {
        if(document.getElementById(indicatorFrameId) != null){
            return;
        }
        img = document.createElement("IMG");
        img.setAttribute("src", "/webdesktop/resources/images/progressimg.gif");
        img.setAttribute("name", indicatorFrameId);
        img.setAttribute("id", indicatorFrameId);
        img.style.left = ImgLeft+"px";
        img.style.top = ImgTop+"px";
        img.style.width = "54px";
        img.style.height = "55px";
        img.style.position="absolute";
        img.style.zIndex = "201";
        img.style.visibility="visible";
        //initPopUp();setPopupMask();
        document.body.appendChild(img);
    }
    catch(ex) {}
    document.body.style.cursor='wait';
}

function RemoveIndicator(indicatorFrameId){
    try {
        
        var img = document.getElementById(indicatorFrameId);
        if(img!=null){
            document.body.removeChild(img);
        }
       // hidePopupMask();
    }
    catch(ex) {hidePopupMask();}
    document.body.style.cursor='auto';
}


function RefreshWLHeader(data){
    var ctrlTableId="wlf:pnlResult";
    HandleProgressBar(data);
    if(data.status == "success"){
        renderButtons(ctrlTableId,"wlf");
        createFixedTableHeader(ctrlTableId,'wlf');
        
        handleMoreOption();
    }
}

function FindPos(Str,SearchStr)
{
	len = Str.length;
	for(i=0;i < len;++i)
	{
		if(Str.charAt(i) == SearchStr)
			return i;
	}
	return -1;
}
function setDiversionClick(userid,username){
    url='/webdesktop/components/usermgmt/setdiversion.app?OpenedFor=WD';
    url = appendUrlSession(url);

    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("userids",encode_ParamValue(userid)));
    listParam.push(new Array("usernames",encode_ParamValue(username)));

    var WindowHeight= 420;
    var WindowWidth=  600;

    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=0,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,'setdvr'+UniqueUserId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
   
}

function fetchWIPageWise(index){
    document.getElementById('wlf:selectedIndex').value=index;
    clickLink('wlf:fetchWIPagewise');
}

function openArchiveSearch(){

    ContentLoaderWrapper("/webdesktop/components/search/exportsearch.app?",callBackArchiveSearch,null,"GET",'',true);
}

function callBackArchiveSearch(){
    var webServerInfo = "";
    var targetCabinet = "";
//    var AppServerDetails = "";
//    var strProtocol = "";
    
    if(this.req.getResponseHeader("CallStatus")=="success"){
       webServerInfo = this.req.getResponseHeader("WebServerInfo");
       targetCabinet = this.req.getResponseHeader("TargetCabinet");
//       AppServerDetails ="&AppServerIP="+this.req.getResponseHeader("AppServerIP")+"&AppServerPort="+this.req.getResponseHeader("AppServerPort")+"&AppServerType="+this.req.getResponseHeader("AppServerType");
//       strProtocol = this.req.getResponseHeader("Protocol");
} else {
        //alert("No target Cabinet Found");
        fieldValidator(null, "No target Cabinet Found", "absolute", true);
        return;
    }
    
    var browser;
    if(navigator.appName!="Netscape")
     browser="explorer";
    else
        browser="netscape"
    var url = 'http://'+webServerInfo+'/webdesktop/components/search/searchworklist.app';
//    url = url+"&ArchiveSearch=Y";
//    url += "&TargetCabinet="+targetCabinet+AppServerDetails;
    url = appendUrlSession(url);

    WindowLeft=parseInt(ScreenWidth/2)-parseInt(600/2);
    WindowTop=parseInt(ScreenHeight/2)-parseInt(410/2);
    var listParam=new Array();
    listParam.push(new Array('Action',"1"));
    listParam.push(new Array('OpenFrom',"ArchiveSearch"));
    listParam.push(new Array('browser',browser));    
    listParam.push(new Array('processRightsFlag',"Y"));
    listParam.push(new Array('isSearch',"Y"));
    listParam.push(new Array('ArchiveSearch',"Y"));
    listParam.push(new Array('TargetCabinet',targetCabinet));
    listParam.push(new Array('AppServerIP',this.req.getResponseHeader("AppServerIP")));
    listParam.push(new Array('AppServerPort',this.req.getResponseHeader("AppServerPort")));
    listParam.push(new Array('AppServerType',this.req.getResponseHeader("AppServerType")));
    listParam.push(new Array('SiteId',this.req.getResponseHeader("SiteId")));
    listParam.push(new Array('VolumeId',this.req.getResponseHeader("VolumeId")));
    listParam.push(new Array('UserName',this.req.getResponseHeader("UserName")));
    listParam.push(new Array('Password',this.req.getResponseHeader("Password")));
    listParam.push(new Array('UserIndex',this.req.getResponseHeader("UserIndex")));
    listParam.push(new Array('SessionId',this.req.getResponseHeader("SessionId")));
    listParam.push(new Array('UDBEncrypt',this.req.getResponseHeader("UDBEncrypt")));
    listParam.push(new Array('WebServerInfo',this.req.getResponseHeader("WebServerInfo")));

    
    openNewWindow(url, 'searchWin', 'width=650,height=450,toolbar=no,status=yes,resizable=no,menubar=no,scrollbars=yes,left='+WindowLeft+',top='+WindowTop, false, "", "", "", "",listParam)
   //link_popup(url,'searchWin','width=650,height=450,toolbar=no,status=yes,resizable=no,menubar=no,scrollbars=yes,left='+left+',top='+top,windowList,false);
}

function openWorkItemExt(sessionId,userIndex,cabName,userName,wid,pid,taskid){
    var url = "/webdesktop/components/workitem/openworkitem.app";
    var listParam=new Array();    
    listParam.push(new Array('SessionId',sessionId));
    listParam.push(new Array('UserIndex',userIndex));
    listParam.push(new Array('UserName',userName));
    listParam.push(new Array('CabinetName',cabName));
    listParam.push(new Array('wid',wid));
    listParam.push(new Array('pid',pid));
    listParam.push(new Array('taskid',taskid));
    
    var WinHeight = window.screen.availHeight-60;
    var wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+window.screen.availWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
    openNewWindow(url,'WIWindow',wFeatures,true,"", "", "", "",listParam);
}

function EncryptPassword(stringToBeEncrypted,eToken)
{
       
        var bf = new Blowfish('DES');
        var encryptedString = bf.encryptx(stringToBeEncrypted,eToken);
        return encryptedString;
   
 }
  function openWin(pid,wid,activityType,calledFrom){
     var requestString='';
     var uniqueId=MakeUniqueNumber();
     
     var scrHeight;
     var WinHeight = window.screen.availHeight-60;
     var strCalledFrom="";
     //Bug Id: 28825
     var wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+window.screen.availWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
     var winWidth = window.screen.availWidth-10;
     var wdWidth=0;
     if(wdWidth!='0' && wdWidth<=window.screen.availWidth){
        scrHeight=window.screen.availHeight-15;
        winWidth = wdWidth;
        wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+winWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
     }
     else
     {
        scrHeight = window.screen.availHeight;
        wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+winWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
     }
     //--------------------------------------------------------------------------
     
     if(typeof calledFrom!=undefined && calledFrom!=null){
         strCalledFrom=calledFrom;
     }
    
     requestString=sContextPath+'/components/workitem/view/workdesk.app';
     //var wFeatures = 'scrollbars=no,resizable=Yes,status=yes,left=0,top=0,width='+window.screen.availWidth+', height='+WinHeight;
     var listParam=new Array();

     //Bug Id: 28825
     listParam.push(new Array('Comp_height',encode_ParamValue(scrHeight)));
     listParam.push(new Array('Comp_width',encode_ParamValue(winWidth)));
     //--------------------------------------------------------------------------

     listParam.push(new Array('ProcessInstanceID',pid));
     listParam.push(new Array('WorkitemID',wid));
     listParam.push(new Array('ActivityType',activityType));
     listParam.push(new Array('Option','OPENWI'));
     listParam.push(new Array('wdView',encode_ParamValue('N')));
     listParam.push(new Array('InstrumentListCallFlag','S'));
     listParam.push(new Array('Action','1'));
     listParam.push(new Array('IsOpenWI','Y'));
     listParam.push(new Array('CalledFrom',strCalledFrom));
     openNewWindow(requestString, uniqueId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
     //link_popup(requestString,uniqueId,'scrollbars=no,resizable=no,status=yes,left=0,top=0,width='+window.screen.availWidth+', height='+WinHeight);     
 }

 function openWinCase(pid,wid,activityType,activityId,pDefId){
     var requestString='';
     var uniqueId=MakeUniqueNumber();

     var scrHeight;
     var WinHeight = window.screen.availHeight-60;

     //Bug Id: 28825
     var wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+window.screen.availWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
     var winWidth = window.screen.availWidth-10;
     var wdWidth=0;
     if(wdWidth!='0' && wdWidth<=window.screen.availWidth){
        scrHeight=window.screen.availHeight-15;
        winWidth = wdWidth;
        wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+winWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
     }
     else
     {
        scrHeight = window.screen.availHeight;
        wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+winWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
     }
     //--------------------------------------------------------------------------
     
     requestString=sContextPath+'/components/workitem/view/workdesk.app';
     //var wFeatures = 'scrollbars=no,resizable=Yes,status=yes,left=0,top=0,width='+window.screen.availWidth+', height='+WinHeight;
	 if(document.getElementById("mytasks:hidIsOpFromCaseBasket")!=null){
		document.getElementById("mytasks:hidIsOpFromCaseBasket").value = true;
	 }
     var qDefId = "1";
     var openFrom = "1";
     var listParam=new Array();

     //Bug Id: 28825
     listParam.push(new Array('Comp_height',encode_ParamValue(scrHeight)));
     listParam.push(new Array('Comp_width',encode_ParamValue(winWidth)));
     //--------------------------------------------------------------------------

     listParam.push(new Array('ProcessInstanceID',encode_utf8(pid)));
     listParam.push(new Array('WorkitemID',wid));
     listParam.push(new Array('ActivityType',activityType));
     listParam.push(new Array('Option','OPENWI'));
     listParam.push(new Array('wdView',encode_ParamValue('N')));
     listParam.push(new Array('InstrumentListCallFlag','S'));
     listParam.push(new Array('Action','1'));
     listParam.push(new Array('IsOpenWI','Y'));
     
     clearGarbageRef();//Bug 72462
     var wiWinInfo = null;
     var winObj = null;
     var wiWindowRef = null;
     bCustomWdesk = false;
     
     wiWinInfo = getNextWiWinInfo(pid, wid);
     if (wiWinInfo == null)
     {
        // If workitem is clicked and this workitem is previously not opened, then find the current window info.     
         wiWinInfo = findDefaultWdeskWinInfo();
     }
     if(wiWinInfo!=null){    
            wiWinInfo.PId = pid;
            wiWinInfo.WId = wid; 
            wiWinInfo.ActId = activityId;
            wiWinInfo.PDefId = pDefId;
            wiWinInfo.QueueId = qDefId;
            wiWinInfo.OpenFrom = openFrom;
            winObj = wiWinInfo.WinRef;

            var queryString = "";
            for(var iCount=0;iCount<listParam.length;iCount++) {
                var param = listParam[iCount];
                queryString += param[0] + "=" + param[1] + "&";
            }            
            queryString += "Action="+encode_ParamValue('1');            

            winObj.focus();
            winObj.initNLoadWorkitem(getWDJason(queryString));
            
            //wdWinUId = null;
            //oldWdJason = null;
            //bPrevNextOperation = false;
        } else {            
            listParam.push(new Array('Action',encode_ParamValue('1')));
            uniqueId = MakeUniqueNumber();
            wiWindowRef = openNewWindow(requestString, uniqueId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
            
            wiWinInfo = {
                "PId" : pid,
                "WId" : wid,
                "ActId" : activityId,
                "PDefId" : pDefId,
                "QueueId" : qDefId,
                "WinName" : uniqueId,
                "WinRef" : wiWindowRef,
                "CustomWorkdesk" : bCustomWdesk,
                "OpenFrom" : openFrom
            };

            wiWinInfoMap.put(uniqueId, wiWinInfo);
            wiWindowRef.focus();
            
        }
     //openNewWindow(requestString, uniqueId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
     //link_popup(requestString,uniqueId,'scrollbars=no,resizable=no,status=yes,left=0,top=0,width='+window.screen.availWidth+', height='+WinHeight);     
 }

 var scrollStep=5;
 var timerUp;
 var timerdown;
 var scrollTop;
 function scrollDivUp(divRef){
     scrollTop=document.getElementById(divRef).scrollTop;
     document.getElementById(divRef).scrollTop-=scrollStep;
     timerUp=setTimeout("scrollDivUp('"+divRef+"')",5);
     
 }

 function scrollDivDown(divRef){
     scrollTop=document.getElementById(divRef).scrollTop;
     document.getElementById(divRef).scrollTop+=scrollStep;
     timerdown=setTimeout("scrollDivDown('"+divRef+"')",5);
}

 function stopScrollTimer(){
    clearTimeout(timerUp);
    clearTimeout(timerdown);
 
 }

 // window unload overriding starts
window.onunload = unloadHandler;

function unloadHandler(){
//    alert("Unloading window ..."+ window.name);
    closeWindows();   
    
}

function FAjaxErrorHandler(data){
        if(data.responseCode == '250')
        {
          window.location= "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";
//        createPopUpIFrameWrapper('iFrameId','/omniapp/pages/error/errorpagepopup.app?msgID=-8002&HeadingID=8002',330,450);
//        var screenHeight = window.screen.height;
//        document.getElementById('iFrameId').style.top = screenHeight/6+"px";
        }
         else if(data.responseCode == '310')
    {
        window.location= "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";    
    }
    else if(data.responseCode=='350'){
//            createPopUpIFrameWrapper('iFrameId','/webdesktop/error/errorpagepopup.app?msgID=-8002&HeadingID=8002',330,450);
//            var screenHeight = window.screen.height;
//            document.getElementById('iFrameId').style.top = screenHeight/6+"px";
        window.parent.parent.initPopUp();
        window.parent.parent.setPopupMask();
        window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe','/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message='+INVALID_REQUEST_IS_MADE,140,435);
        var screenHeight = window.screen.height;
        //alert(window.parent.parent.document.getElementById('genericErrorIframe'));
        window.parent.parent.document.getElementById('genericErrorIframe').style.top = screenHeight/6+"px";
        window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 300;
    }
}

 // window unload overriding ends

function checkFile(size)
{
	size = size/1024;
        if(size > 1024)	{
		size = size/1024;
		if(size > uploadLimit)
			return false;
		else
			return true;
	}
	else
		return true;
}

function callBackOnError(){
    var status = this.req.status;
    var screenHeight = window.screen.height;
        if(status == 250){
            window.location= "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";
        }else if(status == 350){
            window.parent.parent.initPopUp();
            window.parent.parent.setPopupMask();
            window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe','/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message='+INVALID_REQUEST_IS_MADE,140,435);
            
            window.parent.parent.document.getElementById('genericErrorIframe').style.top = screenHeight/6+"px";
            window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 300;
        } else if(status == 599){
            window.parent.parent.initPopUp();
            window.parent.parent.setPopupMask();
            window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe','/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message='+INVALID_SESSION,140,435);
            
            window.parent.parent.document.getElementById('genericErrorIframe').style.top = screenHeight/6+"px";
            window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 300;
        }else if(status==310)
            {
                window.location= "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";    
            }
         else{
            window.parent.parent.initPopUp();
            window.parent.parent.setPopupMask();
            window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe','/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message='+ERROR_AT_SERVER_END,140,435);
            
            window.parent.parent.document.getElementById('genericErrorIframe').style.top = screenHeight/6+"px";
            window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 300;
           // alert(ERROR_DATA);
        }

    }

    function adjustHideShowLinks(gridCtrlName,width,tabArray,moreOptionBtn,moreOptionArray){
        var flag = true;
        for(var i=tabArray.length-1; i >= 0;i--){
            var returnFlag = repeat(gridCtrlName.offsetWidth,width,tabArray[i],moreOptionArray[i]);
            if(!returnFlag){
                flag = false;
            }
        }
        if(moreOptionBtn){
            if(flag){
                moreOptionBtn.style.display = "none";
            }else{
                moreOptionBtn.style.display = "inline";
            }
        }

    }

    function repeat(gridWidth,width,tab,moreOptionElement){
        var flag= true;
        if(tab){
            if(gridWidth > width){
                tab.style.display="none";
                moreOptionElement.style.display="inline";
                flag = false;
            }else{
                tab.style.display="inline";
                moreOptionElement.style.display="none";
            }
        }
        return flag;
    }
    
    function ajaxCheckIsAdmin(interval)
{    
    var checkIsAdmin =ContentLoaderWrapper('/webdesktop/ajaxCheckIsAdmin.app?rid='+Math.random(),ajaxCheckIsAdminHandler,null,"POST","");
    function ajaxCheckIsAdminHandler()
    {
        var isAdmin = this.req.responseText        
        var switchInterval = (interval-0)*1000;
        checkIsAdminTimer = setTimeout("ajaxCheckIsAdmin("+interval+")",switchInterval);
    }
}

var checkIsAdminTimer;

function StartCheckIsAdminTimer(interval)
{
    clearTimeout(checkIsAdminTimer);

    var switchInterval = (interval-0)*1000;
    checkIsAdminTimer = setTimeout("ajaxCheckIsAdmin("+interval+")",switchInterval);
}

function StopCheckIsAdminTimer()
{
    clearTimeout(checkIsAdminTimer);
}

function clickLinkSafari(linkId)
{
    if(!linkId)
    {
        return false;
    }

    var fireOnThis = document.getElementById(linkId);
    if (fireOnThis != null) {
        if ((fireOnThis.nodeName.toUpperCase() == "A")) {
            if (fireOnThis.href.lastIndexOf("#") > -1) {
                fireOnThis.href = "javascript:void(0)";
            }
        }

        if (document.createEvent)
        {
            //var evObj = document.createEvent('MouseEvents') ;
            //evObj.initEvent( 'click', true, false ) ;
            //fireOnThis.dispatchEvent(evObj) ;
            var evObj = document.createEvent('MouseEvents');
            evObj.initMouseEvent("click", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
            fireOnThis.dispatchEvent(evObj);
        }
        else if (document.createEventObject)
        {
            fireOnThis.click();

        }
    }
    return ;
}

function handleMoreOption(){
    try{
        var pnlPref = document.getElementById('wlf:pnlinnerPref2');    
        if(pnlPref == null || pnlPref.childElementCount==0)
            document.getElementById('wlf:wlact').style.display = "none";    
        /*if(pnlPref.rows.length < 2){        
            document.getElementById('wlf:moreOptionsBtn').style.display = "none";
            document.getElementById('wlf:wlact').style.display = "none";            
            document.getElementById('wlf:sepMoreBtn').style.display = "none";

        }*/
    }catch(e){

    }
}

function IEVersion(){
	var _n=navigator,_w=window,_d=document;
	var version="NA";
	var na=_n.userAgent;
	var ieDocMode="NA";
	var ie8BrowserMode="NA";
	// Look for msie and make sure its not opera in disguise
	if(/msie/i.test(na) && (!_w.opera)){
		// also check for spoofers by checking known IE objects
		if(_w.attachEvent && _w.ActiveXObject){		
			// Get version displayed in UA although if its IE 8 running in 7 or compat mode it will appear as 7
			version = (na.match( /.+ie\s([\d.]+)/i ) || [])[1];
			// Its IE 8 pretending to be IE 7 or in compat mode		
			if(parseInt(version)==7){				
				// documentMode is only supported in IE 8 so we know if its here its really IE 8
				if(_d.documentMode){
					version = 8; //reset? change if you need to
					// IE in Compat mode will mention Trident in the useragent
					if(/trident\/\d/i.test(na)){
						ie8BrowserMode = "Compat Mode";
					// if it doesn't then its running in IE 7 mode
					}else{
						ie8BrowserMode = "IE 7 Mode";
					}
				}
			}else if(parseInt(version)==8){
				// IE 8 will always have documentMode available
				if(_d.documentMode){ie8BrowserMode = "IE 8 Mode";}
			}
			// If we are in IE 8 (any mode) or previous versions of IE we check for the documentMode or compatMode for pre 8 versions			
			ieDocMode = (_d.documentMode) ? _d.documentMode : (_d.compatMode && _d.compatMode=="CSS1Compat") ? 7 : 5;//default to quirks mode IE5				   			
		}
	}
				 
	return {
		"UserAgent" : na,
		"Version" : version,
		"BrowserMode" : ie8BrowserMode,
		"DocMode": ieDocMode
	}			
}

function checkAndShowMailConstant(elem,bFocus){
    // added on 11/11/2016,bug_id:65439 
    var isChrome = window.chrome;
    var isIEBrowser = (navigator.appName=='Netscape') && (window.navigator.userAgent.indexOf('Trident/') < 0) && (!isChrome)? false: true;
     if(elem!=null && elem.selectedIndex!=-1){//till here bug_id:65439
        var valObj = elem.value;
        if(valObj=='<Constant>'){           
            document.getElementById(elem.id+'Const').style.width ='260px';
            document.getElementById(elem.id+'Const').style.display='inline';
            //BUG 41766 :: 11/09/2013 starts
            if(pageDirection == 'RTL'){
                document.getElementById('mailTrigger:cmb_FromStringFromVarsConst').style.marginRight='-291px';
                document.getElementById('mailTrigger:cmb_ToStringVarsConst').style.marginRight='-291px';
                document.getElementById('mailTrigger:cmb_FromStringCCVarsConst').style.marginRight='-291px';
                 document.getElementById('mailTrigger:cmb_FromStringBCCVarsConst').style.marginRight='-291px';
            }
            else{
                    //modifed on 3/11/2016,bug_id:bug_id:65159
                    /*document.getElementById('mailTrigger:cmb_FromStringFromVarsConst').style.marginLeft='-291px';
                    document.getElementById('mailTrigger:cmb_ToStringVarsConst').style.marginLeft='-291px';
                    document.getElementById('mailTrigger:cmb_FromStringCCVarsConst').style.marginLeft='-291px';
                     document.getElementById('mailTrigger:cmb_FromStringBCCVarsConst').style.marginLeft='-291px';*/
                  // modifed on 11/11/2016,bug_id:65439 
                    if(isChrome !== undefined){
                   
                    document.getElementById('mailTrigger:cmb_FromStringFromVarsConst').style.marginLeft='-310px';
                    document.getElementById('mailTrigger:cmb_ToStringVarsConst').style.marginLeft='-310px';
                    document.getElementById('mailTrigger:cmb_FromStringCCVarsConst').style.marginLeft='-310px';
                    document.getElementById('mailTrigger:cmb_FromStringBCCVarsConst').style.marginLeft='-310px';  
                    document.getElementById('mailTrigger:cmb_FromStringFromVarsConst').style.width='280px';
                    document.getElementById('mailTrigger:cmb_ToStringVarsConst').style.width='280px';
                    document.getElementById('mailTrigger:cmb_FromStringCCVarsConst').style.width='280px';
                    document.getElementById('mailTrigger:cmb_FromStringBCCVarsConst').style.width='280px';
                    }else if(isIEBrowser){
                    document.getElementById('mailTrigger:cmb_FromStringFromVarsConst').style.marginLeft='-302px';
                    document.getElementById('mailTrigger:cmb_ToStringVarsConst').style.marginLeft='-302px';
                    document.getElementById('mailTrigger:cmb_FromStringCCVarsConst').style.marginLeft='-302px';
                    document.getElementById('mailTrigger:cmb_FromStringBCCVarsConst').style.marginLeft='-302px';  
                    document.getElementById('mailTrigger:cmb_FromStringFromVarsConst').style.width='279px';
                    document.getElementById('mailTrigger:cmb_ToStringVarsConst').style.width='279px';
                    document.getElementById('mailTrigger:cmb_FromStringCCVarsConst').style.width='279px';
                    document.getElementById('mailTrigger:cmb_FromStringBCCVarsConst').style.width='279px';   
                    }
                    else{
                     document.getElementById('mailTrigger:cmb_FromStringFromVarsConst').style.marginLeft='-300px';
                    document.getElementById('mailTrigger:cmb_ToStringVarsConst').style.marginLeft='-300px';
                    document.getElementById('mailTrigger:cmb_FromStringCCVarsConst').style.marginLeft='-300px';
                    document.getElementById('mailTrigger:cmb_FromStringBCCVarsConst').style.marginLeft='-300px';//till here bug_id:bug_id:65159
                    document.getElementById('mailTrigger:cmb_FromStringFromVarsConst').style.width='278px';
                    document.getElementById('mailTrigger:cmb_ToStringVarsConst').style.width='278px';
                    document.getElementById('mailTrigger:cmb_FromStringCCVarsConst').style.width='278px';
                    document.getElementById('mailTrigger:cmb_FromStringBCCVarsConst').style.width='278px';
                    }//till here bug_id:65439 
            }
            //BUG 41766 :: 11/09/2013 ends
            if(bFocus){
                //document.getElementById(elem.id+'Const').value = '';
                //document.getElementById(elem.id+'Const').focus();
               
            }
            //document.getElementById(elem.id+'Hidden').value='true';
        }
        else{
            //document.getElementById(elem.id+'Const').blur();
            //document.getElementById(elem.id+'Const').style.display='none';
            //document.getElementById(elem.id+'Hidden').value='false';
        }
    }
}

function TitleCharacterValidation(e,option,textBoxElem,charCount){//charCount added as parameter for BUG 32159 :: 23/05/2012
    var language = (typeof HTML_DIR == "undefined")? 'ltr': HTML_DIR;
    var locale_path = (typeof PATH == "undefined")? 'en_us/': PATH;
    //1:DecimalAndSpace Restriction
    try{
        var evtObj = window.event || e;
        var restrictedChars=0;
        if(option!=undefined)
            restrictedChars=parseInt(option);
        var KeyID = evtObj.keyCode || evtObj.which;
//        evtObj.returnValue = false;
        var returnValue = false;
         if(locale_path=='en_us/' || locale_path=='en/' ){
        switch(restrictedChars){
            case 1://alphabets, numerals and underscore
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123))&&(textBoxElem.value.length<charCount)){//BUG 32159:: 23/05/2012
                    returnValue = true;
                    if(textBoxElem!=undefined){
                        if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58)|| KeyID==47))//lenght = 1
                            returnValue = false;
                    }
                }
                break;
            //added,05/06/2012,BugId:OF_32147
            case 2://alphabets, numerals and underscore, can stsrt with int value also
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123))&&(textBoxElem.value.length<charCount)){//BUG 32159:: 23/05/2012
                    returnValue = true;
                }
                break;//tillHere,BugId:OF_32147
            case 3://int
                if(((KeyID == 45 || (KeyID >=48 && KeyID <58))&&(textBoxElem.value.length<charCount))||(KeyID==8)||(KeyID==16)||(KeyID==46)//Bug 32271 -12Dec2012
                    ||(KeyID==37)||(KeyID==39)||(KeyID==36)||(evtObj.ctrlKey==true && (KeyID == 118 || KeyID == 86||KeyID == 120||KeyID == 88))){//BUG 32159:: 23/05/2012
                    returnValue = true;
                    if(textBoxElem!=undefined){
                        if(textBoxElem.value.length!=0 && KeyID==45)//minus allowed at beginning only
                            returnValue = false;
                    }
                }
                break;
            case 4://long
                if((KeyID == 45 || (KeyID >=48 && KeyID <58))&&(textBoxElem.value.length<charCount)){//BUG 32159:: 23/05/2012
                    returnValue = true;
                    if(textBoxElem!=undefined){
                        if(textBoxElem.value.length!=0 && KeyID==45)//minus allowed at beginning only
                            returnValue = false;
                    }
                }
                break;
            case 6://float
                if((KeyID == 45 || KeyID == 46 || (KeyID >=48 && KeyID <58))&&(textBoxElem.value.length<charCount)){//BUG 32159:: 23/05/2012
                    returnValue = true;
                    if(textBoxElem!=undefined){
                        if(textBoxElem.value.length!=0 && KeyID==45)//minus allowed at beginning only
                            returnValue = false;
                    }
                }
                break;
            case 8://date//Bug 32271 -12Dec2012
            {
                var left=textBoxElem.clientWidth + textBoxElem.scrollLeft;
                openCalenderThis(textBoxElem,'1',textBoxElem.id,'textBox',left+',-43');
                returnValue = false;
            }
            break;
            case 10://string
                returnValue = true;
                break;
            case 12://boolean
                returnValue = true;
                break;
            case 13://numerals,'.' for IP Address
                if(KeyID == 46 || (KeyID >=48 && KeyID <58)){
                    returnValue = true;
                }
                break;
            case 101://alphabets,numerals,underscore,'@','.' ,'-'for emailId
                if(KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || KeyID ==45||KeyID ==46|| KeyID==64){
                    returnValue = true;
                    if(textBoxElem!=undefined){
                        if(textBoxElem.value.length==0 && (KeyID ==46 || KeyID==64))
                            returnValue = false;
                        if(textBoxElem.value.length>0 && textBoxElem.value.indexOf('@')!=-1 && KeyID==64)
                            returnValue = false;
                    }
                }
                break;
            //added on 16/02/2012 for BUG ID 29815
            case 102://alphabets,numerals,underscore,and space
                if(KeyID == 95 || KeyID == 8 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123)|| KeyID==32 )//32 for space
                    returnValue = true;
                break;
            //till here
            //added on 16/02/2012 for BUG ID 30507
            case 103://all except " and '
                if(KeyID != 39 && KeyID !=34)
                    returnValue = true;
                break;
            //till here
            //added on 01/03/2012 for BUG ID 30499
            case 104://alphabets,numerals,underscore(_),and hiphen wwith first character as alphabet
                // characters restricted are \/:*?"<>|,.;'{}[]=+!@#$%^&~`

                if(( KeyID >= 33 && KeyID <=47 && KeyID != 45) || ( KeyID >= 58 && KeyID <=64) || ( KeyID >= 91 && KeyID <=96 && KeyID != 95) || ( KeyID >= 123 && KeyID <=126 ))
                {
                    returnValue = false;
                }else{
                    if(textBoxElem!=undefined)
                    {
                        if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58)|| KeyID==95 || KeyID==45))//lenght = 1
                            returnValue = false;
                        else
                            returnValue = true;
                    }else{
                        returnValue = true;
                    }
                }
                break;
            //till here
            //added,BugID:OF_31120,30/04/2012
            case 105://For Time... numerals,colon(:58)
                if(KeyID >=48 && KeyID <=58 &&(textBoxElem.value.length<charCount)) //BUG 32159:: 23/05/2012
                    returnValue = true;
                break;
            //tillHere,BugID:OF_31120
            default://alphabets,numerals,space and decimal
                if(KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123)|| KeyID==32 || KeyID==46)//32 for space and 46 for decimal(full stop)
                    returnValue = true;
                break;
            //BUG 32159 :: 23/05/2012 starts
            case 110://alphabets, numerals,hiphen and underscore with fist character as alphabet only and length restricted to N
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || KeyID==45)&&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58)|| KeyID==47 || KeyID==95 || KeyID==45))
                    returnValue = false;
                break;
            case 111://for description area of length restricted
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || KeyID ==46|| KeyID==64 || KeyID==32 || KeyID==45) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                else
                    returnValue = false;
                break;
            case 112://alphabets,numerals,hiphen,underscore,and space with fist character as alphabet only and length restricted to N
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123)|| KeyID==32 || KeyID==45) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58)|| KeyID==32 || KeyID==95 || KeyID==45))
                    returnValue = false;
                break;
            case 113://alphabets,numerals,underscore,and with fist character as alphabet only and length restricted to N
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123)) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58) || KeyID==95))
                    returnValue = false;
                break;
            case 114://for description area with <,>,& allowed and length restricted
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || KeyID ==46|| KeyID==64 || KeyID==32 || KeyID==45|| KeyID==38|| KeyID==60|| KeyID==62) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                else
                    returnValue = false;
                break;
            case 115://alphabets,numerals,underscore,hiphen,decimal and with fist character as alphabet only and length restricted to N
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || KeyID==45|| KeyID==46) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58) || KeyID==95|| KeyID==45|| KeyID==46))
                    returnValue = false;
                break;
            case 116://alphabets,numerals,underscore,hiphen,decimal,colon,/,\ and with fist character as alphabet only and length restricted to N
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || KeyID==45|| KeyID==46|| KeyID==47|| KeyID==58|| KeyID==92) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58) || KeyID==95|| KeyID==45|| KeyID==46|| KeyID==47|| KeyID==58|| KeyID==92))
                    returnValue = false;
                break;
            case 117://alphabets,numerals,underscore,hiphen,decimal,colon,/,\,?,@ and with fist character as alphabet only and length restricted to N
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || KeyID==45|| KeyID==46|| KeyID==47|| KeyID==58|| KeyID==92|| KeyID==64 || KeyID==63) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58) || KeyID==95|| KeyID==45|| KeyID==46|| KeyID==47|| KeyID==58|| KeyID==92|| KeyID==64|| KeyID==63))
                    returnValue = false;
                break;
            case 118://alphabets, numerals,hiphen and space with fist character as alphabet only and length restricted to N
                if((KeyID == 32 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || KeyID==45)&&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58)|| KeyID==47 || KeyID==32 || KeyID==45))
                    returnValue = false;
                break;
            case 119://alphabets, numerals,underscore,comma with fist character as alphabet only and length restricted to N
                if((KeyID == 44 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || KeyID==95)&&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58)|| KeyID==95 || KeyID==44))
                    returnValue = false;
                break;
            //BUG 32159 :: 23/05/2012 ends
            //BUG OF_32305::31/05/2012 starts
            case 120://for description area of length restricted and chars ' and " and & restricted only'
                if(KeyID == 39 || KeyID ==34 ||KeyID == 38 ||(textBoxElem.value.length>=charCount))//BUG OF_32262 :: 01/06/2012
                    returnValue = false;
                else
                    returnValue = true;
                break;
            //BUG OF_32305::31/05/2012 ends
            //BUG OF_32480::12/06/2012 starts
            case 122://for description area of length restricted and chars ',",enter,&,< and > restricted only'
                if(KeyID == 39 || KeyID ==34 ||KeyID == 38 || KeyID == 13 || KeyID == 60 || KeyID == 62 ||(textBoxElem.value.length>=charCount))//BUG OF_32262 :: 01/06/2012
				{
					customAlert("Comment length cannot exceed 255 characters.");
                    returnValue = false;
				}
                else
                    returnValue = true;
                break;
            //BUG OF_32480::12/06/2012 ends
            //BUG 32159 :: 18/06/2012 starts
            case 123:// ip
                if(((KeyID >=48 && KeyID <58) ||KeyID==46 ) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && (KeyID==46))
                    returnValue = false;
                break;
            case 124://alphabets, numerals,hiphen,& and underscore with fist character as alphabet only and length restricted to N
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || KeyID==38|| KeyID==45)&&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58)|| KeyID==47 || KeyID==95 || KeyID==38|| KeyID==45))
                    returnValue = false;
                break;
            case 125://For options..same as 131
                if(KeyID >=48 && KeyID <58 &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                break;
            case 128://all
                if(textBoxElem.value.length<charCount)
                    returnValue = true;
                else
                    returnValue = false;
                break;
            case 130://numerals and decimal and length restricted to N
                if(((KeyID >=48 && KeyID <58) || KeyID==46) && (textBoxElem.value.length<charCount))
                    returnValue = true;
                else
                    returnValue = false;
                break;
            case 131://numerals and length restricted to N
                if((KeyID >=48 && KeyID <58) && (textBoxElem.value.length<charCount))
                    returnValue = true;
                else
                    returnValue = false;
                break;
            //BUG 32159 :: 18/06/2012 ends
            //BUG OF_33183 :: 12/07/2012 starts
            case 132://allowed characters are:: `,~,!,@,#,$,%,^,(,),_,+,-,=,{,},|,[,],;,',,,., numerals, alphabets, space, backspace
                if(((KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123)||KeyID==32||KeyID==95||KeyID==45||KeyID==46||KeyID==32||KeyID==44||KeyID==59||KeyID==64||KeyID==96||KeyID==126||KeyID==33||KeyID==35||KeyID==36||KeyID==37||KeyID==94||KeyID==40||KeyID==41||KeyID==43||KeyID==61||KeyID==91||KeyID==93||KeyID==123||KeyID==125||KeyID==39||KeyID==124 )&& (textBoxElem.value.length<charCount))
                    returnValue = true;
                else
                    returnValue = false;
                break;
            //BUG OF_33183 :: 12/07/2012 ends
            //BUG OF_33412 :: 23/07/2012 starts
            case 133://allowed characters are:: `~(){}[] _-=,.'  numerals, alphabets, space, backspace
                if(((KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123)||KeyID==32||KeyID==96||KeyID==126||KeyID==40||KeyID==41||KeyID==123||KeyID==125||KeyID==91||KeyID==93||KeyID==95||KeyID==45||KeyID==61||KeyID==44||KeyID==46||KeyID==39)&& (textBoxElem.value.length<charCount))
                    returnValue = true;
                else
                    returnValue = false;
                break;
            //BUG OF_33412 :: 23/07/2012 ends
            //BUG OF_33359 :: 25/07/2012 ends
            case 134://all allowed except Enter and charCount Not to be checked -- message
                if(KeyID!=13)
                    returnValue = true;
                else
                    returnValue = false;
                break;
            case 135://all allowed except Enter, quotes(', "), | character -- subject
                if(KeyID!=13  && KeyID!=34  && KeyID!=39  && KeyID!=124  && (textBoxElem.value.length<charCount))
                    returnValue = true;
                else
                    returnValue = false;
                break;
            //added,13/08/2012,BugId:33978
            case 136://all allowed except Enter, and SPACE -- SAP FunctionName
                if(KeyID!=13  && KeyID!=32 && (textBoxElem.value.length<charCount))
                    returnValue = true;
                else
                    returnValue = false;
                break;//tillHere,BugId:33978
            //added,06/11/2012,BugId:36270
            case 137://alphabets, numerals and underscore
                if((KeyID == 95 || KeyID==42 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123))&&(textBoxElem.value.length<charCount)){//BUG 32159:: 23/05/2012
                    returnValue = true;
                }else{
                    returnValue = false;
                }
                break;//tillHere,BugId:36270
            //start for bug id 35573
            case 138://for expressions, allowed characters are <, >, !, +,-,/,*,=,(,),comma,.,;alphabets, numerals
                //start for bug id 37372: (KeyID>96 && KeyID < 112) changed to (KeyID>96 && KeyID < 123)
                if(KeyID == 8 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123) || (KeyID>185 && KeyID < 191) || KeyID == 40 || KeyID == 41 || KeyID == 33 || KeyID == 60|| KeyID == 62|| KeyID == 46|| KeyID == 58){
                    returnValue = true;
                }else{
                    returnValue = false;
                }
                break;
            //end for bug id 35573
            //BUG OF_33359 :: 25/07/2012 ends
            //added,12/12/2012,BugId:36687
            case 139://alphabets,numerals (1-9),underscore,and with fist character as alphabet only and length restricted to N
                if((KeyID == 95 || (KeyID >48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123)) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58) || KeyID==95))
                    returnValue = false;
                break;//TillHere,BugId:36687
                if(!returnValue){
                    //e.stopPropogation(true);
                    if(e.stopPropogation)
                        e.stopPropogation(true);
                    if(e.preventDefault)
                        e.preventDefault(true);
                    e.cancelBubble = true;
                }
            // only window characters to be restricted and length not restricted - ripa jain - start
            case 140 :
                // characters restricted are \/:*?"<>|
                if(KeyID == 92 || KeyID == 47 || KeyID == 58 || KeyID == 42 || KeyID == 63 || KeyID == 34 || KeyID == 60 || KeyID == 62 || KeyID == 124)
                    returnValue = false;
                else
                    returnValue = true;
                break;
            // only window characters to be restricted - ripa jain - emd
            // only window characters to be restricted and length restricted to N
            case 141 :
                // characters restricted are \/:*?"<>|&' 
                if(KeyID == 92 || KeyID == 47 || KeyID == 58 || KeyID == 42 || KeyID == 63 || KeyID == 34 || KeyID == 60 || KeyID == 62 || KeyID == 124 || KeyID == 38 || KeyID == 39)
                    returnValue = false;
                else if(textBoxElem.value.length<charCount )
                    returnValue = true;
                else
                    returnValue = false;
                break;
                
            case 150://first char as albabet only and all chars are allowed except \ / : * ? " < > | ' &
                if ((KeyID == 47 || KeyID == 92 || KeyID == 58 || KeyID == 42 || KeyID == 63 || KeyID == 34 || KeyID == 60 || KeyID == 62 || KeyID == 124 || KeyID == 38 || KeyID == 39) || (textBoxElem.value.length >= charCount)){
                    returnValue = false;
                    break;
                } else
                    returnValue = true;
                if (textBoxElem.value.length == 0 && !((KeyID > 64 && KeyID < 91) || (KeyID > 96 && KeyID < 123)))
                    returnValue = false;
                break;

            case 157://first char as albabet only and all chars are allowed except \ / : * ? " < > | ' & 
                if((KeyID == 47 || KeyID == 92 ||KeyID == 58 ||KeyID == 42 ||KeyID == 63 ||KeyID == 34 || KeyID == 60 ||KeyID == 62 ||KeyID == 124 || KeyID == 38 || KeyID == 39 || KeyID == 46) || (textBoxElem.value.length>=charCount)){        
                    returnValue = false;       
                    break;             
                }else if(textBoxElem.value.length==0 && !((KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123))){
                    returnValue = false;  
                }else          
                    returnValue = true;    
                break;
                 
            case 158://first char as albabet only and all chars are allowed except \ / : * ? " < > | ' & 
                if((KeyID == 47 || KeyID == 92 ||KeyID == 58 ||KeyID == 42 ||KeyID == 63 ||KeyID == 34 || KeyID == 60 ||KeyID == 62 ||KeyID == 124 || KeyID == 38 || KeyID == 39 || KeyID == 46 || KeyID == 32) || (textBoxElem.value.length>=charCount)){        
                    returnValue = false;       
                    break;             
                }else if(textBoxElem.value.length==0 && !((KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123))){
                    returnValue = false;  
                }else          
                    returnValue = true;         
                break;
            case 159 ://To allow ? and ' in Exception comments//Bug 66678 and Bug 74397 respectively
                // characters restricted are \<>  -- Bug 75617 
                if(KeyID == 92 || KeyID == 60 || KeyID == 62)
                    returnValue = false;
                else if(textBoxElem.value.length<charCount )
                    returnValue = true;
                else
                    returnValue = false;
                break;
            case 160:
                //characters restricted are &=#<>"'`\ Bug 72899
                if(KeyID==38||KeyID==61||KeyID==35||KeyID==60||KeyID==62||KeyID==34||KeyID==39||KeyID==96||KeyID==92)
                    returnValue = false;
                else if(textBoxElem.value.length<charCount)
                    returnValue = true;
                else
                    returnValue = false;
                break;
            case 161://alphabets,numerals,underscore,space,and with first character as alphabet only and length restricted to N
                if((KeyID == 95 ||KeyID==32 ||(KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123)) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58) || KeyID==95||KeyID==32))
                    returnValue = false;
                break;
            case 162://alphabets,numerals,hiphen,underscore,and space with fist character as alphabet only and length restricted to N
                if((KeyID == 95 || (KeyID >=48 && KeyID <58) || (KeyID>64 && KeyID < 91) || (KeyID>96 && KeyID < 123)|| KeyID==32) &&(textBoxElem.value.length<charCount))
                    returnValue = true;
                if(textBoxElem.value.length==0 && ((KeyID >=48 && KeyID <58)|| KeyID==32 || KeyID==95 || KeyID==45))
                    returnValue = false;
                break;
        }
    }
    else if(textBoxElem.value.length<charCount ){
        if(restrictedChars == 112){
            if(KeyID==40 || KeyID==41 || KeyID==34 || KeyID==39 || KeyID==38 || KeyID==60 || KeyID==62){
                // ()"'
                returnValue = false;
            } else {
                returnValue = true;
            }
        }else if(restrictedChars == 150){
            if (KeyID == 47 || KeyID == 92 || KeyID == 58 || KeyID == 42 || KeyID == 63 || KeyID == 34 || KeyID == 60 || KeyID == 62 || KeyID == 124 || KeyID == 38 || KeyID == 39){
                // \ / : * ? " < > | '
                returnValue = false;
            } else {
                returnValue = true;
            }
        }else if(restrictedChars == 162){ //~`!@#%^&*()-+={}[]|\;':"<>?,./
            if((KeyID>=37 && KeyID<=47) || (KeyID>=58 && KeyID<=64)  || KeyID==34 || KeyID == 92 || KeyID == 124 || KeyID == 96 || KeyID == 126 || KeyID == 33 || KeyID == 35 || KeyID == 94 || KeyID == 91 || KeyID == 93 || KeyID == 123 || KeyID == 125){
                returnValue = false;
            } else {
                returnValue = true;
            }
        } else {
            returnValue = true;
        }
    }
    else{
        returnValue = false;
    }
    }
    catch(excp){
        evtObj.returnValue = false;
    }
    if(!returnValue)
        evtObj.returnValue = returnValue;
    
    return evtObj.returnValue;
}

function addTitleAttributes(ref){
    var numOptions = document.getElementById(ref.id).options.length;
    if(numOptions > 0)
    {
        ref.title = ref.options[ref.options.selectedIndex].text;
        for (var i = 0; i < numOptions; i++){
            document.getElementById(ref.id).options[i].title = document.getElementById(ref.id).options[i].text;
        }
    }
}

function getBrowserType()
{   
    var browserType = "";
    if (document.layers)
        browserType = "nn4"
    if (document.all){
        //Bug Id  35598 10/10/2012 start
        var ieVersion=getInternetExplorerVersion();
        if(ieVersion == 8)
            browserType= "IE8";
        else if(ieVersion ==9)
            browserType= "IE9";
        else if(ieVersion == 10)
            browserType= "IE10";
        else
            browserType = "ie";
    }
    //Bug Id  35598  end
    if (window.navigator.userAgent.toLowerCase().match("gecko"))
        browserType= "gecko";
    return browserType;
}

function getInternetExplorerVersion()
{
    var rv = -1; // Return value assumes failure.
    if (navigator.appName == 'Microsoft Internet Explorer')
    {
        var ua = navigator.userAgent;
        var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
        if (re.exec(ua) != null)
            rv = parseFloat( RegExp.$1 );
    }
    return rv;
}

function isCompatibleForRadioCheck(){
    //returns true if selection index begins with 1 ,false if selection index begins with 0
    if(navigator.appName.indexOf("Microsoft") != -1){
        //check version
        var ieVersion=getInternetExplorerVersion();
        if(ieVersion >= 10){
            return false;
        }
        else{
            return true;
        }
    }else{
        //browser compatible are Chrome, Mozilla
        return false;
    }
}
function ShowUserList(ref,nameCtrl,iDCtrl,hidNameCtrl,CallBackFunction,AllFlag,AnyFlag,NoneFlag,Extra1,compid,expertiseFilter,grpFilter,userfilter,multipleSelect,mode,SharedUsersJson,isCheck,openedFrom){
    var AllUserFlag = "N";
    var AnyUserFlag = "N";
    var NoneUserFlag = "N";
    var IsCheck=false;
    var ProcDefID = "";
    
    if(isCheck != undefined)
        IsCheck = isCheck;
    
    if(AnyFlag != undefined)
        AnyUserFlag = AnyFlag;
    
    if(AllFlag != undefined)
        AllUserFlag = AllFlag;
    
    if(NoneFlag != undefined)
        NoneUserFlag = NoneFlag;
    
    
    var posLeft = findAbsPosX(ref);
    var posTop;

    if(typeof resizeMode != 'undefined' && resizeMode == 'popout')
    {
        posTop = findPosY(ref);
    }
    else
    {
        posTop = findAbsPosY(ref);
    }
    try{
        
        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){
        
    }
    
    var iFrameHeight = 375;
    var iFrameWidth = 350;
    if(ref.form)
    var formid = ref.form.id;
    else
        formid="";
    var popupDivId = "UserPickList";
    var queueId ="";
    var isReasignPicklist="";
	var activityId ="";
    var processDefId =""
    if(Extra1 == "Link"){
        openFrom = Extra1;
    }
    if (iframeChildren.contains(popupDivId) == false)
        iframeChildren.push(popupDivId);
    
    if(Extra1 == "Reasign"){
        queueId = document.getElementById("reassignworkitem:hidQueueId").value;
		if(queueId == 0){
            activityId = document.getElementById("reassignworkitem:hidMQActivityId").value;
            processDefId = document.getElementById("reassignworkitem:hidMQProcessDefId").value;
		}
        isReasignPicklist = "Y";
    }
    
     
    if(Extra1 == "Refer"){
        if(typeof document.getElementById("referworkitem:hidProcessDefId") != 'undefined')
            ProcDefID = document.getElementById("referworkitem:hidProcessDefId").value;
    }
    
    var url="/webdesktop/components/search/transitionuserlist.app?Action=1&WD_SID="+WD_SID;
        url+="&strFormID=" + formid +"&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl 
        + "&PopupDivId=" + popupDivId +"&CallBack="+CallBackFunction+ "&AllFlag=" + AllUserFlag + "&AnyFlag=" +AnyUserFlag+"&NoneFlag="+NoneUserFlag+"&QueueID="+queueId+"&openedFrom="+openedFrom+"&ActivityID="+activityId+"&ProcessDefID="+processDefId+"&ProcoessDefID="+ProcDefID;
    if(compid!=undefined){
        url+="&Comp_ins_id="+compid;
    }
    if(expertiseFilter!=undefined){
        url+="&ExpertiseFilter="+expertiseFilter;
    }
    if(grpFilter!=undefined){
        url+="&GroupFilter="+grpFilter;
    }
    if(userfilter!=undefined){
        url+="&UserFilter="+userfilter;
    }
    if(multipleSelect!=undefined){
        url+="&MultipleSelect="+multipleSelect;
    }
    if(mode!=undefined){
        url+="&Mode="+mode;
    }
    if(SharedUsersJson!=undefined){
        url+="&SharedUsersJson="+encode_utf8(SharedUsersJson);
    }
    if(isReasignPicklist!=undefined){
        url+="&ShowLoggedInUser="+isReasignPicklist;
    }
    if(openFrom!=undefined){
        url+="&FromSearchWI="+openFrom;
    }
    //url+="&MultipleSelect=Y";
    if(openFrom!=undefined && openFrom=='Link'){     
        
        popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true,false,"",IsCheck); //change by amar
    }else if(typeof resizeMode != 'undefined' && resizeMode=='popout'){
        popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
    }else{
           window.parent.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);

    }
}

function ShowUserListPref(ref,nameCtrl,iDCtrl,hidNameCtrl,CallBackFunction,AllFlag,AnyFlag,NoneFlag,Extra1,compid,expertiseFilter,grpFilter,userfilter,multipleSelect,mode,SharedUsersJson,isCheck,openedFrom,processDefId,activityId,taskId){
    var AllUserFlag = "N";
    var AnyUserFlag = "N";
    var NoneUserFlag = "N";
    var IsCheck=false;
    
    if(isCheck != undefined)
        IsCheck = isCheck;
    
    if(AnyFlag != undefined)
        AnyUserFlag = AnyFlag;
    
    if(AllFlag != undefined)
        AllUserFlag = AllFlag;
    
    if(NoneFlag != undefined)
        NoneUserFlag = NoneFlag;
    processDefId = (typeof processDefId == 'undefined')?'': processDefId;
    activityId = (typeof activityId == 'undefined')?'': activityId;
    taskId = (typeof taskId == 'undefined')?'': taskId;
    
    
    var posLeft = findPosX(ref);
    var posTop;

    if(typeof resizeMode != 'undefined' && resizeMode == 'popout')
    {
        posTop = findPosY(ref);
    }
    else
    {
        posTop = findAbsPosY(ref);
    }
    try{
        
        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){
        
    }
    
    var iFrameHeight = 270;
    var iFrameWidth = 290;
    if(ref.form)
    var formid = ref.form.id;
    else
        formid="";
    var popupDivId = "UserPickListPref";
    var queueId ="";
    var isReasignPicklist="";
    if(Extra1 == "Link"){
        openFrom = Extra1;
    }
    
    if(Extra1 == "Reasign"){
        queueId = document.getElementById("reassignworkitem:hidQueueId").value;
        isReasignPicklist = "Y";
    }
    var url="/webdesktop/components/search/userlistPref.app?Action=1&WD_SID="+WD_SID;
        url+="&strFormID=" + formid +"&strFormFieldText=" + nameCtrl + "&strFormFieldID=" + iDCtrl + "&strFormFieldTextHidden=" + hidNameCtrl 
        + "&PopupDivId=" + popupDivId +"&CallBack="+CallBackFunction+ "&AllFlag=" + AllUserFlag + "&AnyFlag=" +AnyUserFlag+"&NoneFlag="+NoneUserFlag+"&QueueID="+queueId+"&openedFrom="+openedFrom;
    if(compid!=undefined){
        url+="&Comp_ins_id="+compid;
    }
    if(expertiseFilter!=undefined){
        url+="&ExpertiseFilter="+expertiseFilter;
    }
    if(grpFilter!=undefined){
        url+="&GroupFilter="+grpFilter;
    }
    if(userfilter!=undefined){
        url+="&UserFilter="+userfilter;
    }
    if(multipleSelect!=undefined){
        url+="&MultipleSelect="+multipleSelect;
    }
    if(mode!=undefined){
        url+="&Mode="+mode;
    }
    if(SharedUsersJson!=undefined){
        url+="&SharedUsersJson="+encode_utf8(SharedUsersJson);
    }
    if(isReasignPicklist!=undefined){
        url+="&ShowLoggedInUser="+isReasignPicklist;
    }
    url+="&ProcessDefId="+processDefId+"&ActivityId="+activityId+"&taskid="+taskId+"&Scope=P";
    
    
    //url+="&MultipleSelect=Y";
    if(openFrom!=undefined && openFrom=='Link'){     
        
          popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true,false,"",IsCheck); //change by amar
    }else if(typeof resizeMode != 'undefined' && resizeMode=='popout'){
        popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
    }else{
           window.parent.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);

    }
}

function openRateUserScreen(userindex,username,disabled,bAbsoluteUserIndex)
{   
    if(typeof bAbsoluteUserIndex != 'undefined'){
        if(bAbsoluteUserIndex == 'true'){     
            try{                
                userindex = userindex.replace( /[^\d.]/g, '');
            } catch(e){
                userindex = userindex.substring(1, userindex.length);
            }
        }
    }
    
    var action = 1;
    if(disabled=='Y'){
        action = 2;
    }
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=620;
    var WindowWidth=400;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2) - 15;
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=0,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;
    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("UIndexToBeRated",encode_ParamValue(userindex)));
    listParam.push(new Array("UNameToBeRated",encode_ParamValue(username)));
    
    var Url="/webdesktop/components/userlist/transitionrateuser.app?WD_SID="+WD_SID+"&UIndexToBeRated"+userindex+"&UNameToBeRated="+username+"&Action="+action;
    var win = openNewWindow(Url,"rateuser",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    } catch(e) {}
}
function openMessageAttributeScreen(fieldId,actionId,archivalMode)
{var action = 1;
    var ScreenHeight=screen.height;
    var ScreenWidth=screen.width;
    var WindowHeight=420;
    var WindowWidth=600;
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2) - 15;
    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=1,top='+WindowTop+',left='+WindowLeft;
    var listParam=new Array();
    listParam.push(new Array("Action",encode_ParamValue("1")));
    listParam.push(new Array("FieldId",fieldId));
    listParam.push(new Array("ActionId",actionId));
    listParam.push(new Array("ArchivalMode",archivalMode));
    var Url="/webdesktop/components/workitem/operations/attributemessage.app?WD_SID="+WD_SID+"&Action="+action;
    var win = openNewWindow(Url,"MessageAttribute",wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
        addWindows(win);
    } catch(e) {}
}

// Omniapp page unload handler implementation
var bOAPUnload = false;
function handleOAPUnload(from){
    bOAPUnload = true;    
    var winCount = 0;
    var redirectToLogin=false;
    if(typeof from!='undefined' && from!=null && from=='LOGOUT'){
        redirectToLogin=true;
    }
    if(wiWinInfoMap.hashArray.length > 0 || targetEmbdWIRef !=null){        
        //when workitem is openend in new window
        closeWindows();
        
        if(wiWinInfoMap.hashArray.length>0){
            //when workitem is openend in new window
            for(var i=0; i<wiWinInfoMap.hashArray.length; i++){
				while(!(wiWinInfoMap.hashArray[i].value.WinRef.closed)){
                    closeWindows();
                }
                if(wiWinInfoMap.hashArray[i].value.WinRef.closed){
                    winCount++;
                }
            }

            if(wiWinInfoMap.hashArray.length == winCount){
                return true;
            }
        }
        
        //when workitem is openend in embedded view
        if(targetEmbdWIRef != null){
            var cleanUpCalled = false;
            
            if(typeof targetEmbdWIRef.doCleanUpEmWd != 'undefined'){
                targetEmbdWIRef.doCleanUpEmWd("beforeunload");
                cleanUpCalled = true;
            } else {
                if(typeof targetEmbdWIRef.doCleanUp != 'undefined'){
                     try{
                    targetEmbdWIRef.doCleanUp("beforeunload");
                    cleanUpCalled = true;
                }
                catch(e){
                    return true;
                }
                }
            }
            
            if(!cleanUpCalled || redirectToLogin){
                return true;
            }
        }
        
        return false;
    } else {        
        return true;
    }     
}

function afterWIDoCleanup(windowUniqueId, bEmbeddedView){
    if(typeof bEmbeddedView == 'undefined'){
        bEmbeddedView = false;
    }
    
    if(!bEmbeddedView){
        if(wiWinInfoMap.hashArray.length > 0){
            removeFromWIWinInfoMap(windowUniqueId);
            /*if(typeof SwitchViewEnabled!= 'undefined') {
                if(SwitchViewEnabled!="Y")
                    removeFromWIWinInfoMap(windowUniqueId);
            }*/
        }
    }
    
    if(wiWinInfoMap.hashArray.length == 0){
        // if all workdesk window get closed then control returned to OmniApp
        OAPUnloadCompleteHandler();
    }
}

function removeFromWIWinInfoMap(windowUniqueId){
    var key = null;
    for(var i=0; i<wiWinInfoMap.hashArray.length; i++){
        key = wiWinInfoMap.hashArray[i].key;
        if(key == windowUniqueId){            
            wiWinInfoMap.hashArray.splice(i, 1);            
        }
    }
}

function OAPUnloadCompleteHandler(){
    if(bOAPUnload){
        window.parent.OAPUnloadCompleteHandler(window.parent.OAPUnloadCode);
        bOAPUnload = false;
    }
}
//----------------------------------------------------

function EncryptParameter(val,eToken)
{
    var paramValue = val;       
    var bf = new Blowfish('DES');
    var encryptValue = bf.encryptx(paramValue,eToken);
    return encode_utf8(encryptValue);
}

function isInternetExplorer11() //Added for Bug 46008
{
   var isIE11 = !!navigator.userAgent.match(/Trident.*rv[ :]*11\./);
   return isIE11;
}

function fieldValidator(controlId, message, position, isCenter, left, top){
    var bRetunValue = true;          
    
    controlId = (typeof controlId == "undefined")? null: controlId;
    left = (typeof left == 'undefined')? 0: left;
    top = (typeof top == 'undefined')? 0: top;
    position = (typeof position == 'undefined')? "absolute": position;
    isCenter = (typeof isCenter == 'undefined')? false: isCenter;
    message = (typeof message == 'undefined')? "": message;
        
    if(controlId != null){
        var controlObj = document.getElementById(controlId);        
        if(controlObj != null){
            setElementFocus(controlObj);
            
            resetFieldValidator();
            addCSS(controlObj, "mandatoryControlCSS");
            
            notifierAbs('notifier', message, position, isCenter, left, top);
            bRetunValue = false;
        }
    } else {
        resetFieldValidator();
        notifierAbs('notifier', message, position, isCenter, left, top);        
    }
    
    if(typeof afterFieldValidator != "undefined"){
        try{
           afterFieldValidator(bRetunValue);
        } catch(e){                 
        }
    }  
     
    return bRetunValue;
}

function resetFieldValidator() {
    /* document.getElementsByClassName returns an HTMLCollection, not just an array of elements.
       HTMLCollections in the HTML DOM are live; they are automatically updated when the underlying document is changed.
    */
    var elements = document.getElementsByClassName("mandatoryControlCSS");                  
    while(elements.length){
        switch(elements[0].type) {
            case "textarea":
            case "password":
            case "file":
            case "text":                     
            case "select-one":
            case "select-multiple":
            case "div":
                removeCSS(elements[0], "mandatoryControlCSS");            
                break;
        }         
    }
    
    if(typeof afterResetFieldValidator != "undefined"){
         try{
            afterResetFieldValidator();
         } catch(e){                 
         }
     }
}

// Mandatory fields validator and Mandatory fields focus
function validator(controlIds){
     var bRetunValue = true;          
     controlIds = (typeof controlIds == "undefined")? null: controlIds;
     var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1;      
     
     if(controlIds != null){
        if(controlIds instanceof Array){                    

        } else {
           controlIds = controlIds.split(","); 
        }

        var controlObj = null;
        var bMandatoryControl = null;
        for(var i=0; i<controlIds.length; i++){
            controlObj = document.getElementById(controlIds[i]);
            if(controlObj != null){
                bMandatoryControl = (' ' + controlObj.className + ' ').indexOf(' mandatoryControl ') > -1;
                bMandatoryControl = (controlObj.type == "hidden")? true: bMandatoryControl; 

                if(bMandatoryControl){
                    if(isEmptyControl(controlObj, true)){
                        if(bRetunValue){
                            setElementFocus(controlObj);
                        }

                        addCSS(controlObj, "mandatoryControlCSS");
                        bRetunValue = false;
                    }else {
                        removeCSS(controlObj, "mandatoryControlCSS");
                    }
                }
            }
        }
     } else {              
        var elements = document.getElementsByClassName("mandatoryControl");          
        for(var i=0; i<elements.length; i++){
            if(isEmptyControl(elements[i])){
                if(bRetunValue){
                    setElementFocus(elements[i]);                    
                }

                addCSS(elements[i], "mandatoryControlCSS");
                bRetunValue = false;
            } else {
                removeCSS(elements[i], "mandatoryControlCSS");
            }
         }
     }

     if(typeof afterValidate != "undefined"){
         try{
            afterValidate(bRetunValue);
         } catch(e){                 
         }
     }     
     
     return bRetunValue;
 } 
 
 function isEmptyControl(element, validateHiddenField) {
    var bEmptyControl = false;
    validateHiddenField = (typeof validateHiddenField == "undefined")?  false: validateHiddenField;    
    
    if(element.style.display == "none" || element.style.visibility == "hidden"){
        return false;
    }
    
    switch(element.type) {
        case "textarea":
        case "password":
        case "file":
        case "text":
            if((Trim(element.value) == "") && !element.disabled){               
               bEmptyControl = true;
            }
            break;                            
        case "select-one":
            if((element.options[element.selectedIndex].value == "-1") && !element.disabled){                
                bEmptyControl = true;
            }   
            break;
        case "hidden":
            if(validateHiddenField){
                if((Trim(element.value) == "") && !element.disabled){               
                   bEmptyControl = true;
                }
            } else {
                bEmptyControl = false;
            }
            break;
    }
    
    return bEmptyControl;
}

function removeCSS(thisObj, classes) {
    /*var newClassName = "";    
    
    if(thisObj != null){
        var classes = thisObj.className.split(" ");
        for(var i = 0; i < classes.length; i++) {
            if(classes[i] != className) {
                newClassName += classes[i] + " ";
            }
        }
        thisObj.className = newClassName.fulltrim();        
    }*/
    
    classes = Array.prototype.slice.call(arguments, 1);
    for (var i = classes.length; i--;) {
        if(classes[i].trim ()){
            classes[i] = classes[i].trim ().split (/\s*,\s*|\s+/);
            for (var j = classes[i].length; j--;){
                if(thisObj){
                    thisObj.classList.remove (classes[i][j]);
                }
            }
        }
    }
}

function removeRespCSS(thisObj, classes) {   
    if(classes && classes.length>0 && thisObj){
        var removeCls=[],i=0,j=0;
        for (i=0;i<classes.length; i++){
            for(j=0;j<thisObj.classList.length;j++){
                if(thisObj.classList[j].indexOf(classes[i])>-1){
                    removeCls.push(thisObj.classList[j]);            
                }
            }
        }
        for(j=0;j<removeCls.length;j++){
            thisObj.classList.remove(removeCls[j]);
        }      
    }
}

function removeAllCSS(tableObj, className) {
    if(tableObj){
        var selectedRows = tableObj.getElementsByClassName(className);
        if(selectedRows && (selectedRows.length > 0)){
            for(var i = selectedRows.length-1; i >= 0; i--){
                removeCSS(selectedRows[i], className);  
            }
        } 
    }
}

function replaceCSS(ref, classNameOld, classNameNew) {
    removeCSS(ref, classNameOld);  
    addCSS(ref, classNameNew);  
}

function addCSS(ref, classes) {    
    /*if(ref != null){
        ref.className += " "+className;
    }*/
  
    if(ref == null){
        return;
    }
    
  classes = Array.prototype.slice.call (arguments, 1);
  for (var i = classes.length; i--;) {
    if(classes[i].trim ()){
        classes[i] = classes[i].trim ().split (/\s*,\s*|\s+/);
        for (var j = classes[i].length; j--;){
            ref.classList.add (classes[i][j]);            
        }
    }
  }
}

function hasCSS(element, cls) {
    var bHasClass = false;    
    if(element != null){
        bHasClass = (' ' + element.className + ' ').indexOf(' ' + cls + ' ') > -1;
    }
    
    return bHasClass;
}

function resetValidator() {
    var elements = document.getElementsByClassName("mandatoryControl");                  
    for(var i=0; i<elements.length; i++){
        switch(elements[i].type) {
            case "textarea":
            case "password":
            case "file":
            case "text":                     
            case "select-one":
                removeCSS(elements[i], "mandatoryControlCSS");            
                break;
        }         
    }
    
    if(typeof afterResetValidator != "undefined"){
         try{
            afterResetValidator();
         } catch(e){                 
         }
     }
}
// ------------------------------------


// message notifier
function notifierAbs(id, msg, position, isCenter, left, top){       
    if(typeof dhtmlx != "undefined"){
        left = (typeof left == 'undefined')? 0: left;
        top = (typeof top == 'undefined')? 0: top;
        position = (typeof position == 'undefined')? "absolute": position;

        isCenter = (typeof isCenter == 'undefined')? false: isCenter;
        var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1;

        if(isCenter){
             var messageWidth = 260;
             var messageHeight = 50;
             if(typeof window.chrome != 'undefined' || isSafari) {
                left=(document.body.clientWidth - messageWidth)/2 + window.document.body.scrollLeft;
                top=(document.documentElement.clientHeight - messageHeight)/2 + window.document.body.scrollTop;
            } else{                    
                left = (document.body.clientWidth - messageWidth)/2 + window.document.documentElement.scrollLeft;
                top = (document.documentElement.clientHeight - messageHeight)/2 + window.document.documentElement.scrollTop;
            }
        }

        dhtmlx.message.position = position;
        dhtmlx.message.hideTimeout = 0;
        dhtmlx.message({
            id: id,
            text: msg,
            expire: 3000,
            top:top + "px",        
            left:left + "px"
        });
    }
}

function hideNotifier(notifierId){
    if(typeof dhtmlx != "undefined"){
        dhtmlx.message.hide(notifierId);
    }
}

function escapeDocClickEvt(e, skipObjects){
    var target = e? e.target: event.srcElement;
    skipObjects = typeof skipObjects == "undefined"? null: skipObjects;
    
    if(skipObjects == null){
        return;
    }
    
    var obj = null;
    var bHideMessage = true;
    for(var i=0; i<skipObjects.length; i++) {
        obj = document.getElementById(skipObjects[i]);
        if(target == obj) {
            bHideMessage = false;                        
            break;
        }
    }

    if(bHideMessage){
        hideNotifier("notifier");
    }
}

// -------------------------------

function handleFieldFocus(data, ids) {
    var bAjaxRequest = true;
    if(data == null){
        bAjaxRequest = false;
    }

    if (!bAjaxRequest || (data.status == "success")) {
        if (!bAjaxRequest || data.requestObject){
            var FocusId = null;
            if(bAjaxRequest){
                FocusId = data.requestObject.getResponseHeader("FocusId");
            } else {
                if(ids != null){                    
                    FocusId = ids;
                }
            }
            
            if (FocusId != null && FocusId != ""){                
                FocusId = FocusId.split(","); 
                if(FocusId.length > 0){                    
                    var genericCSSNodeMap = {"div": "div","table": "table"};
                    var controlObj = null;
                    
                    for(var i=0; i<FocusId.length; i++){                        
                        controlObj = document.getElementById(FocusId[i]);
                        if(controlObj != null && !controlObj.disabled){
                            if(genericCSSNodeMap[controlObj.nodeName.toLowerCase()] != null){
                                addCSS(controlObj, "genericCSS");
                            } else {
                                addCSS(controlObj, "mandatoryControlCSS");
                            }
                            
                            if(FocusId.length == 1){
                                setElementFocus(controlObj);
                            }
                        }
                    }                    
                }
            }
        }
       
    }
}
 
function dependentFieldsCSSRenderer(sourceId, className, escapeIds){  
    sourceId = (typeof sourceId == "undefined" || sourceId == '')? null: sourceId;    
    className = (typeof className == "undefined")? '': className;
    escapeIds = (typeof escapeIds == "undefined")? null: escapeIds;
    
    if(sourceId == null){
        return false;
    }
    
    var sourceObj = document.getElementById(sourceId);
        
    if(sourceObj != null){        
        if(sourceObj.type.toLowerCase() == 'checkbox'){            
            var targetObjects = document.getElementsByClassName(sourceObj.id);
            for(var i=0; i<targetObjects.length; i++){                                        
                if(targetObjects[i] != null){
                    if(sourceObj.type.toLowerCase() == 'checkbox'){
                        if(sourceObj.checked){
                            addCSS(targetObjects[i], className);
                        } else{
                            removeCSS(targetObjects[i], className);
                        }
                    }
                }  
            }
        } else if(sourceObj.type.toLowerCase() == 'radio'){
            var radioObjects = document.getElementsByName(sourceObj.name);            
            var nextSibling = null;
            var escapeIdMap = stringToMap(escapeIds);
                        
            for(var i=0; i<radioObjects.length; i++){ 
                if(typeof escapeIdMap[i+""] != "undefined"){
                } else {
                    nextSibling = radioObjects[i].nextSibling;
                    if(nextSibling != null){
                        if(nextSibling.nodeName.toLowerCase() == "label"){
                            if(radioObjects[i].checked){                    
                                addCSS(nextSibling, className);                            
                            } else {                            
                                removeCSS(nextSibling, className);                            
                            }
                        }
                    }
                }
            }
        }
    }
    
    return true;
}

function stringToMap(str){
    str = (typeof str == "undefined")? null: str;
    var map = {};
    
    if(str == null){
        return map;
    }
    
    if(str instanceof Array){                    
    } else {
        str = str.split(","); 
    }
        
    for(var i=0; i<str.length; i++){ 
        map[str[i]] = str[i];
    }
    
    return map;
}

function setElementFocus(controlObj){
    if((typeof controlObj != 'undefined') && (controlObj != null)){
        var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1;
        
        if(typeof window.chrome != 'undefined'){
            if(typeof controlObj.focus != 'undefined'){
                controlObj.focus();
            } else if(typeof controlObj.select != 'undefined'){
                controlObj.select();
            }
        } else if(isSafari){
            if(typeof controlObj.select != 'undefined'){
                controlObj.select();
            } else if(typeof controlObj.focus != 'undefined'){
                controlObj.focus();                                      
            }
        } else {
            if(typeof controlObj.select != 'undefined'){
                controlObj.select();
            } else if(typeof controlObj.focus != 'undefined'){
                controlObj.focus();
            }
        }  
    }
}
String.prototype.fulltrim=function(){
    return this.replace(/(?:(?:^|\n)\s+|\s+(?:$|\n))/g,'').replace(/\s+/g,' ');
}
String.prototype.trim = function () {
    return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
}
function trimSpace(ref){
    var elementVal = document.getElementById(ref.id).value.fulltrim();
    document.getElementById(ref.id).value=elementVal;
}

function onScrollMOver(thisRef, op){
    var ref = null;
    if(op == 'D'){
        ref = document.getElementById("downArrowPG");
        removeCSS(ref, "arrowupdistheme")
        addCSS(ref, "arrowuptheme");
    } else if(op == 'U'){
        ref = document.getElementById("upArrowPG");
        removeCSS(ref, "arrowdowndistheme")
        addCSS(ref, "arrowdowntheme");
    }
}

function onScrollMOut(thisRef, op){
    var ref = null;
    if(op == 'D'){
        ref = document.getElementById("downArrowPG");
        removeCSS(ref, "arrowuptheme")
        addCSS(ref, "arrowupdistheme");
    } else if(op == 'U'){
        ref = document.getElementById("upArrowPG");
        removeCSS(ref, "arrowdowntheme")
        addCSS(ref, "arrowdowndistheme");
    }
}

function disCutCopyPaste(e){
   
    var keyCode = e.keyCode || e.charCode;  
    if(e.ctrlKey && (keyCode=='67' || keyCode=='86' || keyCode=='88'))
    {
        e.preventDefault();
        return false;
    }else
    {
        return true;
    }
   
}

function showGenMessage(ref, msg, width, height, left, top){    
    setPopupMask();
                
    width = (typeof width == "undefined")? 250: width;
    height = (typeof height == "undefined")? 80: height;    
    
    left = (typeof left == "undefined")? (document.documentElement.clientWidth - width)/2 + window.document.body.scrollLeft: left;
    top = (typeof top == "undefined")? (document.documentElement.clientHeight - height)/2 + window.document.body.scrollTop: top;                

    document.getElementById('genMessageDiv').style.width = width+'px';
    document.getElementById('genMessageDiv').style.height = height+'px';
    document.getElementById('genMessageDiv').style.top = top+'px';
    document.getElementById('genMessageDiv').style.left = left+'px';         
    ref.innerHTML = msg;      
    document.getElementById('genMessageDiv').style.display = 'block';
}

function setPopupMask()
{   
     var isSafari=false;       
     if(navigator.userAgent.indexOf("Safari")!=-1){
         isSafari=true;
     }

     var isChrome = window.chrome; //added on 24/03/2014 ,bug_id:43929
     
    if(gPopupMask == null){
        initPopUp();
    }
    
    if(gPopupMask !=null) {
        gPopupMask.style.display = "block";  
        //added on 24/03/2014 ,bug_id:43929
        if (typeof isChrome != 'undefined' || isSafari) {
            gPopupMask.style.height = (screen.height + window.document.documentElement.clientHeight) + "px";//till here bug_id:43929
        } else {
            gPopupMask.style.height = window.document.documentElement.scrollHeight + "px";
        }
        gPopupMask.style.width = document.documentElement.clientWidth + "px";
    }
}

function hideGenMessage(){
    hidePopupMask();
    document.getElementById('genMessageDiv').style.display = 'none';
}
function ReloadTaskList(workitemID,routeID,processInstanceID,workstageID,activityName,queueType,caseRole,showCaseVisualization){
    if(workitemID!=undefined){
        document.getElementById('tasklist:hidWorkitemId').value=workitemID;
    }
    if(routeID!=undefined){
        document.getElementById('tasklist:hidProcessDefId').value=routeID;
    }
    if(processInstanceID!=undefined){
        document.getElementById('tasklist:hidProcessInstanceId').value=processInstanceID;
    }
    if(workstageID!=undefined){
        document.getElementById('tasklist:hidActivityId').value=workstageID;
    }
    if(activityName!=undefined){
        document.getElementById('tasklist:hidActivityName').value=activityName;
    }
    if(queueType!=undefined){
        document.getElementById('tasklist:hidQueueType').value=queueType;
    }
    if(caseRole!=undefined){
        document.getElementById('tasklist:hidCaseRole').value=caseRole;
    }

    if(showCaseVisualization!=undefined){
        document.getElementById('tasklist:hidShowCaseVisual').value=showCaseVisualization;
    }
    document.getElementById('tasklist:hidSelectedTab').value="TaskStatusTab";
    
    clickLink("tasklist:cmdbtn_go");

}

function viewTaskData(wItemId, pInsId, processDefId, activityId, taskId, subTaskId, taskname, completiondate,assignedTo,ProcessName) {
    var url = '/webdesktop/components/task/viewDataTemplate.app';
    url = appendUrlSession(url);
    var left = (window.screen.width - 600) / 2;
    var top = (window.screen.height - 300) / 2;
    var wFeatures = 'scrollbars=no,status=yes,width=600,height=250,left=' + left + ',top=' + top;
    var listParam = new Array();
    listParam.push(new Array("WorkItemId", encode_ParamValue(wItemId)));
    listParam.push(new Array("ProcessDefId", encode_ParamValue(processDefId)));
    listParam.push(new Array("ProcessName", encode_ParamValue(ProcessName)));
    listParam.push(new Array("ActivityId", encode_ParamValue(activityId)));
    listParam.push(new Array("ProcessInstanceId", encode_ParamValue(pInsId)));
    listParam.push(new Array("taskid", encode_ParamValue(taskId)));
    listParam.push(new Array("subtaskid", encode_ParamValue(subTaskId)));
    listParam.push(new Array("taskname", encode_ParamValue(taskname)));
    listParam.push(new Array("completiondate", encode_ParamValue(completiondate)));
    listParam.push(new Array("assignedTo", encode_ParamValue(assignedTo)));
    
    var win = openNewWindow(url, 'DataTemplate', wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", listParam);
}

function viewTemplate(templateId,pid,wid,processName,processDefId,activityId) {
    var url = '/webdesktop/components/task/viewCustomTemplate.app';
    url = appendUrlSession(url);
    var width = 600;
    var height = 300;
    var left = (window.screen.width - width) / 2;
    var top = (window.screen.height - height) / 2;
    var wFeatures = 'scrollbars=no,status=yes,width=600,height=300,left=' + left + ',top=' + top;
    var listParam = new Array();
    listParam.push(new Array("TemplateId", encode_ParamValue(templateId)));
    listParam.push(new Array("ProcessInstanceId", encode_utf8(pid)));
    listParam.push(new Array("WorkItemId", encode_ParamValue(wid)));
    listParam.push(new Array("ProcessName", encode_utf8(processName)));
    listParam.push(new Array("ProcessDefId", encode_ParamValue(processDefId)));
    listParam.push(new Array("ActivityId", encode_ParamValue(activityId)));
    listParam.push(new Array("Width", encode_ParamValue(width)));
    listParam.push(new Array("Height", encode_ParamValue(height)));
    
    var win = openNewWindow(url, 'DataTemplate', wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", listParam);
}

function validateTaskField(e,textBoxElem,variableType){
    try{
        var evtObj = window.event || e;

        var browser=navigator.appName;
        var KeyID = "";
        if(browser=="Netscape"){ // mozilla browser
            KeyID =  evtObj.which;
            if(KeyID == 0 ) // for tab changed by mohit sharma Bug ID : 41427
                return true;                
        }
        else {   
            KeyID = evtObj.keyCode;
        }  

        evtObj.returnValue = true;
        if(variableType == '8'){ // not allow any value to be entered in case of date
            return false;
        }else if(variableType == '3' || variableType == '4' || variableType == '6'){ // validation for integer
            
            if(((KeyID >=48 && KeyID <58) || KeyID==46 || KeyID==8) && (textBoxElem.value.length<10)){
                evtObj.returnValue = true;
            }else
                evtObj.returnValue = false;
            

            if(browser=="Netscape"){ // mozilla browser
                if(KeyID == 46 || KeyID == 0) // delete key
                    evtObj.returnValue = true;
            } 

        }
       }catch(excp){
            evtObj.returnValue = true;
       }    
    return evtObj.returnValue
}

function getRefreshMsg(){
    var errormsg = CASE_MODIFIED +" <a href='javascript:void(0)' onclick='refreshCase();return false;'>"+REFRESH+"</a> " +THE_CASE ;
    return errormsg;
}
function checkNumber(e,option,textBoxElem,charCount){
    var evtObj = window.event || e;
    var KeyID=e.keyCode;
    if((KeyID == 8 || KeyID == 190 || KeyID == 45 || KeyID == 46 || (KeyID >=48 && KeyID <58))&&(textBoxElem.value.length<charCount)){
                 evtObj.returnValue = true;
                    if(textBoxElem!=undefined){
                        if(textBoxElem.value.length!=0 && KeyID==45)
                            evtObj.returnValue = false;
                    }
                }
         else{
             return false;
         }       
}
function ShowHoldActivityList(ref,ProcessDefID,ProcessName)
{
   var posLeft = findAbsPosX(ref);
    var posTop;
    if(typeof resizeMode != 'undefined' && resizeMode == 'popout')
    {
        posTop = findPosY(ref);
    }
    else
    {
        posTop = findAbsPosY(ref);
    }

    try{

        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){

    }
    
    var iFrameHeight = 275;
    var iFrameWidth = 250;
    if(ref.form)
    var formid = ref.form.id;
    else
        formid="";
    var popupDivId = "holdActivityList"; 
    var url="/webdesktop/components/activity/holdActivityPicklist.app?WD_SID="+WD_SID+"&ProcessDefId="+ProcessDefID+"&ProcessName="+ProcessName;
    window.parent.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
}

function ShowHoldEventList(ref,hidlastworkstepId,hidworkstepId,hidProcessId,hidactivityname,activityname,OpenSrc,ActType)
{
    var posLeft = findAbsPosX(ref);
    var posTop = findAbsPosY(ref);
    try{
        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){}
    var iFrameHeight = 245;
    var iFrameWidth = 230;
    var formid = ref.form.id;
    var popupDivId = "HoldEventPickList";
    var procID= document.getElementById(hidProcessId).value;
    var lastActivityId = document.getElementById(hidlastworkstepId).value;
    var url="/webdesktop/components/workstep/holdeventpicklist.app?Action=1&strFormFieldID=" + hidworkstepId + "&ProcessDefID=" +procID +"&PopupDivId=" + popupDivId +"&hidactivityName="+hidactivityname+"&activityname="+activityname+"&lastActivityId="+lastActivityId+"&WD_SID="+WD_SID;
    
    if(OpenSrc!= undefined && OpenSrc != "")        
        url=url+"&OpenFrom="+OpenSrc;
    
    if(ActType!= undefined && ActType != "")        
        url=url+"&ActivityType="+ActType;  
    
    if(openFrom!=undefined && openFrom=='Link'){
        popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);

    }else{
        window.parent.parent.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
    }
}
function cancelBubble(e) 
{
    if((typeof e != "undefined") && (e != null)){
        var evt = e ? e:window.event;
        if (evt.stopPropagation)
        {
            evt.stopPropagation();
            evt.preventDefault();
        }
        if (evt.cancelBubble!=null || evt.cancelBubble!=true)
        {
            evt.cancelBubble = true;
            evt.returnValue = false;
        }
       }
}

function validateFilterData(val,strType){
   if(strType=="3")
    {
        val=replaceAll(val,',','');
       if(IsNumericVal(val))
       {
           if(val<-32768 || val>32767)
        {
            return 0;
        }
       }
       else{
           return 0;
       }
   }else if(strType=="4")
    {
        val=replaceAll(val,',','');
       if(IsNumericVal(val))
       {
          if(val<-2147483648 || val>2147483648)
        {
            return 0;
        }

       }
       else{
           return 0;
       }
    }else if(strType=="6"){
        val=replaceAll(val,',','');
        if(isNaN(val)){
            return 0;
        }
        if(val<1.4E-45 || val>3.4028235E38)
        {
            return 0;
        }
   } else if(strType=="8") {
        var validationStatus = ValidateDateFormat(val,dateTimeFormat);
        if(validationStatus!=1)
            return 0;
   }

   return 1;
}

function replaceAll(data,searchfortxt, replacetxt)
{ 
	var startIndex=0;
	while(data.indexOf(searchfortxt)!=-1)
	{
		data=data.substring(startIndex,data.indexOf(searchfortxt)) + replacetxt + data.substring(data.indexOf(searchfortxt)+searchfortxt.length,data.length);
	}	
	
	return data;
}

function rowSelector(e){
    // This method must be called last in  event(e.g. onclick) invocation chain of source element
    var bFAjax = false, source = null, tableObj = null, rowNode = null;
    
    if((typeof e == 'undefined') || (e == null)){  
        // Can be used onload of page
        source = null;
    } else if((typeof e == 'object') && (e.source)){        
        // fajax handler
        source = e.source;
        bFAjax = true;
    } else {
        // Non-Ajax event triggered on an element 
        e = e || window.event;
        source = e.target || e.srcElement;
    }
    
    if(source != null){
        tableObj = source.parentNode;
        rowNode = source.parentNode;
        var bTHeadCheckBox = false;
        var bValidTable = false;
    
        // Finds parent table and parent row of checkbox
        while(tableObj && (!(tableObj.nodeName.toUpperCase() == "TABLE") || !bValidTable)){ 
            if(tableObj.nodeName.toUpperCase() == "TR"){
                if(hasCSS(tableObj, 'tablecontent')){
                    rowNode = tableObj;
                    bValidTable = true;
                }
            }
            if(tableObj.nodeName.toUpperCase() == "THEAD"){
                bTHeadCheckBox = true;
                bValidTable = true;
            }
            tableObj = tableObj.parentNode;
        }
    
        if(tableObj){ 
            // Getting new element reference after fajax call
            if(tableObj.id.length > 0){
                tableObj = document.getElementById(tableObj.id);
                if(bFAjax){
                    if(rowNode){
                        rowNode = tableObj.rows[rowNode.rowIndex];
                    }
                }
            }
        
            if(bTHeadCheckBox){
                // if multiple select checkbox checked/unchecked      
                for(var r = tableObj.rows.length-1; r >=0 ; r--){ 
                    if(source.checked) {
                        addCSS(tableObj.rows[r], "row-selector"); 
                    } else {
                        removeCSS(tableObj.rows[r], "row-selector"); 
                    }
                }
            } else {
                /*if(source.checked) {
                // Checkbox attribute taken for handling unchecked checkbox event triggered by other means not manually. 
                rowNode.CheckBox = source;
                addCSS(rowNode, "row-selector");                 
            } else {
                rowNode.CheckBox = null;
                removeCSS(rowNode, "row-selector");                
            }*/
            
                for(var r = 0; r < tableObj.rows.length; r++){ 
                    if(hasSelector(tableObj.rows[r].cells[0])){                
                        addCSS(tableObj.rows[r], "row-selector"); 
                    } else {
                        removeCSS(tableObj.rows[r], "row-selector"); 
                    }
                }                        
            
                var selectedRows = tableObj.getElementsByClassName("row-selector");
                if(selectedRows && (selectedRows.length > 0)){
                    for(var i = selectedRows.length-1; i >= 0; i--){        
                        if(selectedRows[i].CheckBox && !selectedRows[i].CheckBox.checked){
                            selectedRows[i].CheckBox = null;
                            removeCSS(selectedRows[i], "row-selector");                        
                        }
                    }
                } 
            }           
        }
    }
    
    if(bFAjax || (source == null)){
        var rowSelTables = document.getElementsByClassName("row-selector-table");
        if(rowSelTables && (rowSelTables.length > 0)){
            var rowSelTable = null;
            for(var i = 0; i < rowSelTables.length; i++){
                rowSelTable = rowSelTables[i];
                if(rowSelTable != tableObj){
                    for(var j = 0; j < rowSelTable.rows.length; j++){                    
                        if(hasSelector(rowSelTable.rows[j].cells[0])){                
                            addCSS(rowSelTable.rows[j], "row-selector"); 
                        } else {
                            removeCSS(rowSelTable.rows[j], "row-selector"); 
                        }
                    }                
                }
            }
        } 
    }
}

function hasSelector(ref){
    var bSelectorPresent = false;
    var selectorRef = ref.getElementsByTagName("input");
    
    for(var c = 0; c < selectorRef.length ; c++){ 
        if(selectorRef[c].type == 'checkbox'){
            if(selectorRef[c].checked){
                bSelectorPresent = true;
                break;
            }
        }
    }
    
    return bSelectorPresent;
}

function isElementInViewport(el){
    var rect = el.getBoundingClientRect();
    // DOMRect { x: 8, y: 8, width: 100, height: 100, top: 8, right: 108, bottom: 108, left: 8 }
    var windowHeight = (window.innerHeight || document.documentElement.clientHeight);
    var windowWidth = (window.innerWidth || document.documentElement.clientWidth);

    var vertInView = (rect.top >= 0) && ((rect.top + rect.height) <= windowHeight);
    var horInView = (rect.left >= 0) && ((rect.left + rect.width) <= windowWidth);

    return {"IsInView": vertInView && horInView, "IsInVView":vertInView, "IsInHView":horInView};
}

function removeChildrenCSS(parent, className){    
    var childs = parent.getElementsByClassName(className);
    if(childs && (childs.length > 0)){
        for(var i = childs.length-1; i >= 0; i--){        
            removeClass(childs[i], className); 
        }
    }
}

function removeClass(id, remove) {
    var newClassName = "";
    var thisObj = document.getElementById(id);
    
    if((typeof id == "object") || (id instanceof Object)){
        thisObj = id;
    }
    
    if(thisObj != null){
        var classes = thisObj.className.split(" ");

        for(var i = 0; i < classes.length; i++) {
            if(classes[i] !== remove) {
                newClassName += classes[i] + " ";
            }
        }
        thisObj.className = newClassName.fulltrim();
    }    
}

function addClass(id, className) {
    var ref = document.getElementById(id);
    if((typeof id == "object") || (id instanceof Object)){
        ref = id;
    }
    
    if(ref != null){
        ref.className += " "+className;
    }
}

function hasClass(element, cls) {
    var bHasClass = false;    
    if(element != null){
        bHasClass = (' ' + element.className + ' ').indexOf(' ' + cls + ' ') > -1;
    }
    
    return bHasClass;
}

function getElementHW(ref) {    
    var width = Math.max(ref.clientWidth, ref.offsetWidth);            
    var height = Math.max(ref.clientHeight, ref.offsetHeight);            
    return {'Height': height, 'Width': width};
}

function initTableHeaderFix(resize){    
    var headerFixContainer = null;
    var hwJSON = null, overflow = false;   

    headerFixContainer = document.getElementsByClassName("table-header-fix");
    if(typeof resize=='undefined'){
        resize=false;
    }
    if(headerFixContainer){
        for(var i=0; i<headerFixContainer.length; i++){
            if((headerFixContainer[i].firstElementChild != null) && (headerFixContainer[i].firstElementChild.firstElementChild != null)){
                if(headerFixContainer[i].firstElementChild.style.width.indexOf('px') < 0){
                    hwJSON = getElementHW(headerFixContainer[i].firstElementChild);

                    headerFixContainer[i].firstElementChild.style.width = hwJSON.Width + "px";
                    headerFixContainer[i].firstElementChild.firstElementChild.style.width = hwJSON.Width + "px";
                    headerFixContainer[i].style.width = hwJSON.Width + "px"; 
                }
            
                headerFixContainer[i].firstElementChild.style.overflowX = "hidden";
                headerFixContainer[i].firstElementChild.style.overflowY = "auto";
                overflow = hasCSS(headerFixContainer[i], 'xy');
                if(overflow){
                    headerFixContainer[i].firstElementChild.style.overflowX = "auto";                    
                }
                                
                var k=0, bodyRow=null, eps = null, ebs = null, headerCell = null, bodyCell = null, tHead = headerFixContainer[i].firstElementChild.firstElementChild.tHead, tBody = headerFixContainer[i].firstElementChild.firstElementChild.tBodies[0];
                if(tHead.firstElementChild.cells.length == tBody.firstElementChild.cells.length){
                    bodyRow = tBody.children[k];
                    
                    for(; (k < tBody.rows.length) && (bodyRow.style.display == 'none');){
                        bodyRow = tBody.children[++k];
                    }
                    
                    if(k == tBody.rows.length){
                        return false;
                    }
                    
                    for(var j=0; j<tHead.firstElementChild.cells.length; j++){
                        headerCell = tHead.firstElementChild.cells[j];
                        bodyCell = bodyRow.cells[j];
                        
                        if(headerCell.offsetWidth > bodyCell.offsetWidth){
                            eps = getElementStyle(headerCell, "padding");
                            ebs = getElementStyle(headerCell, "border");
                            headerCell.style.minWidth = bodyCell.style.minWidth = headerCell.offsetWidth - (eps.PaddingLeft+ebs.BorderHorizontalWidth) + "px";
                            if(resize==true){
                                addCSS(headerCell,"m");
                                addCSS(bodyCell,"m");
                            }
                        } else if(headerCell.offsetWidth < bodyCell.offsetWidth){
                            eps = getElementStyle(bodyCell, "padding");
                            ebs = getElementStyle(bodyCell, "border");
                            headerCell.style.minWidth = bodyCell.style.minWidth = bodyCell.offsetWidth - (eps.PaddingLeft+ebs.BorderHorizontalWidth) + "px";
                            if(resize==true){
                                addCSS(headerCell,"m");
                                addCSS(bodyCell,"m");
                            }
                        }
                    }
                }
               
                headerFixContainer[i].firstElementChild.onscroll = function(event){
                    event = event || window.event;
                    var source = event.target || event.srcElement;
                    var scrollLeft = source.scrollLeft;                    
                    
                    if((typeof pageDirection != 'undefined') && (pageDirection == 'rtl')) {
                        /*Browser           Type       Most Left    Most Right  Initial
                          WebKit(Chrome)    default    0            100         100
                          Gecko(Firefox)    negative   -100         0           0
                          IE                reverse    100          0           0
                        */
                       
                        var isFirefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
                        var isChrome = (typeof window.chrome != 'undefined') ? true : false;
                        var isSafari = navigator.userAgent.toLowerCase().indexOf('safari/') > -1;
                         if (isChrome){
                            var scrollRight = source.scrollWidth - (scrollLeft + source.clientWidth);           
                            source.firstElementChild.tHead.firstElementChild.style.right = -1*scrollRight + "px";                
                        } 
                        else if(isFirefox || isSafari){
                           // var scrollRight = source.scrollWidth - (scrollLeft + source.clientWidth); 
                            source.firstElementChild.tHead.firstElementChild.style.right = (scrollLeft) + "px";                
                        } else {
                            source.firstElementChild.tHead.firstElementChild.style.right = -1*scrollLeft + "px";                
                        }                       
                    } else {
                        source.firstElementChild.tHead.firstElementChild.style.left = -1*scrollLeft + "px";                                        
                    }
                }      
            }
        }        
    }    
}

function getElementStyle(el, property){ 
    var styleJSON = {};
	
    switch(property){
        case "border":
            styleJSON = {
                BorderLeftWidth:0, 
                BorderRightWidth:0, 
                BorderTopWidth:0, 
                BorderBottomWidth:0
            };
            if (el.currentStyle){
                var value = el.currentStyle.borderLeftWidth.split('p')[0]-0;
                styleJSON.BorderLeftWidth = isNaN(value)? 0: value;
                value = el.currentStyle.borderRightWidth.split('p')[0]-0;
                styleJSON.BorderRightWidth = isNaN(value)? 0: value;
                value = el.currentStyle.borderTopWidth.split('p')[0]-0;
                styleJSON.BorderTopWidth = isNaN(value)? 0: value;
                value = el.currentStyle.borderBottomWidth.split('p')[0]-0;
                styleJSON.BorderBottomWidth = isNaN(value)? 0: value;
            } else if (window.getComputedStyle){
                styleJSON.BorderLeftWidth = getComputedStyle(el,null).getPropertyValue("border-left-width").split('p')[0]-0;
                styleJSON.BorderRightWidth = getComputedStyle(el,null).getPropertyValue("border-right-width").split('p')[0]-0;
                styleJSON.BorderTopWidth = getComputedStyle(el,null).getPropertyValue("border-top-width").split('p')[0]-0;
                styleJSON.BorderBottomWidth = getComputedStyle(el,null).getPropertyValue("border-bottom-width").split('p')[0]-0; 
            }
			
            styleJSON.BorderHorizontalWidth = styleJSON.BorderLeftWidth + styleJSON.BorderRightWidth;
            styleJSON.BorderVerticalWidth = styleJSON.BorderTopWidth + styleJSON.BorderBottomWidth;
            break;
			
        case "padding":
            styleJSON = {
                PaddingLeft:0, 
                PaddingRight:0, 
                PaddingTop:0, 
                PaddingBottom:0
            };
            if (el.currentStyle){
                styleJSON.PaddingLeft = el.currentStyle.paddingLeft.split('p')[0]-0;
                styleJSON.PaddingRight = el.currentStyle.paddingRight.split('p')[0]-0;
                styleJSON.PaddingTop = el.currentStyle.paddingTop.split('p')[0]-0;
                styleJSON.PaddingBottom = el.currentStyle.paddingBottom.split('p')[0]-0;
            } else if (window.getComputedStyle){
                styleJSON.PaddingLeft = getComputedStyle(el,null).getPropertyValue("padding-left").split('p')[0]-0;
                styleJSON.PaddingRight = getComputedStyle(el,null).getPropertyValue("padding-right").split('p')[0]-0;
                styleJSON.PaddingTop = getComputedStyle(el,null).getPropertyValue("padding-top").split('p')[0]-0;
                styleJSON.PaddingBottom = getComputedStyle(el,null).getPropertyValue("padding-bottom").split('p')[0]-0; 
            }
			
            styleJSON.PaddingHorizontalWidth = styleJSON.PaddingLeft + styleJSON.PaddingRight;
            styleJSON.PaddingVerticalWidth = styleJSON.PaddingTop + styleJSON.PaddingBottom;

            break;
    }
   
    return styleJSON;
}
function IframeRequestWithPost(url,ifrm){
    var actionURL=getActionUrlFromURL(url);
    var strprocessname = "";
    var stractivityName = "";
    if (typeof isPdftoolbarenable != 'undefined' && !isPdftoolbarenable(strprocessname, stractivityName)) {
        actionURL = actionURL + "#toolbar=0&navpanes=0";
    }
    var listParam=getInputParamListFromURL(url);
    var popup;
    popup = (ifrm.contentWindow) ? ifrm.contentWindow : (ifrm.contentDocument.document) ? ifrm.contentDocument.document : ifrm.contentDocument;
    popup.document.open();
    popup.document.write("<HTML><HEAD><TITLE></TITLE></HEAD><BODY>");
    popup.document.write("<form id='postSubmit' method='post' action='"+actionURL+"' accept-charset='UTF-8' enctype='application/x-www-form-urlencoded'>");
    for(var iCount=0;iCount<listParam.length;iCount++)
     {
            var param=listParam[iCount];
            popup.document.write("<input type='hidden' id='"+param[0]+"' name='"+param[0]+"'/>");
            popup.document.getElementById(param[0]).value=param[1];//handle single quotes etc
     }
     popup.document.write("</FORM></BODY></HTML>");
     popup.document.close();
     popup.document.forms[0].submit();
}
function FindLeftWindowBoundry()
{
	// In Internet Explorer window.screenLeft is the window's left boundry
	if (window.screenLeft)
	{
		return window.screenLeft;
	}
	
	// In Firefox window.screenX is the window's left boundry
	if (window.screenX)
		return window.screenX;
		
	return 0;
}
function getMainScreenLeft()
{ 
    var winLocation = window.location.href;
    if (winLocation.indexOf('/main/main.app') > -1)
    {
        if (window.screenLeft)
        {
            return window.screenLeft;
        }
        // In Firefox window.screenX is the window's left boundry
        if (window.screenX)
            return window.screenX;
    }
    else if (window.opener != undefined)
    {
        return window.opener.getMainScreenLeft();
    }
    else if (window.top != undefined)
    {
       return window.top.getMainScreenLeft();
    }
return 0;
}

function comboSelectHandler(thisRef, menuId,pageDir){
    var menuRef = document.getElementById(menuId);
    if(typeof pageDir == 'undefined'){//Bug 75619 Start
        pageDir="ltr";
    }// Bug 75619 End
    if(menuRef.style.display != "none"){
        menuRef.style.display = "none";
    } else {// Bug 75619 Start
        if(pageDir=="rtl")
            menuRef.style.right = "0px";
        else
            menuRef.style.left = "0px";
        // Bug 75619 End
        menuRef.style.top = thisRef.clientHeight - 1 + "px";
        menuRef.style.width = thisRef.clientWidth + 1 + "px";
        menuRef.style.display = "block";
    }
}

function filterHandler(thisRef, menuId,pageDir){
    var menuRef = document.getElementById(menuId);
    if(typeof pageDir == 'undefined'){// Bug 75619 Start
        pageDir="ltr";
    }// Bug 75619 End
    if(menuRef.style.display != "none"){
        menuRef.style.display = "none";
    } else {
        menuRef.style.display = "block";
        if(pageDir=='rtl'){// Bug 75619 Start 
            menuRef.style.right=findPosX(thisRef) + thisRef.clientWidth + menuRef.clientWidth+"px";
        }// Bug 75619 End
        else
            menuRef.style.left = findPosX(thisRef) + thisRef.clientWidth - menuRef.clientWidth + "px";
        menuRef.style.top = findPosY(thisRef) + thisRef.clientHeight + 1 + "px";
        //menuRef.style.width = thisRef.clientWidth + 1 + "px";        
    }
}

function openCalendarPerUser(popupWInRef,thiWinRef, thisRef, userindex,username,textId){
    removeCalendarPopup();
    
    var stroption='rmMyCalendar';
    var calId='-1';
    var strUrl='';
    var callBackFunction='';
    var sCalType='B';
    var sProcessId='0';
    var iFrameHeight=250;
    var iFrameWidth=400;
    
    strUrl="/webdesktop/components/calender/mycalendar.app";
    strUrl=appendUrlSession(strUrl);
    strUrl+='&Mode=Cosy&ReadOnly=Y&Width='+iFrameWidth+'&Height='+iFrameHeight+'&textId='+textId+'&Option='+stroption+'&CallBack='+callBackFunction+'&CalID='+calId+'&ListType='+sCalType+'&ProcessID='+sProcessId+"&calUserIndex="+userindex+"&initiate=Y"+"&calUserName="+encode_utf8(encodeURIComponent(username))+"&FromCase=Y";
    
    if(typeof thiWinRef.prevCalId == 'undefined' || thiWinRef.prevCalId == null){
        thiWinRef.prevCalId = thisRef.id;
    } else if(thisRef.id == thiWinRef.prevCalId){
        thiWinRef.prevCalId = null;
        return;
    } else {
        thiWinRef.prevCalId = thisRef.id;
    }    
   
    var posLeft=findAbsPosX(thisRef) + thisRef.clientWidth + 10;
    var posTop=findAbsPosY(thisRef);
    
    if(document.getElementById("scroll")){
        posLeft -= document.getElementById("scroll").scrollLeft;
        posTop -= document.getElementById("scroll").scrollTop;
    }
    
    var windowWidth = (popupWInRef.innerWidth || popupWInRef.document.documentElement.clientWidth);
    var horInView = (posLeft >= 0) && ((posLeft + iFrameWidth) <= windowWidth);
    if(!horInView){
        posLeft = posLeft - (iFrameWidth + thisRef.clientWidth + 15);  
    }
    
    posLeft = posLeft + iFrameWidth;
    
    popupWInRef.popupIFrameOpenerWrapper(this, calendarId, strUrl, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true, false, true, false, true);
    
    addCSS(thisRef.parentNode.parentNode,'row-selector');
}

function showEditRights(){
    var ref = document.getElementById("bp:userlist");
    if(ref){
        ref.style.display = "none";
    }
    ref = document.getElementById("bp:editrights_btn");
    if(ref){
        ref.style.display = "none";
    }
    ref = document.getElementById("bp:prevAssignedUser");
    if(ref){
        ref.style.display = "none";
    }    
    ref = document.getElementById("bp:tasklistdata2");
    if(ref){
        ref.style.display = "none";
    }
    
    ref = document.getElementById("bp:editrights");
    if(ref){
        ref.style.display = "";
    }
    ref = document.getElementById("bp:userlist_btn");
    if(ref){
        ref.style.display = "";
    }
    
    updateContent();
    
    selectedTab = 'E';
}

function showUserRights(){
    var ref = document.getElementById("bp:editrights");
    if(ref){
        ref.style.display = "none";
    }
    ref = document.getElementById("bp:userlist_btn");
    if(ref){
        ref.style.display = "none";
    }
    
    ref = document.getElementById("bp:userlist");
    if(ref){
        ref.style.display = "";
    }
    ref = document.getElementById("bp:editrights_btn");
    if(ref){
        ref.style.display = "";
    }
    ref = document.getElementById("bp:prevAssignedUser");
    if(ref){
        ref.style.display = "";
    }    
    ref = document.getElementById("bp:tasklistdata2");
    if(ref){
        ref.style.display = "";
    }
    
    selectedTab = 'U';
}

function ShowExpPickList(popupWInRef,ref,name,height,width,nameCtrl,hidIdCtrl,hidNameCtrl,divId,strCallback,strFormFieldID){    
    var posLeft = findPosX(ref);
    var posTop = findPosY(ref);

    try{
        posTop  -= document.getElementById("scroll").scrollTop;
        posLeft -= document.getElementById("scroll").scrollLeft;
    }catch(e){

    }
    
    var iFrameHeight = height;
    var iFrameWidth = width;
    var popupDivId = name;
    var url="/webdesktop/components/picklist/expertisepicklist.app?Action=1&WD_SID="+WD_SID+"&strFormFieldText="+nameCtrl+"&strFormFieldTextHidden="+hidNameCtrl+"&PopupDivId="+popupDivId+"&DivId="+divId+"&CallBack="+strCallback+"&strFormFieldID="+hidIdCtrl+"&Width="+iFrameWidth+"&Height="+iFrameHeight;

    popupWInRef.popupIFrameOpenerWrapper(this, popupDivId, url, iFrameWidth, iFrameHeight, posLeft, posTop, false, true, false, true);
}

function numberLenValidation(ref,e,option){
    var evtObj = window.event || e;
    var KeyID = evtObj.keyCode || evtObj.which;
    if (KeyID >=48 && KeyID <58)
    {
        var num;
        num=document.getElementById(ref.id).value;
        num+=''+String.fromCharCode(KeyID)
        if(!isNaN(num)){
            if(option == 1){// for days
                if(num>500 || num<0){
                    document.getElementById(ref.id).value="";
                    document.getElementById(ref.id).focus();
                    var messageWidth = 260;
                    var left = (document.documentElement.clientWidth - messageWidth) / 2;
                    notifierAbs('notifier', VALUE_MUST_LIE_IN_THE_RANGE_DAYS, "absolute", true, left, 10);
                    return false;
                }
            }else if(option == 2){// for Hours
                if(num>24 || num<0){
                    document.getElementById(ref.id).value="";
                    document.getElementById(ref.id).focus();
                    var messageWidth = 260;
                    var left = (document.documentElement.clientWidth - messageWidth) / 2;
                    notifierAbs('notifier', VALUE_MUST_LIE_IN_THE_RANGE_HRS, "absolute", true, left, 10);
                    return false;
                }
            }else if(option == 3){// for Minutes
                if(num>60 || num<0){
                    document.getElementById(ref.id).value="";
                    document.getElementById(ref.id).focus();
                    var messageWidth = 260;
                    var left = (document.documentElement.clientWidth - messageWidth) / 2;
                    notifierAbs('notifier', VALUE_MUST_LIE_IN_THE_RANGE_MINS, "absolute", true, left, 10);
                    return false;
                }
            }
        }else{
            document.getElementById(ref.id).value="";
            document.getElementById(ref.id).focus();
            var messageWidth = 260;
            var left = (document.documentElement.clientWidth - messageWidth) / 2;
            notifierAbs('notifier', VALUE_MUST_LIE_IN_THE_RANGE, "absolute", true, left, 10);
            return false;
        }
    }
    else{
        return false;
    }
   return true;
}
function openWinCaseSubProcess(pid,wid,activityType){

        var wiWindowRef = null;

        
        var listParam=new Array();

        var scrHeight;
        var WinHeight = window.screen.availHeight-60.01;

        var url='/webdesktop/components/workitem/view/workdesk.app';
        var wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+window.screen.availWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
        var winWidth = window.screen.availWidth-10.01;
        var wdWidth=0;
        if(wdWidth!='0' && wdWidth<=window.screen.availWidth){
            scrHeight=window.screen.availHeight-15;
            winWidth = wdWidth;
            wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+winWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
        }
        else
        {
            scrHeight = window.screen.availHeight;
            wFeatures = 'status=yes,resizable=no,scrollbars=yes,width='+winWidth+',height='+WinHeight+',left=0,top=0,resizable=yes,scrollbars=yes';
        }

        
        listParam.push(new Array('ProcessInstanceID',pid));                
        listParam.push(new Array('WorkitemID',encode_ParamValue(wid)));
        listParam.push(new Array('Comp_height',encode_ParamValue(scrHeight)));
        listParam.push(new Array('Comp_width',encode_ParamValue(winWidth)));
        listParam.push(new Array('Option',encode_ParamValue('OPENWI')));
        listParam.push(new Array('IsOpenedFromSubProcess',encode_ParamValue('Y')));//Bug 72360
        if(activityType=='32'){
            listParam.push(new Array('ActivityType',encode_ParamValue('32')));
            listParam.push(new Array('QueueType',encode_ParamValue('U')));
        }


        var wiWinInfo = null;
        var winObj = null;
        wiWinInfo = getNextWiWinInfo(pid, wid);
        if (wiWinInfo == null)
        {
           // If workitem is clicked and this workitem is previously not opened, then find the current window info.     
            wiWinInfo = findDefaultWdeskWinInfo();
        }
        var uniqueId = null;
        if(wiWinInfo!=null){   
        wiWinInfo.PId = pid;
            wiWinInfo.WId = wid; 
//            wiWinInfo.ActId = activityId;
//            wiWinInfo.PDefId = pDefId;
//            wiWinInfo.QueueId = qDefId;
//            wiWinInfo.OpenFrom = openFrom;
            winObj = wiWinInfo.WinRef;

            var queryString = "";
            for(var iCount=0;iCount<listParam.length;iCount++) {
                var param = listParam[iCount];
                queryString += param[0] + "=" + param[1] + "&";
            }            
            queryString += "Action="+encode_ParamValue('1');            

            winObj.focus();
            winObj.initNLoadWorkitem(getWDJason(queryString));
    
        }
        else{
            listParam.push(new Array('Action',encode_ParamValue('1')));
            uniqueId = MakeUniqueNumber();
            wiWindowRef = openNewWindow(url, uniqueId,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);

            wiWinInfo = {
                "PId" : pid,
                "WId" : wid,
                "WinName" : uniqueId,
                "WinRef" : wiWindowRef
            };

            wiWinInfoMap.put(uniqueId, wiWinInfo);
            wiWindowRef.focus();
        }   
}

// ---------------- Detect browser download finish -----------------------
function getCookie( name ) {
  var parts = document.cookie.split(name + "=");
  if (parts.length == 2) {
      return parts.pop().split(";").shift();
  }
}

function expireCookie( cName ) {
    document.cookie = encodeURIComponent(cName) + "=deleted; expires=" + new Date( 0 ).toUTCString();
}

function setFormToken(dtName) {
    var downloadToken = new Date().getTime();
    document.getElementById(dtName).value = downloadToken;
    return downloadToken;
}

var downloadTimer;
var attempts = 30;

// Prevents double-submits by waiting for a cookie from the server.
function downloadHandler(dtName) {
    var downloadToken = setFormToken(dtName);    
    
    downloadTimer = window.setInterval( function() {
        var token = getCookie(dtName);
        
        if( (token == downloadToken) || (attempts == 0) ) {
            unblockSubmit(dtName);
        }

        attempts--;
    }, 500 );
    
    if(typeof onDownload != 'undefined'){
        onDownload('begin');
    }
}

function unblockSubmit(dtName) {  
  window.clearInterval( downloadTimer );
  expireCookie(dtName);
  attempts = 30;
  
  if(typeof onDownload != 'undefined'){
      onDownload('finish');
  }
}

function openTaskRuleDefinitionMgmt(ref,mode,hidselectedrowindex)
{
    var refID = ref.id.split(':');
    //var elementID = refID[0]+':'+refID[1]+':'+refID[2];
    var selectedRowIndex = -1;
    var callFrom;
    if(hidselectedrowindex != ''){
        if(document.getElementById("addTask:"+hidselectedrowindex) != null){
        selectedRowIndex = document.getElementById("addTask:"+hidselectedrowindex).value;
        callFrom = '2';//call from task
        }else if(document.getElementById("editGlobalTemplate:"+hidselectedrowindex)!=null){
        selectedRowIndex = document.getElementById("editGlobalTemplate:"+hidselectedrowindex).value;
        callFrom = '1';//callfrom globaltemplate
        }
    }
    var url="/webdesktop/components/task/";
    url+= "taskRuleDefinition.app?Action="+callFrom+"&Mode="+mode;
    url = url +"&SelectedRowIndex="+selectedRowIndex+"&WD_SID="+WD_SID;


    var WindowHeight=windowH-100;
    var WindowWidth=windowW+200;
    //url = appendUrlSession(url);
   // window.opener.createPopUpIFrameWrapperInContainer("RuleDefMgmtFrame",url,WindowHeight,WindowWidth);
    popupIFrameOpenerWrapper(this,'RuleDefMgmtFrame',url,WindowWidth,WindowHeight,40,100,false,true,false,true);
}
//function cancelBubble(event){
//    if(event.stopPropagation)
//               {
//                   event.stopPropagation();
//                   event.preventDefault();
//               }
//               else
//               {
//                   event = window.event;
//                   event.cancelBubble = true;
//               }
//        }

// ------------------------------------------

function callCustomPickList(ref,procfilterData,selectedVarName,selectedVarType,selProcessName, selActivityName, selQueueName, selProcessId, selActivityId, selQueueId) {
    var arr = ref.id.split(":");
    var len = arr.length;
    var strName = "";
    for(var count=0;count<len-1;count++){
        if(count==0)
            strName = arr[count] ;
        else
        {
            strName=strName + ":" + arr[count] ;
        }
    }
    
    var strProcfilterData = strName+":"+procfilterData;
    var strVarName = strName+":"+selectedVarName;
    var strVarType =  strName+":"+selectedVarType;

    showPickList(strProcfilterData, strVarName, strVarType, selProcessName, selActivityName, selQueueName, selProcessId, selActivityId, selQueueId);
}

function SearchWorkitemWrapper(comp_ins_id, jsonoutput){
    var queueId,processDefId,mode,orderBy,filterString,output,defId,value;    
    var opJson = JSON.parse(jsonoutput);   
    
    for(var i = 0; i< opJson.Outputs.length; i++){
        output=opJson.Outputs[i].Output;
        defId=output.DefId;
        value=output.Value;

        switch(defId){
            case "1":
                    filterString = value;
                    break;
            case "2":
                    queueId = value;
                    break;
            case "3":
                    processDefId = value;
                    break;
            case "4":
                    //mode = value;
                    mode = "PM";
                    break;
            case "5":
                    orderBy = value;
                    break;        
            default:
        }
    }
    
    try{
        if(window.parent.iFrameWorkitemListRef.document.getElementById('wlf:queueSelect')){
            window.parent.iFrameWorkitemListRef.document.getElementById('wlf:queueSelect').value = "S";
        }
        
        window.parent.iFrameWorkitemListRef.SearchWorkitem(queueId,processDefId,mode,orderBy,filterString,comp_ins_id);
    } catch(e){        
    }

}

function SetDateOptionForExit(value){
   
    if(value==10){
        if(document.getElementById('frmsearchworkitem:completedBtwCheckBox')!=undefined && document.getElementById('frmsearchworkitem:completedBtwCheckBox')!=null){
               if(document.getElementById('frmsearchworkitem:excludeExitChkBox').checked==true){
                           document.getElementById('frmsearchworkitem:completedBtwCheckBox').checked=false;
                           EnableDisableCompletedDate(false);
               }
               else{
                   if(document.getElementById('frmsearchworkitem:createdBtwCheckBox').checked==false && document.getElementById('frmsearchworkitem:introBtwCheckBox').checked==false){
                    EnableDisableCompletedDate(true);
                }
               }
               
                
            }
    }
    
}



function EnableDisableExcludeExitWorkitem(value)
{
    if(value){
        document.getElementById("frmsearchworkitem:excludeExitChkBox").checked=false;
       // document.getElementById("frmsearchworkitem:excludeExitChkBox").disabled=true;
        
    }else{
        document.getElementById("frmsearchworkitem:excludeExitChkBox").disabled=false;
    }

}

String.prototype.trimEx = function () {
    return this.replace(/(\r\n|\n|\r)/gm, '');
}

function wehw(strFormName,rowCount){
    if(strFormName == 1){
        strFormName = "wlf";
    } else {
        strFormName = "frmlinkedworkitemlist";
    }
    var hjn = document.getElementById(strFormName+":hjn"+(rowCount+1));
    if(hjn){
        hjn = hjn.innerHTML;
        var trimRegEx = /(\r\n|\n|\r)/gm; 
        var p = hjn.split(SEPERATOR1+SEPERATOR4);
        
        var wlistEJson= "{\"Outputs\":[{\"Output\":{\"Name\":\"WorkitemID\",\"Value\":\""+p[0].replace(trimRegEx, "")+"\",\"DefId\":\"1\"}},"+
                        "{\"Output\":{\"Name\":\"WorkitemName\",\"Value\":\""+p[1]+"\",\"DefId\":\"2\"}},"+
                        "{\"Output\":{\"Name\":\"WorkitemState\",\"Value\":\""+p[2]+"\",\"DefId\":\"3\"}},"+
                        "{\"Output\":{\"Name\":\"ProcessInstanceID\",\"Value\":\""+p[3]+"\",\"DefId\":\"4\"}},"+
                        "{\"Output\":{\"Name\":\"ProcessInstanceState\",\"Value\":\""+p[4]+"\",\"DefId\":\"5\"}},"+
                        "{\"Output\":{\"Name\":\"RouteId\",\"Value\":\""+p[5]+"\",\"DefId\":\"6\"}},"+
                        "{\"Output\":{\"Name\":\"RouteName\",\"Value\":\""+p[6]+"\",\"DefId\":\"7\"}},"+
                        "{\"Output\":{\"Name\":\"ActivityName\",\"Value\":\""+p[7]+"\",\"DefId\":\"8\"}},"+
                        "{\"Output\":{\"Name\":\"ActivityType\",\"Value\":\""+p[8]+"\",\"DefId\":\"9\"}},"+
                        "{\"Output\":{\"Name\":\"WorkstageId\",\"Value\":\""+p[9]+"\",\"DefId\":\"10\"}},"+
                        "{\"Output\":{\"Name\":\"QueueType\",\"Value\":\""+p[10]+"\",\"DefId\":\"11\"}},"+
                        "{\"Output\":{\"Name\":\"QueueName\",\"Value\":\""+p[11]+"\",\"DefId\":\"12\"}},"+
                        "{\"Output\":{\"Name\":\"QueueId\",\"Value\":\""+p[12]+"\",\"DefId\":\"13\"}},"+
                        "{\"Output\":{\"Name\":\"AssignedTo\",\"Value\":\""+p[13]+"\",\"DefId\":\"14\"}},"+
                        "{\"Output\":{\"Name\":\"AssignmentType\",\"Value\":\""+p[14]+"\",\"DefId\":\"15\"}},"+
                        "{\"Output\":{\"Name\":\"ChecklistComplete\",\"Value\":\""+p[15]+"\",\"DefId\":\"16\"}},"+
                        "{\"Output\":{\"Name\":\"LockStatus\",\"Value\":\""+p[16]+"\",\"DefId\":\"17\"}},"+
                        "{\"Output\":{\"Name\":\"LockedTime\",\"Value\":\""+p[17]+"\",\"DefId\":\"18\"}},"+
                        "{\"Output\":{\"Name\":\"LockedBy\",\"Value\":\""+p[18]+"\",\"DefId\":\"19\"}},"+
                        "{\"Output\":{\"Name\":\"IntroducedBy\",\"Value\":\""+p[19]+"\",\"DefId\":\"20\"}},"+
                        "{\"Output\":{\"Name\":\"IntroductionOn\",\"Value\":\""+p[20]+"\",\"DefId\":\"21\"}},"+
                        "{\"Output\":{\"Name\":\"EntryDateTime\",\"Value\":\""+p[21]+"\",\"DefId\":\"22\"}},"+
                        "{\"Output\":{\"Name\":\"ExpiredDateTime\",\"Value\":\""+p[22]+"\",\"DefId\":\"23\"}},"+
                        "{\"Output\":{\"Name\":\"InstrumentStatus\",\"Value\":\""+p[23]+"\",\"DefId\":\"24\"}},"+
                        "{\"Output\":{\"Name\":\"PriorityLevel\",\"Value\":\""+p[24]+"\",\"DefId\":\"25\"}},"+
                        "{\"Output\":{\"Name\":\"ReferredTo\",\"Value\":\""+p[25]+"\",\"DefId\":\"26\"}},"+
                        "{\"Output\":{\"Name\":\"ReferredBy\",\"Value\":\""+p[26]+"\",\"DefId\":\"27\"}},"+
                        "{\"Output\":{\"Name\":\"ProcessedBy\",\"Value\":\""+p[27]+"\",\"DefId\":\"28\"}},"+
                        "{\"Output\":{\"Name\":\"wi_count\",\"Value\":\""+p[28]+"\",\"DefId\":\"29\"}},"+
                        "{\"Output\":{\"Name\":\"wlSortOrder\",\"Value\":\""+p[29]+"\",\"DefId\":\"30\"}},"+
                        "{\"Output\":{\"Name\":\"wlOrderBy\",\"Value\":\""+p[30]+"\",\"DefId\":\"31\"}},"+
                        "{\"Output\":{\"Name\":\"wlSortLastValue\",\"Value\":\""+p[31]+"\",\"DefId\":\"41\"}},"+
                        "{\"Output\":{\"Name\":\"allowreassignment\",\"Value\":\""+p[32]+"\",\"DefId\":\"32\"}},"+
                        "{\"Output\":{\"Name\":\"InstrumentListCallFlag\",\"Value\":\""+p[33]+"\",\"DefId\":\"33\"}},"+
                        "{\"Output\":{\"Name\":\"ArchivalMode\",\"Value\":\""+p[34]+"\",\"DefId\":\"34\"}},"+
                        "{\"Output\":{\"Name\":\"ProcessInstanceIDEnc\",\"Value\":\""+p[35]+"\",\"DefId\":\"35\"}},"+
                        "{\"Output\":{\"Name\":\"CreationDateTime\",\"Value\":\""+p[36]+"\",\"DefId\":\"39\"}},"+
                        "{\"Output\":{\"Name\":\"URN\",\"Value\":\""+p[37]+"\",\"DefId\":\"40\"}}]}";
                    
        WorkitemEventHandler('1',strFormName,rowCount,'WorkitemClick',wlistEJson,p[34]);
    }
}
var Initiate=0,Hold=1,Unhold=2,Delete=3,Reassign=4,Properties=5,Done=6,Refer=7,Revoke=8,Priority=9,Reminder=10,LockForMe=11,UnAssign=12;

function getOuterHeight(el) {
    var height = 0;
    if(el != null){
      height = el.offsetHeight;
      height += (el.style.marginLeft-0)+(el.style.marginRight-0);
    }
  return height;
}

function getRealDimension(ref, iMargin) {
    if (ref == null) {
        return {"Width": 0, "Height": 0, "BorderWidth": 1, "BorderColor": '#d7d7d7', "MarginTop": 0, "MarginBottom": 0, "MarginLeft": 0, "MarginRight": 0, "PH": 0, "MH": 0};
    }

    iMargin = (typeof iMargin == 'undefined') ? false : iMargin;

    var style = null;
    if (window.getComputedStyle) {
        style = window.getComputedStyle(ref);
    } else if (ref.currentStyle) {
        style = ref.currentStyle;
    }
    if (style != null) {
        var marginH = 0, ml = 0, mr = 0;
        ml = parseFloat(style.marginLeft);
        mr = parseFloat(style.marginRight);
        if (iMargin) {
            marginH = ml + mr;
        }

        var paddingH = 0, borderH = 0, width = 0, borderWidth = 1, borderColor = '#d7d7d7';
        if (style.boxSizing == 'content-box') {
            paddingH = parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
            borderH = parseFloat(style.borderLeftWidth) + parseFloat(style.borderRightWidth);
        }
        borderWidth = parseInt(style.borderLeftWidth);
        borderColor = style.borderLeftColor;

        if (ref.currentStyle) {
            if ((ref.currentStyle.width.indexOf('%') < 0) && (ref.currentStyle.width.indexOf('auto') < 0)) {
                width = parseFloat(ref.currentStyle.width);
            } else {
                width = parseFloat(style.width);
            }
        } else {
            width = parseFloat(style.width);
        }

        var realWidth = width + paddingH + borderH + marginH;

        if (style.boxSizing != 'content-box') {
            paddingH = parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
        }

        var marginV = 0, mt = 0, mb = 0;
        mt = parseFloat(style.marginTop);
        mb = parseFloat(style.marginBottom);
        if (iMargin) {
            marginV = mt + mb;
        }

        var paddingV = 0, borderV = 0, height = 0, heightUnit = null;
        if (style.boxSizing == 'content-box') {
            paddingV = parseFloat(style.paddingTop) + parseFloat(style.paddingBottom);
            borderV = parseFloat(style.borderTopWidth) + parseFloat(style.borderBottomWidth);
        }

        if (ref.currentStyle) {
            if ((ref.currentStyle.height.indexOf('%') < 0) && (ref.currentStyle.height.indexOf('auto') < 0)) {
                height = parseFloat(ref.currentStyle.height);
            } else {
                height = parseFloat(style.height);
            }
        } else {
            if (style.height.indexOf('%') > -1) {
                heightUnit = '%';
            }

            height = parseFloat(style.height);
        }
    }
    var realHeight = height + paddingV + borderV + marginV;

    return {"Width": Math.floor(realWidth), "Height": Math.floor(realHeight), "HeightUnit": heightUnit, "BorderWidth": borderWidth, "BorderColor": borderColor, "MarginTop": mt, "MarginBottom": mb, "MarginLeft": ml, "MarginRight": mr, "PH": paddingH, "MH": ml + mr};
}

function showOAPItemMenu(srcRef,itemListRef,iframeRef,isOAPMenuOpt,repaintItems,left,top,bCenter){
    isOAPMenuOpt = (typeof isOAPMenuOpt == 'undefined')? false: isOAPMenuOpt;
    repaintItems = (typeof repaintItems == 'undefined')? false: repaintItems;
    left = (typeof left == 'undefined')? 0: left;
    top = (typeof top == 'undefined')? 0: top;
    bCenter = (typeof bCenter == 'undefined')? false: bCenter;
    
    if(isOAPMenuOpt){
        window.parent.showOAPItemMenu(srcRef,itemListRef,iframeRef,repaintItems,left,top,bCenter);
    } else {
        //window.hideOAPMenu(srcRef,itemListRef,iframeRef,repaintItems);
    }                
}

function hideAllOAPItemPMenu(exceptThis, srcRef){
     window.parent.hideAllOAPMenu(exceptThis, srcRef);
}

function isOAPItemMenuVisible(thisRef){
    return window.parent.isOAPItemMenuVisible(thisRef);
}

function initFlexMenu(isOAPMenuOpt, showOnlyVisible, controlFree){
    isOAPMenuOpt = (typeof isOAPMenuOpt == 'undefined')? false: isOAPMenuOpt;
    controlFree = (typeof controlFree == 'undefined')? false: controlFree;
    showOnlyVisible = (typeof showOnlyVisible == 'undefined')? false: showOnlyVisible;  // If true will show element with style.display!='none'
    var srcollMRef = null;
    var srcollMRefList = document.getElementsByClassName("oa-fmenu-w");
    
    if(srcollMRefList){
        var  srcollMIdValid = true, pRealWidth = 0;
        for(var m=0; m<srcollMRefList.length; m++){
            srcollMRef = srcollMRefList[m];
            
            srcollMIdValid = !((typeof srcollMRef.id=='undefined') || (srcollMRef.id=='') || (srcollMRef.id==null));            
            if(!srcollMIdValid){
                continue;
            }
            
            var pContRef = getRealDimension(srcollMRef);
            pRealWidth = pContRef.Width-pContRef.PH;
            
            if(isNaN(pRealWidth)){
                continue;
            }

            if(srcollMRef.children.length > 0){
                var optMRef = srcollMRef.getElementsByClassName('oa-fmenu-opt')[0];
                optMRef.setAttribute('OAPMenuOpt',isOAPMenuOpt);
                optMRef.setAttribute('mid',srcollMRef.id+'opt');  // Menu options div id
                
                var optMWidth = getRealDimension(optMRef,true).Width;
                var marginWrap = 3;
                pRealWidth -= optMWidth+marginWrap;

                var childCount = srcollMRef.children.length-1;            
                var fitChildCount=0,cRealWidth=0;
                var vChileCount = 0;
                                
                for(var i=0; i<childCount; i++){
                    if(srcollMRef.children[i].style.display != 'none' || !showOnlyVisible){
                        cRealWidth += getRealDimension(srcollMRef.children[i],true).Width;
                        
                        if(cRealWidth<pRealWidth){
                            srcollMRef.children[i].style.display = "";
                            removeCSS(srcollMRef.children[i], "h");
                            addCSS(srcollMRef.children[i], "v");
                            fitChildCount++;                    
                        } else {
                            srcollMRef.children[i].style.display = "none";  
                            removeCSS(srcollMRef.children[i], "v");
                            addCSS(srcollMRef.children[i], "h");
                        }

                        removeCSS(srcollMRef.children[i], "last");
                        vChileCount++;
                    } else {
                        removeCSS(srcollMRef.children[i], "v");
                        removeCSS(srcollMRef.children[i], "h");
                    }
                }

                if((vChileCount > fitChildCount) && (fitChildCount > 0 || !showOnlyVisible)){                
                    optMRef.style.display = "";
                    addCSS(optMRef, "last");
                } else {
                    optMRef.style.display = "none";
                    removeCSS(optMRef, "last");
                    if(fitChildCount>0){
                        addCSS(srcollMRef.children[fitChildCount-1], "last");
                    }
                }
                
                try {
                    if(isOAPMenuOpt){
                        window.parent.hideOAPMenu(srcollMRef.id+'opt');
                    } else {
                        window.parent.hideOAPMenu(srcollMRef.id+'opt',(window.frameElement || window).id);
                    }                
                } catch(e) {
                }
            }
        }
    }
}

function showFlexMenu(e,handler,mclass){
    var ref = null, srcollMRef = null;
    mclass = (typeof mclass == 'undefined')? '': mclass;
    
    if((typeof e == 'undefined') || (e == null)){ 
        ref = null;
    } else {
        e = e || window.event;
        ref = e.target || e.srcElement;
    }

    if(ref != null){
        srcollMRef = ref.parentNode;
    }
    
    if(ref && (ref.style.display != 'none')){
        // Finds parent scrollable Menu div
        while(srcollMRef){ 
            if(srcollMRef.nodeName.toUpperCase() == "DIV"){
                if(hasCSS(srcollMRef, 'oa-fmenu-w')){
                    break;
                }
            }            
            srcollMRef = srcollMRef.parentNode;
        }
        
        var isOAPMenuOpt = ref.getAttribute('OAPMenuOpt');
        isOAPMenuOpt = (isOAPMenuOpt == 'true');
        
        var rd = getRealDimension(ref);        
        var left = 0;
        
        if(isOAPMenuOpt){
            left = findAbsPosX(ref)+rd.Width;
        } else {
            left = findPosX(ref)+rd.Width;
        }
        
        var top = 0;
        if(isOAPMenuOpt){
            top = findAbsPosY(ref)+rd.Height-1;
        } else {
            top = findPosY(ref)+rd.Height-1;
        }
        
        var mItemsJson={};
        mItemsJson["Items"]=[];
        
        if(srcollMRef){
            if(srcollMRef.children.length > 0){                                
                var childCount = srcollMRef.children.length;               
                var paramRef=null, fmlbl = null, icon = null,showedit=null;
                for(var i=0,j=0; i<childCount; i++){
                    if(mclass.length>0){
                        if(hasCSS(srcollMRef.children[i], mclass)){
                            mItemsJson["Items"][j]={};
                            mItemsJson["Items"][j]["Id"]=srcollMRef.children[i].id;
                            
                            fmlbl = srcollMRef.children[i].getElementsByClassName("fmlbl");
                            if(fmlbl){
                                fmlbl = fmlbl[0];
                                if(fmlbl){
                                    mItemsJson["Items"][j]["Label"]=fmlbl.innerHTML.replace(/(\r\n|\n|\r)/gm, "");
                                }
                            }
                            
                            icon = srcollMRef.children[i].getElementsByClassName("i");
                            if(icon){
                                icon=icon[0];
                                if(icon){
                                    mItemsJson["Items"][j]["Icon"] = icon.className;
                                }
                            }
                            
                            paramRef = srcollMRef.children[i].getElementsByClassName("fmpid");
                            if(paramRef != null && paramRef[0]){
                                mItemsJson["Items"][j]["Param"]=srcollMRef.children[i].getElementsByClassName("fmpid")[0].value.replace(/(\r\n|\n|\r)/gm, "");
                            }
                            showedit = srcollMRef.children[i].getElementsByClassName("fmqt");
                            if(showedit){
                                showedit=showedit[0];
                                if(showedit){
                                    mItemsJson["Items"][j]["editShow"] = showedit.value;
                                }
                            }
                            
                            
                            j++;
                        }
                    } else {                    
                        if(srcollMRef.children[i].style.display=='none'){
                            mItemsJson["Items"][j]={};
                            mItemsJson["Items"][j]["Id"]=srcollMRef.children[i].getElementsByClassName("fmuid")[0].value-0;
                            mItemsJson["Items"][j]["Label"]=srcollMRef.children[i].getElementsByClassName("fmlbl")[0].innerHTML.replace(/(\r\n|\n|\r)/gm, "");
                            
                            paramRef = srcollMRef.children[i].getElementsByClassName("fmpid");
                            if(paramRef != null && paramRef[0]){
                                mItemsJson["Items"][j]["Param"]=srcollMRef.children[i].getElementsByClassName("fmpid")[0].value.replace(/(\r\n|\n|\r)/gm, "");
                            }
                            showedit = srcollMRef.children[i].getElementsByClassName("fmqt");
                            if(showedit){
                                showedit=showedit[0];
                                if(showedit){
                                    mItemsJson["Items"][j]["editShow"] = showedit.value;
                                }
                            }
                            j++;
                        }   
                    }
                }
            }
        }
        
        if(mItemsJson["Items"].length > 0){
            mItemsJson["Handler"]=handler;
            var mid = srcollMRef.id+'opt';
            
            if(window.addEventListener){
                window.addEventListener("click",function (e) {
                    e = e || window.event;
                    var ref = e.target || e.srcElement;
                    var mid = null;
                    if(hasCSS(ref, 'mcc')){
                        mid = ref.getAttribute('mid');
                        if(mid){
                            var mDiv=window.parent.document.getElementById(mid);
                            window.parent.hideAllOAPMenu(mDiv);
                        }
                    } else {
                        window.parent.hideAllOAPMenu();
                    }
                },false);                
            } else if(window.attachEvent) {
                window.attachEvent("onclick",function (e) {
                    e = e || window.event;
                    var ref = e.target || e.srcElement;
                    var mid = null;
                    if(hasCSS(ref, 'mcc')){
                        mid = ref.getAttribute('mid');
                        if(mid){
                            var mDiv=window.parent.document.getElementById(mid);
                            window.parent.hideAllOAPMenu(mDiv);
                        }
                    } else {
                        window.parent.hideAllOAPMenu();
                    }
                });
            }
            
            if(isOAPMenuOpt){
                if(pageDirection == 'rtl' && srcollMRef.id == 'wlf:scrollQueryList'){ 
                          left=left+80;
                }
                window.parent.showOAPFlexMenu(window.frameElement.id,mid,JSON.stringify(mItemsJson),isOAPMenuOpt,left,top,true);            
            } else {
                showOAPFlexMenu((window.frameElement || window).id,mid,mItemsJson,isOAPMenuOpt,left,top,true);            
            }
        }
    }
}

function initFlexCombo(isOAPMenuOpt, maxCmenuOptHt, isNative,lazyLoad){
    isOAPMenuOpt = (typeof isOAPMenuOpt == 'undefined')? false: isOAPMenuOpt;
    maxCmenuOptHt = (typeof maxCmenuOptHt == 'undefined' || maxCmenuOptHt==null)? 0: maxCmenuOptHt;    
    isNative = (typeof isNative == 'undefined' || isNative==null)? true: isNative;
    lazyLoad = (typeof lazyLoad == 'undefined' || lazyLoad==null)? true: lazyLoad;
    var cmenuList = document.getElementsByClassName("oa-cmenu-s");
    
    window.parent.hideAllOAPMenu();
    
    if(cmenuList){
        var  cmenuIdValid = true, ncombo = null, ncomboParent=null;
                
        for(var m=0; m<cmenuList.length; m++){
            ncombo = cmenuList[m];
            
            if(ncomboParent != ncombo.parentNode){
                ncomboParent = ncombo.parentNode;
                ncomboParent.className="oa-cmenu-w";
            }
                        
            cmenuIdValid = !((typeof ncombo.id=='undefined') || (ncombo.id=='') || (ncombo.id==null));            
            if(!cmenuIdValid){
                continue;
            }
            
            initComboMenuSelector(ncombo, maxCmenuOptHt, isNative,lazyLoad);
        }
                
        var srcollMRefList = document.getElementsByClassName("oa-cmenu-w");        
        if(srcollMRefList){
            var srcollMRef = null;
            
            for(var m=0; m<srcollMRefList.length; m++){
                srcollMRef = srcollMRefList[m];                
                var pRealWidth = getRealDimension(srcollMRef).Width;
                
                var childCount = srcollMRef.children.length;            
                var fitChildCount=0,cRealWidth=0;

                for(var i=0; i<childCount; i++){
                    if(srcollMRef.children[i].style.display.indexOf('none')<0){
                        cRealWidth += getRealDimension(srcollMRef.children[i],true).Width;

                        if(cRealWidth<pRealWidth){
                            srcollMRef.children[i].style.display = "";
                            fitChildCount++;                    
                        } else {
                            //srcollMRef.children[i].style.display = "none";                    
                        }
                    }
                }
            }
        }
        
    }
}

function initComboMenuSelector(ncombo,maxCmenuOptHt,isNative,lazyLoad){
    var cmenuRealDm=getRealDimension(ncombo);    
    // Hiding native combo
    var ncomboDisplay = ncombo.style.display;
    ncombo.style.display='none';
    
    var cmenuOptId = ncombo.id+"opt";   // Menu options div id
    var cmenuDiv=document.getElementById(ncombo.id+"cm"); // Menu controller
    
    if(cmenuDiv == null){
        cmenuDiv=document.createElement("div");
        cmenuDiv.setAttribute('id',ncombo.id+'cm'); // native combo id
        cmenuDiv.setAttribute('mid',cmenuOptId); 
        cmenuDiv.setAttribute('cid',ncombo.id); // native combo id
        cmenuDiv.setAttribute('sid',ncombo.selectedIndex); // native combo selected index
        cmenuDiv.className="oa-cmenu"; 
        
        if(hasCSS(ncombo,'oa-group')){
            cmenuDiv.className+=" oa-group";
        }

        var rd = null;
        cmenuDiv.onclick=function(e){
            var ncomboId = this.getAttribute('cid');
            var cmOptId = this.getAttribute('mid');
            rd = getRealDimension(this);        
            var left = findAbsPosX(this);//+rd.Width;
            var top = findAbsPosY(this)+rd.Height-rd.BorderWidth;
            window.parent.showOAPFlexComboMenu(window.frameElement.id,cmOptId,ncomboId,cmenuRealDm.Width,maxCmenuOptHt,left,top,true,rd.Width);            
        }
        
        if(!lazyLoad){
            rd = getRealDimension(cmenuDiv);  
            window.parent.showOAPFlexComboMenu(window.frameElement.id,cmenuOptId,ncombo.id,cmenuRealDm.Width,maxCmenuOptHt,-10000,-10000,true,rd.Width);            
        }

        ncombo.parentNode.insertBefore(cmenuDiv, ncombo.nextSibling);

        var label=document.createElement("span");
        label.setAttribute('mid',cmenuOptId);
        label.className='mcc';
        label.style.height=cmenuRealDm.Height-2*cmenuRealDm.BorderWidth+(cmenuRealDm.HeightUnit==null?"px":cmenuRealDm.HeightUnit);
        label.style.lineHeight=cmenuRealDm.Height-2*cmenuRealDm.BorderWidth+(cmenuRealDm.HeightUnit==null?"px":cmenuRealDm.HeightUnit);
        if(ncombo.options[ncombo.selectedIndex]){
            label.innerHTML = encode_ParamValue(ncombo.options[ncombo.selectedIndex].text);
        }
        cmenuDiv.appendChild(label);

        var handle=document.createElement("span");
        handle.setAttribute('mid',cmenuOptId);
        handle.className='mcc';
        cmenuDiv.appendChild(handle);
        
        if(isNative){
            cmenuDiv.style.borderColor=ncombo.style.borderColor;
        } else {
            cmenuDiv.style.borderColor=cmenuRealDm.BorderColor;
        }
        
        cmenuDiv.style.borderWidth=cmenuRealDm.BorderWidth+'px';
        
        if(window.addEventListener){
            window.addEventListener("click",function (e) {
                e = e || window.event;
                var ref = e.target || e.srcElement;
                var mid = null;
                if(hasCSS(ref, 'mcc')){
                    mid = ref.getAttribute('mid');
                    if(mid){
                        var mDiv=window.parent.document.getElementById(mid);
                        window.parent.hideAllOAPMenu(mDiv);
                    }
                } else {
                    window.parent.hideAllOAPMenu();
                }
            },false);                
        } else if(window.attachEvent) {
            window.attachEvent("onclick",function (e) {
                e = e || window.event;
                var ref = e.target || e.srcElement;
                var mid = null;
                if(hasCSS(ref, 'mcc')){
                    mid = ref.getAttribute('mid');
                    if(mid){
                        var mDiv=window.parent.document.getElementById(mid);
                        window.parent.hideAllOAPMenu(mDiv);
                    }
                } else {
                    window.parent.hideAllOAPMenu();
                }
            });
        }
    } else {
        cmenuDiv.setAttribute('sid',ncombo.selectedIndex); // native combo selected index
        
        if(ncombo.options[ncombo.selectedIndex]){
            cmenuDiv.children[0].innerHTML = encode_ParamValue(ncombo.options[ncombo.selectedIndex].text);
        }
    }
    
    if(isNative){
        cmenuDiv.style.width=cmenuRealDm.Width+"px";
        cmenuDiv.style.height=cmenuRealDm.Height+(cmenuRealDm.HeightUnit==null?"px":cmenuRealDm.HeightUnit);    
        ncombo.style.height=cmenuDiv.style.height; // IE issue with style.height -> 100% fix
    }
    
    cmenuDiv.style.marginLeft=cmenuRealDm.MarginLeft+'px';
    cmenuDiv.style.marginRight=cmenuRealDm.MarginRight+'px';
    cmenuDiv.style.marginTop=cmenuRealDm.MarginTop+'px';
    cmenuDiv.style.marginBottom=cmenuRealDm.MarginBottom+'px';
    
    if(ncomboDisplay.indexOf('none')<0){
        cmenuDiv.style.display = '';
    } else {
        var bShow = hasCSS(ncombo,'oa-cmenu-show');
        var bHide = hasCSS(ncombo,'oa-cmenu-hide');
        if(bShow || !bHide){
            cmenuDiv.style.display = '';
        } else {
            cmenuDiv.style.display = 'none';
        }
    }    
    
    return cmenuDiv;
}

function fireEvent(element,event){
    if (document.createEventObject){
        // dispatch for IE
        var evt = document.createEventObject();
        return element.fireEvent('on'+event,evt)
    }
    else{
        // dispatch for firefox + others
        var evt = document.createEvent("HTMLEvents");
        evt.initEvent(event, true, true ); // event type,bubbling,cancelable
        return element.dispatchEvent(evt);
    }
}

function hideAllMenu(ref){
    if(ref && ref.parentNode){
        if(hasCSS(ref, 'mcc')){
            var mid = ref.parentNode.getAttribute('mid');
            if(mid){
                var mDiv=document.getElementById(mid);
                hideAllOAPMenu(mDiv);
            }
        } else {
            hideAllOAPMenu();
        }
    } else {
        hideAllOAPMenu();
    }
}

function hideAllOAPMenu(exceptThis){
    var midRef = document.getElementsByClassName("oa-menu");
    
    if(midRef){
        for(var i=0; i<midRef.length; i++){
            if(midRef[i] == exceptThis || hasCSS(midRef[i],'oa-imenu-dn')){
                continue;
            }
            
            if(midRef[i]){
                if(hasCSS(midRef[i],'db')){
                   removeCSS(midRef[i],'db');
                   addCSS(midRef[i],'dn');
                } else {
                   midRef[i].style.display='none'; 
                }                
            }
        }
    }
}

function showOAPFlexMenu(pid,mid,mItemsJson,isOAPMenuOpt,left,top,repaintItems){
    //pid -> parent Iframe id
    //mid -> Menu id
    //mItemsJson -> Menu items json in string form
    //repaintItems -> If true then repaint menu items
    
    var finalWindow=window;  
        
    var mDiv = finalWindow.document.getElementById(mid);
    var bMDivFound = (mDiv != null);
      
    var bCenter = ((typeof left == 'undefined') || (typeof top == 'undefined') || left=="" || top=="" || left==null || top==null);    
   
    if(bMDivFound){
        repaintItems = (typeof repaintItems == 'undefined')? false: repaintItems;
        
        if(mDiv.style.display != "none"){
            mDiv.style.display="none";
            return mDiv;
        } else if(!repaintItems){
            mDiv.style.display="block";
            
            var rd = getRealDimension(mDiv);;
            if(bCenter){
                var docWidth = finalWindow.document.body.clientWidth;
                var docHeight = finalWindow.document.documentElement.clientHeight;  
                left=(docWidth-rd.Width)/2;
                top=(docHeight-rd.Height)/2;
            } else {
                left -= rd.Width;
            }

            mDiv.style.left = left+"px";
            mDiv.style.top = top+"px";  
            
            return mDiv;
        }
    }
       
    if(bMDivFound){
        removeAllChildNodes(mDiv);
    } else {        
        mDiv=finalWindow.document.createElement("div");
        mDiv.setAttribute("id", mid);
        mDiv.setAttribute("pid", pid);
        mDiv.className="oa-menu bdr"; 
        finalWindow.document.body.appendChild(mDiv);
    }
    
    //mItemsJson='{"Handler":"sbqlhandler","Items":[{"Id":"1","Label":"Items1"},{"Id":"2","Label":"Items2"}]}';
    //mItemsJson = JSON.parse(mItemsJson);
    
    if(mItemsJson.Handler){
        mDiv.setAttribute("handler", mItemsJson.Handler);
    }
    
    var item=null,iconItem=null,parentWrapper=null;
    for(var i=0; i<mItemsJson.Items.length; i++){
        parentWrapper=finalWindow.document.createElement("div");
        parentWrapper.setAttribute("iid", mItemsJson.Items[i].Id);
        parentWrapper.setAttribute("title", mItemsJson.Items[i].Label);
        parentWrapper.parent = mDiv;
        
        item=finalWindow.document.createElement("span");        
        if(mItemsJson.Items[i].Icon){
            item.className = mItemsJson.Items[i].Icon;
        } else {
            item.className = 'dn';
        }        
        parentWrapper.appendChild(item);
        
        item=finalWindow.document.createElement("span");
        item.innerHTML=mItemsJson.Items[i].Label;
        item.parent = mDiv;
        parentWrapper.appendChild(item);
        
        parentWrapper.onclick=function (){            
            hideOAPMenu(this.parent.getAttribute("id"));
            try{
                if(this.parent.getAttribute("handler")){
                    parseJSON(this.parent.getAttribute("handler")+"('"+this.getAttribute("iid")+"')");
                }
            } catch(e){}            
        }
        
        mDiv.appendChild(parentWrapper);
    }
    
    mDiv.style.display="block";
    
    var rd = getRealDimension(mDiv);
    if(bCenter){
        var docWidth = finalWindow.document.body.clientWidth;
        var docHeight = finalWindow.document.documentElement.clientHeight;  
        left=(docWidth-rd.Width)/2;
        top=(docHeight-rd.Height)/2;
    } else {
        left -= rd.Width;
    }
    
    mDiv.style.left = left+"px";
    
    if((typeof pageDirection != 'undefined') && (pageDirection == 'rtl')) {
        mDiv.style.textAlign = 'right';
    } else {
        mDiv.style.textAlign = 'left';
    }
    
    mDiv.style.top = (top+2)+"px";    
    
    return mDiv;
}
function removeAllChildNodes(node) {
    try{
        if (node && node.hasChildNodes && node.removeChild) {
            while (node.hasChildNodes()) {
                if(node.firstChild.hasChildNodes()){                
                    while(node.firstChild.hasChildNodes())
                        removeAllChildNodes(node.firstChild);
                }    
                else
                    node.removeChild(node.firstChild);
            }
        }
    }catch(e) {}
}

function hideOAPMenu(mid){    
    //mid -> Menu id
         
    var midRef = document.getElementById(mid);
    if(midRef){
        midRef.style.display='none';
    }
}

function paintTile(tileJsonData){    
    var maintable = document.createElement("table");                       
    var trMainRow=maintable.insertRow(-1);
    var alignType=tileJsonData.alignmentType;
    if(alignType=='left' && pageDirection == "rtl")
        alignType='right';
    maintable.setAttribute('style','padding:0px 10px;width:100%;border-collapse: collapse;text-align:'+alignType);                
    var tabMainCell;
    var elem = document.createElement("img");                
    elem.setAttribute("src", tileJsonData.tileicon);
  //  elem.setAttribute("src", "data:image/jpeg;base64,"+tileJsonData.tileicon);
    elem.setAttribute("height", "35px");
    elem.setAttribute("width", "35px");
    if(pageDirection == "rtl")
    elem.setAttribute("style", "margin:2px 6px 2px 0px;transform: rotateY(180deg);");
    else
    elem.setAttribute("style", "margin:2px 0px 2px 6px");
    tabMainCell = trMainRow.insertCell(-1);
    tabMainCell.appendChild(elem);
    trMainRow.appendChild(tabMainCell);  
    //document.getElementById('tileContainerDiv').append(elem);
    var table = document.createElement("table");
    table.setAttribute('style','padding-left:5px;');
    var filterSize=tileJsonData.filters.length;
    for (var filterCount=0;filterCount<filterSize;filterCount++) {                   
        var tr = table.insertRow(-1);
       // console.log('tileJsonData.filters[i] -->'+tileJsonData.filters[i]);
         var tabCell = tr.insertCell(-1);
         tabCell.classList.add("fieldlabel");
         if(pageDirection == "rtl"){
             tabCell.setAttribute('style', 'text-align:right !important;font-weight:bold !important;font-size:'+tileJsonData.filterFontSize+' !important;color:'+tileJsonData.filterFontColor+' !important;');  
         }else{
         tabCell.setAttribute('style', 'text-align:left !important;font-weight:bold !important;font-size:'+tileJsonData.filterFontSize+' !important;color:'+tileJsonData.filterFontColor+' !important;');
         }// tabCell.style.color=tileJsonData.colors[i];                     
         tabCell.innerHTML =tileJsonData.filters[filterCount].alias;                     
         tr.appendChild(tabCell); 
      //   table.appendChild(tr);
     //    tr = table.insertRow(-1);
         var tabCell = tr.insertCell(-1);
         tabCell.classList.add("fieldlabel");
         tabCell.innerHTML = " : ";
         tr.appendChild(tabCell); 
         
         tabCell = tr.insertCell(-1);
         tabCell.classList.add("fieldlabel");
         tabCell.setAttribute('style', 'color:'+tileJsonData.filterCountFontColor+' !important;font-weight:bold !important;font-size:'+tileJsonData.filterCountFontSize+' !important;');
         tabCell.innerHTML =tileJsonData.filters[filterCount].val;
         tr.appendChild(tabCell);
         tr.setAttribute('id','filterRow_'+ filterCount);
         table.appendChild(tr);
    }
    
    trMainRow.setAttribute('style', 'display:inline-block');
    tabMainCell = trMainRow.insertCell(-1);
    tabMainCell.appendChild(table);
    trMainRow.appendChild(tabMainCell);  
   // maintable.appendChild(trMainRow);
    var tileCont = document.getElementById('tileContainerDiv');
    tileCont.style.backgroundColor=tileJsonData.tileBackColor;
    tileCont.style.border=tileJsonData.tileBorderSize+'px solid '+tileJsonData.tileBorderColor;
//    document.getElementById('tileContainerDiv').style='background-color:'+tileJsonData.tileBackColor+';border:'+tileJsonData.tileBorderSize+'px solid '+tileJsonData.tileBorderColor;
    tileCont.innerHTML='';
    tileCont.appendChild(maintable);  
//    if (tileJsonData.criteriaName != '') {          //set criteria name as header = Y
//        var header = maintable.createTHead();
//        var row = header.insertRow(0);
//        var cell = row.insertCell(0);
//        cell.innerHTML = tileJsonData.criteriaName;
//        cell.setAttribute('style','font-weight:bold !important;color:'+tileJsonData.headFontColor+';font-size:'+tileJsonData.headFontSize);
//    }
}

function selectOAPFlexComboMenu(comboid,index){
	 if(comboid != "wlf:searchWI" && comboid != "wlf:processlist" && comboid != "wlf:AliasList" && comboid != "wlf:VariantList"){
        window.parent.selectOAPFlexComboMenu(comboid+"opt",index);
	 }
}
function showRecentSearch(rsRef,rsListId){
    var rsListRef=document.getElementById(rsListId);
    var rd = getRealDimension(rsRef); 
    
    var posLeft=findAbsPosX(rsRef)+rd.Width;
    var posTop =findAbsPosY(rsRef)+rd.Height;
    window.parent.showRecentSearch(window.frameElement,rsListRef,posLeft,posTop);
}
function searchRecent(rcListId,index){
    document.getElementById("wlf:hidSelRSindex").value=index;
    window.parent.iFrameWorkitemListRef.hidePopupMask();
    document.getElementById("wlf:btnSelRSindex").click();
}
var isSelectedFromList=false;

function showRSSelection(data) {
    if (data.status == "success")
    {
        var index=document.getElementById("wlf:hidSelRSindex").value;
        var key = document.getElementById("wlf:hidKey").value;
        var ProcessID = document.getElementById("wlf:hidProcessDefId").value;
        var SearchCriteria = document.getElementById("wlf:inpSearchCriteria").value;
        var SearchCriteriaType = document.getElementById("wlf:hidSearchCriteriaType").value;
        var AliasId = document.getElementById("wlf:hidAliasDefId").value;
        var VariantId = document.getElementById("wlf:hidVariantId").value;
		var refPList = document.getElementById("wlf:processlist");
        var refAlist = document.getElementById("wlf:AliasList");
        var refVList = document.getElementById("wlf:VariantList");
        document.getElementById("wlf:searchPrefix").value = key;
        document.getElementById("wlf:Prefix").value = key;
        document.getElementById("wlf:searchWI").value = SearchCriteria;
        refPList.value = ProcessID;
        
        if (SearchCriteriaType == "1" || SearchCriteriaType == '2')
        {
            selectOAPFlexComboMenu("wlf:searchWI", SearchCriteria);
            refPList.style.display = '';
            refVList.style.display = 'none';
            refAlist.style.display = 'none';
            refVList.value = VariantId;
            if(VariantId != ''){
                selectOAPFlexComboMenu("wlf:VariantList", VariantId);
                refVList.style.display = '';
            }
        }
        else
        {
            if(SearchCriteriaType == '4'){
                document.getElementById("wlf:bAliasInQS").value = 'true';
                refAlist.selectedIndex = AliasId;
                
                selectOAPFlexComboMenu("wlf:searchWI", SearchCriteria);
                
                selectOAPFlexComboMenu("wlf:AliasList", AliasId);
                refPList.style.display = 'none';
                refAlist.style.display = '';
                refVList.style.display = 'none';
            } else if(SearchCriteriaType == '3') {
                selectOAPFlexComboMenu("wlf:searchWI", SearchCriteria);
				refPList.style.display = 'none';
                refAlist.style.display = 'none';
                refVList.style.display = 'none';
                
                document.getElementById("wlf:bAliasInQS").value = 'false';
            } else {
                selectOAPFlexComboMenu("wlf:searchWI", SearchCriteria);
                
                document.getElementById("wlf:bAliasInQS").value = 'false';
            }
        }



        isSelectedFromList = true;

        document.getElementById("wlf:cmdBtnRS").click();
    }
}

function refreshQueuelist(){
    var searchBase=document.getElementsByName('frmsearchworkitem:optSearchBase').value;
    if(searchBase=='1'){
       document.getElementById('frmsearchworkitem:qidtext').value='#{WDGEN.LABEL_SELECT_QUEUE}';
       document.getElementById('frmsearchworkitem:hidQid').value=''; 
    }
}
  function customAlert(msg,callBackHandler){
    setPopupMask();
    var width = "270";
    var height = "80";
    var left = (document.documentElement.clientWidth - width) / 2 + window.document.body.scrollLeft;
    var top = (document.documentElement.clientHeight - height) / 2 + window.document.body.scrollTop;
    var divref = document.createElement('div');
    divref.id="customAlert";
    divref.style.width = width + 'px';
   // divref.style.height = height + 'px';
    divref.style.position="absolute";
    divref.style.top = top + 'px';
    divref.style.left = left + 'px'; 
    divref.style.zIndex="9999";
    divref.style.backgroundColor="#ffffff";
    divref.style.display="block";
    divref.style.border="1px solid #d3d3d3";
    divref.onmouseup = function (event){
       cancelBubble(event);
    }
    var iFrameRef=document.createElement("iframe");
    iFrameRef.id="hiddenCustomFrame";
    iFrameRef.setAttribute("src","about:blank");
    iFrameRef.style.display="";
    iFrameRef.style.width = width + 'px';
    iFrameRef.style.height = height + 'px';
    iFrameRef.style.position="absolute";
    iFrameRef.style.top = top + 'px';
    iFrameRef.style.left = left + 'px'; 
    iFrameRef.style.zIndex="9998";
    iFrameRef.style.border="0";
    var tbl = document.createElement('table');
    tbl.style.border="0px";
    tbl.style.cellSpacing="0";
    tbl.style.cellPadding="0";
    tbl.style.width="100%";
    tbl.style.height="100%";
    tbl.style.marginTop="5px";
    var tbdy = document.createElement('tbody');
    var tr = document.createElement('tr');
    var td = document.createElement('td');
    addCSS(td,"wdaligncenter");
    var label=document.createElement("label");
    addCSS(label,"fieldlabel");
    label.style.whiteSpace="normal";
    label.innerHTML=msg;
    td.appendChild(label);
    tr.appendChild(td);
    tbl.appendChild(tr);
    divref.appendChild(tbl);
    tbl = document.createElement('table');
    tbl.style.border="0px";
    tbl.style.cellSpacing="0";
    tbl.style.cellPadding="0";
    tbl.style.width="100%";
    tbl.style.height="100%";
    tr = document.createElement('tr');
    td = document.createElement('td');
    addCSS(td,"wdaligncenter");
    var btn=document.createElement("BUTTON");
    addCSS(btn,"pButtonStyle");
    btn.innerHTML = LABEL_OK;
    btn.id="btn_custom";
    btn.addEventListener('click',function(){
        closeCustomAlert(callBackHandler);
    });
    btn.style.marginBottom="5px";
    btn.style.marginTop="5px";
    td.appendChild(btn);
    tr.appendChild(td);
    tbl.appendChild(tr);
    divref.appendChild(tbl);
    document.forms[0].appendChild(iFrameRef);
    document.forms[0].appendChild(divref);
    document.getElementById("btn_custom").focus();
    return false;
}


function closeCustomAlert(callBackHandler){
    if(typeof callBackHandler!="undefined"){
        parseJSON(callBackHandler);
    }
    var divRef=document.getElementById("customAlert");
    var iFrameRef=document.getElementById("hiddenCustomFrame");
    document.forms[0].removeChild(divRef);
    document.forms[0].removeChild(iFrameRef);
    hidePopupMask();
    return false;
}
function customFloater(message,messageType){
    var width="280px";
    if(document.getElementById("custom_toaster")!=null){
        document.forms[0].removeChild(document.getElementById("custom_toaster"));
    }
    var divref = document.createElement('div');
    divref.id="custom_toaster";
    divref.style.width=width;
    if(messageType=="error"){
        divref.style.backgroundColor="#BA3212";
    } else if(messageType=="success"){
        divref.style.backgroundColor="#268844";
    } else if(messageType=="info"){
        divref.style.backgroundColor="#0072C6";
    } else if(messageType=="warning"){
        divref.style.backgroundColor="#A7571C";
    } 
    divref.style.borderRadius="5px";
    addCSS(divref,"floaterDiv");
    var tbl = document.createElement('table');
    tbl.id="custom_floater_table";
    tbl.style.width="100%";
    tbl.style.marginTop="15px";
    tbl.style.marginBottom="15px";
    var tr = document.createElement('tr');
    var td = document.createElement('td');
    td.style.width="35px";
    td.style.textAlign="center";
    td.style.paddingLeft="15px";
    td.style.paddingRight="8px";
    var img=document.createElement('img');
    if(messageType=="success"){
        img.src="/omniapp/resources/images/success.png";
    } else if(messageType=="error"){
        img.src="/omniapp/resources/images/error.png";
    } else if(messageType=="info"){
        img.src="/omniapp/resources/images/info_float.png";
    } else if(messageType=="warning"){
        img.src="/omniapp/resources/images/warning.png";
    }
    td.appendChild(img);
    tr.appendChild(td);
    td = document.createElement('td');
    td.style.width="180px";
    td.style.color="#ffffff";
    var label= document.createElement('label');
    label.innerHTML=message;
    label.style.fontSize="12px";
    td.appendChild(label);
    tr.appendChild(td);
    td = document.createElement('td');
    td.style.width="22px";
    td.style.paddingLeft="8px";
    td.style.paddingRight="8px";
    td.style.verticalAlign="top";
    img=document.createElement('img');
    img.style.width="15px";
    img.src="/omniapp/resources/images/toaster_close.png";
    img.style.cursor="pointer";
    img.addEventListener('click',function(){
        closeCustomFloater();
    });
    td.appendChild(img);
    tr.appendChild(td);
    tbl.appendChild(tr);
    divref.appendChild(tbl);
    document.forms[0].appendChild(divref);
    setTimeout(closeCustomFloater,5000);
    return false;
}

function closeCustomFloater(){
    var divRef=document.getElementById("custom_toaster");
    if(divRef!=null)
       document.forms[0].removeChild(divRef);
    return false;
}


function closeAllPopups()
{
    var arrLen = iframeChildren.length;
    if(arrLen != 0){
    for(var i=0; i < arrLen; i++)
   {
    var id="popupIFrame_" + iframeChildren[i];
    if(parent.document.getElementById(id) != null)
    {
    parent.document.body.removeChild(parent.document.getElementById(id));
    }
   }
}
}

function addDataToForm(form, data) {
   
    if(typeof form === 'string') {
        if(form[0] === '#') form = form.slice(1);
        form = document.getElementById(form);
    }

    var keys = Object.keys(data);
    var name;
    var value;
    var input;

    for (var i = 0; i < keys.length; i++) {
        name = keys[i];
        Array.prototype.forEach.call(form.elements, function (inpt) {
             if(inpt.name === name) {
                 inpt.parentNode.removeChild(inpt);
             }
        });

        value = data[name];
        input = document.createElement('input');
        input.setAttribute('name', name);
        input.setAttribute('value', value);
        input.setAttribute('type', 'hidden');

        form.appendChild(input);
    }

    return form;
}


function createXMLHttpRequest() {
   // try {return new ActiveXObject("Msxml2.XMLHTTP");} catch (e) {}
    try {return new ActiveXObject("Microsoft.XMLHTTP");} catch (e) {}
    try {return new XMLHttpRequest();} catch(e) {}
    return null;
}

function closeFloat(type){
  var ref;
  if(type=='error')  
    ref=document.getElementsByClassName('erMsgFloat');
  else if(type=='success')
    ref=document.getElementsByClassName('sucMsgFloat');
  else if(type=='info')
    ref=document.getElementsByClassName('iMsgFloat'); 
  else if(type=='warning')
    ref=document.getElementsByClassName('wrnMsgFloat');

    if (ref != null && ref != undefined)
        for (var i = 0; i < ref.length; i++) {
            removeAllChildNodes(ref[i]);
        } 
   
}

function adjustContGen(respArray){
    var height,width;
    width=window.innerWidth;
    height=window.innerHeight;
    for(var i=0;i<respArray.length;i++){
        if (respArray[i][0] != null) {
            if (respArray[i][1] == null) {
                document.getElementById(respArray[i][0].id).style.height = height + "px";
            } else if (respArray[i][1] != false) {
                document.getElementById(respArray[i][0].id).style.height = (height - respArray[i][1]) + "px";
            }

            if (respArray[i][2] == null) {
                document.getElementById(respArray[i][0].id).style.width = width + "px";
            } else if (respArray[i][2] != false) {
                document.getElementById(respArray[i][0].id).style.width = (width - respArray[i][2]) + "px";
            }
        }
  
    }
}

if (window.addEventListener) {
    window.addEventListener("resize", function () {
        if (typeof prehookResize != 'undefined')
            prehookResize();
        if (typeof resizeContainers != 'undefined')
            resizeContainers();
    }, false);
} else if (window.attachEvent) {
    window.attachEvent("onresize", function () {
        if (typeof prehookResize != 'undefined')
            prehookResize();
        if (typeof resizeContainers != 'undefined')
            resizeContainers();
    });
}

function getUrlParameter(qs, name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(qs);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}
function tabSwitchPnl(event, tabtoshow,src) {
    var mytPg = document.getElementById('mytPg');
    var mtb = document.getElementById('mTab');
    var alltPg = document.getElementById('alltPg');
    var atb = document.getElementById('aTab');
    if(tabtoshow=='myt' && hasCSS(mytPg,'dn')){
        removeCSS(mytPg,'dn');addCSS(mytPg,'db');
        removeCSS(alltPg,'db');addCSS(alltPg,'dn');
        removeCSS(mtb,'toolbarLink');addCSS(mtb,'oa-stab tabItemSelected');
        removeCSS(atb,'oa-stab tabItemSelected');addCSS(atb,'toolbarLink');
        document.getElementById('myTasksFrame').contentWindow.compRefresh();
    }
    if(tabtoshow=='allt' && hasCSS(alltPg,'dn')){
        removeCSS(alltPg,'dn');addCSS(alltPg,'db');
        removeCSS(mytPg,'db');addCSS(mytPg,'dn');
        removeCSS(atb,'toolbarLink');addCSS(atb,'oa-stab tabItemSelected');
        removeCSS(mtb,'oa-stab tabItemSelected');addCSS(mtb,'toolbarLink');
        document.getElementById('allTasksFrame').contentDocument.getElementById('tasklist:hidSelectedTab').value="TaskStatusTab";
        document.getElementById('allTasksFrame').contentWindow.compRefresh();
    }
}

function getObjectValues(obj){
    var vals = Object.keys(obj).map(function(key) {
    return obj[key];})

    return vals;
}
function getScreenResolution() {
    var sWidth = window.screen.width;
    var sHeight = window.screen.height;
    
    var dpRatio = window.devicePixelRatio? window.devicePixelRatio: 1;
    
    sWidth = sWidth*dpRatio;
    sHeight = sHeight*dpRatio;
    
    return {"ScreenWidth": sWidth, "ScreenHeight": sHeight};
}
           var scrollTopVal;
function HideDisplayDivs(data){
    var queueId=document.getElementById("frmsearchworkitem:hidQid").value;
    var pid=document.getElementById("frmsearchworkitem:hidPid").value;
    var globalqid = document.getElementById("frmsearchworkitem:hidGlobalQid").value;
    var scrollDiv= document.getElementById("scroll");
    if(data.status=='begin'){
        scrollTopVal=scrollDiv.scrollTop;
    }
    if(data.status=='success'){
        if(queueId!="" || pid!="" || globalqid!=""){
            dataDivClick = 'N';
            checkDataDiv();
            if(document.getElementById('frmsearchworkitem:globalqueueChk').checked && typeof ToggleOtherFields != 'undefined')
            {
                document.getElementById('frmsearchworkitem:buttonGlobalQList').disabled=false;
                ToggleOtherFields('D');
            }
        //                  } else if(document.getElementById('frmsearchworkitem:globalqueueChk').checked == false &amp;&amp; typeof ToggleOtherFields != 'undefined') {
        //                    ToggleOtherFields('E');
        //                  }
        }
        scrollDiv.scrollTop=scrollTopVal;
        renderRegNoField(pid);
        initSearchOptions();
        if(window.parent.popoutMode){
            document.getElementById("frmsearchworkitem:popoutIcon").style.display="none";
            document.getElementById("frmsearchworkitem:popinIcon").style.display="";
            window.parent.popoutMode=true;
        }else{
            document.getElementById("frmsearchworkitem:popoutIcon").style.display="block";
            document.getElementById("frmsearchworkitem:popinIcon").style.display="none";
            window.parent.popoutMode=false;
        } 
    }
               
}
function setPrcVal(){
    var ref = document.getElementById("wlf:processlist");
    if(ref){
        setProcessId(ref);
    }
}
           
function regClickEventListener(evtObj){
    if(evtObj.addEventListener){
        evtObj.addEventListener("click",function (e) {
            e = e || evtObj.event;
            var source = e.target || e.srcElement;
            
            try{
                hideAllOAPMenuEx(source);
            } catch(e){                
            }
        },false);    
    } else if(evtObj.attachEvent) {
        evtObj.attachEvent("onclick",function (e) {
            e = e || evtObj.event;
            var source = e.target || e.srcElement;
            try{
                hideAllOAPMenuEx(source);
            } catch(e){                
            }
        });
    }
}


function hideAllOAPMenuEx(ref){
    var bHideMenu = true;
    
    if(ref){// && ref.parentNode){
        if(hasCSS(ref, 'mcc')){
            /*var mid = ref.parentNode.getAttribute('mid');
            if(mid){*/
                bHideMenu = false;
            //}
        } else {
            bHideMenu = true;
        }
    } else {
        bHideMenu = true;
    }
    
    if(bHideMenu){
        if((typeof window.parent != 'undefined') && (typeof window.parent.hideAllOAPMenuEx != 'undefined')){
            window.parent.hideAllOAPMenuEx();
        }
        if((typeof window.parent != 'undefined') && (typeof window.parent.hideIframe != 'undefined')){
            window.parent.hideIframe("DivShim");
        }
    }
}

if(window.addEventListener){
    window.addEventListener("load",function () {
        regClickEventListener(document);
    },false);
} else if(window.attachEvent) {
    window.attachEvent("load",function () {
        regClickEventListener(document);
    });
}

function popupIFrameOpenerWrapperExt(callerIFrameWinRef, id, url, width, height, left, top, isHeader, isMoveLink, isCloseLink, isModal, isCenter, display,ischeck, skipHeader) {
     var cntpath;
     if(window.parent.opener.parent.getContextPath(url) == 'undefined')
         cntpath=getContextPath(url);
     else            
         cntpath=window.parent.opener.parent.getContextPath(url);
     
     var ridkey;
     if(window.parent.opener.parent.getRequestTokenName(url) == 'undefined')
         ridkey= getRequestTokenName(url);
     else
         ridkey= window.parent.opener.parent.getRequestTokenName(url);
     
     var ridValue;
   var trui= getActionUrlFromURL(url);
   if(typeof cntpath=='undefined' || cntpath=='')
        cntpath="omniapp";
    if(typeof ridkey=='undefined' || ridkey=='')
        ridkey="OAP_RId";
    var servletUrl = "/"+cntpath+"/secuidsv";
    (cntpath == 'webdesktop' && typeof WD_SID != 'undefined' && WD_SID != null) && (servletUrl += "?WD_SID=" + WD_SID);      
    var xhReq = createXMLHttpRequest();
    //createIndicator(indicatorid);
    xhReq.open("POST", servletUrl, true);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
   
    xhReq.onreadystatechange = onResponse;
    
    xhReq.send("T-URI="+trui);
   
    function onResponse() {        
        try {
            
            if (xhReq.readyState==4) { 
                if (xhReq.status==200) {
                   ridValue =  xhReq.getResponseHeader(ridkey);
                   if (url.indexOf("?") > 0) {
                        url = url + "&"+ridkey+"=" + ridValue;
                    } else {
                        url = url + "?"+ridkey+"=" + ridValue;
                    }
                   popupIFrameOpenerExt(callerIFrameWinRef, id, url, width, height, left, top, isHeader, isMoveLink, isCloseLink, isModal, isCenter, display,ischeck, skipHeader);
                } 
            }       
        } catch(e) {
            alert(ERROR_FETCHING_DATA);
        }
    }
    
}

function popupIFrameOpenerExt(callerIFrameWinRef, id, url, width, height, left, top, isHeader, isMoveLink, isCloseLink, isModal, isCenter, display,ischeck, skipHeader) {
    skipHeader = (typeof skipHeader == 'undefined')? false: skipHeader;
    var isChrome = window.chrome; 
    
    if(isCenter!=null && isCenter!=undefined && isCenter){       
        if(typeof isChrome != 'undefined') {
            left=(window.screen.availWidth -width)/2 + window.document.body.scrollLeft;
            top=(window.screen.availHeight -height)/2 + window.document.body.scrollTop-40;
//            alert(left)
        }
        else{        
            left = (window.screen.width - width)/2 + window.document.documentElement.scrollLeft;
            top = (document.documentElement.clientHeight - height)/2 + window.document.documentElement.scrollTop;
            
        }
    } else {
        left -= width;
        if(ischeck){   //added by amar
            //alert("true");
        } else if((top+height+25)>document.documentElement.clientHeight){
            if((top-height) > -1){
                top -= height;
                //if top is less than Height
                if(top<0){
                    top = -top;
                }
            } else {
                top -= (top+height+25) - document.documentElement.clientHeight;
            }
        } else {
            if(!skipHeader){
                top += 25;
            }
        }

        if(left<0){
            left += width;
        }
    }
 
    try {
        var finalWindow = window;
        if(finalWindow.document.getElementById("popupIFrame_"+id) != null)
            return;

        if(isModal) {
            initPopUp();
            setPopupMask();
        }
        var iframe = finalWindow.document.createElement("IFRAME");
        // Creates IFRAME
        /*
        
        if(typeof display != 'undefined' && !display){
            iframe.style.diplay = "none";
        }
        */
        
        iframe.style.zIndex = "1001";
        iframe.setAttribute("src", url);
        iframe.setAttribute("name", "popupIFrame_"+id);
        iframe.setAttribute("id", "popupIFrame_"+id);
        iframe.frameBorder="0";
        iframe.style.frameBorder="0";
        iframe.scrolling="no";
        iframe.style.scrolling="no";
        iframe.style.visibility="visible";
        iframe.style.position="absolute";

        iframe.style.width= width+"px";
        iframe.style.height = height+"px";
        iframe.style.left = left+"px";
        iframe.style.top = top+"px";
        iframe.className = "iframeShadow ";
        //iframe.style.width= "100%";
        //iframe.style.height = (height) + "px";
        iframe.style.backgroundColor = "white";
        //iframe.style.border = "1px solid green";
        //containerDiv.appendChild(iframe);        
        finalWindow.document.body.appendChild(iframe);

        //createMoveAction(containerDiv.id, width, isMoveLink);
        //createCloseAction(containerDiv.id, isCloseLink);

        setTimeout(function (){readyStateChecker("popupIFrame_"+id, 1, READY_STATE_PROBE_INTERVAL, callerIFrameWinRef);}, readyStateProbeTimeSequence[0]);
        
        document.getElementById("popupIFrame_"+id).contentWindow.parentWindowRef = callerIFrameWinRef;
        document.getElementById("popupIFrame_"+id).contentWindow.rootWindowRef = this;
    } catch(ex){}
}

/*function wordWrap(control, wrapLength)
{
    var sString = control.value;
    var sStringResult = "";
    var iStartNow = 0;
    var iWrapPoint = 0;
    var iWrapItself = 0;
    
    while (iWrapPoint != -1)
    {
        // Hint : Use another wrap point for '\n' and find the best amont the two, to use it in on blur.
        iWrapItself = (sString.substring(iStartNow, addTOWord(iStartNow, wrapLength))).lastIndexOf("\n");
        if (iWrapItself != -1)
        {
            sStringResult += (sString.substring(iStartNow, addTOWord(iStartNow,iWrapItself))+"\n");
            iStartNow = addTOWord(addTOWord(iStartNow, iWrapItself), 1);
            continue;
        }
        iWrapPoint = (sString.substring(iStartNow, addTOWord(iStartNow, wrapLength))).lastIndexOf(" ");
        if (iWrapPoint == -1 && (sString.length > addTOWord(iStartNow, wrapLength)))
            iWrapPoint = wrapLength;
		sStringResult=sStringResult.trim();	
        if (sStringResult)
            sStringResult += "\n";
        if ((iWrapPoint == -1) || (sString.length < addTOWord(iStartNow, wrapLength)))
        {
            sStringResult += sString.substring(iStartNow, sString.length);
            break;
        }
        else
            sStringResult += sString.substring(iStartNow, addTOWord(iStartNow, iWrapPoint));
        iStartNow = addTOWord(addTOWord(iStartNow, iWrapPoint), 1);
    }
    control.value = Trim(sStringResult, "\n");
    //destination.value = sStringResult;
}*/

function wordWrap(control, wrapLength)
{
	var sString = control.value;
	var sStringResult = "";
	var iStartNow = 0;
	var iWrapPoint = 0;
	var iWrapItself = 0;
	while (iWrapPoint != -1)
	{
		// Hint : Use another wrap point for '\n' and find the best amont the two, to use it in on blur.
		iWrapItself = (sString.substring(iStartNow, addTOWord(iStartNow, wrapLength))).lastIndexOf("\n");
		if (iWrapItself != -1)
		{
			sStringResult += "\n" + sString.substring(iStartNow, addTOWord(iStartNow, iWrapItself));
			iStartNow = addTOWord(addTOWord(iStartNow, iWrapItself), 1);
			continue;
		}
		iWrapPoint = (sString.substring(iStartNow, addTOWord(iStartNow, wrapLength))).lastIndexOf(" ");
		if (iWrapPoint == -1 && (sString.length > addTOWord(iStartNow, wrapLength)))
			iWrapPoint = wrapLength;
		if (sStringResult)
			sStringResult += "\n";
		if ((iWrapPoint == -1) || (sString.length < addTOWord(iStartNow, wrapLength)))
		{
			sStringResult += sString.substring(iStartNow, sString.length);
			break;
		}
		else
			sStringResult += sString.substring(iStartNow, addTOWord(iStartNow, iWrapPoint));
		iStartNow = addTOWord(addTOWord(iStartNow, iWrapPoint), 1);
	}
	control.value = Trim(sStringResult, "\n");
	//destination.value = sStringResult;
}

function addTOWord(int1, int2)
{
    //return ( (1-int1-int2)*-1+1 );
    return (int1 * 1 + int2 * 1)
}
function handleSpecialChar(value) {
    if(value != null && (value!="")){
        value = value.replace(/\&/g, "&amp;");
        value = value.replace( /\"/g, "&quot;");
        value = value.replace(/\'/g, "&apos;");
        value = value.replace(/\</g, "&lt;");
        value = value.replace(/\>/g, "&gt;");
    }
    return value;
}

function setFieldValueSafely(fieldRef, fieldValue) {
    if(typeof fieldRef != 'undefined' && typeof fieldValue != 'undefined') {
        fieldRef.value = fieldValue;
    }
}

function startScheduler(ref){
    var formid="startTimerSchedulerForm";
    var tableID=formid+":dtSchedularList";
   var rowCount=document.getElementById(tableID).rows.length ;
     rowCount--;
    var chkBoxID=tableID+":";
    var currentChkBoxID="";
   var noOfSelectedRows=0;
   var selectedIndexes="";
   /* var schedulersAlreadyStarted="";
    var bCheck=false;
    var count=0;*/
    for (var iCount=0;iCount <rowCount;iCount++)
    {
        currentChkBoxID=chkBoxID + iCount +":chkBox" ;
        
          try 
          {
            if(document.forms[formid][currentChkBoxID].checked)
            {
                noOfSelectedRows++;
                var deleteSchedulerIndex = "";

                    deleteSchedulerIndex=document.getElementById(tableID+":"+iCount+":hidSchedulerId").value;
               
                if(selectedIndexes.length > 0)
                {
                        selectedIndexes=selectedIndexes + ":" + deleteSchedulerIndex ;
                }
                else
                {
                        selectedIndexes = deleteSchedulerIndex +"";
                }
             }
          }
         catch(e)
         {
         }
     }
     if(selectedIndexes==""){
//         if(schedulerType=='RS')
            customAlert("ALERT_SCHEDULER_START");
//        else if(schedulerType=='TA')
//            customAlert(ALERT_TREND_START);
        return false;
    }
 
    document.getElementById("startTimerSchedulerForm:hidSelectedIds").value=selectedIndexes;
//    document.getElementById(chkBoxID+"chkBoxAll").checked=false;
      
    return true;
}

         
function renderStartStopButtons() 
{
    var ctrlTableId="startTimerSchedulerForm:dtSchedularList";
    var ctrlTable=document.getElementById(ctrlTableId);

   
    var bStartFlag=false;
    var bStopFlag=false;
    var selectetdRowCount=0;
    var startState=false;
    try 
    {
        if(ctrlTable!=null) 
        {
            var rowCount = ctrlTable.tBodies[0].rows.length;
            for(var iCount = 0; iCount < rowCount;iCount++) 
              {
                var el=document.getElementById(ctrlTableId+":"+iCount +":chkBox");
                if(el.checked) 
                {
                   selectetdRowCount++;
                   //var schedulerId=document.getElementById(ctrlTableId+":"+iCount+":hidSchedulerId").value;
                   var status=document.getElementById(ctrlTableId+":"+iCount+":hidStatus").value;
                   if(status==3){
                    bStopFlag=false;
                    bStartFlag=false;
                   }
                   
                  if(status==0){
                   bStopFlag=false;
                    if(selectetdRowCount==1){
                        bStartFlag=true;
                        }
                    }
                   if(status==1 || status==2){
                   bStartFlag=false;
                        if(selectetdRowCount==1){
                            bStopFlag=true;
                        }
                   }
                   if(status==1){
                       startState=true;
                   }
                }
             }
        } 



        var StartBtn=document.getElementById("startTimerSchedulerForm:start");

        var StopBtn=document.getElementById("startTimerSchedulerForm:stop");
        
        if(bStartFlag){
                StartBtn.style.display = "inline";
                document.getElementById('startTimerSchedulerForm:start').style.display = "inline-block";
                document.getElementById('startTimerSchedulerForm:startDis').style.display = "none";
                
        }else{  
                StartBtn.style.display = "none";
                document.getElementById('startTimerSchedulerForm:start').style.display = "none";
                document.getElementById('startTimerSchedulerForm:startDis').style.display = "inline-block";
//                document.getElementById('startTimerSchedulerForm:stopDis').style.display = "none";
//                document.getElementById('startTimerSchedulerForm:stop').style.display = "inline-block";
//                
        }

        if(bStopFlag){
                StopBtn.style.display = "inline";
                document.getElementById('startTimerSchedulerForm:stop').style.display = "inline-block";
           //     document.getElementById('schlist:stopBtnDis').style.display = "none";
                document.getElementById('startTimerSchedulerForm:stopDis').style.display = "none";
//                if(document.getElementById('startTimerSchedulerForm:linkExec') != null) {
//                document.getElementById('startTimerSchedulerForm:linkExec').style.display = "inline-block";
//                }
//                if(document.getElementById('startTimerSchedulerForm:linkExecDis') != null){
//                document.getElementById('startTimerSchedulerForm:linkExecDis').style.display = "none";
//                }
           //     if(document.getElementById('schlist:execBtn') != null) {
          //      document.getElementById('schlist:execBtn').style.display = "inline";
            //    }
           //     if(document.getElementById('schlist:execBtnDis') != null) {
           //     document.getElementById('schlist:execBtnDis').style.display = "none";
           //     }
        }else{
                StopBtn.style.display = "none";
                document.getElementById('startTimerSchedulerForm:stop').style.display = "none";
          //      document.getElementById('schlist:stopBtnDis').style.display = "inline";
                document.getElementById('startTimerSchedulerForm:stopDis').style.display = "inline-block";
//                if(document.getElementById('startTimerSchedulerForm:linkExec') != null) {
//                document.getElementById('startTimerSchedulerForm:linkExec').style.display = "none";
//                }
//                if(document.getElementById('startTimerSchedulerForm:linkExecDis') != null){
//                document.getElementById('startTimerSchedulerForm:linkExecDis').style.display = "inline-block";
//                }
       //         if(document.getElementById('schlist:execBtn') != null) {
        //        document.getElementById('schlist:execBtn').style.display = "none";
         //       }
        //        if(document.getElementById('schlist:execBtnDis') != null) {
       //         document.getElementById('schlist:execBtnDis').style.display = "inline";
        //        }
        }

       
    }catch(ex){}
}


function stopScheduler(ref){
   var formid="startTimerSchedulerForm";
    var tableID=formid+":dtSchedularList";
    rowCount=document.getElementById(tableID).rows.length ;
    rowCount--;
    var chkBoxID=tableID+":";
    var currentChkBoxID="";
    noOfSelectedRows=0;
    selectedIndexes="";
    /*var schedulersAlreadyStopped="";
    var bCheck=false;
    var count=0;*/
    var bStopFlag=false;
    var bImmedeateExecute=false;
    var StopBtn=document.getElementById("startTimerSchedulerForm:stop");
    for (var iCount=0;iCount <rowCount;iCount++)
    {
        currentChkBoxID= chkBoxID+iCount +":chkBox" ;
        try 
          {
            if(document.forms[formid][currentChkBoxID].checked)
            {
                noOfSelectedRows++;
                var schedulerId = "";
//                if(schedulerType!="undefined" && schedulerType!=null && schedulerType=='TA'){
//                  schedulerId=document.getElementById(tableID+":"+iCount+":hidTrendId").value;  
//                }else if(schedulerType!="undefined" && schedulerType!=null && schedulerType=='IMRS'){
//                    bImmedeateExecute=true;
//                    schedulerId=document.getElementById(tableID+":"+iCount+":hidSchedulerId").value;
//                }
//                else
                    schedulerId=document.getElementById(tableID+":"+iCount+":hidSchedulerId").value;
                /*var StopSchedulerCheck=document.getElementById(tableID+":"+iCount+":hidSchedulerStatus").value;
                if(StopSchedulerCheck=="Stopped"){
                    bStopFlag=true;
                    if(count==0){
                    schedulersAlreadyStopped=schedulerId;
                    }else{
                    schedulersAlreadyStopped=schedulersAlreadyStopped+","+schedulerId;
                    }
                    count++;
                    bCheck=true;
                }*/
                if(selectedIndexes.length > 0)
                {
                        selectedIndexes=selectedIndexes + ":" + schedulerId ;
                }
                else
                {
                        selectedIndexes = schedulerId +"";
                }
             }
          }
         catch(e)
         {
         }
     }
     if(selectedIndexes==""){
//         if(schedulerType=='RS')
            customAlert("ALERT_SCHEDULER_STOP");
//        else if(schedulerType=='TA')
//            customAlert(ALERT_TREND_STOP);
//        else if(schedulerType=='IMRS')
//            customAlert(ALERT_SCHEDULER_EXEC);
        return false;
    }
//    if(bStopFlag){
//        StopBtn.src='../crweb/en_us/images/stop_dis.gif';
//        StopBtn.disabled=true;
//    }
    /*if(bCheck){
        if(count==1){
        alert("Scheduler with the Id "+schedulersAlreadyStopped+" has already stopped");
        return false;
        }else{
        alert("Some selected Schedulers with the Ids " +schedulersAlreadyStopped+ " have already been stopped");
        return false;
        }
    }*/
    document.getElementById("startTimerSchedulerForm:hidSelectedIds").value=selectedIndexes;
//    document.getElementById(chkBoxID+"chkBoxAll").checked=false;
      
    return true;

}
function getFieldValueSafely(fieldRef) {
    var fieldValue;
    if(typeof fieldRef != 'undefined') {
        fieldValue = fieldRef.value;
    }
    return fieldValue;
}

function getOAPWindowRef() {
    var winRef = window;
    var winRefParent = getParentWindow(window);
    var winRefOpener = getOpenerWindow(window);
    var omniappWindow = null;
    
    if(typeof winRef != 'undefined' && winRef != null && checkForOAPWindow(winRef)) {
        omniappWindow = winRef;
    }
    
    if(omniappWindow == null) {
        if(typeof winRefParent != 'undefined' && winRefParent != null && winRef != winRefParent) {
            if(checkForOAPWindow(winRefParent)) {
                omniappWindow = winRefParent;
            }
        }
    }
    
    if(omniappWindow == null) {
        if(typeof winRefOpener != 'undefined' && winRefOpener != null && winRef != winRefOpener) {
            if(checkForOAPWindow(winRefOpener)) {
                omniappWindow = winRefOpener;
            }
        }
    }
    
    if(omniappWindow == null && winRef != winRefParent) {
        try {
            omniappWindow = winRefParent.getOAPWindowRef();
        } catch(e) {
            omniappWindow = null;
        }
    }
    
    if(omniappWindow == null && winRef != winRefOpener) {
        try {
            omniappWindow = winRefOpener.getOAPWindowRef();
        } catch(e) {
            omniappWindow = null;
        }
    }
    
    return omniappWindow;
}

function getWorkitemWindowRef() {
    var winRef = window;
    var winRefParent = getParentWindow(window);
    var winRefOpener = getOpenerWindow(window);
    var workitemWindow = null;
    
    if(typeof winRef != 'undefined' && winRef != null && checkForWorkitemWindow(winRef)) {
        workitemWindow = winRef;
    }
    
    if(workitemWindow == null) {
        if(typeof winRefParent != 'undefined' && winRefParent != null && winRef != winRefParent) {
            if(checkForWorkitemWindow(winRefParent)) {
                workitemWindow = winRefParent;
            }
        }
    }
    
    if(workitemWindow == null) {
        if(typeof winRefOpener != 'undefined' && winRefOpener != null && winRef != winRefOpener) {
            if(checkForWorkitemWindow(winRefOpener)) {
                workitemWindow = winRefOpener;
            }
        }
    }
    
    if(workitemWindow == null && winRef != winRefParent) {
        try {
            workitemWindow = winRefParent.getWorkitemWindowRef();
        } catch(e) {
            workitemWindow = null;
        }
    }
    
    if(workitemWindow == null && winRef != winRefOpener) {
        try {
            workitemWindow = winRefOpener.getWorkitemWindowRef();
        } catch(e) {
            workitemWindow = null;
        }
    }
    
    return workitemWindow;
}

function updateWebSessionTime() {
    ContentLoaderWrapper('/webdesktop/generic/dummy.app', null, null, "POST", "");
}

function checkForOAPWindow(win) {
    var oapWinFlag;
    try {
        oapWinFlag = (typeof win.isOAPWindow != 'undefined' && win.isOAPWindow);
    }catch(e) {
        oapWinFlag = false;
    }
    return oapWinFlag;
}

function checkForWorkitemWindow(win) {
    var wiWinFlag;
    try {
        wiWinFlag = (typeof win.isWorkitemWindow != 'undefined' && win.isWorkitemWindow);
    }catch(e) {
        wiWinFlag = false;
    }
    return wiWinFlag;
}

function getParentWindow(win) {
    var parentWin;
    try {
        parentWin = win.parent;
    } catch(e) {
        parentWin = null;
    }
    return parentWin;
}

function getOpenerWindow(win) {
    var openerWin;
    try {
        openerWin = win.opener;
    } catch(e) {
        openerWin = null;
    }
    return openerWin;
}