

var DATA_TYPE_SYS_OBJECTS=3

var DATA_ATTRIB_READ_ONLY = 1
var DATA_ATTRIB_WRITE_ONLY = 2
var DATA_ATTRIB_READ_WRITE = 3

var NG_VAR_INT = 3
var NG_VAR_LONG = 4
var NG_VAR_FLOAT = 6
var NG_VAR_DATE = 8
var NG_VAR_STRING = 10
var NG_VAR_BOOLEAN = 12
var NG_VAR_SHORTDATE = 15
var NG_VAR_TIME = 16
var NG_VAR_DURATION = 17
var READ_MODE = "R";
var WRITE_MODE = "W";
var NEW_WI_MODE = "N";
var AUDIT_MODE = "A";

var OP_LESSTHAN = 1;            //   <      
var OP_LESSTHANEQUALTO = 2;     //   <=     
var OP_EQUALTO = 3;             //   =      
var OP_NOTEQUALTO = 4;          //   =      
var OP_GREATERTHAN = 5;         //   >      
var OP_GREATERTHANEQUALTO = 6 ; //   >=     
var OP_LIKE = 7;                //   LIKE   
var OP_NOTLIKE = 8;             //   NOTLIKE
var OP_NULL = 9;                //   NULL   
var OP_NOTNULL = 10;            //   NOTNULL



