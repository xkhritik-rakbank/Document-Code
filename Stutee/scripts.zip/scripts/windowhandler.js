
//to use this code you have to define a unique winname
var windowList=new Array();
function wfWindow (winName,winHandler,status){
this.handler=winHandler;//handler for window
this.winName=winName;//unique name 
this.status=status;//status  
}
function getWindowHandler(winArray,name){
    
    var i=0;

	for(i=0;i<winArray.length;i++)
            {
		if(winArray[i].winName == name)
                 {
                    return winArray[i].handler;
               }
        }

}

function isWindowExist(winArray,winName)
{
 
	var i;
	for(i=0;i<winArray.length;i++){
           try{
		   if(typeof winArray[i]!='undefined' &&winArray[i]!=null&&winArray[i].winName&&winArray[i].winName == winName){
			return true;
			}
		   }
		   catch(e){
			 
			 winArray.removeAt(i);
		     return false;
		   
		   }
        }
        return false;
}
function getDetail(winArray,winName){
var i;
if(isWindowExist(winArray,winName)){
	for(i=0;i<winArray.length;i++){
            
            if(typeof winArray[i]!='undefined' &&winArray[i]!=null&&  winArray[i].winName == winName)
			return winArray[i];
        }
	}


}
function closewindows(winholder)
{	
        var i="";
        var winlist='';
        if(winholder)
            winlist=winholder;
        else
            winlist=windowList;

	for(i=winlist.length-1; i >= 0; i--){
	try{
            if(!(winlist[i].handler.location==window.location))
              {
                if(winlist[i].handler.handleunlockreq){
                    winlist[i].handler.unlockflag='N';
                }
		winlist[i].handler.close();
               }
	}
	catch(e){
	
        }
    }
}

function removeFromArray(winArray,name)
{
    var i;

    if (typeof winArray != 'undefined') {

        try {
            for (i = 0; i < winArray.length; i++) {
                if (winArray[i].winName == name)
                {
                    winArray.removeAt(i);

                    return;
                }
            }
        } catch (e) {
            winArray.removeAt(i);
        }
    }
}


function link_popup(src,uname,features,winholder,Ext,bOpenSecureWindow) {

var ieVersion=getInternetExplorerVersion();    
var openSecWinFlag = true;
  if(bOpenSecureWindow != undefined && !bOpenSecureWindow && (ieVersion-0) == 9)
      openSecWinFlag = false;

  var winlist='';
   if(winholder){
    winlist=winholder;
   }else{
    winlist=windowList;
   }
   if(isWindowExist(winlist,uname)){
       var winObj= getWindowHandler(winlist,uname);
       winObj.focus();
        return false;
       }
    else
    {
    var uniqueId=MakeUniqueNumber();
    //src = appendUrlSession(src);
    
    var url = getActionUrlFromURL(src);
    url = appendUrlSession(url);   
       
    var listParam=new Array();
    
    if(openSecWinFlag)
        {
            listParam = getInputParamListFromURL(src);
            theWindow = openNewWindow(url,uniqueId,features, true,"Ext1","Ext2","Ext3","Ext4",listParam);
        }
        else
        {
            theWindow = window.open_(src,uniqueId,features,true);
        }
    
    //theWindow = window.open(src,uniqueId,features);
    if((ieVersion-0) > 9){
    theWindow = window.open(src,uniqueId,features);
    }else{
    theWindow.focus();
    }
    }
    return theWindow;
}

function addWindowToParent(windowList,name){
    
   var win1=new wfWindow(name,this,"open");
    windowList.append(win1);
}

