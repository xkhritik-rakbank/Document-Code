

function workitem(wi_view_win, workitem_win, process_inst_id, workitem_id,
    activity_id, priority, participant, reassignment_allowed, workstep_name,
    entry_date_time, valid_till, status, state, workable_to_do_item_count,
    folder_id, audit_status, checklist_complete, lock_status, locked_time,
    introduction_date_time, queue_name, process_name, assigned_user, view_mode,
    queue_type, queue_id, introduced_by, process_id, workitem_form,
    attribute_list, to_do_item_list, doc_types_list, attachment_list,
    action_list, exception_list, interface_list, assignment_type, attribute_map,
    refered_by, history_list, dynamicConst_list)
{
    this.wi_view_win = wi_view_win;
    this.workitem_win = workitem_win;
    this.process_inst_id = process_inst_id;
    this.workitem_name = process_inst_id;
    this.workitem_id = workitem_id;
    this.activity_id = activity_id;
    this.priority = priority;
    this.participant = participant;
    this.reassignment_allowed = reassignment_allowed;
    this.workstep_name = workstep_name;
    this.entry_date_time = entry_date_time;
    this.valid_till = valid_till;
    this.status = status;
    this.state = state;
    this.workable_to_do_item_count = workable_to_do_item_count;
    this.folder_id = folder_id;
    this.audit_status = audit_status;
    this.checklist_complete = checklist_complete;
    this.lock_status = lock_status;
    this.locked_time = locked_time;
    this.introduction_date_time = introduction_date_time;
    this.queue_name = queue_name;
    this.process_name = process_name;
    this.assigned_user = assigned_user;
    this.view_mode = view_mode;
    this.queue_type = queue_type;
    this.queue_id = queue_id;
    this.introduced_by = introduced_by;
    this.process_id = process_id;
    this.assignment_type = assignment_type;
    this.workitem_form = workitem_form;
    /*this.getFieldValueBag = window.parent.getFieldValueBag;*/
    this.refered_by = refered_by;
    this.resp_tmpl_list = new Array();

    if(attribute_list == null) {
        this.attribute_list = new Array();
    } else {
        this.attribute_list = attribute_list;
    }

    if(attribute_map == null) {
        this.attribute_map = new Array();
    } else {
        this.attribute_map = attribute_map;
    }

    if(to_do_item_list == null) {
        this.to_do_item_list = new Array();
    } else {
        this.to_do_item_list = to_do_item_list;
    }

    if(doc_types_list == null) {
        this.doc_types_list = new Array();
    } else {
        this.doc_types_list = doc_types_list;
    }

    if(attachment_list == null) {
        this.attachment_list = new Array();
    } else {
        this.attachment_list = attachment_list;
    }

    if(action_list == null) {
        this.action_list = new Array();
    } else {
        this.action_list = action_list;
    }

    if(exception_list == null) {
        this.exception_list = new Array();
    } else {
        this.exception_list = exception_list;
    }

    if(interface_list == null) {
        this.interface_list = new Array();
    } else {
        this.interface_list = interface_list;
    }

    if(history_list == null) {
        this.history_list = new Array();
    } else {
        this.history_list = history_list;
    }
    
    if(dynamicConst_list == null) {
        this.dynamicConst_list = new Array();
    } else {
        this.dynamicConst_list = dynamicConst_list;
    }
}

function attachment(index,name, isindex, no_of_pages, annotation_flag,
    document_type, created_by_appname, created_time, version_flag, version_no,
    checkout_status, checkout_by, attachment_status, doc_attribute, comment,
    author, LoginUserRights)
{
    this.index = index;
    this.name = name;
    this.no_of_pages = no_of_pages;
    this.annotation_flag = annotation_flag;
    this.document_type = document_type;
    this.doctype_attribute = doc_attribute;
    this.created_by_appname = created_by_appname;
    this.created_time = new Date(Date.parse(created_time));
    this.versionflag = (version_flag==null)?'':version_flag;
    this.versionno = (version_no==null)?'1.0':version_no;
    this.checkoutstatus = (checkout_status==null)?'':checkout_status;
    this.checkoutby = (checkout_by==null) ? '' : checkout_by;
    this.author = author;
    this.LoginUserRights = LoginUserRights;
    this.status = attachment_status;
    
    if(isindex.charAt(isindex.length-1) == '#') {
        this.isindex = isindex.substring(0,isindex.length-1);
    } else {
        this.isindex = isindex;
    }
    
    if(comment == '') {
        this.comment = name;
    } else {
        this.comment = comment;
    }
}

function exception(index, name, description, status, type, added_flag,
    history_list,exception_trigger)
{
    this.index = index;
    this.name = name;
    this.description = description;
    this.status = status;
    this.type = type;
    this.added_flag = added_flag;
    this.exception_trigger = exception_trigger;
    
    if(history_list == null) {
        this.history_list = new Array();
    } else {
        this.history_list=history_list;
    }
    
    this.clearFields = function() {
        this.status='';
        this.added_flag=false;
        this.history_list.length=0;
    }
}

function exception_history(action, activity_name, user_name, action_date_time,
    comments, status)
{
    this.action = action;
    this.activity_name = activity_name;
    this.user_name = user_name;
    this.action_date_time = action_date_time;
    this.comments = comments;
    this.status= status;
}

function trigger(triggerID, triggerType, triggerName, className, parentElement,
    triggerObject)
{
    this.triggerID = triggerID;
    this.triggerType = triggerType; //M,E,L,D
    this.triggerName = triggerName;
    this.className = className;
    this.triggerObject = triggerObject;
    this.parentElement = parentElement;
}

function workitem_attribute(name,type,length,value,modified_flag) {
    this.name = name;
    this.value = value;
    this.scope = type.substring(0,1);
    this.rw = type.substring(1,2);
    this.type = type.substring(2);
    this.length = length;
    this.modified_flag = modified_flag;
}

function constant_attribute(Name,Value,LastModifiedOn) {
    this.Name = Name;
    this.Value = Value;
    this.LastModifiedOn = LastModifiedOn;
}

function todo_item(index, name, value) {
    this.index = index;
    this.name = name;
    this.value = value;
}

function getWiObject(pid, wid, taskid) {
    if(typeof pid == 'undefined' || typeof wid == 'undefined' || pid == null || wid == null || WIObjectSupport != 'Y') {
        return null;
    }
    
    if(typeof taskid == 'undefined' || taskid == null) {
        taskid = "";
    }
    
    var sUrl = sContextPath + '/getwiobject';
    var wd_rid = getRequestToken(sUrl);
    var params = 'pid='+encode_utf8(pid)+'&wid='+wid+'&taskid='+taskid + '&WD_SID='+WD_SID + '&WD_RID=' + wd_rid + "&randNum=" + Math.random();
    
    var wiObject = null;
    var xhReq = createXMLHttpRequest();
    xhReq.open("POST", sUrl, false);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhReq.onreadystatechange = function() {
        if (xhReq.readyState == 4 && xhReq.status == 200) {
            wiObject = parseWorkitemObject(xhReq.responseText);
        }
    }
    xhReq.send(params);
    
    return wiObject;
}

function parseWorkitemObject(wiObjJsonString) {
    var wiObj = JSON.parse(wiObjJsonString);
    var workitemProperty = JSON.parse(wiObj.WorkitemProperty);
    var wi_object = new workitem("",
        "",
        decodeURIComponent(workitemProperty.ProcessInstanceId),
        decodeURIComponent(workitemProperty.WorkitemId),
        decodeURIComponent(workitemProperty.WorkStageId),
        decodeURIComponent(workitemProperty.PriorityLevel),
        decodeURIComponent(workitemProperty.UserName),
        "",
        decodeURIComponent(workitemProperty.ActivityName),
        decodeURIComponent(workitemProperty.EntryDateTime),
        decodeURIComponent(workitemProperty.ExpiryDateTime),
        decodeURIComponent(workitemProperty.InstrumentStatus),
        decodeURIComponent(workitemProperty.WorkitemState),
        "",
        decodeURIComponent(workitemProperty.FolderId),
        "",
        decodeURIComponent(workitemProperty.CheckListCompleteFlag),
        decodeURIComponent(workitemProperty.LockStatus),
        decodeURIComponent(workitemProperty.LockedTime),
        decodeURIComponent(workitemProperty.IntroductionDateTime),
        decodeURIComponent(workitemProperty.QueueName),
        decodeURIComponent(workitemProperty.RouteName),
        decodeURIComponent(workitemProperty.AssignedTo),
        decodeURIComponent(workitemProperty.ViewMode),
        decodeURIComponent(workitemProperty.QueueType),
        decodeURIComponent(workitemProperty.QueueId),
        decodeURIComponent(workitemProperty.IntroducedBy),
        decodeURIComponent(workitemProperty.RouteId),
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        decodeURIComponent(workitemProperty.ReferredBy),
        null);
    
    fillAttributeList(wi_object, JSON.parse(wiObj.AttributeList));
    fillDocumentList(wi_object, JSON.parse(wiObj.DocumentList));
    fillToDoList(wi_object, JSON.parse(wiObj.ToDoList));
    fillDynamicConstantList(wi_object, JSON.parse(wiObj.DynamicConstantList));
    fillExceptionList(wi_object, JSON.parse(wiObj.ExceptionList));
    
    return wi_object;
}

function fillAttributeList(wi_object, objAttribList) {
    var attribute;
    for (var i=0; i<objAttribList.length; i++) {
        attribute = objAttribList[i];
        wi_object.attribute_list[decodeURIComponent(attribute.Name)] = new workitem_attribute(
            decodeURIComponent(attribute.Name),
            decodeURIComponent(attribute.Type),
            decodeURIComponent(attribute.Length),
            decodeURIComponent(attribute.Value),
            false);
    }
}

function fillDocumentList(wi_object, objDocList) {
    var doc;
    for (var i=0; i<objDocList.length; i++) {
        doc = objDocList[i];
        wi_object.attachment_list[i] = new attachment(
            decodeURIComponent(doc.DocumentIndex),
            decodeURIComponent(doc.DocumentName),
            decodeURIComponent(doc.ISIndex),
            decodeURIComponent(doc.NoOfPages),
            decodeURIComponent(doc.AnnotationFlag),
            decodeURIComponent(doc.DocumentType),
            decodeURIComponent(doc.CreatedByAppName),
            decodeURIComponent(doc.CreationDateTime),
            decodeURIComponent(doc.VersionFlag),
            decodeURIComponent(doc.DocumentVersionNo),
            decodeURIComponent(doc.CheckoutStatus),
            decodeURIComponent(doc.CheckoutBy),
            "",
            "",
            decodeURIComponent(doc.Comment),
            decodeURIComponent(doc.DocumentOwner),
            "");
    }
}

function fillToDoList(wi_object, objToDoList) {
    var todoitem
    for (var i=0; i<objToDoList.length; i++) {
        todoitem = objToDoList[i];
        wi_object.to_do_item_list[i] = new todo_item(
            decodeURIComponent(todoitem.Index),
            decodeURIComponent(todoitem.Name),
            decodeURIComponent(todoitem.Value));
    }
}

function fillDynamicConstantList(wi_object, objDynamicConstantList) {
    var dynConst;
    for (var i=0; i<objDynamicConstantList.length; i++) {
        dynConst = objDynamicConstantList[i];
        wi_object.dynamicConst_list[decodeURIComponent(dynConst.ConstantName)] = new constant_attribute(
            decodeURIComponent(dynConst.ConstantName),
            decodeURIComponent(dynConst.ConstantValue),
            decodeURIComponent(dynConst.LastModifiedOn));
    }
}

function fillExceptionList(wi_object, objExceptionList) {
    var excp, excpHistList, excpHist;
    for (var i=0; i<objExceptionList.length; i++) {
        excp = objExceptionList[i];
        wi_object.exception_list[i] = new exception(
            decodeURIComponent(excp.ExceptionID),
            decodeURIComponent(excp.ExceptionName),
            decodeURIComponent(excp.Description),
            '',
            decodeURIComponent(excp.ExceptionType),
            false,
            new Array(),
            "");
        
        excpHistList = excp.ExceptionHistories;
        for(var j=0; j<excpHistList.length; j++) {
            excpHist = excpHistList[j];
            wi_object.exception_list[i].history_list[j] = new exception_history(
                decodeURIComponent(excpHist.ActionIndex),
                decodeURIComponent(excpHist.ActivityName),
                decodeURIComponent(excpHist.UserName),
                decodeURIComponent(excpHist.ActionDateTime),
                decodeURIComponent(excpHist.Comments),
                decodeURIComponent(excpHist.Status));
        }
    }
}