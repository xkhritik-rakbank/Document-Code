


var strSelectedIndex = "";
var checkResize = 0;
var ScreenWidth = function() {
    try {
        return window.parent.screen.availWidth;
    } catch(e) {
        return window.screen.availWidth;
    }
}();
var ScreenHeight = function() {
    try {
        return window.parent.screen.availHeight;
    } catch(e) {
        return window.screen.availHeight;
    }
}();
var WindowLeft = "";
var WindowTop = "";
var refItem;
var selectedWiInfo = "";
var ReqParams = "";
var worklistString = "";
var WD_SID;
var oper = "";
var bOprRefreshWorkitem = false;

window.onresize = function() {
    checkResize = 1;
}

function wioc(obj, ref) {
    strSelectedIndex = "";

    var reftype = (typeof ref);
    if (reftype == 'string') {
        ref = document.getElementById(ref);
    }

    refItem = ref;
    var ctrlTableId = "wlf:pnlResult";
    var checkboxId = "wlf:cb_";

    var QId = document.getElementById("wlf:hidQueueId").value;
    var QName = document.getElementById("wlf:hidQueueName").value;
    var QType = document.getElementById("wlf:hidQueueType").value;
    var orderBy = document.getElementById('wlf:hidOrderBy').value;
    var sortOrder = document.getElementById('wlf:hidSortOrder').value;
    var flag = document.getElementById('wlf:hidFlag').value;
    var filterString = document.getElementById('wlf:hidFilterString').value;
    var filterTag = "<FilterString>";
    var index = 0;
	var activityId = document.getElementById('wlf:hidActivityId').value;
    var processDefId = document.getElementById('wlf:hidProcessDefId').value;
//    if(flag==2){
//         filterString=filterString.substring(0, filterString.lastIndexOf("</FilterString>"));
//         index=index+filterTag.length;
//         filterString=filterString.substring(index,filterString.length);
//    }
    if (flag == 4)
    {
        index = filterString.substring(0, filterString.lastIndexOf("<Filter>")).length;
        filterString = filterString.substring(index, filterString.length);
    }
    if (obj == 'txt' || obj == 'csv' || obj == 'xls' || obj == 'pdf') {
        //showSave="N";
        var save = document.getElementById("wlf:Save");
        var disSave = document.getElementById("wlf:disableSave");
        var saveDiv = document.getElementById("saveDiv");
        var saveMenuImg = document.getElementById("wlf:saveSubMenuImg");

        if (save != undefined && disSave != undefined && saveMenuImg != undefined) {
            saveDiv.style.display = "none";
        } else {
            save = document.getElementById("wlf:Save");
            disSave = document.getElementById("wlf:disableSave");
            saveMenuImg = document.getElementById("wlf:saveSubMenuImg");

            if (save != undefined && disSave != undefined && saveMenuImg != undefined) {
                saveDiv.style.display = "none";
            }
        }
    }

    var authFlag = document.getElementById("wlf:hidAuthorizedFlag").value;
    worklistString = "QueueId=" + QId + "&QueueType=" + QType + "&OrderBy=" + orderBy + "&SortOrder=" + sortOrder + "&FilterString=" + encode_utf8(filterString) + "&Flag=" + flag + "&AuthFlag=" + authFlag;
    if ((flag == 3) || (flag == 4) || (flag == 5)) {
        worklistString = worklistString + "&isSearch=Y"
    } else {
        worklistString = worklistString + "&isSearch=N"
    }

    var ctrlTable = document.getElementById(ctrlTableId);

    var paramflag = "N";
    var param = "";
    var strSelWiPidList = "";
    //document.getElementById('MoreDiv').style.display = 'none';
    //document.getElementById('MoreDiv2').style.display = 'none';

    if (ctrlTable != null)
    {

        var rowCount = ctrlTable.tBodies[0].rows.length;
        if (rowCount > 0) {
            for (var iCount = 0; iCount < rowCount - 1; iCount++)
            {

                var wiClicked = document.getElementById(checkboxId + iCount);
                if (wiClicked.checked) {
                    paramflag = "N";
                    //alert(checkboxId+iCount);
                    if (strSelectedIndex.length == 0) {
                        strSelectedIndex = strSelectedIndex + iCount;
                    } else {
                        strSelectedIndex = strSelectedIndex + "," + iCount;
                    }

                    if (paramflag == "N") {
                        var jsonOutput = document.getElementById("wlf:hjn" + (iCount + 1)).innerHTML;
                        //jsonOutput= parseJSON("("+jsonOutput+")");
                        //var arrobjJsonOutput= jsonOutput.Outputs;
                        var arrobjJsonOutput = jsonOutput.split(SEPERATOR1+SEPERATOR4);

                        //for(var i=0;i<arrobjJsonOutput.length;i++){
                        //var outputJson=arrobjJsonOutput[i];
                        //var objJson=outputJson.Output;

                        //if(objJson.Name=='QueueId'){
                        //listParam.push(new Array(objJson.Name,encode_ParamValue(objJson.Value)));
                        param = param + "QueueId=" + arrobjJsonOutput[12] + "&";
                        //}
                        //if(objJson.Name=='QueueType'){
                        //  listParam.push(new Array(objJson.Name,encode_ParamValue(objJson.Value)));
                        param = param + "QueueType=" + arrobjJsonOutput[10] + "&";
                        //}
                        if (obj == 'Reminder' || obj == 'Properties' || obj == 'hold' || obj == 'unhold') {
                            //if(objJson.Name=='ProcessInstanceID'){
                            //  listParam.push(new Array(objJson.Name,encode_ParamValue(objJson.Value)));
                            param = param + "ProcessInstanceID=" + encode_utf8(arrobjJsonOutput[3]) + "&";
                            //}
                            //if(objJson.Name=='WorkitemID'){
                            //  listParam.push(new Array(objJson.Name,encode_ParamValue(objJson.Value)));
                            param = param + "WorkitemID=" + arrobjJsonOutput[0].replace(/(\r\n|\n|\r)/gm, "") + "&";
                            //}
                        }

                        if (obj == 'Initiate' || obj == 'Done') {
                            //if(objJson.Name=='ProcessInstanceID'){
                            if (strSelWiPidList.length == 0) {
                                strSelWiPidList = encode_utf8(arrobjJsonOutput[3]);
                            } else {
                                strSelWiPidList = strSelWiPidList + "," + encode_utf8(arrobjJsonOutput[3]);
                            }
                            //}
                        }

                        //if(obj=='Initiate'){
                        //if(objJson.Name=='QueueName'){
                        //  listParam.push(new Array(objJson.Name,encode_ParamValue(objJson.Value)));
                                        var qString = arrobjJsonOutput[11].replace(/'/g, "");
                                        //qString = escape(qString)
                        param = param + "QueueName=" + encode_utf8(qString) + "&";
                        //}
                        //}
                        //if(objJson.Name=='RouteId'){
                        param = param + "RouteId=" + arrobjJsonOutput[5] + "&";
                        //}
                        //if(objJson.Name=='RouteName'){
                                param=param+"RouteName="+encode_utf8(arrobjJsonOutput[6])+"&";
                        //}
                        //if(objJson.Name=='WorkstageId'){
                        param = param + "WorkstageId=" + arrobjJsonOutput[9] + "&";
                        //}
                        //if(objJson.Name=='ActivityName'){
                        param = param + "ActivityName=" + encode_utf8(arrobjJsonOutput[7]) + "&";
                        //}
                        //if(objJson.Name=='WorkitemState') {
                        param = param + "WorkitemState=" + arrobjJsonOutput[2] + "&";
                        //}
                                param=param+"URN="+encode_utf8(arrobjJsonOutput[37])+"&";
                        paramflag = 'Y';
                        //}
                    }
                }
            }
        }
    }
    //  alert(param);
    var Url = "";
    var isSearch = document.getElementById("wlf:hidFlag").value;
    if(document.getElementById("wlf:hidSelectedOpr"))
        document.getElementById("wlf:hidSelectedOpr").value = obj;
    if (obj == 'Filter')
    {
        var WindowHeight = 420;
        var WindowWidth = 600;
        var wFeatures = 'status=yes,resizable=1,scrollbars=no,width=' + (WindowWidth + 40) + ',height=' + WindowHeight + ',left=' + windowY + ',top=' + (window1X);
        Url = sContextPath + '/components/search/setfilter.app?Action=1&QueueID=' + QId + '&QueueName=' + encodeURIComponent(QName);
        //alert(wLMode);
        if (wLMode != undefined) {
            Url = Url + "&WLMode=" + wLMode;
        } else {
            Url = Url + "&WLMode=PM";
        }
        openNewWindow(Url, 'filter', wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", "");
    }
    else if (obj == 'Reassign') {
        ReqParams = param;
		if(arrobjJsonOutput[12]==0){
            ReqParams=ReqParams+"ActivityId="+activityId+"&";
            ReqParams=ReqParams+"ProcessDefId="+processDefId+"&";
		}
        var selWIList = strSelectedIndex + "";
        if (strSelectedIndex != "") {
            selWIList = selWIList.split(",");
        }
        var reassignLoader = ContentLoaderWrapper(sContextPath + '/ajaxcustom.app?CheckedIndexes=' + strSelectedIndex + '&SelectedWICount=' + selWIList.length + '&WD_SID=' + WD_SID, reassignFunHandler, callBackOnError, "POST", "");
        //document.getElementById("Reassign").style.top = "10px";
    } else if (obj == 'Priority') {
        var woklistMode = (typeof wLMode == 'undefined') ? 'WD' : wLMode;
        var insId = '';
        if (document.getElementById("wlf:hidCompInsID") != null) {
            insId = document.getElementById("wlf:hidCompInsID").value;
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            insId = document.getElementById("wlf:hidExtCompInsID").value;
        }
        Url = sContextPath + '/components/workitem/operations/changepriority.app?Action=1&CheckedIndexes=' + strSelectedIndex + '&insid=' + insId + '&' + param + '&WD_SID=' + WD_SID + '&WorklistMode=' + woklistMode;
        WindowLeft = findAbsPosX(refItem);
        WindowTop = findAbsPosY(refItem);
        window.parent.popupIFrameOpenerWrapper(refItem, "Priority", Url, 350, 285, WindowLeft, WindowTop, false, true, false, true, true);

    } else if (obj == 'Delete') {
        setPopupMask();
        document.getElementById('MessageDiv').style.display = 'inline';
        positionmenu('wlf:moreOptionsBtn', 'MessageDiv');
    } else if (obj == 'Refer') {
        var insId = '';
        if (document.getElementById("wlf:hidCompInsID") != null) {
            insId = document.getElementById("wlf:hidCompInsID").value;
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            insId = document.getElementById("wlf:hidExtCompInsID").value;
        }
        Url = sContextPath + '/components/workitem/operations/referworkitem.app?Action=1&CheckedIndexes=' + strSelectedIndex + '&' + param + '&OpenFrom=WD' + '&insid=' + insId + '&WD_SID=' + WD_SID;

        //createPopUpIFrame("Refer",Url,400,400);
        //document.getElementById("Refer").style.top = "10px";
        WindowLeft = findAbsPosX(refItem);
        WindowTop = findAbsPosY(refItem);
        window.parent.popupIFrameOpenerWrapper(this, "Refer", Url, 375, 289, WindowLeft, WindowTop, false, true, false, true, true);

    } else if (obj == 'Initiate') {
        var selWIList = strSelectedIndex + "";
        if (strSelectedIndex != "") {
            selWIList = selWIList.split(",");
        }
        var insId = '';
        if (document.getElementById("wlf:hidCompInsID") != null) {
            insId = document.getElementById("wlf:hidCompInsID").value;
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            insId = document.getElementById("wlf:hidExtCompInsID").value;
        }
        if (isSearch == '3')
            var initiateLoader = ContentLoaderWrapper('/webdesktop/ajaxinitiate.app?CheckedIndexes=' + strSelectedIndex + '&WD_SID=' + WD_SID, deleteHandler, null, "POST", "");
        else
            var Customurl = ContentLoaderWrapper('/webdesktop/ajaxCustomFormUrl.app', CustomFormUrlHandlerForInitiate, null, "POST", 'OP=I&CheckedIndexes=' + strSelectedIndex + '&SelectedWICount=' + selWIList.length + "&strwilist=" + strSelWiPidList + "&" + param + '&WD_SID=' + WD_SID);
    } else if (obj == 'Done') {
        getDoneInformation();
        var flag = wiOptDoneClick();//Bug 68258
        if (flag == true) {
            WindowLeft = findAbsPosX(refItem);
            WindowTop = findAbsPosY(refItem);

            var selWIList = strSelectedIndex + "";
            if (strSelectedIndex != "") {
                selWIList = selWIList.split(",");
            }
            var insId = '';
            if (document.getElementById("wlf:hidCompInsID") != null) {
                insId = document.getElementById("wlf:hidCompInsID").value;
            } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
                insId = document.getElementById("wlf:hidExtCompInsID").value;
            }
            //       if(isSearch == '3' || isSearch == '4') //Bug Id : 54389
            //         var doneLoader = ContentLoaderWrapper('/webdesktop/ajaxdone.app?CheckedIndexes='+strSelectedIndex +'&fromSearch=Y&WD_SID='+WD_SID,deleteHandler,callBackOnError,"POST","");
            //   else
            var Customurl = ContentLoaderWrapper('/webdesktop/ajaxCustomFormUrl.app?', CustomFormUrlHandlerForDone, callBackOnError, "POST", 'OP=D&CheckedIndexes=' + strSelectedIndex + '&SelectedWICount=' + selWIList.length + "&strwilist=" + strSelWiPidList + "&" + param + '&WD_SID=' + WD_SID);
        }
    } else if (obj == 'Lock') {
        document.getElementById("wlf:selIndexWIOp").value = strSelectedIndex;
        if (document.getElementById("wlf:hidCompInsID") != null) {
            if (document.getElementById("wlf:hidCompInsID").value != '') {
                document.getElementById("insid").value = document.getElementById("wlf:hidCompInsID").value;
            }
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            if (document.getElementById("wlf:hidExtCompInsID").value != '') {
                document.getElementById("insid").value = document.getElementById("wlf:hidExtCompInsID").value;
            }
        }

        clickLink("wlf:LockWI");
    } else if (obj == 'Reminder') {
        Url = sContextPath + '/components/workitem/operations/setreminders.app?Action=1&' + param + '&TimeZone=' + (new Date()).getTimezoneOffset() + '&WD_SID=' + WD_SID;
        //createPopUpIFrameWrapper("Reminder",Url,600,600);
        //document.getElementById("Reminder").style.top = "10px";
        WindowLeft = parseInt(ScreenWidth / 2) - parseInt(550 / 2);
        WindowTop = parseInt(ScreenHeight / 2) - parseInt(500 / 2) - 115;
        window.parent.popupIFrameOpenerWrapper(this, "Reminder", Url, 550, 540, WindowLeft, WindowTop, false, true, false, true, true);
    } else if (obj == 'Release') {
        //WindowLeft=findAbsPosX(refItem);
        //WindowTop=findAbsPosY(refItem);
        WindowLeft = parseInt(ScreenWidth / 2) + 180 - 56;
        WindowTop = parseInt(ScreenHeight / 2) + 133;
        document.getElementById("wlf:selIndexWIOp").value = strSelectedIndex;
        if (document.getElementById("wlf:hidCompInsID") != null) {
            if (document.getElementById("wlf:hidCompInsID").value != '') {
                document.getElementById("insid").value = document.getElementById("wlf:hidCompInsID").value;
            }
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            if (document.getElementById("wlf:hidExtCompInsID").value != '') {
                document.getElementById("insid").value = document.getElementById("wlf:hidExtCompInsID").value;
            }
        }
        clickLink("wlf:ReleaseWI");
    } else if (obj == 'Revoke') {
        WindowLeft = findAbsPosX(refItem);
        WindowTop = findAbsPosY(refItem);
        document.getElementById("wlf:selIndexWIOp").value = strSelectedIndex;
        if (document.getElementById("wlf:hidCompInsID") != null) {
            if (document.getElementById("wlf:hidCompInsID").value != '') {
                document.getElementById("insid").value = document.getElementById("wlf:hidCompInsID").value;
            }
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            if (document.getElementById("wlf:hidExtCompInsID").value != '') {
                document.getElementById("insid").value = document.getElementById("wlf:hidExtCompInsID").value;
            }
        }
        clickLink("wlf:revokeWI");
    } else if (obj == 'New') {

    } else if (obj == 'Properties') {
        var flagProp = true;
        if (typeof WIPropertiesClick != undefined) {
            var flagProp = WIPropertiesClick();
        }
        var insId = '';
        if (document.getElementById("wlf:hidCompInsID") != null) {
            insId = document.getElementById("wlf:hidCompInsID").value;
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            insId = document.getElementById("wlf:hidExtCompInsID").value;
        }
        if (flagProp) {
            var strArchivalMode = document.getElementById("wlf:hidArchivalMode").value;
            Url = '/webdesktop/components/workitem/operations/workitemproperties.app?Action=1&' + param + "&CheckedIndexes=" + strSelectedIndex + "&ArchivalMode=" + strArchivalMode;
            WindowLeft = parseInt(ScreenWidth / 2) - parseInt(800 / 2);
            WindowTop = parseInt(ScreenHeight / 2) - parseInt(410 / 2);
            var WindowHeight = 420;
            var WindowWidth = 800;


            //   popupIFrameOpenerWrapper(this, "WIProperties", url, 600, 410, left, top, false, false, false, true);

            var wFeatures = 'height=' + WindowHeight + ',width=' + WindowWidth + ',resizable=1,status=1,scrollbars=auto,top=' + WindowTop + ',left=' + WindowLeft;

            openNewWindow(Url, 'WIProperties', wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", "");
        }
    } else if (obj == 'xls' || obj == 'pdf' || obj == 'csv' || obj == 'txt') {
        saveType = obj;
        if (isIE()) {
            clickLink("wlf:enableDownload");
        } else {
            clickLinkSafari("wlf:enableDownload");
        }

    } else if (obj == 'UserPref') {
        Url = sContextPath + '/preferences/preferences.app?Action=1';

        if (wLMode != undefined) {
            Url = Url + "&WLMode=" + wLMode;
        } else {
            Url = Url + "&WLMode=PM";
        }

        WindowLeft = parseInt(ScreenWidth / 2) - parseInt(600 / 2);
        WindowTop = parseInt(ScreenHeight / 2) - parseInt(410 / 2);

        var left = (window.screen.width - 600) / 2;
        var top = (document.documentElement.clientHeight - 410) / 2;

        var WindowHeight = 420;
        var WindowWidth = 600;

        var wFeatures = 'height=' + 550 + ',width=' + WindowWidth + ',resizable=1,status=1,scrollbars=auto,top=' + WindowTop + ',left=' + WindowLeft;

        openNewWindow(Url, 'Preferences', wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", "");

        //  window.parent.popupIFrameOpenerWrapper(this, "Preferences", Url, 600, 410, WindowLeft, WindowTop, false, true, false, true);
    } else if (obj == "adhocRoute") {
        //WindowLeft=findAbsPosX(ref);
        //WindowTop=findAbsPosY(ref);

        var insId = '';
        if (document.getElementById("wlf:hidCompInsID") != null) {
            insId = document.getElementById("wlf:hidCompInsID").value;
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            insId = document.getElementById("wlf:hidExtCompInsID").value;
        }
        Url = sContextPath + '/components/workitem/operations/adhocrouting.app?Action=1&CheckedIndexes=' + strSelectedIndex + '&OpenFrom=PM' + '&Operation=Adhoc' + '&Name=Adhoc&a=b' + '&WD_SID=' + WD_SID + '&insid=' + insId;//Bug 74916//Bug 76132

        window.parent.popupIFrameOpenerWrapper(this, "adhoc", Url, 600, 250, WindowLeft, WindowTop, false, true, false, true, true);
    } else if (obj == "unlock") {
        var insId = '';
        if (document.getElementById("wlf:hidCompInsID") != null) {
            insId = document.getElementById("wlf:hidCompInsID").value;
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            insId = document.getElementById("wlf:hidExtCompInsID").value;
        }
        Url = sContextPath + '/components/workitem/operations/unlock.app?Action=1&CheckedIndexes=' + strSelectedIndex + '&OpenFrom=PM' + '&Operation=Unlock' + '&Name=Unlock' + '&WD_SID=' + WD_SID + '&insid=' + insId;
        window.parent.popupIFrameOpenerWrapper(this, "unlock", Url, 350, 250, WindowLeft, WindowTop, false, true, false, true, true);
    } else if (obj == "hold") {
        var insId = '';
        if (document.getElementById("wlf:hidCompInsID") != null) {
            insId = document.getElementById("wlf:hidCompInsID").value;
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            insId = document.getElementById("wlf:hidExtCompInsID").value;
        }
        Url = sContextPath + '/components/workitem/operations/hold.app?Action=1&' + param + '&OpenFrom=WD&WD_SID=' + WD_SID + '&insid=' + insId;

        WindowLeft = parseInt(ScreenWidth / 2) - parseInt(550 / 2);
        WindowTop = parseInt(ScreenHeight / 2) - parseInt(500 / 2) - 115;
        window.parent.popupIFrameOpenerWrapper(this, "hold", Url, 400, 300, WindowLeft, WindowTop, false, true, false, true, true);
    } else if (obj == "unhold") {
        Url = sContextPath + '/components/workitem/operations/unhold.app?Action=1&' + param + '&OpenFrom=WD&WD_SID=' + WD_SID;
        WindowLeft = parseInt(ScreenWidth / 2) - parseInt(550 / 2);
        WindowTop = parseInt(ScreenHeight / 2) - parseInt(500 / 2) - 115;
        window.parent.popupIFrameOpenerWrapper(this, "unhold", Url, 400, 320, WindowLeft, WindowTop, false, true, false, true, true);
    }
}

function newWorkitemClickWrapper()
{
    var queueProcessLoaded = document.getElementById("wlf:queueProcessLoaded").value;
    if (queueProcessLoaded == "N") {
        clickLink("wlf:getQueueProcessList");
    } else {
        //clickLink("wlf:getQueueProcessList");        //Bug 91740  //Bug 98869
        newWorkitemClick();
    }
}

function newWorkitemClickWrapperHandler(data) {
    HandleProgressBar(data);

    if (data.status == 'begin') {
        document.getElementById("wlf:queueProcessLoaded").value = "Y";
    }

    if (data.status == 'success') {
        newWorkitemClick();
    }
}

function newWorkitemClick()
{
    //clickLink('wlf:cmdCreateNewWI');
    NewWorkitemAction();
}


function CustomFormUrlHandlerForInitiate()
{
    var response = this.req.responseText;
    var url = "";
    var formNotFound = "";
    var selectedWorkItemInfoXml = '';
    response = parseJSON("(" + response + ")");
    var queueID;
    var strPMSType = "";
    var strOPR = "";

    for (i = 0; i < response.length; i++)
    {
        url = response[i].FormURL + "";
        formNotFound = response[i].FormNotFound;
        queueID = response[i].QueueID;
        var queueName = response[i].strQueuename;
        selectedWorkItemInfoXml = selectedWorkItemInfoXml + response[i].SelectedWorkItemInfo;
        strPMSType = response[i].PMSType;
        strOPR = response[i].OPR;
    }

    var selWIList = strSelectedIndex;
    var attributeXmlTmp = "";
    selWIList = selWIList.split(",");
    attributeXmlTmp = setQueueData(queueID, selWIList.length);
    var insId = '';
    if (document.getElementById("wlf:hidCompInsID") != null) {
        insId = document.getElementById("wlf:hidCompInsID").value;
    } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
        insId = document.getElementById("wlf:hidExtCompInsID").value;
    }
    if (formNotFound == "True")
        var initiateLoader = ContentLoaderWrapper('/webdesktop/ajaxinitiate.app?CheckedIndexes=' + strSelectedIndex + '&WD_SID=' + WD_SID, deleteHandler, callBackOnError, "POST", "");
    else
    {
        url = url + "&attributeXmlTmp=" + attributeXmlTmp + "&queueName=" + queueName + "&OPR=" + strOPR;

        var ScreenHeight = screen.height;
        var ScreenWidth = screen.width;
        var WindowHeight = 400;
        var WindowWidth = 600;
        var WindowLeft = parseInt(ScreenWidth / 2) - parseInt(WindowWidth / 2);
        var WindowTop = parseInt(ScreenHeight / 2) - parseInt(WindowHeight / 2);
        var wFeatures = 'resizable=no,scrollbars=auto,status=yes,top=' + WindowTop + ',left=' + WindowLeft + ',width=' + WindowWidth + ',height=' + WindowHeight;

        var listParam = new Array();
        listParam = getInputParamListFromURL(url);
        openNewWindow(url, 'test', wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", listParam);
    }
}


function deleteHandler() {
    var response = this.req.responseText;
    response = response.trim();
    if (response != "success") {
        WindowLeft = findAbsPosX(refItem);
        WindowTop = findAbsPosY(refItem);
        var url = '/webdesktop/components/workitem/list/failedworkitemlist.app?WD_SID=' + WD_SID;
        window.parent.popupIFrameOpenerWrapper(this, "failedworkitemlist", url, 400, 300, WindowLeft, WindowTop, false, true, false, true);
        //createPopUpIFrameWrapper("failedworkitemlist", url, 400, 400);
    }
    else {
//        if(wLMode == "CM"){
//                if(window.parent.iFrameTaskListRef != null){
//                    window.parent.iFrameTaskListRef.clearTaskList();
//                }
//        }
        showSuccessDiv(OPERATION_PERFORMED_SUCCESSFULLY);
    }
}

function refresh()
{
    RefreshWorklist();
    if (targetEmbdWIRef != null) {
        if (typeof targetEmbdWIRef.doRefreshEbmdWI != 'undefined') {
            targetEmbdWIRef.doRefreshEbmdWI();
        }
    }
}

function refreshWrapper(opr)
{
    if (typeof opr != 'undefined' && opr != null) {
        document.getElementById('wlf:hidOprFlag').value = true;
        document.getElementById('wlf:hidOprPerf').value = opr;
    }
    else {
        document.getElementById('wlf:hidOprFlag').value = false;
        document.getElementById('wlf:hidOprPerf').value = "";
    }
    refresh();
}

function showSuccessDiv(msg) {
    setPopupMask();

    var width = 250;
    var height = 70;
    var left = (document.documentElement.clientWidth - width) / 2 + window.document.body.scrollLeft;
    var top = (document.documentElement.clientHeight - height) / 2 + window.document.body.scrollTop;

    document.getElementById('genSuccessDiv').style.top = top + 'px';
    document.getElementById('genSuccessDiv').style.left = left + 'px';
    document.getElementById('wlf:successpanel:genSuccessMsg').innerHTML = encode_ParamValue(msg);

    document.getElementById('genSuccessDiv').style.display = 'block';


}

function CustomFormUrlHandlerForDone() {
    var response = this.req.responseText;
    response = parseJSON("(" + response + ")");
    var queueID = "";
    var formNotFound = "";
    var url = "";
    var selectedWorkItemInfoXml = '';
    var strPMSType = "";
    var strOPR = "";

    for (var i = 0; i < response.length; i++)
    {
        url = response[i].FormURL + "";
        formNotFound = response[i].FormNotFound;
        queueID = response[i].QueueID;
        var queueName = response[i].strQueuename;
        selectedWorkItemInfoXml = selectedWorkItemInfoXml + response[i].SelectedWorkItemInfo;
        strPMSType = response[i].PMSType;
        strOPR = response[i].OPR;
    }

    var selWIList = strSelectedIndex;
    var attributeXmlTmp = "";
    selWIList = selWIList.split(",");
    attributeXmlTmp = setQueueData(queueID, selWIList.length);

    if (formNotFound == "True") {
        //changes for 31559 - Parameter fromSearch=N is passed 
        var insId = '';
        if (document.getElementById("wlf:hidCompInsID") != null) {
            insId = document.getElementById("wlf:hidCompInsID").value;
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            insId = document.getElementById("wlf:hidExtCompInsID").value;
        }

        var doneLoader = ContentLoaderWrapper('/webdesktop/ajaxdone.app?CheckedIndexes=' + strSelectedIndex + '&AttributeXml=' + attributeXmlTmp + '&fromSearch=N' + '&WD_SID=' + WD_SID, deleteHandler, callBackOnError, "POST", "");
    } else {
        url = url + "&attributeXmlTmp=" + attributeXmlTmp + "&queueName=" + queueName + "&OPR=" + strOPR;

        var ScreenHeight = screen.height;
        var ScreenWidth = screen.width;
        var WindowHeight = 400;
        var WindowWidth = 600;
        var WindowLeft = parseInt(ScreenWidth / 2) - parseInt(WindowWidth / 2);
        var WindowTop = parseInt(ScreenHeight / 2) - parseInt(WindowHeight / 2);
        var wFeatures = 'resizable=no,scrollbars=auto,status=yes,top=' + WindowTop + ',left=' + WindowLeft + ',width=' + WindowWidth + ',height=' + WindowHeight;

        var listParam = new Array();
        listParam = getInputParamListFromURL(url);
        openNewWindow(url, 'test', wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", listParam);
    }
}

function customDoneCallBack(attributeXml, attributeXmlTmp, queueName) {
    if (attributeXml.length > 1 || attributeXmlTmp.length > 1) {
        attributeXml = attributeXmlTmp + attributeXml;
        var insId = '';
        if (document.getElementById("wlf:hidCompInsID") != null) {
            insId = document.getElementById("wlf:hidCompInsID").value;
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            insId = document.getElementById("wlf:hidExtCompInsID").value;
        }
        if (IsCompleteWorkItem(queueName)) {
            var doneLoader = ContentLoaderWrapper('/webdesktop/ajaxdone.app', deleteHandler, callBackOnError, "POST", 'CheckedIndexes=' + strSelectedIndex + '&AttributeXml=' + attributeXml + '&fromSearch=N' + '&WD_SID=' + WD_SID);
        } else {
            var doneLoader = ContentLoaderWrapper('/webdesktop/ajaxdone.app', deleteHandler, callBackOnError, "POST", 'CheckedIndexes=' + strSelectedIndex + '&AttributeXml=' + attributeXml + '&fromSearch=N&IsCompleteWorkItem=N' + '&WD_SID=' + WD_SID);
        }
    }
}

function customInitiateCallBack(attributeXml, attributeXmlTmp, queueName) {
    if (attributeXml.length > 1 || attributeXmlTmp.length > 1) {
        attributeXml = attributeXmlTmp + attributeXml;
        var insId = '';
        if (document.getElementById("wlf:hidCompInsID") != null) {
            insId = document.getElementById("wlf:hidCompInsID").value;
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            insId = document.getElementById("wlf:hidExtCompInsID").value;
        }
        var initiateLoader = ContentLoaderWrapper('/webdesktop/ajaxinitiate.app?CheckedIndexes=' + strSelectedIndex + '&AttributeXml=' + attributeXml + '&fromSearch=N&WD_SID=' + WD_SID, deleteHandler, callBackOnError, "POST", "");
    }
}

function saveFormdata(formDataTodo, frm, from) {
    /*check for frm value is present in validatData also,to be modified there also*/
    var formWindow = getWindowHandler(windowList, "formGrid");
    var todoWindow = getWindowHandler(windowList, "todoGrid");
    var taskWindow = getWindowHandler(windowList, "taskGrid");
    var formParam = "";	//used to store form parameter
    var todoParam = "";       //used to store todo param
    var taskParam = "";       //used to store task param
    var param = "";           //used to store combined param
    var status;
    var taskstatus;
    if (typeof frm == 'undefined')
        frm = '';
    if (typeof from == 'undefined')
        from = '';
    if (typeof formWindow != 'undefined') {
        status = validatData(frm);
        if (status != 'false') {
            if (wiproperty.formType != "NGFORM")
            {
                setmessageinDiv(status, "true", 3000);
                if (from == 'close')
                    customAlert(VALIDATION_FAILED);
                formWindow.focus();

            }
            return false;
        }
        wiform = formWindow.document.getElementById('wdesk');
        if (wiproperty.formType == "NGFORM") {
            if (ngformproperty.type == "applet") {
                if (!bDefaultNGForm) {
                } else {
                    formParam = "ngParam=" + encodeURIComponent(formWindow.document.wdgc.getFieldValueBagEx()) + "&";
                }
            }
            else
                formParam = formWindow.getNGFormValuesForAjax();
        }
        else if (wiproperty.formType == "HTMLFORM") {
            formParam = getFormValuesForAjax(wiform);

        }
        else if (wiproperty.formType == "VARIANTFORM") {//added for Variant : 17 Oct 13
            formParam = getFormValuesForAjax(wiform);

        }
        else if (wiproperty.formType == "CUSTOMFORM") {
            var customform = '';
            //commented code As discuss with KD sir by mandeep start on 17/01/2011
            if (WIObjectSupport.toUpperCase() == 'Y')
                customform = formWindow.frames['customform'].document.forms['dataform'];
            else
                customform = formWindow.frames['customform'].document.forms['wdesk'];
            //commented code As discuss with KD sir by mandeep end on 17/01/2011
            formParam = getFormValuesForAjax(customform);

        }
    }

    //Handling for task form
    if (typeof taskWindow != 'undefined') {
        taskstatus = validateTaskData(frm);
        if (taskstatus != 'false') {
            if (wiproperty.TaskFormType != "NGFORM")
            {
                setmessageinDiv(taskstatus, "true", 3000);
                if (from == 'close')
                    customAlert(VALIDATION_FAILED);
                taskWindow.focus();

            }
            return false;
        }
        witaskform = taskWindow.document.getElementById('wdesk');
        if (wiproperty.TaskFormType == "NGFORM") {
            if (taskngformproperty.type == "applet") {
                if (!bDefaultNGForm) {
                } else {
                    taskParam = "taskngParam=" + encodeURIComponent(taskWindow.document.wdgc.getFieldValueBagEx()) + "&";
                }
            }
            else
                taskParam = taskWindow.getNGFormValuesForAjax();
        }
        else if (wiproperty.TaskFormType == "HTMLFORM") {
            taskParam = getFormValuesForAjax(witaskform);

        }
    }

    if ((typeof todoWindow != 'undefined' && typeof formWindow != 'undefined')) {
        if (todoWindow.location != formWindow.location || wiproperty.formType == "CUSTOMFORM" || wiproperty.formType == "NGFORM") {
            var todoform = todoWindow.document.getElementById('wdesk');
            todoParam = todoWindow.getFormValuesForAjax(todoform);
        }
    }
    else if ((typeof todoWindow != 'undefined' && typeof formWindow == 'undefined')) {
        var todoform = todoWindow.document.getElementById('wdesk');
        todoParam = todoWindow.getFormValuesForAjax(todoform);
    }


    param = formParam + todoParam + taskParam;

    if (frm == 'done' || frm == 'introduce') {
        if (docCheckOut != 0) {
            if (confirmCheckout == "N") {
                customAlert(ALERT_DOCUMENT_CHECKEDOUT);
                return false;
            }
            else {
                retValDoc = confirm(CONFIRM_DOC_STATUS);
                if (!retValDoc)
                    return retValDoc;
            }
        }
    }
    var chkToDo = 'true';
    var excpWindow = getWindowHandler(windowList, "exceptionGrid");

    if (typeof excpWindow != 'undefined') {
        chkToDo = excpWindow.excpOk("save", formDataTodo, param, from);
        if (chkToDo == false) {
            return false;
        }
    }
    else {
        var pid = document.getElementById('wdesk:pid').value;
        var wid = document.getElementById('wdesk:wid').value;
        var taskid = document.getElementById('wdesk:taskid').value;
        var trigDesc = '';
        var url = '';
        var xhReq;

        for (var i = 0; i < 3; i++) {
            try {
                xhReq = null;
                url = '/webdesktop/ajaxexcpok.app';
                url = appendUrlSession(url);
                if (window.XMLHttpRequest)
                    xhReq = new XMLHttpRequest();
                else
                    xhReq = new ActiveXObject("Microsoft.XMLHTTP");
                var wd_rid = getRequestToken(url);
                url += "&WD_RID=" + wd_rid;
                xhReq.open("POST", url, false);
                xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                var strCustomParam = document.getElementById("customParam").value;  //puneet tbd
                var strExtParam = getExtParam(strprocessname, stractivityName);
                xhReq.send(param + 'pid=' + encodeURIComponent(pid) + '&CustomAjax=true&wid=' + wid + '&taskid=' + taskid + '&trigDesc=' + trigDesc + '&flag=' + formDataTodo + '&customParam=' + strCustomParam + '&WD_SID=' + WD_SID + '&extParam=' + strExtParam);
                break;
            } catch (ex) {
                //alert("ex: "+ex);
            }
        }


        if (xhReq.status == 200 && xhReq.readyState == 4) {
            chkToDo = xhReq.responseText;
            /*            if(msg)
             msg.hideDialog();*/
        }
        else
        {
            if (xhReq.status == 598) {
                if (xhReq.responseText == '975') { // Error handling for case refresh
                    var errormsg = getRefreshMsg();
                    document.getElementById('Save').style.display = 'none';
                    document.getElementById('Done').style.display = 'none';
                    document.getElementById('Close').style.display = 'none';
                    setmessageinDiv(errormsg, "false", 3000);
                } else
                    customAlert(xhReq.responseText);

            } else if (xhReq.status == 599) {
                //url = sContextPath+"/login/logout.jsp?"+"error=4020";
                url = sContextPath + "/error/errorpage.app?msgID=4020";
                url = appendUrlSession(url);
                //window.open(url,reqSession);

                var width = 320;
                var height = 160;
                var left = (window.screen.availWidth - width) / 2;
                var top = (window.screen.availHeight - height) / 2;

                //window.open(url,reqSession);
                if (window.showModalDialog) {
                    window.showModalDialog(url, '', "dialogWidth:" + width + "px;dialogHeight:" + height + "px;center:yes;dialogleft: " + left + "px;dialogtop: " + top + "px");
                }
            }
            else if (xhReq.status == 250)
            {
                window.location = "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";
            }
            else if (xhReq.status == 310)
            {
                window.location = "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";
            }
            else if (xhReq.status == 400)
                customAlert(INVALID_REQUEST_ERROR);
            else if (xhReq.status == 12029) {
                customAlert(ERROR_SERVER);
            }
            else {
                customAlert(ALERT_OPERATION_UNSUCCESSFUL);
                if (msg)
                    msg.hideDialog();
                return false;
            }
            if (msg)
                msg.hideDialog();
            return false;
        }
    }
    if (chkToDo == 'false') {
        customAlert(TO_DO_LIST_MANDATORY);
        return false;
    }
    else if (chkToDo == 'failure')
        return false;
    return true;
}

function introduceWI(bringNextWorkitem, confirmFlag) {
    /*if (document.getElementById("expGrid") != null) {
        window.parent.hideShowInterfaceTab("exp", "form");
        window.parent.toggleIntFace("form", "exp");
    }*/
    if (isFormLoaded == false)
        return;
    if (checkExpStatus == "Y") {
        if (!checkExpTempStatus()) {
            customAlert(ALERT_COMMIT_EXCEPTION_BEFORE_SUBMIT);
            return;
        }
    }

    if ((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm) {
        try {
            var ngformIframe = document.getElementById("ngformIframe");
            var isValidated = false;
            if (bAllDeviceForm) {
                isValidated = ngformIframe.contentWindow.eval("isComponentValidated()");
            } else {
                isValidated = ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.isComponentValidated()");
            }
            if (!isValidated) {
                return;
            }
        } catch (e) {
        }
    }

    var formWindow = getWindowHandler(windowList, "formGrid");
    /* if(typeof formWindow!='undefined' && wiproperty.formType=="NGFORM"){
     var validationStatus = "";
     validationStatus = document.wdgc.ValidateControls('D');
     if(validationStatus == false)
     return false;
     }else if(typeof customValidation!='undefined' &&!customValidation("D")){
     return false;
     }*/
    if (formWindow) {//added for Variant
        executeOnSaveVariant();
    }
    if (!form_cutomValidation(IntroParamHook())) {
        hideProcessing();
        return false;
    }
    var batchflag = document.getElementById('wdesk:batchflag').value;
    var status = "";
    if (!saveFormdata('formDataTodo', 'introduce')) {
        hideProcessing();
        return false;
    }
    //Bug 75400 Start
    if (typeof confirmAnnotationSave != undefined && confirmAnnotationSave == "Y") {
        if ((document.getElementById('wdesk:ivapp') != null) && (document.getElementById('wdesk:ivapp').style.display == "inline" || document.getElementById('wdesk:ivapp').style.display == "block")) {
            try {
                if (document.IVApplet && document.IVApplet.annotationModified()) {
                    document.IVApplet.saveAnnotations();
                }
            } catch (e) {
            }
        }
        if ((document.getElementById('wdesk:ifrm') != null) && (document.getElementById('wdesk:ifrm').style.display == "inline" || document.getElementById('wdesk:ifrm').style.display == "block")) {
            if (isOpAll == 'Y' && typeof opall_toolkit != 'undefined' && opall_toolkit && opall_toolkit.annotationModified()) {
                opall_toolkit.saveAnnotation();
            }
        }
    }
    //Bug 75400 End
    var nextWI = (
        isEmbd == 'Y' ||
        wiproperty.isSearch == 'Y' ||
        batchflag == 'N' ||
        (typeof strOpenWI != 'undefined' && strOpenWI == "Y") ||
        (typeof qType != 'undefined' && qType == "T") ||
        (typeof strYesBringNextWI != 'undefined' && strYesBringNextWI == "N" && !yesBringNextWI(strprocessname, stractivityName)) ||
        (typeof bringNextWIOnDone != 'undefined' && bringNextWIOnDone=='N' && !yesBringNextWI(strprocessname,stractivityName)) ||
        (typeof bringNextWorkitem != 'undefined' && bringNextWorkitem == "N")
        ) ? "N" : "Y";

    if(typeof bringNextWorkitem != 'undefined' && (bringNextWorkitem == "Y" || bringNextWorkitem == "N")) {
        nextWI = bringNextWorkitem;
    }
    
    var noConfirmPopup = (confirmDone == 'N' && disableConfirmDone(strprocessname,stractivityName));    
    if(typeof confirmFlag != 'undefined') {
        if(confirmFlag == "Y") {
            noConfirmPopup = false;
        } else if(confirmFlag == "N") {
            noConfirmPopup = true;
        }
    }
    
    if(noConfirmPopup) {
        showProcessing();
        if(nextWI == 'N') {
            handleIntroduceWI('2');
        } else {
            handleIntroduceWI('1');
        }
    }
    else {
        /* var url = "/webdesktop/faces/workitem/view/close.jsp?PName=introduce1&flag=TEXT_INTRODUCE_DONE_WORKITEM&isEmbd="+isEmbd;
         url = appendUrlSession(url);*/
        if (false)//TODO modal dialog
        {
            var url = sContextPath + "/components/workitem/view/confirmdone.app?PName=introduce1&flag=TEXT_INTRODUCE_DONE_WORKITEM&isEmbd=" + isEmbd;
            url = appendUrlSession(url);
            url += '&nextWI=' + nextWI;
            // alert(url);
            ret = window.showModalDialog(url, '', "dialogWidth:" + (windowVW + 100) + "px;dialogHeight:" + windowVH + "px;center:yes;");
            handleIntroduceWI(ret);
        }
        else {
            var url = sContextPath + "/components/workitem/view/confirmdone.app";
            url = appendUrlSession(url);
            url = url + "&PName=introduce1";
            url = url + "&flag=" + encode_ParamValue("TEXT_INTRODUCE_DONE_WORKITEM");
            url = url + "&isEmbd=" + encode_ParamValue(isEmbd);
            url = url + "&nextWI=" + encode_ParamValue(nextWI);

            var popupWidth = (window.screen.width / 1366) * 340;
            var popupHeight = (window.screen.height / 768) * 180;
            var left = (window.screen.width - popupWidth) / 2;
            var top = (document.documentElement.clientHeight - popupHeight) / 2;
            showPopupMask();
            popupIFrameOpenerWrapper(window, "confirmdone", url, popupWidth, popupHeight, left, top, false, true, false, false, true);
            //url+='&nextWI='+nextWI;
            // ret = window.open(url,'closewi',"height="+window5H+",width="+window5W+",status=yes,toolbar=no,menubar=no,location=no,left="+window5X+",top="+window5Y);
        }
    }
}

function handleIntroduceWI(ret) {
    /*Bug Id: 33846:workitem window got freeze*/
    if (typeof CalledFrom != 'undefined') {
        if (CalledFrom != 'M') {
            /*Bug Id: 33846:workitem window got freeze*/
            if (typeof openWorkitemFromLink != 'undefined' && openWorkitemFromLink == 'false') {
                if (window.opener && typeof window.opener.handleDoneIntro == 'unknown') {
                    window.location.href = sContextPath + "/error/errorpage.app?msgID=-8002&HeadingID=8002&WD_SID=" + WD_SID;
                    return false;
                }/*Bug Id: 33846:workitem window got freeze*/
                if (window.opener && typeof window.opener.handleDoneIntro != 'undefined') {
                    window.opener.handleDoneIntro = true;
                    window.opener.handlePrev = false;
                }
            }
        }
    }

    var dataFrm = document.getElementById('wdesk');
    if (ret == '1' || ret == '2') {
        saveReturnOption = ret;
        var formWindow = getWindowHandler(windowList, "formGrid");
        var ngformIframe = document.getElementById("ngformIframe");
        var searchFlag = typeof window.opener != "undefined" ? window.opener.document.getElementById("wlf:hidFlag") : null;
        if(searchFlag && searchFlag.value == "2"){
            dataFrm.FilterString.value = window.opener.document.getElementById("wlf:hidFilterString").value;
dataFrm.decodeFlag.value = window.opener.document.getElementById("wlf:encodeFlag").value;
        }
        if (typeof formWindow != 'undefined' && wiproperty.formType == "NGFORM" && !bAllDeviceForm) {
            if ((ngformproperty.type == "applet") && !bDefaultNGForm) {
                try {
                    if (ngformIframe != null) {
                        if (formIntegrationApr == "4") {
                            //ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.fireFormValidation('I','N')");	                                                                
                            ngformIframe.contentWindow.saveFormStarted("I", "N");
                        } else {
                            ngformIframe.contentWindow.clickLink('cmdNgFormIntroduceRefresh');
                        }
                    }
                } catch (e) {

                }
            } else {
                var retVal = document.wdgc.SaveData('D');
                if (retVal != 1) {
                    hideProcessing();
                    return 'false';
                }
                if (!IntroduceClick()) {
                    hideProcessing();
                    return false;
                }

                unlockflag = "N";
                if (ret == '1') {
                    dataFrm.CloseWindow.value = 'false';
                    dataFrm.isEmbeddded.value = isEmbd;
                }
                else if (ret == '2') {
                    dataFrm.CloseWindow.value = 'true';//close window
                    dataFrm.isEmbeddded.value = isEmbd;
                    if (isEmbd == "Y") {
                        if (typeof isEmbedddedNextWI != 'undefined' && !isEmbedddedNextWI(strprocessname, stractivityName)) {
                            dataFrm.isEmbdNextWI.value = "N"
                        } else {
                            dataFrm.isEmbdNextWI.value = "Y"
                        }
                    }
                }
                var ngParam = getNGParam();
                document.getElementById('extParam').value = getExtParam(strprocessname, stractivityName);
                if (typeof openWorkitemFromLink != 'undefined' && openWorkitemFromLink == 'false') {
                    hideWIFromList(sourceInsId);
                }
                clickWiLink("INTRODUCE", "wdesk:controller", ngParam);
            }
        } else {
            if (!IntroduceClick()) {
                hideProcessing();
                return false;
            }

            unlockflag = "N";
            if (ret == '1') {
                dataFrm.CloseWindow.value = 'false';
                dataFrm.isEmbeddded.value = isEmbd;
            }
            else if (ret == '2') {
                dataFrm.CloseWindow.value = 'true';//close window
                dataFrm.isEmbeddded.value = isEmbd;
                if (isEmbd == "Y") {
                    if (typeof isEmbedddedNextWI != 'undefined' && !isEmbedddedNextWI(strprocessname, stractivityName)) {
                        dataFrm.isEmbdNextWI.value = "N"
                    } else {
                        dataFrm.isEmbdNextWI.value = "Y"
                    }
                }
            }
            var ngParam = getNGParam();
            document.getElementById('extParam').value = getExtParam(strprocessname, stractivityName);
            if (typeof openWorkitemFromLink != 'undefined' && openWorkitemFromLink == 'false') {
                hideWIFromList(sourceInsId);
            }

            if ((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm && (bAllDeviceForm || bAllDeviceTaskForm) && bCustomIForm) {
                if (typeof formWindow != 'undefined' && ngformIframe != null) {
                    var isIntroduceComplete = "";
                    if (typeof ngformIframe.contentWindow.customIFormHandler != 'undefined') {
                        isIntroduceComplete = ngformIframe.contentWindow.customIFormHandler('I');
                        if (isIntroduceComplete != null && isIntroduceComplete.length > 0) {
                            isIntroduceComplete = isIntroduceComplete.trim();
                        }
                    }
                    var responseJSON;
                    if (typeof isIntroduceComplete != 'undefined' && isIntroduceComplete != null && isIntroduceComplete != '') {
                        try {
                            responseJSON = JSON.parse(decodeURIComponent(isIntroduceComplete));
                        } catch (e) {
                        }

                        if (typeof responseJSON != 'undefined' && typeof responseJSON.ResponseCode != 'undefined') {
                            if (responseJSON.ResponseCode == '701') {
                                hideProcessing();
                                if (onSaveValidationFailure(responseJSON.ResponseMessage)) {
                                    setmessageinDiv(responseJSON.ResponseMessage, "false", 3000);
                                }
                                return "failure";
                            } else if (responseJSON.ResponseCode == '599') {
                                hideProcessing();
                                setmessageinDiv(INVALID_SESSION, "false", 3000);
                                return "failure";
                            } else if (responseJSON.ResponseCode != '200' && responseJSON.ResponseCode != '304') {
                                hideProcessing();
                                setmessageinDiv(ERROR_AT_SERVER_END, "false", 3000);
                                return "failure";
                            }
                        } else {
                            if (isIntroduceComplete == "599") {
                                hideProcessing();
                                setmessageinDiv(INVALID_SESSION, "false", 3000);
                                return "failure";
                            } else if (isIntroduceComplete == "701") {
                                hideProcessing();
                                setmessageinDiv(ERROR_AT_SERVER_END, "false", 3000);
                                return "failure";
                            }
                        }
                    }
                }
            }

            clickWiLink("INTRODUCE", "wdesk:controller", ngParam);
        }
    }
    else {
        hideProcessing();
        return;
    }
}

function saveNGFormHandlerOpt() {
    var responseJson = parseJSON("(" + this.req.responseText + ")");
    this.IsValidateForm = responseJson.IsValidateForm;
}

function getNGParam() {
    var ngParam = '';
    var formWindow = getWindowHandler(windowList, "formGrid");
    if (typeof formWindow != 'undefined') {
        if (wiproperty.formType == "NGFORM")
        {
            if (ngformproperty.type == "applet") {
                if ((typeof bDefaultNGForm != 'undefined') && !bDefaultNGForm) {
                } else {
                    if (typeof formWindow.document.wdgc != 'undefined') {
                        ngParam = formWindow.document.wdgc.getFieldValueBagEx();
                    }
                }
            }
            else
                ngParam = formWindow.getNGFormValuesForAjax();
        }
        else if (wiproperty.formType == "CUSTOMFORM") {
            var customform = '';
            //commented code As discuss with KD sir by mandeep start on 18/01/2011
            if (WIObjectSupport.toUpperCase() == 'Y')
                customform = formWindow.frames['customform'].document.forms['dataform'];
            else
                customform = formWindow.frames['customform'].document.forms['wdesk'];
            //commented code As discuss with KD sir by mandeep end on 18/01/2011
            ngParam = getFormValuesForAjax(customform);

        } else if (typeof formWindow != 'undefined' && wiproperty.formType == "HTMLFORM") {
            /*var wiform= formWindow.document.getElementById('wdesk');
             ngParam=getFormValuesForAjax(wiform);*/
            ngParam = '';
        }
    }
    return ngParam;
}

function getTaskNGParam() {
    var taskngParam = '';
    var taskWindow = getWindowHandler(windowList, "taskGrid");
    if (typeof taskWindow != 'undefined') {
        if (wiproperty.TaskFormType == "NGFORM")
        {
            if (taskngformproperty.type == "applet") {
                if ((typeof bDefaultNGForm != 'undefined') && !bDefaultNGForm) {
                } else {
                    if (typeof taskWindow.document.wdgc != 'undefined') {
                        taskngParam = taskWindow.document.wdgc.getFieldValueBagEx();
                    }
                }
            }
            else
                taskngParam = taskWindow.getNGFormValuesForAjax();
        }
    }
    return taskngParam;
}

function freeWorkitem(maillogoutflag, type)
{
    SaveOnCLose = wiproperty.SaveOnClose;
    var dataFrm = document.getElementById('wdesk');
    maillogoutflag = (typeof maillogoutflag == 'undefined' ? "" : maillogoutflag);
    type = (typeof type == 'undefined' ? "" : type);
    if (maillogoutflag == "")
    {
        if (unlockflag == "Y" && wiproperty.locked != "Y") {
            var bJSFFormSave = false;

            if (type == 'beforeunload' && wiproperty.formType == "NGFORM" && ngformproperty.type == "applet" && (typeof bDefaultNGForm != 'undefined') && !bDefaultNGForm && !bAllDeviceForm) {
                var ngformIframe = document.getElementById("ngformIframe");
                if (ngformIframe != null) {
                    var isValueChanged = false;
                    try {
                        isValueChanged = ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.isValueChanged()");
                    } catch (e) {
                    }

                    if (isValueChanged) {
                        bJSFFormSave = true;
                    }
                }
            }

            if (saveCalled == true)
            {
                var qStr = '';
                var flag = 'Y';
                var url = sContextPath + "/components/workitem/view/confirmdone.app?PName=freeWorkitem1&WD_SID=" + WD_SID;

                if (bJSFFormSave) {
                    url += "&flag=JSF_FORM_NOT_SAVED";
                } else {
                    url += "&flag=TEXT_SAVE_WORKITEM";
                }

                url = appendUrlSession(url);
                var ret = 0;
                if (wiproperty.SaveOnClose == 'Y' && isSaveOnClose(strprocessname, stractivityName)) {
                    /*if (window.showModalDialog){
                     if(type=="menuWinClose" && (isEmbd=="N")){
                     if(bJSFFormSave){
                     showWISaveMessage(JSF_FORM_NOT_SAVED, 560, 80, null, null, {'SubType': type, 'Type': 'Close'});                                  
                     } else {
                     showWISaveMessage(ALERT_CLOSE_SAVE_CONFIRM, 270, 80, null, null, {'SubType': type, 'Type': 'Close'});
                     }
                     return false;                            
                     } else {
                     var dialogLeft = document.body.clientWidth/2-windowVW/2;
                     var dialogTop = document.body.clientHeight/2-windowVH/2;
                     
                     if(bJSFFormSave){
                     windowVW += 100;
                     } else {
                     windowVW = windowVW;
                     }
                     var isAlertOnWiClose = true;
                     if (typeof isAlertOnWorkitemClose != 'undefined') {
                     isAlertOnWiClose = isAlertOnWorkitemClose(strprocessname, stractivityName);
                     }
                     if (isAlertOnWiClose) {
                     try{
                     ret = window.showModalDialog(url,'',"dialogWidth:"+windowVW+"px;dialogHeight:"+windowVH+"px;dialogLeft:"+dialogLeft+"px;dialogTop:"+dialogTop+"px");                            
                     }catch(e){
                     ret=1;
                     }
                     //Do not close the workitem on clicking X in save workitem modal dialog
                     if(ret=='' || ret==undefined)
                     return false;
                     //Do not close the workitem on clicking X in save workitem modal dialog
                     } else{
                     ret = 2;
                     }
                     }
                     }
                     else
                     {*/
                    var retval;
                    if (bJSFFormSave) {
                        if (type == "menuWinClose" && (isEmbd == "N")) {
                            showWISaveMessage(JSF_FORM_NOT_SAVED, 560, 80, null, null, {'SubType': type, 'Type': 'Close'});
                        }/* else if(type=="UnloadWIEvent" && (isEmbd=="N")){ 
                         showWISaveMessage(JSF_FORM_NOT_SAVED, 560, 80, null, null, {'SubType': type, 'Type': 'Close'});
                         } */ else {
                            //retval = confirm(JSF_FORM_NOT_SAVED);
                        }
                    } else {
                        if (type == "menuWinClose" && (isEmbd == "N")) {
                            showWISaveMessage(ALERT_CLOSE_SAVE_CONFIRM, 280, 80, null, null, {'SubType': type, 'Type': 'Close'});
                        } /*else if(type=="UnloadWIEvent" && (isEmbd=="N")){ 
                         showWISaveMessage(ALERT_CLOSE_SAVE_CONFIRM, 270, 80, null, null, {'SubType': type, 'Type': 'Close'});
                         } */ else {
                            //retval = confirm(ALERT_CLOSE_SAVE_CONFIRM);
                        }
                        if (type == "menuWinClose" && (isEmbd == "N")) {
                            return false;
                        } else {
                            if (retval)
                                ret = 2;
                            else
                                ret = 1;
                        }
                    }


                    //}
                } else {
                    if (wiproperty.DefaultSave == 'Y')
                        ret = 2;
                    else
                        ret = 1;
                }
            }
            else
                ret = 1;
            if (type == "menuWinClose") {
                var closeValue = handleunlockreq(ret, type);
                if (closeValue != undefined && !closeValue) {
                    return false;
                }
            } else {
                handleunlockreq(ret, type);
            }

        } else if (wiproperty.locked == "Y") {
            if (type == "menuWinClose") {
                handleWindowClose();
            }
        }
    }
    if (wiproperty.locked == "Y" && strRemovefrommap == "Y") {
        removefrommap();
    }
    return true;
}

function handleunlockreq(ret, type) {
    type = (typeof type == 'undefined') ? '' : type;

    if (ret == 2 && type == "menuWinClose") {
        var closeValue = mainSave('close', type);
        if (closeValue != undefined && closeValue == 'closeFail') {
            return false;
        }
    } else if (ret == 2)
        mainSave('close', type);

    var bUnlockWI = true;
    if (typeof bNgFormRefresh != 'undefined' && bNgFormRefresh) {
        bUnlockWI = false;
    }
    
    var bCloseWorkiemFlag = ((ret == 1 || ret == 3) && type == "menuWinClose");

    if (wiproperty.formType == "NGFORM" && ngformproperty.type == "applet" && (typeof bDefaultNGForm != 'undefined') && !bDefaultNGForm && !bAllDeviceForm) {
        // NGHTML Form
        if (type == "menuWinClose") {
            // Window is closed from menu close option
            if (ret == 2) {
                // save workitem
                bUnlockWI = false;
            } else if (ret == 3) {
                // do not save workitem only unlock and close window
                bUnlockWI = false;
                //if(wiproperty.IsTask == 'N')
                sendUnlockReq(bCloseWorkiemFlag);
                //handleWindowClose();
            } else if (ret == 1) {
                // do not save workitem only unlock and close window
                bUnlockWI = false;
                //if(wiproperty.IsTask == 'N')
                sendUnlockReq(bCloseWorkiemFlag);
                //handleWindowClose();
            }
        }
    }

    if (bUnlockWI) {
        //if(wiproperty.IsTask == 'N')
        var status = sendUnlockReq(bCloseWorkiemFlag);
        /*if (status == '310') {
            return false;
        } else if (type == "menuWinClose") {
            handleWindowClose();
        }*/
    }
}

function getRequestToken(url) {
    var trui = getActionUrlFromURL(url);
    var servletUrl = "/webdesktop/secuidsv";
    (typeof WD_SID != 'undefined' && WD_SID != null) && (servletUrl += "?WD_SID=" + WD_SID);

    var xhReq = createXMLHttpRequest();
    //createIndicator(indicatorid);
    xhReq.open("POST", servletUrl, false);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    var wd_rid;
    xhReq.onreadystatechange = onResponse;

    xhReq.send("T-URI=" + trui);

    function onResponse() {
        try {

            if (xhReq.readyState == 4) {
                if (xhReq.status == 200) {
                    wd_rid = xhReq.getResponseHeader("WD_RID");
                }
            }
        } catch (e) {
            alert(ERROR_FETCHING_DATA);
        }
    }
    return wd_rid;
}

function sendUnlockReq(bCloseWorkiemFlag) {
    bUnlockWorkitem = (typeof bUnlockWorkitem == 'undefined' ? true : bUnlockWorkitem);
    var bdisconnectFromMail = ((typeof disconnectFromMail == 'undefined' || disconnectFromMail == null) ? "Y" : disconnectFromMail);
    if (!bUnlockWorkitem) {
        return;
    }

    if(typeof bCloseWorkiemFlag == 'undefined' || bCloseWorkiemFlag == null) {
        bCloseWorkiemFlag = true;
    }

    var param = "";
    var tempWidth = 800;
    var tempHeight = 800;
    var pid = document.getElementById('wdesk:pid');
    var wid = document.getElementById('wdesk:wid');
    var taskid = document.getElementById('wdesk:taskid');
    var dataFrm = document.getElementById('wdesk');
    var finalWidth;
    var finalHeight;
    var finalTop;
    var finalLeft;
    if (navigator.appName == "Microsoft Internet Explorer")
    {
        /*finalWidth=document.body.offsetWidth;
         finalHeight=document.body.offsetHeight;*/
        finalWidth = document.documentElement.clientWidth + 34;
        finalHeight = document.documentElement.clientHeight + 77;
        finalLeft = window.screenLeft;
        finalTop = window.screenTop;
    }
    else
    {
        finalWidth = window.outerWidth + 1;
        finalHeight = window.outerHeight - 1;
        finalLeft = window.screenX + 8;
        finalTop = window.screenY + 54;
    }
    if (finalWidth || finalHeight || finalTop || finalLeft)
        strCallSetWin = 'Y';
    var Left = encode_utf8(dataFrm.Left.value);
    /*******In case of Custom Template Horizontal height of upper Table*********************/
    var Height = "";
    if (dataFrm.Height != undefined)
        Height = dataFrm.Height.value;
    /*******In case of  Custom Template Horizontal height of upper Table*********************/

    var strTempPref = getTempletPref();
    if (strTempPref != '' && strCallSetWin == 'N')
        strCallSetWin = 'Y';
    param += 'pid=' + encode_utf8(pid.value) + '&wid=' + wid.value + '&taskid=' + taskid.value + '&Left=' + Left + '&TopHeight=' + Height + '&Right=' + '100' + '&strCallSetWin=' + strCallSetWin + '&templetPref=' + encode_utf8(strTempPref) + '&finalWidth=' + finalWidth + '&finalHeight=' + finalHeight + '&finalLeft=' + finalLeft + '&finalTop=' + finalTop + '&checkResize=' + checkResize;
    if (wiproperty.locked == "Y")
        param = param + '&IsReadOnly=Y';

    if (wiproperty.isSearch == "Y")
        param = param + '&fromSearch=Y';
    else
        param = param + '&fromSearch=N';

    //var prefXml=fetchPrefenceXml();
    param = param + "&WD_SID=" + WD_SID;
//       if (window.XMLHttpRequest) {
//        ajaxReq= new XMLHttpRequest();
//        } else if (window.ActiveXObject) {
//        ajaxReq= new ActiveXObject("Microsoft.XMLHTTP");
//        }

    if (typeof CalledFrom != 'undefined') {
        if (CalledFrom == 'M') {
            param = param + "&calledFrom=M";
        }
    }
    param = param + "&DisconnectFromMail=" + bdisconnectFromMail + "&CustomAjax=true";
    
    if (!bOprRefreshWorkitem) {
        var url = '/webdesktop/ajaxunlockworkitem.app';
        if (bWIOpenedFrmWList && typeof window.opener.handleUnlockWorkitem != 'undefined') {
            window.opener.handleUnlockWorkitem(url, param, "wiList", false);
            if(bCloseWorkiemFlag) {
                handleWindowClose();
            }
        } else {
            handleUnlockWorkitem(url, param, "", bCloseWorkiemFlag);
        }
    }
}

function handleUnlockWorkitem(url, params, origin, bCloseWorkiemFlag) {    
    var trui= getActionUrlFromURL(url);
    var servletUrl = "/webdesktop/secuidsv";            
    (typeof WD_SID != 'undefined' && WD_SID != null) && (servletUrl += "?WD_SID=" + WD_SID);
    var xhReq = createXMLHttpRequest();
    xhReq.open("POST", servletUrl, true);
    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhReq.onreadystatechange = onResponse;    
    xhReq.send("T-URI="+trui);
   
    function onResponse() {
        try {
            var wd_rid;
            if (xhReq.readyState == 4) {
                if (xhReq.status == 200) {
                    wd_rid =  xhReq.getResponseHeader("WD_RID");                   
                    if(params != undefined) {
                        params = params+"&WD_RID="+wd_rid;
                    } else {
                        url = url+"&WD_RID="+wd_rid;
                    }
                    xhReq = createXMLHttpRequest();
                    xhReq.open("POST", url, true);
                    xhReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhReq.onreadystatechange = function() {
                        if(xhReq.readyState == 4) {
                            handleUnlockWorkitemCB(xhReq.status, xhReq.responseText, origin, bCloseWorkiemFlag);
                        }
                    };
                    xhReq.send(params);
                }
            }
        } catch(e) {
            alert(ERROR_FETCHING_DATA);
        }
    }
}

function handleUnlockWorkitemCB(httpStatus, responseTxt, origin, bCloseWorkiemFlag) {
    if (httpStatus == 200) {
        var srvrRespose = responseTxt;
        if (srvrRespose != "") {
            try {
                srvrRespose = parseJSON("(" + srvrRespose + ")");
                window.status = srvrRespose[1].description;
            } catch (e) {
            }
        }
    } else if (httpStatus == 598 && origin != "wiList") {
        customAlert(responseTxt);
    } else if (httpStatus == 599) {
        var url = sContextPath + "/error/errorpage.app?msgID=4020";
        url = appendUrlSession(url);

        var width = 320;
        var height = 160;
        var left = (window.screen.availWidth - width) / 2;
        var top = (window.screen.availHeight - height) / 2;
        if (window.showModalDialog) {
            window.showModalDialog(url, '', "dialogWidth:" + width + "px;dialogHeight:" + height + "px;center:yes;dialogleft: " + left + "px;dialogtop: " + top + "px");
        }
    } else if (httpStatus == 310) {
        window.onunload = window.onbeforeunload = null;
        window.location = "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";
    } else if (httpStatus == 400 && origin != "wiList") {
        customAlert(INVALID_REQUEST_ERROR);
    } else if (httpStatus == 12029 && origin != "wiList") {
        customAlert(ERROR_SERVER);
    } else if (origin != "wiList") {
        customAlert(ALERT_OPERATION_UNSUCCESSFUL);
    }
        
    if(bCloseWorkiemFlag) {
        handleWindowClose();
    }
}

function cleanFormSession(sUrl) {
    if(typeof sUrl != 'undefined' && sUrl != '') {
        var url = sUrl;
        var params = '';
        var qmIndex = sUrl.indexOf('?')
        if(qmIndex > -1) {
            url = sUrl.substring(0, qmIndex);
            url = url + '?rand=' + Math.random();
            params = sUrl.substring(qmIndex+1);
        }
        var ajaxReq;
        if (window.XMLHttpRequest) {
            ajaxReq= new XMLHttpRequest();
        } else if (window.ActiveXObject) {
            ajaxReq= new ActiveXObject("Microsoft.XMLHTTP");
        }
        ajaxReq.open("POST", url, true);
        ajaxReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        /*ajaxReq.onreadystatechange = function() {
            if (ajaxReq.readyState == 4) {
                if(ajaxReq.status == 200) {
                    
                } else {
                    
                }
            }
        }*/
        ajaxReq.send(params);
    }
}

function removefrommap() {
    var pid = document.getElementById('wdesk:pid').value;
    var wid = document.getElementById('wdesk:wid').value;
    var taskid = document.getElementById('wdesk:taskid').value;
    var requestString;
    if (taskid == null || taskid == '' || taskid == undefined) {
        requestString = "modelKey=" + pid + "_" + wid;
    } else {
        requestString = "modelKey=" + pid + "_" + wid + "_" + taskid;
    }
    var docChange = ContentLoaderWrapper('/webdesktop/ajaxremovefrommap.app?' + requestString, removeMapHandler, callBackOnError, "POST", "");
}

function removeMapHandler() {

}

function done(bringNextWorkitem, confirmFlag) {
    /*if (document.getElementById("expGrid") != null) {
        window.parent.hideShowInterfaceTab("exp", "form");
        window.parent.toggleIntFace("form", "exp");
    }*/
    if (isFormLoaded == false)
        return;

    if (typeof isTaskFormLoaded != "undefined" && isTaskFormLoaded == false)//Form handling for Task Data
        return;

    if (checkExpStatus == "Y") {
        if (!checkExpTempStatus()) {
            customAlert(ALERT_COMMIT_EXCEPTION_BEFORE_SUBMIT);
            return;
        }
    }

    if (typeof taskid != 'undefined' && taskid != '') {

    } else {
        if ((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm) {
            try {
                var ngformIframe = document.getElementById("ngformIframe");
                var isValidated = false;
                if (bAllDeviceForm) {
                    isValidated = ngformIframe.contentWindow.eval("isComponentValidated()");
                } else {
                    isValidated = ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.isComponentValidated()");
                }
                if (!isValidated) {
                    return;
                }
            } catch (e) {
            }
        }
    }

    //Form handling for Task Data
    if ((wiproperty.TaskFormType == "NGFORM") && (taskngformproperty.type == "applet") && !bDefaultNGForm) {
        try {
            var taskngformIframe = document.getElementById("taskngformIframe");
            var isValidated = false;
            if (bAllDeviceTaskForm) {
                isValidated = taskngformIframe.contentWindow.eval("isComponentValidated()");
            } else {
                isValidated = taskngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.isComponentValidated()");
            }
            if (!isValidated) {
                return;
            }
        } catch (e) {
        }
    }

    var formWindow = getWindowHandler(windowList, "formGrid");
    /* if(typeof formWindow!='undefined' && wiproperty.formType=="NGFORM"){
     var validationStatus = "";
     validationStatus = document.wdgc.ValidateControls('D');
     if(validationStatus == false)
     return false;
     }else if(typeof customValidation!='undefined' &&!customValidation("D")){
     return false;
     }*/
    if (formWindow) {//added for Variant
        executeOnSaveVariant();
    }
    if (!(wiproperty.IsTask == 'Y' && wiproperty.TaskFormViewMode == 'R')) { // Handling for task form in reas mode
        if (!form_cutomValidation("D")) {
            hideProcessing();
            return false;
        }
    }
    var batchflag = document.getElementById('wdesk:batchflag').value;
    var status = "";
    if (!saveFormdata('formDataTodo', 'done')) {
        hideProcessing();
        return false;
    }
    //Bug 75400 Start
    if (typeof confirmAnnotationSave != undefined && confirmAnnotationSave == "Y") {
        if (document.getElementById('wdesk:ivapp') != null && (document.getElementById('wdesk:ivapp').style.display == "inline" || document.getElementById('wdesk:ivapp').style.display == "block")) {
            try {
                if (document.IVApplet && document.IVApplet.annotationModified()) {
                    document.IVApplet.saveAnnotations();
                }
            } catch (e) {
            }
        }
        if (document.getElementById('wdesk:ifrm') != null && (document.getElementById('wdesk:ifrm').style.display == "inline" || document.getElementById('wdesk:ifrm').style.display == "block")) {
            if (isOpAll == 'Y' && typeof opall_toolkit != 'undefined' && opall_toolkit && opall_toolkit.annotationModified()) {
                opall_toolkit.saveAnnotation();
            }
        }
    }
    //Bug 75400 End
    var nextWI = (
        isEmbd == 'Y' ||
        wiproperty.isSearch == 'Y' ||
        batchflag == 'N' ||
        (typeof strOpenWI != 'undefined' && strOpenWI == "Y") ||
        (typeof qType != 'undefined' && qType == "T") ||
        (typeof strYesBringNextWI != 'undefined' && strYesBringNextWI == "N" && !yesBringNextWI(strprocessname, stractivityName)) ||
        (typeof bringNextWIOnDone != 'undefined' && bringNextWIOnDone=='N' && !yesBringNextWI(strprocessname,stractivityName))
        ) ? "N" : "Y";
            
    if(typeof bringNextWorkitem != 'undefined' && (bringNextWorkitem == "Y" || bringNextWorkitem == "N")) {
        nextWI = bringNextWorkitem;
    }
    
    var noConfirmPopup = (confirmDone == 'N' && disableConfirmDone(strprocessname,stractivityName));    
    if(typeof confirmFlag != 'undefined') {
        if(confirmFlag == "Y") {
            noConfirmPopup = false;
        } else if(confirmFlag == "N") {
            noConfirmPopup = true;
        }
    }
    
    if(noConfirmPopup || taskid != '') {
        showProcessing();
		if(nextWI == 'N') {
			handleDoneWI('2');
        } else {
            handleDoneWI('1');
        }
	}
    else {
        /* var url = "/webdesktop/faces/workitem/view/close.jsp?PName=done1&flag=TEXT_INTRODUCE_DONE_WORKITEM&isEmbd="+isEmbd;
         url = appendUrlSession(url);*/
        if (false) {
            var url = sContextPath + "/components/workitem/view/confirmdone.app?PName=done1&flag=TEXT_INTRODUCE_DONE_WORKITEM&isEmbd=" + isEmbd + "&WD_SID=" + WD_SID;
            url = appendUrlSession(url);
            url += '&nextWI=' + nextWI;
            ret = window.showModalDialog(url, '', "dialogWidth:" + (windowVW + 100) + "px;dialogHeight:" + windowVH + "px;center:yes;");
            handleDoneWI(ret);
        }
        else {
            var url = sContextPath + "/components/workitem/view/confirmdone.app";
            url = appendUrlSession(url);
            url = url + "&PName=done1";
            url = url + "&flag=" + encode_ParamValue("TEXT_INTRODUCE_DONE_WORKITEM");
            url = url + "&isEmbd=" + encode_ParamValue(isEmbd);
            url = url + "&nextWI=" + encode_ParamValue(nextWI);

            var popupWidth = (window.screen.width / 1366) * 340;
            var popupHeight = (window.screen.height / 768) * 180;
            var left = (window.screen.width - popupWidth) / 2;
            var top = (document.documentElement.clientHeight - popupHeight) / 2;
            showPopupMask();
            popupIFrameOpenerWrapper(window, "confirmdone", url, popupWidth, popupHeight, left, top, false, true, false, false, true);
            // url+='&nextWI='+nextWI;
            // ret = window.open(url,'closewi',"height="+window5H+",width="+window5W+",status=yes,toolbar=no,menubar=no,location=no,left="+window5X+",top="+window5Y);
        }
    }
}

function handleDoneWI(ret) {
    if (typeof CalledFrom != 'undefined') {
        if (CalledFrom != 'M') {
            /*Bug Id: 33846:workitem window got freeze*/
            if (bWIOpenedFrmWList && typeof window.opener.handleDoneIntro == 'unknown') {
                window.location.href = sContextPath + "/error/errorpage.app?msgID=-8002&HeadingID=8002&WD_SID=" + WD_SID;
                return false;
            }/*Bug Id: 33846:workitem window got freeze*/
            if (bWIOpenedFrmWList && typeof window.opener.handleDoneIntro != 'undefined') {
                window.opener.handlePrev = false;
                window.opener.handleDoneIntro = true;
            }
        }
    }
    var dataFrm = document.getElementById('wdesk');
    var flag = false;
    if (ret == '1' || ret == '2') {
        saveReturnOption = ret;
        var formWindow = getWindowHandler(windowList, "formGrid");
        var taskWindow = getWindowHandler(windowList, "taskGrid");
        var ngformIframe = document.getElementById("ngformIframe");
        var searchFlag = typeof window.opener != "undefined" && window.opener!= null ? window.opener.document.getElementById("wlf:hidFlag") : null;
        if(searchFlag && searchFlag.value == "2"){
            dataFrm.FilterString.value = window.opener.document.getElementById("wlf:hidFilterString").value;
dataFrm.decodeFlag.value = window.opener.document.getElementById("wlf:encodeFlag").value;
        }

        if (typeof formWindow != 'undefined' && wiproperty.formType == "NGFORM" && !bAllDeviceForm) {
            if ((ngformproperty.type == "applet") && !bDefaultNGForm) {
                try {
                    if (ngformIframe != null) {
                        if (formIntegrationApr == "4") {
                            //ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.fireFormValidation('D','N')");	                                                                
                            ngformIframe.contentWindow.saveFormStarted("D", "N");
                        } else {
                            ngformIframe.contentWindow.clickLink('cmdNgFormDoneRefresh');
                        }
                    }
                } catch (e) {

                }
            } else {
                flag = true;
                var retVal = document.wdgc.SaveData('D');
                if (retVal != 1) {
                    hideProcessing();
                    return 'false';
                }

                //handling for task (saving task data)
                if (typeof taskWindow != 'undefined' && wiproperty.TaskFormType == "NGFORM") {
                    if ((taskngformproperty.type == "applet") && !bDefaultNGForm) {
                        try {
                            var taskngformIframe = document.getElementById("taskngformIframe");
                            taskngformIframe.contentWindow.clickLink('cmdTaskNgFormDoneRefresh');
                        } catch (e) {

                        }
                    } else {
                        var retVal = document.wdgc.SaveData('D');
                        if (retVal != 1) {
                            hideProcessing();
                            return 'false';
                        }
                    }
                }
            }
        } else if (typeof taskWindow != 'undefined' && wiproperty.TaskFormType == "NGFORM" && !bAllDeviceForm && !bAllDeviceTaskForm) {
            if ((taskngformproperty.type == "applet") && !bDefaultNGForm) {
                try {
                    var taskngformIframe = document.getElementById("taskngformIframe");
                    taskngformIframe.contentWindow.clickLink('cmdTaskNgFormDoneRefresh');
                } catch (e) {

                }
            } else {
                flag = true;
                var retVal = document.wdgc.SaveData('D');
                if (retVal != 1) {
                    hideProcessing();
                    return 'false';
                }
            }
        } else {
            flag = true;
        }

        if (flag || strprocessname == 'BAIS' || strprocessname == 'TWC') {
			var doneFlag = false;
			doneFlag = DoneClick();
            if (!doneFlag) {
                hideProcessing();
                return false;
            }
			
			if (doneFlag != true) {
                hideProcessing();
                return false;
            }
			
			if (strprocessname == 'BAIS')
			{
				if(customform.document.getElementById("isDoneValidated").value != 'Validated')
				{
					alert('Kindly close the workitem, clear browser cache and retry');
					hideProcessing();
					return false;
				}
			}

            unlockflag = "N";
            if (ret == '1') {
                dataFrm.CloseWindow.value = 'false';
                dataFrm.isEmbeddded.value = isEmbd;
            }
            else if (ret == '2') {
                dataFrm.CloseWindow.value = 'true';
                dataFrm.isEmbeddded.value = isEmbd;
                if (isEmbd == "Y") {
                    if (typeof isEmbedddedNextWI != 'undefined' && !isEmbedddedNextWI(strprocessname, stractivityName)) {
                        dataFrm.isEmbdNextWI.value = "N"
                    } else {
                        dataFrm.isEmbdNextWI.value = "Y"
                    }
                }
            }
            var ngParam = getNGParam();
            document.getElementById('extParam').value = getExtParam(strprocessname, stractivityName);
            if (typeof CalledFrom != 'undefined' && CalledFrom != 'M') {
                hideWIFromList(sourceInsId);
            }

            if ((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm && (bAllDeviceForm || bAllDeviceTaskForm) && bCustomIForm) {
                var isDoneCompleted = '';
                if (typeof taskid != 'undefined' && taskid != '') {
                    var taskngformIframe = document.getElementById("taskngformIframe");
                    if (typeof formWindow != 'undefined' && taskngformIframe != null) {
                        try {
                            var isValidated = false;
                            if (bAllDeviceTaskForm) {
                                isValidated = taskngformIframe.contentWindow.eval("isComponentValidated()");
                            }
                            if (!isValidated) {
                                return;
                            }
                        } catch (e) {
                        }

                        if (typeof taskngformIframe.contentWindow.customIFormHandler != 'undefined') {
                            isDoneCompleted = taskngformIframe.contentWindow.customIFormHandler('D');
                            if (isDoneCompleted != null && isDoneCompleted.length > 0) {
                                isDoneCompleted = isDoneCompleted.trim();
                            }
                        }
                    }
                } else {
                    if (typeof formWindow != 'undefined' && ngformIframe != null) {
                        if (typeof ngformIframe.contentWindow.customIFormHandler != 'undefined') {
                            isDoneCompleted = ngformIframe.contentWindow.customIFormHandler('D');
                            if (isDoneCompleted != null && isDoneCompleted.length > 0) {
                                isDoneCompleted = isDoneCompleted.trim();
                            }
                        }
                    }
                }
                var responseJSON;
                if (typeof isDoneCompleted != 'undefined' && isDoneCompleted != null && isDoneCompleted != '') {
                    try {
                        responseJSON = JSON.parse(decodeURIComponent(isDoneCompleted));
                    } catch (e) {
                    }
                    if (typeof responseJSON != 'undefined' && typeof responseJSON.ResponseCode != 'undefined') {
                        if (responseJSON.ResponseCode == '701') {
                            hideProcessing();
                            if (onSaveValidationFailure(responseJSON.ResponseMessage)) {
                                setmessageinDiv(responseJSON.ResponseMessage, "false", 3000);
                            }
                            return "failure";
                        } else if (responseJSON.ResponseCode == '599') {
                            hideProcessing();
                            setmessageinDiv(INVALID_SESSION, "false", 3000);
                            return "failure";
                        } else if(responseJSON.ResponseCode != '200' && responseJSON.ResponseCode != '304') {
                            hideProcessing();
                            setmessageinDiv(ERROR_AT_SERVER_END, "false", 3000);
                            return "failure";
                        }
                    } else {
                        if (isDoneCompleted == "599") {
                            hideProcessing();
                            setmessageinDiv(INVALID_SESSION, "false", 3000);
                            return "failure";
                        } else if (isDoneCompleted == "701") {
                            hideProcessing();
                            setmessageinDiv(ERROR_AT_SERVER_END, "false", 3000);
                            return "failure";
                        }
                    }
                }
            }
			if(strprocessname == 'AO' || strprocessname == 'SRM' || strprocessname == 'BAIS' )
			{
			alert("The request has been submitted successfully.");
			}
            clickWiLink("DONE", "wdesk:controller", ngParam);
        }
    }
    else {
        noClickAfterDone();
        hideProcessing();
        return;
    }
}

function setAuditStatus(auditStatus) {
    if (isFormLoaded == false)
        return;
    if (checkExpStatus == "Y") {
        if (!checkExpTempStatus()) {
            customAlert(ALERT_COMMIT_EXCEPTION_BEFORE_SUBMIT);
            return;
        }
    }
    if (wiproperty.assignmentType == 'A') {
        if (!saveFormdata('formDataTodo'))
            return;
        if ((auditStatus == 'A' && AcceptClick()) || (auditStatus == 'R' && RejectClick())) {
            if (auditStatus == 'R')
            {
                var url = '/webdesktop/components/workitem/view/auditcomments.app?WD_SID=' + WD_SID;
                url = appendUrlSession(url);
                var win = link_popup(url, 'RejectComment', 'scrollbars=no,resizable=no,status=yes,left=' + (window1Y + 100) + ',top=' + (window1X + 120) + ',width=' + (window1W - 200) + ',height=' + (windowH - 100), windowList, false);

            }
            else
                setAuditStatusWrapper(auditStatus);
        }
    }
}

function setAuditStatusWrapper(auditStatus, comment) {
    var dataFrm = document.getElementById('wdesk');
    if (auditStatus == 'R')
        dataFrm.comment.value = comment;
    dataFrm.CloseWindow.value = 'true';//close window
    unlockflag = "N";//do not show save on close window
    dataFrm.AuditStatus.value = auditStatus;
    dataFrm.isEmbeddded.value = isEmbd;
    if (isEmbd == "Y") {
        if (typeof isEmbedddedNextWI != 'undefined' && !isEmbedddedNextWI(strprocessname, stractivityName)) {
            dataFrm.isEmbdNextWI.value = "N"
        } else {
            dataFrm.isEmbdNextWI.value = "Y"
        }
    }
    var batchflag = document.getElementById('wdesk:batchflag').value;
    var ret = "";
    var formWindow = getWindowHandler(windowList, "formGrid");
    var nextWI = 'Y';
    if (wiproperty.isSearch == 'Y' || batchflag == 'N' || (typeof strOpenWI != 'undefined' && strOpenWI == "Y"))
        nextWI = 'N';
    if (window.showModalDialog) {
        var url = "/webdesktop/components/workitem/view/confirmdone.app?PName=accept&flag=TEXT_INTRODUCE_DONE_WORKITEM&isEmbd=" + isEmbd;
        url = appendUrlSession(url);
        url += '&nextWI=' + nextWI;
        ret = window.showModalDialog(url, '', "dialogWidth:" + (windowVW + 100) + "px;dialogHeight:" + windowVH + "px;center:yes;");
        handleAudit(ret, auditStatus);
    }
    else {
        url = "/webdesktop/components/workitem/view/confirmdone.app";
        url = appendUrlSession(url);
        var wFeatures = "height=" + windowVH + ",width=" + (windowVW + 100) + ",status=yes,toolbar=no,menubar=no,location=no,left=" + window5X + ",top=" + window5Y;
        var listParam = new Array();
        listParam.push(new Array("PName", encode_ParamValue("accept")));
        listParam.push(new Array("flag", encode_ParamValue("TEXT_INTRODUCE_DONE_WORKITEM")));
        listParam.push(new Array("isEmbd", encode_ParamValue(isEmbd)));
        listParam.push(new Array("nextWI", encode_ParamValue(nextWI)));
        ret = openNewWindow(url, 'closewi', wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", listParam);
    }
}

function handleAudit(ret, auditStatus) {
    if (window.opener && typeof window.opener.handleDoneIntro != 'undefined') {
        window.opener.handlePrev = false;
        window.opener.handleDoneIntro = true;
    }
    var dataFrm = document.getElementById('wdesk');
    if (ret == 1 || ret == 2) {
        if (ret == '1') {
            dataFrm.CloseWindow.value = 'false';
            dataFrm.isEmbeddded.value = isEmbd;
        }
        else if (ret == '2') {
            dataFrm.CloseWindow.value = 'true';
            dataFrm.isEmbeddded.value = isEmbd;
            if (isEmbd == "Y") {
                if (typeof isEmbedddedNextWI != 'undefined' && !isEmbedddedNextWI(strprocessname, stractivityName)) {
                    dataFrm.isEmbdNextWI.value = "N"
                } else {
                    dataFrm.isEmbdNextWI.value = "Y"
                }
            }
        }
        if (typeof formWindow != 'undefined' && wiproperty.formType == "NGFORM") {
            if ((ngformproperty.type == "applet") && !bDefaultNGForm) {
                var opt = "A";
                if (auditStatus != 'A') {
                    opt = "R";
                }
                var ajaxRef = ContentLoaderWrapper('/webdesktop/ajaxSaveNGFormHandler.app', saveNGFormHandlerOpt, null, "POST", 'wid=' + wid + '&taskid=' + taskid + '&pid=' + encodeURIComponent(pid) + '&opt=' + opt, false);
                if (typeof ajaxRef.IsValidateForm != 'undefined') {
                    if (!ajaxRef.IsValidateForm) {
                        return 'false';
                    }
                }
            } else {
                var retVal;
                if (auditStatus == 'A')
                    retVal = document.wdgc.SaveData('A');
                else
                    retVal = document.wdgc.SaveData('R');
                if (retVal != 1)
                    return 'false';
            }
        }
        var ngParam = getNGParam();
        hideWIFromList();
        clickWiLink("DONE", "wdesk:controller", ngParam);//execute done logic
    }
    return;
}
function handlereferwi(val) {
    var wdesk_win;
    if (windowProperty.winloc == 'S')
        wdesk_win = window.opener;
    else if (windowProperty.winloc == 'T')
        wdesk_win = window.opener.opener;
    if (wdesk_win != null) {
        var dataFrm = wdesk_win.document.getElementById('wdesk');
        dataFrm.ToSave.value = 'false';
        if (val == '2') {
            if (!wdesk_win.saveFormdata('formData'))
                return;
            //wdesk_win.for_save("referSave");
            dataFrm.ToSave.value = 'true';
        }
        if (wdesk_win.ReferClick()) {
            dataFrm.CloseWindow.value = 'false';
            wdesk_win.unlockflag = "N";
            dataFrm.TargetUser.value = referTo;
            dataFrm.ReferQueueType.value = qtype;
            var ngParam = '';
            if (dataFrm.ToSave.value == 'true') {
                var formWindow = wdesk_win.getWindowHandler(windowList, "formGrid");
                if (typeof formWindow != 'undefined' && wdesk_win.wiproperty.formType == "NGFORM") {
                    if ((wdesk_win.ngformproperty.type == "applet") && (typeof wdesk_win.bDefaultNGForm != 'undefined') && !wdesk_win.bDefaultNGForm) {
                        var ajaxRef = ContentLoaderWrapper('/webdesktop/ajaxSaveNGFormHandler.app', saveNGFormHandlerOpt, null, "POST", 'wid=' + wdesk_win.wid + '&taskid=' + wdesk_win.taskid + '&pid=' + encodeURIComponent(wdesk_win.pid) + '&opt=S', false);
                        if (typeof ajaxRef.IsValidateForm != 'undefined') {
                            if (!ajaxRef.IsValidateForm) {
                                return 'false';
                            }
                        }
                    } else {
                        if (typeof wdesk_win.document.wdgc != 'undefined') {
                            var retVal = wdesk_win.document.wdgc.SaveData('S');
                            if (retVal != 1)
                                return 'false';
                        }
                    }
                }
                ngParam = wdesk_win.getNGParam();
            }
            wdesk_win.clickLink("REFERSAVE", "wdesk:controller", ngParam);
            window.close();
        }
    }
}

function DeleteWorkitem(confirm) {
    if (confirm == "yes") {
        document.getElementById("wlf:selIndexWIOp").value = strSelectedIndex;
        if (document.getElementById("wlf:hidCompInsID") != null) {
            if (document.getElementById("wlf:hidCompInsID").value != '') {
                document.getElementById("insid").value = document.getElementById("wlf:hidCompInsID").value;
            }
        } else if (document.getElementById("wlf:hidExtCompInsID") != null) {
            if (document.getElementById("wlf:hidExtCompInsID").value != '') {
                document.getElementById("insid").value = document.getElementById("wlf:hidExtCompInsID").value;
            }
        }
        clickLink("wlf:deleteWI");
    } else if (confirm == "no") {
        document.getElementById("MessageDiv").style.display = "none";
    }
    hidePopupMask();
}

function getWinFocus() {
    var wiWinInfo = null;
    try {
        wiWinInfo = wiWinInfoMap.get("CustomNewWI").value;
    } catch (e) {
        wiWinInfo = null;
    }

    if (wiWinInfo != null && wiWinInfo.WinName == 'CustomNewWI') {
        wiWinInfo.WinRef.focus();
    }
}

function openNewWorkitem(PdefId, PVariantId, formid, source) {//PVariantId added for Variant : 17 Oct 13
    formid = (typeof formid == 'undefined') ? 'wlf' : formid;
    source = (typeof source == 'undefined') ? '' : source;

    var scrHeight;
    var WinHeight = window.screen.availHeight - 60;

    var winWidth = window.screen.availWidth - 10;
    var wdWidth = 0;
    var wFeatures;
    if (wdWidth != '0' && wdWidth <= window.screen.availWidth) {
        scrHeight = window.screen.availHeight - 15;
        winWidth = wdWidth;
        wFeatures = 'status=yes,resizable=no,scrollbars=yes,width=' + winWidth + ',height=' + WinHeight + ',left=0,top=0,resizable=yes,scrollbars=yes';
    }
    else
    {
        scrHeight = window.screen.availHeight;
        wFeatures = 'status=yes,resizable=no,scrollbars=yes,width=' + winWidth + ',height=' + WinHeight + ',left=0,top=0,resizable=yes,scrollbars=yes';
    }
    var url = sContextPath + '/components/workitem/view/newwi.app';

    var queueId = document.getElementById(formid + ':hidQueueId').value;
    var queueType = document.getElementById(formid + ':hidQueueType').value;
    var queueName = "";
    if(formid == 'preferenceForm') {
        queueName = document.getElementById(formid + ':hidQN').value;
    } else if(formid == 'wlf') {
        queueName = document.getElementById(formid + ':hidQueueName').value;
    }
	 if (typeof NewClick != 'undefined') {
        var isNewClick = NewClick(PdefId, queueId, queueType, queueName);
        if (typeof isNewClick == 'undefined' || !isNewClick) {
            return;
        }
    }
	
    if (typeof isCustomWorkitem != 'undefined') {
        customNewWI = isCustomWorkitem(PdefId, queueId, queueType, queueName);
    }
    
    if(typeof getCustomFeatureForWIWindow != 'undefined') {
        var cFeatures = getCustomFeatureForWIWindow("", "", PdefId,queueId,queueType, queueName);
        if(typeof cFeatures != 'undefined' && cFeatures != '') {
            wFeatures = cFeatures;
        }
    }

    var InstrumentListSortOrder = document.getElementById(formid + ':hidSortOrder').value;
    var InstrumentListOrderBy = document.getElementById(formid + ':hidOrderBy').value;
//        var queueId=document.getElementById(formid+':hidQueueId').value;
//        var queueType=document.getElementById(formid+':hidQueueType').value;
    var listParam = new Array();
    listParam.push(new Array('Action', encode_ParamValue('NewWi')));
    listParam.push(new Array('PrcDefId', encode_ParamValue(PdefId)));
    listParam.push(new Array('PrcVariantId', encode_ParamValue(PVariantId)));     //added for Variant : 17 Oct 13
    listParam.push(new Array('InstrumentListSortOrder', encode_ParamValue(InstrumentListSortOrder)));
    listParam.push(new Array('InstrumentListOrderBy', encode_ParamValue(InstrumentListOrderBy)));
    listParam.push(new Array('CalledFrom', encode_ParamValue("NEW")));
    listParam.push(new Array('Source', encode_ParamValue(source)));
    listParam.push(new Array('QueueId', encode_ParamValue(queueId)));
    listParam.push(new Array('QueueType', encode_ParamValue(queueType)));
    listParam.push(new Array('wdView', encode_ParamValue('N')));
    listParam.push(new Array('allowreassignment', encode_ParamValue("N")));
    listParam.push(new Array('InstrumentListCallFlag', encode_ParamValue("Q")));
    listParam.push(new Array('Comp_height', encode_ParamValue(scrHeight)));
    listParam.push(new Array('Comp_width', encode_ParamValue(winWidth)));

    var getFormTypeVar = "";
    if (typeof getFormType != 'undefined') {
        getFormTypeVar = getFormType(PdefId, queueId, queueType);
        listParam.push(new Array('FormTypeName', encode_ParamValue(getFormTypeVar)));
    }

    var wiWinInfo = null;
    var uniqueId = MakeUniqueNumber();
    var win = null;
    var openWinFlag = true;

    if (customNewWI != undefined && customNewWI) {
        //Added by Reddy for redirecting the control to Custom JSP Calling window based on queueName -- Starts here
		//alert("QueueName"+queueName);
		if(queueName=="EPP_PBO_Introduction")
		{
			url = sContextPath+'/components/workitem/view/EPPNewWI.jsp';
		}
		else
		{
			url = sContextPath + '/components/workitem/view/customNewWI.jsp';
		}
		//Ends here
		//url = sContextPath + '/components/workitem/view/customNewWI.app';
        uniqueId = "CustomNewWI";
        try {
            wiWinInfo = wiWinInfoMap.get(uniqueId).value;
        } catch (e) {
            wiWinInfo = null;
        }
		//condition added by stutee.mishra on 25/03/2022
        if(queueName!="SRM_PBO" && queueName!="EPP_PBO_Introduction"){
			if (wiWinInfo != null && wiWinInfo.WinName == 'CustomNewWI') {
            customAlert(PROCESS_OPENED_WORKITEM, "getWinFocus()");
            openWinFlag = false;
           }
		}
		//ends here.
        
    }

    if (openWinFlag) {
        win = openNewWindow(url, uniqueId, wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", listParam);
        if (win != null) {
            wiWinInfo = {
                "WinName": uniqueId,
                "PDefId": PdefId,
                "WinRef": win
            };

            wiWinInfoMap.put(uniqueId, wiWinInfo);
            win.focus();
        }
    }
}

function reassignFunHandler() {

    var response = this.req.responseText;
    selectedWiInfo = response;
    if (typeof worklistHandler != 'undefined' && !worklistHandler("reassign", response))
        return;
    var woklistMode = (typeof wLMode == 'undefined') ? 'WD' : wLMode;
    var cstmReassign = false;
    if (typeof customReassign != 'undefined' && customReassign(response, '', ''))
        cstmReassign = true;
    if (typeof customWorklistMode != 'undefined') {
        var chgMode = customWorklistMode();
        if (chgMode != '')
            woklistMode = chgMode;
    }
    var insId = '';
    if (document.getElementById("wlf:hidCompInsID") != null) {
        insId = document.getElementById("wlf:hidCompInsID").value;
    }
    else if (document.getElementById("wlf:hidExtCompInsID") != null) {
        insId = document.getElementById("wlf:hidExtCompInsID").value;
    }
    var Url = sContextPath + '/components/workitem/operations/reassignworkitem.app?Action=1&CheckedIndexes=' + strSelectedIndex + '&' + ReqParams + '&WorklistMode=' + woklistMode + '&OpenFrom=WD&WD_SID=' + WD_SID + '&CustomReassign=' + cstmReassign + '&insid=' + insId;
    WindowLeft = findAbsPosX(refItem);
    WindowTop = findAbsPosY(refItem);
    //alert(Url);
    window.parent.popupIFrameOpenerWrapper(window, "Reassign", Url, 350, 290, WindowLeft, WindowTop, false, true, false, true, true);
}

function reassignCallBack() {
    if (targetEmbdWIRef != null) {
        targetEmbdWIRef.doRefreshEbmdWI();
    }
    if (wLMode == "CM") {
        if (window.parent.iFrameTaskListRef != null)
            window.parent.iFrameTaskListRef.clearTaskList();
    }
}

function instanceHeaderClick(flagType) {
    flagType = (typeof flagType == 'undefined' ? '' : flagType);

    var queueId = document.getElementById("wlf:hidQueueId").value;
    var filterString = document.getElementById('wlf:hidFilterString').value;
    oper = document.getElementById('wlf:hidFlag').value;

    var queryString = 'QueueId=' + queueId + '&WD_SID=' + WD_SID;
    if (flagType == 2 || oper == 2) {
        queryString += "&FilterString=" + filterString;
    }
    var workitemCount = "";//Bug 72882 Start
    if (document.getElementById("wlf:isSearchWorkitemlistCalled").value == "Y" && isCountEnabled == "Y") {
        WICountCallCheck = "Y";
        var queueName = queueName + " [" + document.getElementById("wlf:countFromSearch").value + "]";
        var queueId = document.getElementById('wlf:hidQueueId').value;
        var oper = document.getElementById('wlf:hidFlag').value - 0;
        if (queueId == "0") {
            queueName = MY_QUEUE;
        } else if (queueId == "" && (oper == "4" || oper == "3")) {
            queueName = LABEL_MYSEARCHQUEUE;
        } else if (queueId == "") {
            queueName = AUTHORIZED_QUEUE;
        } else {
            queueName = document.getElementById('wlf:hidQueueName').value;
        }
        queueName = queueName + " [" + document.getElementById("wlf:countFromSearch").value + "]";
        if (this.FlagType == 2 || oper == 2) {
            window.parent.changePanelTitle(comp_ins_id, LABEL_SETFILTERFORQUEUE + queueName);
        } else {
            window.parent.changePanelTitle(comp_ins_id, queueName);
        }

        document.getElementById('MoreDiv').style.display = "none";
    }//Bug 72882 End
    else {
        workitemCount = ContentLoaderWrapper('/webdesktop/ajaxwicount.app', setWorkitemCount, callBackOnError, "POST", queryString);
        workitemCount.FlagType = flagType;
    }
    //var workitemCount= ContentLoaderWrapper('/webdesktop/ajaxwicount.app',setWorkitemCount,callBackOnError,"POST",queryString);

}

function setWorkitemCount() {
    WICountCallCheck = "Y";
    var response = this.req.responseText;

    if (isNaN(parseInt(response))) {
        customAlert("Unable to Count Workitem");
        return false;
    }

    var queueName;
    var queueId = document.getElementById('wlf:hidQueueId').value;
    var oper = document.getElementById('wlf:hidFlag').value - 0;
    if (queueId == "0") {
        queueName = MY_QUEUE;
    } else if (queueId == "" && (oper == "4" || oper == "3")) {
        queueName = LABEL_MYSEARCHQUEUE;
    } else if (queueId == "") {
        queueName = AUTHORIZED_QUEUE;
    } else {
        queueName = document.getElementById('wlf:hidQueueName').value;
    }

    if (oper == "5") {
        queueName = document.getElementById('wlf:hidQueueName').value;
    }

    if (typeof wLMode != 'undefined' && wLMode == 'CM') {
        queueName = "[" + response + "]";
    } else {
        queueName = queueName + " [" + response + "]";
    }

    if (this.FlagType == 2 || oper == 2) {
        window.parent.changePanelTitle(comp_ins_id, LABEL_SETFILTERFORQUEUE + queueName);
	} else if(typeof cmMode != 'undefined' && cmMode == 'CM'){
        document.getElementById('wlf:WICount').innerHTML = "["+response+"]";
		document.getElementById('wlf:WICount').title = queueName;
    } else {
        window.parent.changePanelTitle(comp_ins_id, queueName);
    }

    document.getElementById('MoreDiv').style.display = "none";
    //document.getElementById('MoreDiv2').style.display = "none";
//    document.getElementById('wlf:lblWI1').style.display = "none";
//    document.getElementById('wlf:lblWI2').style.display = "block";
//    document.getElementById('wlf:lblWICount').innerHTML = response;
//    document.getElementById('wlf:lblWICount').style.display = "block";


}


function saveWorklist() {
    var frameObj = document.getElementById('frmSaveWI');
    var encodeFlag = document.getElementById("wlf:encodeFlag").value;
    //Bug 67205 starts
    var inpSearchCriteria = document.getElementById("wlf:inpSearchCriteria").value;
    var hidFlag = document.getElementById('wlf:hidFlag').value;
    var pid = document.getElementById('wlf:hidProcessDefId').value;
    if (hidFlag == "4") {
        if (!inpSearchCriteria == "0") {
            userDefFlag = "N";
        }
        else
        {
            userDefFlag = "Y";
        }
    }
    else
    {
        userDefFlag = "Y";
    }
    //Bug 67205 ends

    var isChrome = (typeof window.chrome != 'undefined') ? true : false;
    var browser;
    if (isChrome) {
        browser = "N";
    } else {
        browser = "Y";
    }

    var ref = document.getElementById("wlf:hidArchivalMode");
    var strArchivalMode = "N";
    if (ref) {
        strArchivalMode = ref.value;
    }

    if (pid == null) {
        pid = "";
    }

    var cid = document.getElementById("wlf:cid").value;
    var fid = document.getElementById("wlf:fid").value;

    Url = sContextPath + "/SaveWorkitemList?" + worklistString + '&type=' + saveType + '&encodeFlag=' + encodeFlag + '&userDefFlag=' + userDefFlag + "&ArchiveSearch=" + strArchivalMode + '&ProcessDefinationId=' + pid + '&browser=' + browser + "&cid=" + cid + "&fid=" + fid + "&WD_SID=" + WD_SID + "&WD_RID=" + getRequestToken("/webdesktop/SaveWorkitemList");
    if (wLMode != undefined) {
        Url = Url + '&WLMode=' + wLMode;
    }

    IframeRequestWithPost(Url, frameObj)

    //frameObj.src=Url;
}

function openReminderListWindow() {
    url = '/webdesktop/components/workitem/operations/reminderlist.app?Action=1';
    WindowLeft = parseInt(ScreenWidth / 2) - parseInt(600 / 2);
    WindowTop = parseInt(ScreenHeight / 2) - parseInt(410 / 2);

    var WindowHeight = 470;
    var WindowWidth = 950;

    var wFeatures = 'height=' + WindowHeight + ',width=' + WindowWidth + ',resizable=1,status=1,scrollbars=auto,top=' + WindowTop + ',left=' + WindowLeft;
    openNewWindow(url, 'ReminderList', wFeatures, true, "Ext1", "Ext2", "Ext3", "Ext4", "");
}

function fetchPrefenceXml() {
    var intArrayRef = interfaceMap.getIterator();

    var ref = document.getElementById("containerDiv");
    var contDivTop = '';
    var contDivLeft = '';
    if (ref) {
        contDivTop = findPosY(ref);
        contDivLeft = findPosX(ref);
    }


    var screenWidth = window.screen.width;
    var screenHeight = window.screen.height;

    if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        //IE 6+ in 'standards compliant mode'        
        screenWidth = document.documentElement.clientWidth;
        screenHeight = document.documentElement.clientHeight;
    } else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
        //IE 4 compatible
        screenWidth = document.body.clientWidth;
        screenHeight = document.body.clientHeight;
    }

    var preferenceXml = "<Interfaces>";
    preferenceXml += "<Resolution><ScreenWidth>" + screenWidth + "</ScreenWidth><ScreenHeight>" + screenHeight + "</ScreenHeight></Resolution>";
    for (var i = 0; i < intArrayRef.length; i++) {
        var prefXml = "<Interface";
        if (intArrayRef[i].value.Status == "O") {
            prefXml = prefXml + " Type='" + intArrayRef[i].value.Type + "' Top='" + (intArrayRef[i].value.Top - contDivTop) + "' Left='" + (intArrayRef[i].value.Left - contDivLeft) +
                    "' Width='" + intArrayRef[i].value.Width + "' Height='" + intArrayRef[i].value.Height + "'/>"
            preferenceXml = preferenceXml + prefXml;
        }
    }
    preferenceXml = preferenceXml + "</Interfaces>";
    var prefColSpan = getPrefColSpan();
    if (prefColSpan > 0) {
        preferenceXml += "<WDeskRespLayout><Interfaces><LeftInterface class=\"" + prefColSpan + "\"/><RightInterface class=\"" + (12 - prefColSpan) + "\"/></Interfaces></WDeskRespLayout>";
    }
    return preferenceXml;
}
function getPrefColSpan() {
    var retVal;
    var xlPos = respInterfaceInfo.leftRefNewClass.indexOf("col-xl-");
    var lgPos = respInterfaceInfo.leftRefNewClass.indexOf("col-lg-");
    if (xlPos > -1) {
        retVal = respInterfaceInfo.leftRefNewClass.substring(xlPos+7,respInterfaceInfo.leftRefNewClass.indexOf(' ',xlPos));
    } else if (lgPos > -1) {
        retVal = respInterfaceInfo.leftRefNewClass.substring(lgPos+7,respInterfaceInfo.leftRefNewClass.indexOf(' ',lgPos));
    }
    return retVal;
}
function saveWorkDeskLayout(type) {
    var ajaxReq;
    var param = "";
    var tempWidth = 800;
    var tempHeight = 800;
    var pid = document.getElementById('wdesk:pid');
    var wid = document.getElementById('wdesk:wid');
    var taskid = document.getElementById('wdesk:taskid');
    var dataFrm = document.getElementById('wdesk');
    var finalWidth;
    var finalHeight;
    var finalTop;
    var finalLeft;
    if (navigator.appName == "Microsoft Internet Explorer")
    {
        /*finalWidth=document.body.offsetWidth;
         finalHeight=document.body.offsetHeight;*/
        finalWidth = document.documentElement.clientWidth + 34;
        finalHeight = document.documentElement.clientHeight + 77;
        finalLeft = window.screenLeft;
        finalTop = window.screenTop;
    }
    else
    {
        finalWidth = window.outerWidth + 1;
        finalHeight = window.outerHeight - 1;
        finalLeft = window.screenX + 8;
        finalTop = window.screenY + 54;
    }
        if(finalWidth || finalHeight || finalTop || finalLeft)
            strCallSetWin='Y';
        var Left = encode_utf8(dataFrm.Left.value);
        /*******In case of Custom Template Horizontal height of upper Table*********************/
        var Height="";
        if(dataFrm.Height !=undefined)
            Height= dataFrm.Height.value;
        /*******In case of  Custom Template Horizontal height of upper Table*********************/
        
        var strTempPref=getTempletPref();
        if(strTempPref!=''&& strCallSetWin=='N')
            strCallSetWin='Y';
        param+='pid='+encode_utf8(pid.value)+'&wid='+wid.value+'&taskid='+taskid.value+'&Left='+Left+'&TopHeight='+Height+'&Right='+'100'+'&strCallSetWin='+strCallSetWin+'&templetPref='+encode_utf8(strTempPref)+'&finalWidth='+finalWidth+'&finalHeight='+finalHeight+'&finalLeft='+finalLeft+'&finalTop='+finalTop+'&checkResize='+checkResize;
        if(wiproperty.locked=="Y")
           param=param+'&IsReadOnly=Y';
       
       if(type=='P'){
           param=param+'&saveprefrence=Y';
       }
       
       var prefXml=fetchPrefenceXml();
       param = param+"&PrefXml="+prefXml+"&NewWorkdesk=Y&WD_SID="+WD_SID;
       if (window.XMLHttpRequest) {
        ajaxReq= new XMLHttpRequest();
        } else if (window.ActiveXObject) {
        ajaxReq= new ActiveXObject("Microsoft.XMLHTTP");
        }
        var url = '/webdesktop/ajaxunlockworkitem.app';
        url = appendUrlSession(url);
        var wd_rid=getRequestToken(url);
         url+="&WD_RID="+wd_rid;
         if(ajaxReq != null){
        ajaxReq.open("POST", url, false);
        ajaxReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        ajaxReq.send(param);
        if (ajaxReq.readyState == 4&&ajaxReq.status == 200) {
                var errorRespose=ajaxReq.responseText;
				if(errorRespose!=""){
                                    try{
					var errorRespose=parseJSON("("+errorRespose+")");
					window.status=errorRespose[1].description;
                                    }catch(e){}
				}
        } else {
            if(ajaxReq.status==598)
               customAlert(ajaxReq.responseText);
            else if(ajaxReq.status==599){
			//url = "/webdesktop/faces/login/login.jsp?"+"error="+ajaxReq.getResponseHeader('ngerror');
                        url = sContextPath+"/error/errorpage.app?msgID=4020";
			url = appendUrlSession(url);
                        
                        var width = 320;
                        var height = 160;
                        var left = (window.screen.availWidth-width)/2;
                        var top = (window.screen.availHeight-height)/2;
                        
                        //window.open(url,reqSession);
                        if (window.showModalDialog){
                            window.showModalDialog(url,'',"dialogWidth:"+width +"px;dialogHeight:"+height+"px;center:yes;dialogleft: "+left+"px;dialogtop: "+top+"px");
                        }
            }
              else if(ajaxReq.status==310)
            {
                window.location= "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";    
            }
            else if(ajaxReq.status == 400)
                  customAlert(INVALID_REQUEST_ERROR);
             else if(ajaxReq.status==12029){
                customAlert(ERROR_SERVER); 
            } 
            else
                customAlert(ALERT_OPERATION_UNSUCCESSFUL);
        }
            return 'failure';
        }
}

function clickAssignToMe(){ 
    ngformSaveCalled();
    var ret=0;
    myBrowser = navigator.appName;
    var dataFrm = document.getElementById('wdesk');
    dataFrm.ToSave.value='false';
    dataFrm.wLMode.value =wLMode;
    var formWindow=getWindowHandler(windowList,"formGrid");
    var ngformIframe = document.getElementById("ngformIframe");	
    if (window.showModalDialog)
    {
        if(saveCalled==true)
        {
            var url = sContextPath+"/components/workitem/view/confirmdone.app?PName=lockforme1&flag=TEXT_LOCKFORME_SAVE_CONFIRM&WD_SID="+WD_SID;
            url = appendUrlSession(url);
            ret = window.showModalDialog(url,'',"dialogWidth:"+windowVW+"px;dialogHeight:"+windowVH+"px;center:yes;");
           
        }
        if (ret == '2'){
            if((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm){  
                if(ngformIframe != null){
                    try
                    {
                        var isValidated = false; 
                        if(bAllDeviceForm){
                            isValidated = ngformIframe.contentWindow.eval("isComponentValidated()"); 
                        } else {
                            isValidated = ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.isComponentValidated()"); 
                        }
                        if(!isValidated){
                            return;
                        }
                    }
                    catch(e){}
                }
            }
            if(!form_cutomValidation("L"))
                return false;
            if(!saveFormdata('formData','','close')){
                return false;
            }
            if(bDefaultNGForm)
                dataFrm.ToSave.value='true';
        }
        
        if(wiLockForMeClick()){
            dataFrm.CloseWindow.value='false';
            unlockflag="N";
            var ngParam='';
            if(typeof formWindow!='undefined' &&  wiproperty.formType=="NGFORM" && bDefaultNGForm){
                if(dataFrm.ToSave.value == 'true'){                    
                    var retVal =  document.wdgc.SaveData('S');
                    if(retVal != 1)
                        return 'false';
                
                    ngParam= getNGParam();
                }
            } else if(typeof formWindow!='undefined' &&  wiproperty.formType=="NGFORM" && !bDefaultNGForm) {
                if(ngformIframe != null){
                    if(bAllDeviceForm){
                        dataFrm.ToSave.value='true';
                    } else {
                        var ngformIframeWindow = ngformIframe.contentWindow;
                        var wiDummySaveStructWinRef = ngformIframeWindow;
                        if(formIntegrationApr == "4"){
                            wiDummySaveStructWinRef = window;
                        }
                        
                        wiDummySaveStructWinRef.WiDummySaveStruct.Type = 'AssignToMe';
                        wiDummySaveStructWinRef.WiDummySaveStruct.Params.sourceWindow = window; 
                        
                        if(formIntegrationApr == "4"){
                            ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.fireFormValidation('S','Y')");	                                                                
                        } else {	
                            ngformIframeWindow.clickLink('cmdNgFormDummySave');
                        }
                    }
                }
            }else if(typeof formWindow!='undefined' && wiproperty.formType=="HTMLFORM") {
                ngParam= getNGParam();
                dataFrm.ToSave.value='true';
            } else if(typeof formWindow!='undefined' && wiproperty.formType=="CUSTOMFORM") {
                ngParam= getNGParam();
                dataFrm.ToSave.value='true';
            } 
            
            if((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && bDefaultNGForm || (wiproperty.formType=="HTMLFORM" || wiproperty.formType=="CUSTOMFORM" || bAllDeviceForm))
            {
                hideWIFromList();
                
                if(bCustomIForm){
                    if(typeof formWindow!='undefined' && ngformIframe != null){
                        if(typeof ngformIframe.contentWindow.customIFormHandler != 'undefined'){
                            ngformIframe.contentWindow.customIFormHandler('S');
                        }
                    }
               }
                
                clickWiLink("LOCKFORMESAVE","wdesk:controller",ngParam);
            }
        //window.close();
        }
    }
    else{
        if(saveCalled==true)
        {
           // winname = 'lockformemodal';
            var url = "/webdesktop/components/workitem/view/confirmdone.app";
            url = appendUrlSession(url);
            var wFeatures = 'scrollbars=no,modal=yes,width='+window4W+',height='+windowVH+',left='+window4Y+',top='+(window3X+100);

            var listParam=new Array();
            listParam.push(new Array("PName",encode_ParamValue('lockforme1')));
            listParam.push(new Array("flag",encode_ParamValue('TEXT_LOCKFORME_SAVE_CONFIRM')));

            var win = openNewWindow(url,'lockformemodal',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
                
        /*var url = "/webdesktop/faces/workitem/view/close.jsp?PName=lockforme1&flag=TEXT_LOCKFORME_SAVE_CONFIRM";
                win = window.open(url,winname,'scrollbars=no,modal=yes,width='+window4W+',height='+windowVH+',left='+window4Y+',top='+(window3X+100));*/
        }
        else
        {
            if(wiLockForMeClick()){
                dataFrm.CloseWindow.value='false';
                unlockflag="N";
                hideWIFromList();
                
                if(bCustomIForm){
                    if(typeof formWindow!='undefined' && ngformIframe != null){
                        if(typeof ngformIframe.contentWindow.customIFormHandler != 'undefined'){
                            ngformIframe.contentWindow.customIFormHandler('S');
                        }
                    }
               }
               
                clickWiLink("LOCKFORMESAVE","wdesk:controller",'');
            // window.close();
            }
               
        }
    }
}

function clickRelease(){
    ngformSaveCalled();
    var ret=0;
    var wdesk_win;
    var myBrowser = navigator.appName;
    var dataFrm = document.getElementById('wdesk');
    dataFrm.ToSave.value='false';
    var formWindow=getWindowHandler(windowList,"formGrid");
    var ngformIframe = document.getElementById("ngformIframe");
    if (window.showModalDialog)
    {
        if(saveCalled==true)
        {
            var url = sContextPath+"/components/workitem/view/confirmdone.app?PName=release1&flag=TEXT_RELEASE_SAVE_CONFIRM&WD_SID="+WD_SID;
            url = appendUrlSession(url);
            ret = window.showModalDialog(url,'',"dialogWidth:"+windowVW+"px;dialogHeight:"+windowVH+"px;center:yes;"+"dialogleft="+window4Y+"px;"+"dialogtop="+(window3X+100)+"px;");
            
        }
        if (ret == '2'){
            if((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && !bDefaultNGForm){	
                if(ngformIframe != null){
                    try
                    {
                        var isValidated = false; 
                        if(bAllDeviceForm){
                            isValidated = ngformIframe.contentWindow.eval("isComponentValidated()"); 
                        } else {
                            isValidated = ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.isComponentValidated()"); 
                        }
                        if(!isValidated){
                            return;
                        }
                    }
                    catch(e){}
                }
            }
            if(!form_cutomValidation("L"))
                return false;
            if(!saveFormdata('formData','','close')){
                return false;
            }
            if(bDefaultNGForm)
                dataFrm.ToSave.value='true';
        }
    
        if(wiReleaseClick()){
            dataFrm.CloseWindow.value='false';
            unlockflag="N";
            var ngParam='';
            if(dataFrm.ToSave.value == 'true'){
                var formWindow= getWindowHandler(windowList,"formGrid");
                if(typeof formWindow!='undefined' &&  wiproperty.formType=="NGFORM"){
                    var retVal =  document.wdgc.SaveData('S');
                    if(retVal != 1)
                        return 'false';
                }
                ngParam= getNGParam();
            }
            else if(typeof formWindow!='undefined' &&  wiproperty.formType=="NGFORM" && !bDefaultNGForm) {
                if(ngformIframe != null){
                    if(bAllDeviceForm){
                        dataFrm.ToSave.value='true';
                    } else {
                        var ngformIframeWindow = ngformIframe.contentWindow;
                        var wiDummySaveStructWinRef = ngformIframeWindow;
                        if(formIntegrationApr == "4"){
                            wiDummySaveStructWinRef = window;
                        }
                        
                        wiDummySaveStructWinRef.WiDummySaveStruct.Type = 'Release';
                        wiDummySaveStructWinRef.WiDummySaveStruct.Params.sourceWindow = window; 
                        
                        if(formIntegrationApr == "4"){
                            ngformIframe.contentWindow.eval("com.newgen.omniforms.formviewer.fireFormValidation('S','Y')");	                                                                
                        } else {	                        
                            ngformIframeWindow.clickLink('cmdNgFormDummySave');
                        }
                    }
                }
            } else if(typeof formWindow!='undefined' && wiproperty.formType=="HTMLFORM") {
                ngParam= getNGParam();
                dataFrm.ToSave.value='true';
            } else if(typeof formWindow!='undefined' && wiproperty.formType=="CUSTOMFORM") {
                ngParam= getNGParam();
                dataFrm.ToSave.value='true';
            } 
            
            if((wiproperty.formType == "NGFORM") && (ngformproperty.type == "applet") && bDefaultNGForm || (wiproperty.formType=="HTMLFORM" || wiproperty.formType=="CUSTOMFORM" || bAllDeviceForm))
            {
                hideWIFromList();
                
                if(bCustomIForm){
                    if(typeof formWindow!='undefined' && ngformIframe != null){
                        if(typeof ngformIframe.contentWindow.customIFormHandler != 'undefined'){
                            ngformIframe.contentWindow.customIFormHandler('S');
                        }
                    }
               }
               
                clickWiLink("RELEASESAVE","wdesk:controller",ngParam);
            } 
        // window.close();
        }
    }
    else{
        if(saveCalled==true)
        {
           // winname = 'releasemodal';
            var url = "/webdesktop/components/workitem/view/confirmdone.app"
            url = appendUrlSession(url);
            var wFeatures = 'scrollbars=no,modal=yes,width='+window4W+',height='+windowVH+',left='+window4Y+',top='+(window3X+100);

            var listParam=new Array();
            listParam.push(new Array("PName",encode_ParamValue('release1')));
            listParam.push(new Array("flag",encode_ParamValue('TEXT_RELEASE_SAVE_CONFIRM')));

            var win = openNewWindow(url,'releasemodal',wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
                
        /*var url = "/webdesktop/faces/workitem/view/close.jsp?PName=release1&flag=TEXT_RELEASE_SAVE_CONFIRM";
                win = window.open(url,winname,'scrollbars=no,modal=yes,width='+window4W+',height='+windowVH+',left='+window4Y+',top='+(window3X+100));*/
        }
        else
        {
            if(wiReleaseClick()){
                dataFrm.CloseWindow.value='false';
                unlockflag="N"; 
                hideWIFromList();
                
                if(bCustomIForm){
                    if(typeof formWindow!='undefined' && ngformIframe != null){
                        if(typeof ngformIframe.contentWindow.customIFormHandler != 'undefined'){
                            ngformIframe.contentWindow.customIFormHandler('S');
                        }
                    }
               }
               
                clickWiLink("RELEASESAVE","wdesk:controller",'');
            //  window.close();
            }
        }
    }
}



function handleLockForMeWI(val){
    var wdesk_win;     
    var dataFrm = document.getElementById('wdesk');
    dataFrm.ToSave.value='false';
    dataFrm.wLMode.value =wLMode;
    if (val == '2'){
    if(typeof window.frames['ifrmFormDiv'] != 'undefined'){
           try{
               if(bAllDeviceForm){
                    window.frames['ifrmFormDiv'].fireFormValidation("R");
               } else {
                    window.frames['ifrmFormDiv'].com.newgen.omniforms.formviewer.fireFormValidation("R");
               }
           }catch(ex)
           {
               if(bAllDeviceForm){
                    window.frames['ifrmFormDiv'].contentWindow.fireFormValidation("R");
               } else {
                    window.frames['ifrmFormDiv'].contentWindow.com.newgen.omniforms.formviewer.fireFormValidation("R");
               }
           }
          return;
       }else{
            if(!saveFormdata('formData'))
                return; 
            dataFrm.ToSave.value='true';
       }
    }
    if(wiLockForMeClick()){
        dataFrm.CloseWindow.value='false';
        unlockflag="N";
        var ngParam='';
        if(dataFrm.ToSave.value == 'true'){
            var formWindow=getWindowHandler(windowList,"formGrid");
            if(typeof formWindow!='undefined' && wiproperty.formType=="NGFORM"){
                var retVal = document.wdgc.SaveData('S');
                if(retVal != 1)
                    return 'false';
            }
            ngParam=getNGParam();
        }
        hideWIFromList();
        clickWiLink("LOCKFORMESAVE","wdesk:controller",ngParam);
    //  window.close();
    }
}

function handleReleaseWI(val){ 
    var wdesk_win;     
    var dataFrm = document.getElementById('wdesk');
    dataFrm.ToSave.value='false'; 
    if (val == '2'){
         if(typeof window.frames['ifrmFormDiv'] != 'undefined'){
           try{
               if(bAllDeviceForm){
                    window.frames['ifrmFormDiv'].fireFormValidation("R");
               } else {
                    window.frames['ifrmFormDiv'].com.newgen.omniforms.formviewer.fireFormValidation("R");
               }
           }catch(ex)
           {
               if(bAllDeviceForm){
                    window.frames['ifrmFormDiv'].contentWindow.fireFormValidation("R");
               } else {
                    window.frames['ifrmFormDiv'].contentWindow.com.newgen.omniforms.formviewer.fireFormValidation("R");
               }
           }
          return;
       }else{
            if(!saveFormdata('formData'))
                return; 
            dataFrm.ToSave.value='true';
        }
    } 
    if(wiReleaseClick()){ 
        dataFrm.CloseWindow.value='false';
        unlockflag="N"; 
        var ngParam=''; 
        if(dataFrm.ToSave.value == 'true'){
            var formWindow=getWindowHandler(windowList,"formGrid");
            if (typeof formWindow != 'undefined' && wiproperty.formType == "NGFORM" && bDefaultNGForm) {
                if ((typeof document.wdgc != 'undefined') && document.wdgc) {
                    var retVal = document.wdgc.SaveData('S');
                    if (retVal != 1)
                        return 'false';
                }
            }
            ngParam=getNGParam();
        } 
        hideWIFromList();
        clickWiLink("RELEASESAVE","wdesk:controller",ngParam);
    // window.close();
    }
}
