function resizeCompWH(height,width,type,diffHeight){
    var strWLMode = (typeof wLMode == 'undefined')? 'PM':wLMode;
    height = (typeof height == 'undefined')? null:height;
    width = (typeof width == 'undefined')? null:width;
    type = (typeof type == 'undefined')? '':type;
    diffHeight = (typeof diffHeight == 'undefined')? null:diffHeight;
    var scrollDivRef = document.getElementById('scroll');
    
    if(strWLMode == 'RS' || strWLMode == 'CM' || strWLMode == 'PM' || strWLMode == 'WD'){                
        if(scrollDivRef && width){
            var realWidth = (width-20);
            scrollDivRef.style.width = realWidth+'px';
            
            document.getElementById('wlf:hidWidth').value=realWidth;
            var ref = document.getElementById('Comp_width');
            ref.value = realWidth;
            
            //resizeRSWorkList(false);
            renderButtons('wlf:pnlResult','wlf');
            //$(".chosen-select").chosen();
        }
        if(scrollDivRef && (diffHeight != null)){
            var h = (parseInt(scrollDivRef.style.height)+diffHeight);
            scrollDivRef.style.height = h+'px';
            document.getElementById('wlf:hidHeight').value=h;
            document.getElementById('Comp_height').value=h;
        }else {
            scrollDivRef.style.height = (height-40) +'px';
            document.getElementById('wlf:hidHeight').value=(height-10);
            document.getElementById('Comp_height').value=(height-10);
        }
    } 
	
	else if ((scrollDivRef && (height != null)) && typeof IsEmbeddedWList != 'undefined' && IsEmbeddedWList) {
        var ref = document.getElementById('Comp_height');
        ref.value = height;
    }
	
	else {
        if(width!=undefined && width!="" && width){
            var realWidth = (width-20);
            
            document.getElementById('wlf:hidWidth').value=realWidth;
            document.getElementById('Comp_width').value=realWidth;
            
            scrollDivRef.style.width = realWidth+'px';        
        }
        if(height!=undefined && height!="" && height){
            document.getElementById('wlf:hidHeight').value=height;
            document.getElementById('Comp_height').value=height;
        }

      //  clickLink("wlf:RefreshForMinMax");
    }
}
function FilterWorkitemWinHandler(event_DefId,event_name,jsonoutput){                
    if(comp_ins_loc=='i')
        window.parent.CompEventHandler(event_DefId,event_name,jsonoutput);
    else
        CompEventHandler(event_DefId,event_name,jsonoutput);
}
function changeimage(flag)
{

    var searchPrefix = document.getElementById("wlf:pqks:searchPrefix");
    if(searchPrefix == null){
        searchPrefix = document.getElementById("wlf:searchPrefix");
    }
    var prefix = document.getElementById("wlf:pqks:Prefix");
    if(prefix == null){
        prefix = document.getElementById("wlf:Prefix");
    }
    
    if(flag ==1)
    {
        if((searchPrefix.value=="" || searchPrefix.value == OP_WI_SEARCH) && prefix.value == OP_WI_SEARCH)
            prefix.value="";
        else{
            if(prefix.value != searchPrefix.value && prefix.value == OP_WI_SEARCH){
                prefix.value=searchPrefix.value;
            }
        }
    }
    else
    {

        if(searchPrefix.value=="")
            prefix.value=OP_WI_SEARCH;
        else{
            if(prefix.value != searchPrefix.value){
                prefix.value=searchPrefix.value;
            } else if(prefix.value == OP_WI_SEARCH){
                searchPrefix.value="";
            }
        }
    }
}
            
function handleEnter(e,id, bSetFocus)
{
    var browser=navigator.appName;
    if(browser=="Netscape")
    {
        if(e.which == 13)
        {
            var ref = document.getElementById("wlf:pqks:searchPrefix");
            if(ref == null){
                ref = document.getElementById("wlf:searchPrefix");
            }
            
            var ref2 = document.getElementById("wlf:pqks:Prefix");
            if(ref2 == null){
                ref2 = document.getElementById("wlf:Prefix");
            }
            
            ref.value=ref2.value;       
            
            var bSetFocus = (typeof bSetFocus == 'undefined')? true: bSetFocus;
            
            if(bSetFocus){
                setElementFocus(document.getElementById(id));
            }
            clickLink(id);
            cancelBubble(e);
        }
    }
    else
    {
        e=window.event;
        if(e.keyCode == 13)
        {
            var ref = document.getElementById("wlf:pqks:searchPrefix");
            if(ref == null){
                ref = document.getElementById("wlf:searchPrefix");
            }
            
            var ref2 = document.getElementById("wlf:pqks:Prefix");
            if(ref2 == null){
                ref2 = document.getElementById("wlf:Prefix");
            }
            
            ref.value=ref2.value;                           
            setElementFocus(document.getElementById(id));
            clickLink(id);
            cancelBubble(e);
        }
    }
}

function handleEnterSB(e,id, bSetFocus)
{
    isSelectedFromList=false;
    var pName = "";
    var browser=navigator.appName;
    if(browser=="Netscape")
    {
        if(e.which == 13)
        {
            var ref = document.getElementById("wlf:pqks:searchPrefix");
            if(ref == null){
                ref = document.getElementById("wlf:searchPrefix");
            }
            
            var ref2 = document.getElementById("wlf:pqks:Prefix");
            if(ref2 == null){
                ref2 = document.getElementById("wlf:Prefix");
            }
            
            ref.value=ref2.value;       
            
            var bSetFocus = (typeof bSetFocus == 'undefined')? true: bSetFocus;
            
            if(bSetFocus){
                setElementFocus(document.getElementById(id));
            }
            clickLink(id); 
            
            var searchCriteria = document.getElementById("wlf:searchWI").value;
            var pDefId = document.getElementById("wlf:processlist").value;
            pName =  document.getElementById("wlf:hidPName").value;
            
            var variantId = null;
            if(document.getElementById("wlf:VariantList").style.display != "none"){
                variantId = document.getElementById("wlf:VariantList").value;    
            }    
            
            var aliasInfo = '';    
            if(!(searchCriteria=='0' || searchCriteria=='1')){
                var qaliasselected = (document.getElementById("wlf:bAliasInQS").value == 'true');
                if(qaliasselected){
                    aliasInfo = document.getElementById("wlf:AliasList").value;
                }
            }
            
            if(window.parent.iFrameWorkitemListRef){                
                window.parent.iFrameWorkitemListRef.quickSearchExt(true,ref.value,searchCriteria,pDefId,variantId,aliasInfo,pName);
                renderQListCss();
            }
            
            cancelBubble(e);
        }
    }
    else
    {
        e=window.event;
        if(e.keyCode == 13)
        {
            var ref = document.getElementById("wlf:pqks:searchPrefix");
            if(ref == null){
                ref = document.getElementById("wlf:searchPrefix");
            }
            
            var ref2 = document.getElementById("wlf:pqks:Prefix");
            if(ref2 == null){
                ref2 = document.getElementById("wlf:Prefix");
            }
            
            ref.value=ref2.value;                           
            
            var bSetFocus = (typeof bSetFocus == 'undefined')? true: bSetFocus;
            
            if(bSetFocus){
                setElementFocus(document.getElementById(id));
            }
            clickLink(id);
            
            var searchCriteria = document.getElementById("wlf:searchWI").value;
            var pDefId = document.getElementById("wlf:processlist").value;
            pName =  document.getElementById("wlf:hidPName").value;
            var variantId = null;
            if(document.getElementById("wlf:VariantList").style.display != "none"){
                variantId = document.getElementById("wlf:VariantList").value;    
            }    
            
            var aliasInfo = '';    
            if(!(searchCriteria=='0' || searchCriteria=='1')){
                var qaliasselected = (document.getElementById("wlf:bAliasInQS").value == 'true');
                if(qaliasselected){
                    aliasInfo = document.getElementById("wlf:AliasList").value;
                }
            }
            
            if(window.parent.iFrameWorkitemListRef){
                window.parent.iFrameWorkitemListRef.quickSearchExt(true,ref.value,searchCriteria,pDefId,variantId,aliasInfo,pName);
                renderQListCss();
            }
            
            cancelBubble(e);
        }
    }
}

function FilterEventHandler(event_DefId,event_name,jsonoutput){   
    window.parent.CompEventHandler(comp_ins_id,event_DefId,event_name,jsonoutput);
    document.getElementById('MoreDiv').style.display = 'none';
    //document.getElementById('MoreDiv2').style.display = 'none';
}
function RefreshWorkitem(data){
    HandleProgressBar(data);
    if(data.status=='success'){
        var error= document.getElementById("wlf:hidFailedWorkitemlist").value;
        var selOpr = document.getElementById("wlf:hidSelectedOpr").value;
        if(error=='true'){
            Url = '/webdesktop/components/workitem/list/failedworkitemlist.app?WD_SID='+WD_SID;
            window.parent.popupIFrameOpenerWrapper(this, "failedworkitemlist", Url, 400, 300, WindowLeft, WindowTop, false, true, false, false,true);
            if(selOpr=='Lock' || selOpr=='Delete' || selOpr=='Release' || selOpr=='Revoke')
                RefreshWorklistWrapper("D");
        }else{
            RefreshWorklistWrapper("D");
            if(targetEmbdWIRef!=null){
                if(typeof targetEmbdWIRef.doRefreshEbmdWI != 'undefined'){
                    targetEmbdWIRef.doRefreshEbmdWI();
                }
            }
            if(window.parent.iFrameTaskListRef != null){
                window.parent.iFrameTaskListRef.clearTaskList();
            }
            if(window.parent.iFrameCaseBasketRef != null){
                window.parent.iFrameCaseBasketRef.compRefresh();
            }
        }
    }

}
function closediv(ref){
    document.getElementById('QuickSearchDiv').style.display = 'none';                      
    var hidSearch = document.getElementById('wlf:hidSearch').value;
    if(hidSearch != 'true'){
        var ref2 = document.getElementById("wlf:pqks:searchPrefix");
        if(ref2 == null){
            ref2 = document.getElementById("wlf:searchPrefix");
        }
        
        ref2.value='';
        document.getElementById('wlf:hidFlag').value='1';
    }
}
function closeQLDiv(){
    document.getElementById('queryListDiv').style.display = 'none';
}
function enabledisableProcesslist(ref){
    var ref2 = document.getElementById('wlf:pqks:searchWI');
    if(ref2 == null){
        ref2 = document.getElementById('wlf:searchWI');
    }
    var decisionCriteria=ref2.value;
    document.getElementById('wlf:inpSearchCriteria').value=decisionCriteria;

    if(isIE()) {
        clickLink("wlf:btnQuickSearchQV");
    }else {
        clickLinkSafari("wlf:btnQuickSearchQV");
    }
}

function edProcesslist(ref){
    var decisionCriteria=ref.value;
    document.getElementById('wlf:inpSearchCriteria').value=decisionCriteria;

    if(isIE()) {
        clickLink("wlf:btnQuickSearchQV");
    }else {
        clickLinkSafari("wlf:btnQuickSearchQV");
    }
}

function setProcessId(ref,fetchVariant){
    document.getElementById('wlf:hidProcessDefId').value=ref.value;
    document.getElementById('wlf:hidPid').value=ref.value;
    var pname = document.getElementById('wlf:hidPName');
    if(pname && ref.options && ref.options.length>0)
        pname.value = ref.options[ref.selectedIndex].innerHTML.trimEx();
    if(fetchVariant!= undefined && fetchVariant){
        if(isIE()) {
            clickLink("wlf:btnQuickSearchVariant");
        }else {
            clickLinkSafari("wlf:btnQuickSearchVariant");
        }
    }
}
 function setAliasId(ref){
     document.getElementById('wlf:hidAliasDefId').value=ref.value;
     setDefaultOptions();
 }           
function embeddedWorkitemEventHandler(eventDefId,rowcount,eventName,objJsonOutput){                    
    window.parent.CompEventHandler(comp_ins_id,eventDefId,eventName,objJsonOutput);
}
               
function hideDeleteDiv(){
    document.getElementById("MessageDiv").style.display="none";
}
function NewWorkitemAction()
{
    var ctrlTableId="wlf:pnlResult";
    var bPrcListError = document.getElementById('wlf:hidbPrcListError').value;
    var bMultiplePrc = document.getElementById('wlf:hidMultiplePrc').value;
    var PDefIdNewWi = document.getElementById('wlf:hidPDefIdNewWi').value;
    var PVariantIdNewWi = document.getElementById('wlf:hidPVariantIdNewWi').value;

    if(bPrcListError == "true" || bMultiplePrc == "true")
    {
        /*if(document.getElementById('NewWorkitem')){
            document.getElementById('NewWorkitem').style.display="inline";
        }*/
        if(document.getElementById('wlf:NewShow')!=null && document.getElementById('wlf:NewShow')!=undefined ){
            //positionmenu('wlf:NewShow','NewWorkitem');
            showWlistMenu(document.getElementById('wlf:NewShow'),'NewWorkitem')
        } else{
            //positionmenu('wlf:NewShow','NewWorkitem');
            showWlistMenu(document.getElementById('wlf:NewShow'),'NewWorkitem')
        }
    }
    else if(PDefIdNewWi != "")
    {
        openNewWorkitem(PDefIdNewWi,PVariantIdNewWi);
    }

    //renderButtons(ctrlTableId,"wlf");

}

function selectProcess(processId,ProcessName,variantId)
{
    openNewWorkitem(processId,variantId);
}

function onmouseOver(ref)
{
    ref.className = 'wdSelected';
}

function onmouseOut(ref)
{
    ref.className = 'wdSimple';
}
function HideNewWIDIV(){
    document.getElementById('NewWorkitem').style.display="none";
}
            
function hideOnDocumentClick(e){

    var refId = event.srcElement.id;
    var index = refId.lastIndexOf(":");
    var subId = refId.substring(index+1);

    if(subId=='expandBtn' || subId=='collapseBtn' || subId=='expand' || subId=='collapse')
        return;
    var queryListDiv=document.getElementById('queryListDiv');
    var querylistBtn=document.getElementById('wlf:queryListBtn');
    var moreOptionsBtn=document.getElementById('wlf:moreOptionsBtn');                
    var deleteWI=document.getElementById('wlf:Delete');
    var New=document.getElementById('wlf:NewShow');
    var MoreDiv=document.getElementById('MoreDiv');
    var MoreDiv2=document.getElementById('MoreDiv2');
    var saveDiv=document.getElementById('saveDiv');
    var QuickSearchDiv=document.getElementById('QuickSearchDiv');
    var MessageDiv=document.getElementById('MessageDiv');
    var NewWorkitem=document.getElementById('NewWorkitem');
    var downImage=document.getElementById('wlf:downImage');
    var upImage=document.getElementById('wlf:upImage');
	var activityId=document.getElementById('wlf:hidActivityId');
    var processdefId=document.getElementById('wlf:hidProcessDefId');
    var target=e?e.target:event.srcElement;
    if(target==querylistBtn){                    
        saveDiv.style.display='none';
        MoreDiv.style.display='none';
        //MoreDiv2.style.display='none';
        if(QuickSearchDiv){
            QuickSearchDiv.style.display='none';
        }
        MessageDiv.style.display='none';
        if(NewWorkitem){
            NewWorkitem.style.display='none';
        }
    }else if(target==moreOptionsBtn){
        stopScrollTimer();
        if(QuickSearchDiv){
            QuickSearchDiv.style.display='none';
        }
        MessageDiv.style.display='none';
        if(NewWorkitem){
            NewWorkitem.style.display='none';
        }
        
        if(queryListDiv){
            queryListDiv.style.display='none';
        }
    }else if(target==New ){
        if(MoreDiv){
            MoreDiv.style.display='none';
        }
        //MoreDiv2.style.display='none';
        saveDiv.style.display='none';
        if(queryListDiv){
            queryListDiv.style.display='none';
        }
        MessageDiv.style.display='none';
        if(QuickSearchDiv){
            QuickSearchDiv.style.display='none';
        }
    }else if(target==deleteWI ){
        if(MoreDiv){
            MoreDiv.style.display='none';
        }
        //MoreDiv2.style.display='none';
        saveDiv.style.display='none';
        if(queryListDiv){
            queryListDiv.style.display='none';
        }
        if(QuickSearchDiv){
            QuickSearchDiv.style.display='none';
        }
        if(NewWorkitem){
            NewWorkitem.style.display='none';
        }
    }else{
        if(MoreDiv){
            MoreDiv.style.display='none';
        }
        if(MoreDiv2){
            MoreDiv2.style.display='none';
        }        
        /*if(saveDiv){
            saveDiv.style.display='none';                    
        }*/
        if(NewWorkitem){
            NewWorkitem.style.display='none';
        }
    }
    
    hideAllMenu(event.srcElement);
}
function getWICount(navType, wiCount){
    var wlTable = document.getElementById("wlf:pnlResult").children[1];
    var currentBatchSize = parseInt(document.getElementById("wlf:currentBatchSize").value);
    var i = wiCount;
     if(typeof wlTable!='undefined'){
    if(navType == 'P'){
        for(i=(wiCount+1); i >= 0; i--){
            if(typeof wlTable.rows[i] != 'undefined'){
                if(wlTable.rows[i].style.display != "none"){
                    return (i-1);
                }
            }
        }
    } else if(navType=='N'){
        for(i=(wiCount+1); i <= currentBatchSize; i++){
            if(typeof wlTable.rows[i] != 'undefined'){
                if(wlTable.rows[i].style.display != "none"){
                    return (i-1);
                }
            }
        }
    }
    }
    return i;
}
function openPrevWorkitem(wiCount, winName, wdJason){
    wdWinUId = winName;
    oldWdJason = wdJason;
    bPrevNextOperation = true;
    document.getElementById("wlf:workitemNavType").value = "P";
    document.getElementById("wlf:currentWiCount").value = wiCount;
    var hidLabelId = document.getElementById("wlf:hidLabelId").value;
    var prevBatchNav = document.getElementById("wlf:prevBatchNav").value;

    wiCount = getWICount('P', wiCount-1);
    if(prevBatchNav=="false"){
        if(wiCount < 0){
            return false;
        } else {
            clickLink("wlf:pnlResult_"+wiCount+hidLabelId);
            return true;
        }
    } else if(prevBatchNav=="true"){
        if(wiCount < 0){
           document.getElementById("wlf:prevBoundCheck").value = false;
            if(clickLinkPrevBatch)
                clickLinkPrevBatch();
            return true;
        } else {
            clickLink("wlf:pnlResult_"+wiCount+hidLabelId);
            return true;
        }
    }
}
            
function WorkitemEventHandlerWrapper(opType, winName, wdJason){
    opType = (typeof opType == 'undefined')? '': opType;
    wdJason = (typeof wdJason == 'undefined')? null: wdJason;
                
    wdWinUId = winName;
    oldWdJason = wdJason;                
    bPrevNextOperation = true;
                
    if(opType == 'N'){
        document.getElementById("wlf:workitemNavType").value = "N";
    } else if(opType == 'P'){
        document.getElementById("wlf:workitemNavType").value = "P";                    
    } else {
        bPrevNextOperation = false;
    }
                
    var queueId = document.getElementById('wlf:hidQueueId').value;
    var queueType = document.getElementById('wlf:hidQueueType').value;
    var activityType = '';
    if(wdJason != null){
        activityType = wdJason.ActivityType;
    }
                
    var eventDefId="1";
    var frmName=document.forms[0].id;
    var rowcount=0;
    var eventName='WorkitemClick';
    var objJsonOutput="{\"Outputs\":[{\"Output\":{\"Name\":\"ProcessInstanceID\",\"Value\":\"\"}},{\"Output\":{\"Name\":\"ProcessInstanceIDEnc\",\"Value\":\"\"}},{\"Output\":{\"Name\":\"WorkitemID\",\"Value\":\"\"}},{\"Output\":{\"Name\":\"RouteId\",\"Value\":\"\"}},{\"Output\":{\"Name\":\"WorkstageId\",\"Value\":\"\"}},{\"Output\":{\"Name\":\"QueueId\",\"Value\":\""+queueId+"\"}},{\"Output\":{\"Name\":\"RouteName\",\"Value\":\"\"}},{\"Output\":{\"Name\":\"ActivityName\",\"Value\":\"\"}},{\"Output\":{\"Name\":\"QueueType\",\"Value\":\""+queueType+"\"}},{\"Output\":{\"Name\":\"ActivityType\",\"Value\":\""+activityType+"\"}},{\"Output\":{\"Name\":\"wlSortLastValue\",\"Value\":\"\"}}]}";
    var archiveMode='N';
    WorkitemEventHandler(eventDefId, frmName, rowcount, eventName, objJsonOutput, archiveMode);
}

function getWiNavigationInfo(){
    var nextBatchNav = document.getElementById("wlf:nextBatchNav").value;
    var prevBatchNav = document.getElementById("wlf:prevBatchNav").value;
    var currentBatchSize = document.getElementById("wlf:currentBatchSize").value;
    var wiNavJason = {
        "IsNextBatch" : nextBatchNav,
        "IsPrevBatch" : prevBatchNav,
        "CurrentBatchSize" : currentBatchSize
    };

    return wiNavJason;
}
            
function updateWiListMessage(wiCount){
    if(wiCount >= 0){
        var wiNavJason = window.getWiNavigationInfo();
        if(wiNavJason.IsPrevBatch == "true" || wiNavJason.IsNextBatch == "true"){
            var prevAvailWiCount = getWICount('P', wiCount-1);                                       
            if(prevAvailWiCount < 0){
                document.getElementById("wlf:noWiInBatchMsg").style.display = "";
                document.getElementById("wlf:pnlResult").style.display = "none";                    
            }
        } else {
            var prevAvailWiCount = getWICount('P', wiCount-1);                                       
            if(prevAvailWiCount < 0){
                document.getElementById("wlf:noWiMsg").style.display = "";
                document.getElementById("wlf:pnlResult").style.display = "none";                    
            }
        }
    }
}

function openNextWorkitem(wiCount, winName, wdJason){
    wdWinUId = winName;
    oldWdJason = wdJason;
    bPrevNextOperation = true;
    document.getElementById("wlf:workitemNavType").value = "N";
    document.getElementById("wlf:currentWiCount").value = wiCount;
    var hidLabelId = document.getElementById("wlf:hidLabelId").value;
    var nextBatchNav = document.getElementById("wlf:nextBatchNav").value;
    var currentBatchSize = parseInt(document.getElementById("wlf:currentBatchSize").value);

    wiCount = getWICount('N', wiCount+1);
    if(nextBatchNav == "false"){
        if(wiCount >= currentBatchSize){
            return false;
        } else {
            clickLink("wlf:pnlResult_"+wiCount+hidLabelId);
            return true;
        }
    } else if(nextBatchNav == "true"){
        if(wiCount >= currentBatchSize){
            document.getElementById("wlf:nextBoundCheck").value = false;
            if(clickLinkNextBatch)
                clickLinkNextBatch();
            return true;
        } else {
            clickLink("wlf:pnlResult_"+wiCount+hidLabelId);
            return true;
        }
    }
}

function openNextEmbWorkitem(wiCount){
    wiCount = getWICount('N', wiCount+1);
    var hidLabelId = document.getElementById("wlf:hidLabelId").value;
    var currentBatchSize = parseInt(document.getElementById("wlf:currentBatchSize").value);

    if(wiCount >= currentBatchSize){
        return -1;
    } else {
        clickLink("wlf:pnlResult_"+wiCount+hidLabelId);
        return wiCount;
    }
}

function renderWorklist(data){
    if(data.status == "success"){
        var workitemNavType = document.getElementById("wlf:workitemNavType").value;
        var hidLabelId = document.getElementById("wlf:hidLabelId").value;
        var wiCount = parseInt(document.getElementById("wlf:currentWiCount").value);
        createFixedTableHeader("wlf:pnlResult",'wlf');
        if(workitemNavType == "P"){
            clickLink("wlf:pnlResult_"+(wiCount-1)+hidLabelId);
        } else if(workitemNavType == "N"){
            clickLink("wlf:pnlResult_"+(wiCount+1)+hidLabelId);
        }
    }
}
function enableDownloadWorklist(data){
    if(data.status=="success"){
        var enableDownload=document.getElementById("wlf:hidEnableSaveWlist").value;
        var startTime=document.getElementById("wlf:hidStartTime").value;
        var endTime=document.getElementById("wlf:hidEndTime").value;
        //startTime=DBToLocal(startTime,"dd/mm/yy");
        //endTime=DBToLocal(endTime,"dd/mm/yy");

        if(enableDownload=="true"){
            saveWorklist();
        }else{
            //alert(SAVE_AVAILABLE+startTime+TO+endTime);
        }
    }
}
            
function showDiv(event){
    if (event.stopPropagation) {
        event.stopPropagation();   
    } else {
        event.cancelBubble = true; 
    }
}

function clickNavCmdLink(linkId){
    clickLink("wlf:"+linkId);
}

function showSaveOptions(ref,tMenu){
    showWlistMenu(ref,tMenu);
    /*var saveDiv = document.getElementById("saveDiv");
    if(saveDiv.style.display == "none"){
        positionmenu(ref.id,'saveDiv',fromMainPref);
        saveDiv.style.display = "block";
    }*/
}
            
function compRefresh(op){
    var divScroll = document.getElementById("scroll");
    var wlscrollleft = document.getElementById("wlf:wlscrollleft");
    if(wlscrollleft) {
        wlscrollleft.value = divScroll.scrollLeft;
    }
    showSave = "Y";
    document.getElementById("wlf:quickSearchLoaded").value = "N";
    document.getElementById("wlf:queueProcessLoaded").value = "N";  
    
    if(!window.parent.allowCustomWL){
        var isCriteriaSearch = false;
        var ref = document.getElementById('wlf:hidFlag');
        if(ref){
            var refValue = ref.value;
            if(refValue == "5"){
                // Criteria search
                
                ref = document.getElementById('wlf:cid');
                refValue = ref.value;
                if(refValue != ''){
                    ref = document.getElementById('wlf:fid');
                    refValue = ref.value;
                    if(refValue != ''){
                        isCriteriaSearch = true;
                    }
                }
            }
        }
        if(op!="popout" && op!="popin"){
            if(isCriteriaSearch){
                clickLink("wlf:searchCriteria");
            } else {
                clickLink("wlf:lnkSortData");
            }
        }
    }                
}

function compOnMouseOver()
{

}

function compOnMouseOut()
{

}
function showQSSelection(data){
    if(data.status=="success"){
        var strWLMode = (typeof wLMode == 'undefined')? 'PM':wLMode;
        if(strWLMode == 'PM' || strWLMode == 'WD'){
            setDefaultOptions();          
            resizeCompSB(true);
        } else {        
            var ref = document.getElementById('wlf:quickSearchFilter2');
            if(ref){
                openQuickSearch(ref);
            }
        }
    }
}

function showPSSelection(data) {
    if(data.status=="success"){
        setDefaultOptions();
    }
}

function setDefaultOptions() {
    var ref1 = document.getElementById("wlf:Prefix");
    var ref2 = document.getElementById("wlf:searchPrefix");    
    var aliasRef = document.getElementById("wlf:AliasList");
    if(aliasRef){        
        document.getElementById("wlf:hidQueueAliasId").value=aliasRef.selectedIndex;
        //aliasRef.selectedIndex = document.getElementById("wlf:hidAliasDefId").value;
    }
    
    if(ref1 && ref2){
        //ref2.value="";
        //ref1.value=OP_WI_SEARCH;
        ref1.blur(); 
    }
}

function hideSaveDiv(){
    document.getElementById('saveDiv').style.display = "none";
}

function searchonchange(ref)
{
    var ref2 = document.getElementById("wlf:pqks:searchPrefix");
    if(ref2 == null){
        ref2 = document.getElementById("wlf:searchPrefix");
    }
    ref2.value= ref.value;
}

function searchOnImageClick(bCalledFromExt,bQSAlways,searchPrefix,searchCriteria,pDefId,variantId,aliasInfo,queueAliasIndex,pName){
    bCalledFromExt = (typeof bCalledFromExt == 'undefined')? false: bCalledFromExt;
    bQSAlways = (typeof bQSAlways == 'undefined')? bQuickSearchSent: !bQSAlways;
    searchPrefix = (typeof searchPrefix == 'undefined')? null: searchPrefix;
    searchCriteria = (typeof searchCriteria == 'undefined')? null: searchCriteria;
    pDefId = (typeof pDefId == 'undefined')? null: pDefId;
    variantId = (typeof variantId == 'undefined')? null: variantId;
    aliasInfo = (typeof aliasInfo == 'undefined')? '': aliasInfo;
    queueAliasIndex=(typeof queueAliasIndex == 'undefined')? '0': queueAliasIndex;
    pName = (typeof pName == 'undefined')? '': pName;
    bQuickSearchSent = bQSAlways;
    
    if(bQuickSearchSent){
        return false;
    }
              
    var ref = null;
    
    if(searchPrefix != null){
        ref = document.getElementById("wlf:pqks:searchPrefix");
        if(ref == null){
            ref = document.getElementById("wlf:searchPrefix");
        }
        
        if(ref != null){
            ref.value=searchPrefix;
        }        
        
        var tempVar=document.getElementById("wlf:pqks:searchWI");
        if(tempVar == null){
            tempVar=document.getElementById("wlf:searchWI");
        }
        tempVar.value = searchCriteria;

        tempVar=document.getElementById("wlf:pqks:Prefix");
        if(tempVar == null){
            tempVar=document.getElementById("wlf:Prefix");
        }
        tempVar.value = searchPrefix;
        
        tempVar=document.getElementById('wlf:pqks:processlist')
        if(tempVar == null){
            tempVar=document.getElementById('wlf:processlist');
        } 
        tempVar.value = pDefId;
        
        tempVar=document.getElementById('wlf:hidPName');
        tempVar.value = pName;
        
        tempVar = document.getElementById('wlf:pqks:VariantList');
        if(tempVar == null){
            tempVar = document.getElementById('wlf:VariantList');
        }
        
        if(variantId == null){
            tempVar.style.display = "none";
            tempVar.value = "";
        } else {
            tempVar.style.display = "";
            tempVar.value = variantId;
        }             
        document.getElementById('wlf:hidQSAlias').value=queueAliasIndex;
        document.getElementById('wlf:CalledFromExt').value='N';
        
        if(!(searchCriteria=='0' || searchCriteria=='1') && bCalledFromExt){
            if((aliasInfo.length > 0) && (aliasInfo.indexOf(':') > -1)){
                document.getElementById('wlf:CalledFromExt').value='Y';                
                document.getElementById('wlf:bAliasInQS').value='true';                
                document.getElementById('wlf:hidQSAlias').value = aliasInfo;
            }            
        }
    } else {           
        ref = document.getElementById("wlf:pqks:searchPrefix");
        if(ref == null){
            ref = document.getElementById("wlf:searchPrefix");
        }

        var ref2 = document.getElementById("wlf:pqks:Prefix");
        if(ref2 == null){
            ref2 = document.getElementById("wlf:Prefix");
        }

        if(ref != null && ref2 != null){
            ref.value=ref2.value;
        }
    }
    
    if(ref != null && ref.value == OP_WI_SEARCH){
        ref.value="";
        
        ref = document.getElementById("wlf:pqks:cmdBtn");
        if(ref == null){
            ref = document.getElementById("wlf:cmdBtn");
        }
        clickLink(ref.id);
    }
    else{
        ref = document.getElementById("wlf:pqks:cmdBtn");
        if(ref == null){
            ref = document.getElementById("wlf:cmdBtn");
        }
        clickLink(ref.id);        
    }
}

function searchOnImageClickSB(bQSAlways){          
    var result = true;
    var ref = document.getElementById("wlf:pqks:searchPrefix");
    if(ref == null){
        ref = document.getElementById("wlf:searchPrefix");
    }
    
    var ref2 = document.getElementById("wlf:pqks:Prefix");
    if(ref2 == null){
        ref2 = document.getElementById("wlf:Prefix");
    }
    
    if(ref != null && ref2 != null){
        ref.value=ref2.value;
    } 
//    else {
//        //ref = document.getElementById("wlf:pqks:searchPrefix");
//        ref.value=ref2.value;
//    }
    /*if(ref.value==OP_WI_SEARCH || ref.value==''){
        window.parent.customAlert(PLEASE_ENTER_SOME_FILTER_STRING);
        return false;
    }*/
    var searchCriteria = document.getElementById("wlf:searchWI").value;
    var pDefId = document.getElementById("wlf:processlist").value;
    var pName =  document.getElementById("wlf:hidPName").value;
    var variantId = null;
    if(document.getElementById("wlf:VariantList").style.display != "none"){
        variantId = document.getElementById("wlf:VariantList").value;    
    }    
    
    var aliasInfo = '';        
    if(!(searchCriteria=='0' || searchCriteria=='1')){
        var qaliasselected = (document.getElementById("wlf:bAliasInQS").value == 'true');
        var SearchCriteriaType = document.getElementById("wlf:hidSearchCriteriaType").value;
        var queueAliasIndex=document.getElementById("wlf:hidQueueAliasId").value
        if(qaliasselected && (SearchCriteriaType == '4')){
            aliasInfo = document.getElementById("wlf:AliasList").value;
            document.getElementById('wlf:hidAliasDefId').value=aliasInfo;
        } else {
            document.getElementById('wlf:hidAliasDefId').value="";
        }
    }
    if(ref != null){
    if(ref.value == OP_WI_SEARCH){
        ref.value="";
        
        //clickLink(ref.id);
        if(window.parent.iFrameWorkitemListRef){
            window.parent.iFrameWorkitemListRef.searchOnImageClick(true,bQSAlways,ref.value,searchCriteria,pDefId,variantId,aliasInfo,queueAliasIndex,pName);
            renderQListCss();
        }
    }
    else{
        //clickLink(ref.id);        
        if(window.parent.iFrameWorkitemListRef){
            window.parent.iFrameWorkitemListRef.searchOnImageClick(true,bQSAlways,ref.value,searchCriteria,pDefId,variantId,aliasInfo,queueAliasIndex,pName);
            renderQListCss();
        }
    }
    }
    
    document.getElementById("wlf:hidSelectedQueryIndex").value="";
    
    if(isSelectedFromList){
        result = false;
        isSelectedFromList=false;
    }
    if((searchCriteria=='0' || searchCriteria=='1') && (pDefId==LABEL_SELECT_PROCESS || pDefId=='-1'))
        result=false;
    /*if(result)
        clickLink("wlf:cmdLinkRS");*/
    return result;
}

function SaveRecentSearch(){
    if(!isSelectedFromList){
        clickLink("wlf:cmdLinkRS");
    }
    
    isSelectedFromList = false;
}
            
function expandProcess(index){
    document.getElementById("wlf:selectedIndexInTable").value = index;
    clickLink("wlf:expand");
}
function renderVariants(data){
    if(data.status=='success'){

    }
}
function collapseProcess(index){
    document.getElementById("wlf:selectedIndexInTable").value = index;
    clickLink("wlf:collapse");
}
function collapseVariants(data){
    if(data.status=='success'){

    }
}
            
var bCollaborationEnabled = false;
if(typeof window.parent.isCollaborationEnabled != 'undefined'){
    bCollaborationEnabled = window.parent.isCollaborationEnabled();
}

if(bCollaborationEnabled){
    window.onbeforeunload = finalize;
    try{
        window.parent.syncShowHideNotification(true);
    }catch(e){}
}

function finalize(){
    logoutFromNodeServer();
}

function logoutFromNodeServer(){
    if(typeof window.parent.disconnect != 'undefined'){
        var messageJSON = {
            FromUserIndex: '',
            MessageText : '',
            TargetComponentDefId : "", //compulsory
            Application : "",   //Application type to find out Iframe reference
            TargetComponentHandler : 'disconnectHandler',
            RoomId : (""),
            params:'',
            TimeStamp: new Date().getTime(),
            AppType:'', //may be needed (internal/external)   //not compulsory default value is Int
            Msg:[]
        }

        window.parent.disconnect(userIndex,JSON.stringify(messageJSON));
    }
}

function disconnectHandler(){
}

// Collaboration logout ----------------
        
function hideWorkitemFromList(processInstanceId){
    var wlTable = document.getElementById("wlf:pnlResult");                
    var totalWiCount = document.getElementById("wlf:pnlResult").tBodies[0].rows.length;
    if(wlTable !=null && wlTable !=undefined) {
        for(i=0; i < totalWiCount-1 ; i++){
            var jsonOutputWI=document.getElementById("wlf:hjn"+(i+1)).innerHTML;
            jsonOutputWI=parseJSON("("+jsonOutputWI+")");
            var tablepid='';

            var arrobjJsonOutput= jsonOutputWI.Outputs;
            for(var j=0;j < arrobjJsonOutput.length;j++){
                var outputJson=arrobjJsonOutput[j];
                var objJson=outputJson.Output;
                if(objJson.Name=='ProcessInstanceID'){
                    tablepid = encode_ParamValue(objJson.Value)
                    break;
                }
            }

            if(processInstanceId == tablepid){
                wlTable.tBodies[0].rows[i+1].style.display = "none";
                break;
            }
        }
    }
}
        
function checkQueue(){
    if(document.getElementById('wlf:queueSelect').value == 'N' || document.getElementById('wlf:queueSelect').value == 'S' || document.getElementById('wlf:queueSelect').value == 'F'){
                    
        return false;
    }
    document.getElementById('wlf:hidQueueSearch').value=document.getElementById('wlf:queueSelect').value;
    clickLink("wlf:getQueueListCM");
}
function clickNavCmdLinkWrapper(linkId){              
    if(!navigationLinkInitiated){
        navigationLinkInitiated = true
        clickLink("wlf:"+linkId);
    }
}
            
function HandleEventWrapper(data){
    var hidLabelId = document.getElementById("wlf:hidLabelId").value;
    var currentBatchSize = parseInt(document.getElementById("wlf:currentBatchSize").value);
    if(data.status == "success"){
        navigationLinkInitiated = false;
        if(document.getElementById("wlf:nextBoundCheck").value == "false"){
             document.getElementById("wlf:currentWiCount").value = 0;
             clickLink("wlf:pnlResult_"+"0"+hidLabelId);   
        }
            
        if(document.getElementById("wlf:prevBoundCheck").value == "false"){
            var wi_count = currentBatchSize-1;
            document.getElementById("wlf:currentWiCount").value = wi_count;
            clickLink("wlf:pnlResult_"+wi_count+hidLabelId); 
        }
        document.getElementById("wlf:nextBoundCheck").value = true;
        document.getElementById("wlf:prevBoundCheck").value = true;
    }
                
    onloadInitWorklistAjax(data);
}
function HandleEventWrapperQS(data){
    if(data.status == "success"){
        if(window.parent.iFrameSearchBarRef.document.getElementById('wlf:Prefix'))
            setElementFocus(window.parent.iFrameSearchBarRef.document.getElementById('wlf:Prefix'));        
    } 
    HandleEventWrapper(data);
}
            
function FAjaxErrorHandlerWrapper(data){
    if(data.status == "success"){
        navigationLinkInitiated = false;
    }
                
    FAjaxErrorHandler(data);
}
            
function onloadInitWorklistAjaxWrapper(data){
    if(data.status == "success"){                    
        var ref = document.getElementById('wlf:hidFlag');
        if((ref.value-0) == 3){
            ref = document.getElementById('wlf:lblWI1');
            if(ref != null){
             //   ref.style.display="none";                    
            }
        }
        document.getElementById('wlf:encodeFlag').value="1";
        ref = document.getElementById('wlf:hidFilterString');
        var filterStringTemp = ref.value;
        var filterStringEnc = EncryptPassword(filterStringTemp, eToken);
        ref.value = encode_utf8(filterStringEnc);
    }
                
    onloadInitWorklistAjax(data);                
}
function loadReminderCount(){
    var reminderListLinkRef=document.getElementById('wlf:hidGetReminder');
    if(typeof reminderListLinkRef!='undefined' && reminderListLinkRef!=null && typeof showReminderCountIni!='undefined' && showReminderCountIni!=null && showReminderCountIni==true){
                       
        if(timeOutIdRCount!=''){
            window.clearTimeout(timeOutIdRCount);
        } 
        clickLink('wlf:hidGetReminder');
        var reminderCountRef = document.getElementById('wlf:countCmdLink');
        var reminderDivRef = document.getElementById('wlf:reminderDiv');
        if(typeof reminderCountRef!='undefined' && reminderCountRef!=null){
            var iremCount = reminderCountRef.innerText.trim();
            if(typeof reminderDivRef!='undefined' && reminderDivRef!=null && iremCount > 0){
                reminderDivRef.style.display = "inline";
            } else {
                reminderDivRef.style.display = "none";
            }
        }
    }
}
            
function openReminderList(){
    openReminderListWindow();
}
            
function handleLoadCountReminder(){
                
    try{
        if(timeOutIdRCount!=''){
            window.clearTimeout(timeOutIdRCount);
        }
        var refInterval=document.getElementById('wlf:hidRefreshReminderCountInterval').value;
        refInterval=refInterval-0;
        if(refInterval > 0){
            var rtime=(refInterval-0)*60*1000;
            timeOutIdRCount=setTimeout("loadReminderCount()",rtime);
        }
    }catch(e){
        customAlert(e);
    }
}
function HandleReminderCount(data){
    if(data.status='success'){
        handleLoadCountReminder();
    }
}
function clickLinkWrapper(link,opr,from){
    if(typeof opr!='undefined' && opr!=null){
        document.getElementById('wlf:hidOprFlag').value=true;
        document.getElementById('wlf:hidOprPerf').value=opr;
    }
    else{
        document.getElementById('wlf:hidOprFlag').value=false;
        document.getElementById('wlf:hidOprPerf').value="";
    }
    
    var hidCtrSrch = document.getElementById('wlf:hidCtrSrch').value;
    if(hidCtrSrch=='true'){
        clickLink("wlf:searchCriteria");
    } else { 
        clickLink(link);
    }
}
            
function clickLinkNextBatch(){
                
    clickLink('wlf:getNextBatch');
}
              
function clickLinkPrevBatch(){
                
    clickLink('wlf:getPrevBatch');
}

function wehw(strFormName,rowCount){//,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23,p24,p25,p26,p27,p28,p29,p30,p31,p32,p33,p34,p35,p36,p37,archivalMode){
    if(strFormName == 1){
        strFormName = "wlf";
    } else {
        strFormName = "frmlinkedworkitemlist";
    }
    var hidWiJson = document.getElementById(strFormName+":hjn"+(rowCount+1));
    if(hidWiJson){
        hidWiJson = hidWiJson.innerHTML;
        var trimRegEx = /(\r\n|\n|\r)/gm; 
        var p = hidWiJson.split(SEPERATOR1+SEPERATOR4);
        
        var wlistEJson= "{\"Outputs\":[{\"Output\":{\"Name\":\"WorkitemID\",\"Value\":\""+p[0].replace(trimRegEx, "")+"\",\"DefId\":\"1\"}},"+
                        "{\"Output\":{\"Name\":\"WorkitemName\",\"Value\":\""+p[1]+"\",\"DefId\":\"2\"}},"+
                        "{\"Output\":{\"Name\":\"WorkitemState\",\"Value\":\""+p[2]+"\",\"DefId\":\"3\"}},"+
                        "{\"Output\":{\"Name\":\"ProcessInstanceID\",\"Value\":\""+p[3]+"\",\"DefId\":\"4\"}},"+
                        "{\"Output\":{\"Name\":\"ProcessInstanceState\",\"Value\":\""+p[4]+"\",\"DefId\":\"5\"}},"+
                        "{\"Output\":{\"Name\":\"RouteId\",\"Value\":\""+p[5]+"\",\"DefId\":\"6\"}},"+
                        "{\"Output\":{\"Name\":\"RouteName\",\"Value\":\""+p[6]+"\",\"DefId\":\"7\"}},"+
                        "{\"Output\":{\"Name\":\"ActivityName\",\"Value\":\""+p[7]+"\",\"DefId\":\"8\"}},"+
                        "{\"Output\":{\"Name\":\"ActivityType\",\"Value\":\""+p[8]+"\",\"DefId\":\"9\"}},"+
                        "{\"Output\":{\"Name\":\"WorkstageId\",\"Value\":\""+p[9]+"\",\"DefId\":\"10\"}},"+
                        "{\"Output\":{\"Name\":\"QueueType\",\"Value\":\""+p[10]+"\",\"DefId\":\"11\"}},"+
                        "{\"Output\":{\"Name\":\"QueueName\",\"Value\":\""+p[11]+"\",\"DefId\":\"12\"}},"+
                        "{\"Output\":{\"Name\":\"QueueId\",\"Value\":\""+p[12]+"\",\"DefId\":\"13\"}},"+
                        "{\"Output\":{\"Name\":\"AssignedTo\",\"Value\":\""+p[13]+"\",\"DefId\":\"14\"}},"+
                        "{\"Output\":{\"Name\":\"AssignmentType\",\"Value\":\""+p[14]+"\",\"DefId\":\"15\"}},"+
                        "{\"Output\":{\"Name\":\"ChecklistComplete\",\"Value\":\""+p[15]+"\",\"DefId\":\"16\"}},"+
                        "{\"Output\":{\"Name\":\"LockStatus\",\"Value\":\""+p[16]+"\",\"DefId\":\"17\"}},"+
                        "{\"Output\":{\"Name\":\"LockedTime\",\"Value\":\""+p[17]+"\",\"DefId\":\"18\"}},"+
                        "{\"Output\":{\"Name\":\"LockedBy\",\"Value\":\""+p[18]+"\",\"DefId\":\"19\"}},"+
                        "{\"Output\":{\"Name\":\"IntroducedBy\",\"Value\":\""+p[19]+"\",\"DefId\":\"20\"}},"+
                        "{\"Output\":{\"Name\":\"IntroductionOn\",\"Value\":\""+p[20]+"\",\"DefId\":\"21\"}},"+
                        "{\"Output\":{\"Name\":\"EntryDateTime\",\"Value\":\""+p[21]+"\",\"DefId\":\"22\"}},"+
                        "{\"Output\":{\"Name\":\"ExpiredDateTime\",\"Value\":\""+p[22]+"\",\"DefId\":\"23\"}},"+
                        "{\"Output\":{\"Name\":\"InstrumentStatus\",\"Value\":\""+p[23]+"\",\"DefId\":\"24\"}},"+
                        "{\"Output\":{\"Name\":\"PriorityLevel\",\"Value\":\""+p[24]+"\",\"DefId\":\"25\"}},"+
                        "{\"Output\":{\"Name\":\"ReferredTo\",\"Value\":\""+p[25]+"\",\"DefId\":\"26\"}},"+
                        "{\"Output\":{\"Name\":\"ReferredBy\",\"Value\":\""+p[26]+"\",\"DefId\":\"27\"}},"+
                        "{\"Output\":{\"Name\":\"ProcessedBy\",\"Value\":\""+p[27]+"\",\"DefId\":\"28\"}},"+
                        "{\"Output\":{\"Name\":\"wi_count\",\"Value\":\""+p[28]+"\",\"DefId\":\"29\"}},"+
                        "{\"Output\":{\"Name\":\"wlSortOrder\",\"Value\":\""+p[29]+"\",\"DefId\":\"30\"}},"+
                        "{\"Output\":{\"Name\":\"wlOrderBy\",\"Value\":\""+p[30]+"\",\"DefId\":\"31\"}},"+
                        "{\"Output\":{\"Name\":\"wlSortLastValue\",\"Value\":\""+p[31]+"\",\"DefId\":\"41\"}},"+
                        "{\"Output\":{\"Name\":\"allowreassignment\",\"Value\":\""+p[32]+"\",\"DefId\":\"32\"}},"+
                        "{\"Output\":{\"Name\":\"InstrumentListCallFlag\",\"Value\":\""+p[33]+"\",\"DefId\":\"33\"}},"+
                        "{\"Output\":{\"Name\":\"ArchivalMode\",\"Value\":\""+p[34]+"\",\"DefId\":\"34\"}},"+
                        "{\"Output\":{\"Name\":\"ProcessInstanceIDEnc\",\"Value\":\""+p[35]+"\",\"DefId\":\"35\"}},"+
                        "{\"Output\":{\"Name\":\"CreationDateTime\",\"Value\":\""+p[36]+"\",\"DefId\":\"39\"}}]}";
                    
        WorkitemEventHandler('1',strFormName,rowCount,'WorkitemClick',wlistEJson,p[34]);
    }
}

var gPopupMask;
function initPopUp() {
    if(gPopupMask == null) {
        // Add the HTML to the body
        theBody = document.getElementsByTagName('BODY')[0];
        popmask = document.createElement('div');
        popmask.id = 'popupMask';
        theBody.appendChild(popmask);
        gPopupMask = document.getElementById("popupMask");
        gPopupMask.style.display = "none";
        gPopupMask.style.position = "absolute";
        gPopupMask.style.zIndex = "200";
        gPopupMask.style.top = "0px";
        gPopupMask.style.left = "0px";
        gPopupMask.style.width = "100%";
        gPopupMask.style.height = "100%";
        gPopupMask.style.opacity = "0.4";
        gPopupMask.style.filter = "alpha(opacity=40)";
        gPopupMask.style.backgroundColor = "#d8dce0"; 
    }
}

function hidePopupMask()
{
    if(gPopupMask != null) {
        gPopupMask.style.display = "none";        
    }
}

function setPopupMask()
{
    if(gPopupMask ==null)
    {
        initPopUp(); 
    }
    if(gPopupMask !=null) {
        gPopupMask.style.display = "block";
        gPopupMask.style.height = window.document.documentElement.scrollHeight + "px";
        gPopupMask.style.width = document.documentElement.clientWidth + "px";
    }
}

function Blowfish(k){
    if (k.length==0) throw "0 length key";	
}

Blowfish.prototype.encryptx=function(t,key){
    var enc="";
    for(var i=0;i<t.length;i++)
    {
        var ch=t.charCodeAt(i);
        var x='';
        for(var k=0;k<key.length;k++)
        {
            var z=key.charCodeAt(k);
            x=ch^z;
            ch=x;
        }
        enc=enc+String.fromCharCode(ch);
    }
    return enc;
};
var Initiate=0,Hold=1,Unhold=2,Delete=3,Reassign=4,Properties=5,Done=6,Refer=7,Revoke=8,Priority=9,Reminder=10,LockForMe=11,UnAssign=12;

function SearchCriteria(cId,fId,falias){
    document.getElementById('wlf:hidCompInputWLMode').value="RS";    
    document.getElementById('wlf:hidWListMode').value="RS";
    document.getElementById('wlf:cid').value=cId;
    document.getElementById('wlf:fid').value=fId;
    document.getElementById('wlf:hidQueueName').value = falias;
    
    document.getElementById('wlf:hidQueueId').value="";
    document.getElementById('wlf:hidQueueType').value='';
    document.getElementById('wlf:hidSearch').value=true;
    document.getElementById('wlf:hidAllowReassignment').value="N";
    document.getElementById('wlf:hidFlag').value="5";
    
    var orderBySrch = (typeof orderBySearch == 'undefined')? '2': orderBySearch;
	var sortOrderSrch = (typeof sortOrderSearch == 'undefined')? 'A': sortOrderSearch;
    
    document.getElementById('wlf:hidOrderBy').value=orderBySrch;
    document.getElementById('wlf:hidSortOrder').value=sortOrderSrch;
    document.getElementById('wlf:hidQueueVarName').value='';
    document.getElementById('wlf:hidClientSorting').value=false;
    
    clickLink("wlf:searchCriteria");
}

function SearchCriteriaExt(cId,fId){
    if(window.parent.iFrameWorkitemListRef){
        window.parent.iFrameWorkitemListRef.SearchCriteria(cId,fId);
    }    
}

function openAdvanceSearchPopup(refItem,searchQueryID,globalQuery){
    
    if(window!=null && window.parent != null && window.parent.document.getElementById("popupIFrame_AdvanceSearch")!=null){
	//window.parent.document.getElementById("popupIFrame_AdvanceSearch").style.display='none';
	if(typeof searchQueryID!='undefined' || typeof globalQuery!='undefined')
        removeIFrame("popupIFrame_AdvanceSearch");
        else{
           window.parent.document.getElementById("popupIFrame_AdvanceSearch").style.display='block'; 
           return;
        }
    }
    var browser;
    if (navigator.appName != "Netscape")
        browser = "explorer";
    else
        browser = "netscape"
    searchQueryID = (typeof searchQueryID == 'undefined')? '0': searchQueryID;    
    var Url="/webdesktop/components/search/advancesearch.app?Action=1&OpenFrom=&browser=" + browser + "&processRightsFlag=Y&isSearch=Y&QueueFlag=Y&AdvSearchFlag=Y&AllWorkItemsFlag=&InProcessFlag=Y&Mode=PM&ProcessFlag=Y&RegNoFlag=Y&SearchPrevVersionFlag=Y&SortVersionFlag=Y&Type=1&Comp_ins_id=2010&queryID="+searchQueryID+"&GlobalQuery="+globalQuery;
    Url = appendUrlSession(Url);
    WindowLeft=findAbsPosX(refItem);
    WindowTop=findAbsPosY(refItem);
    window.parent.parent.popupIFrameOpenerWrapper(this, "AdvanceSearch", Url, 850, 425, WindowLeft, WindowTop, false, true, false, true, true);
    //window.parent.parent.createPopUpIFrameWrapper("AdvanceSearch",Url,405,700);
}

function quickSearchExt(bCalledFromExt,searchPrefix,searchCriteria,pDefId,variantId,aliasInfo,pName){
    var ref;
        
    if(searchPrefix != null){
        ref = document.getElementById("wlf:pqks:searchPrefix");
        if(ref == null){
            ref = document.getElementById("wlf:searchPrefix");
        }
        
        if(ref != null){
            ref.value=searchPrefix;
        }        
        
        var tempVar=document.getElementById("wlf:pqks:searchWI");
        if(tempVar == null){
            tempVar=document.getElementById("wlf:searchWI");
        }
        tempVar.value = searchCriteria;

        tempVar=document.getElementById("wlf:pqks:Prefix");
        if(tempVar == null){
            tempVar=document.getElementById("wlf:Prefix");
        }
        tempVar.value = searchPrefix;
        
        tempVar=document.getElementById('wlf:pqks:processlist')
        if(tempVar == null){
            tempVar=document.getElementById('wlf:processlist');
        } 
        tempVar.value = pDefId;
        
        tempVar=document.getElementById('wlf:hidPName');
        tempVar.value = pName;
        
        tempVar = document.getElementById('wlf:pqks:VariantList');
        if(tempVar == null){
            tempVar = document.getElementById('wlf:VariantList');
        }
        
        if(variantId == null){
            tempVar.style.display = "none";
            tempVar.value = "";
        } else {
            tempVar.style.display = "";
            tempVar.value = variantId;
        }                
        
        aliasInfo = (typeof aliasInfo == 'undefined')? '': aliasInfo;
        bCalledFromExt = (typeof bCalledFromExt == 'undefined')? false: bCalledFromExt;
        
        document.getElementById('wlf:CalledFromExt').value='N';
        
        if(!(searchCriteria=='0' || searchCriteria=='1') && bCalledFromExt){
            if((aliasInfo.length > 0) && (aliasInfo.indexOf(':') > -1)){
                document.getElementById('wlf:CalledFromExt').value='Y';                
                document.getElementById('wlf:bAliasInQS').value='true';                
                document.getElementById('wlf:hidQSAlias').value = aliasInfo;
            }            
        }
    }
    
    ref = document.getElementById("wlf:pqks:cmdBtn");
    if(ref == null){
        ref = document.getElementById("wlf:cmdBtn");
    }
    
    bQuickSearchSent = false;
    
    clickLink(ref.id);        
}

function resizeCompSB(isOAPMenuOpt){
    //var s= new Date().getTime();
    initMainContainer();    
    initFlexCombo(isOAPMenuOpt,250,false,false);
    initFlexMenu(isOAPMenuOpt); 
    //var e= new Date().getTime();
    //alert(e-s)    
}

function renderQListCss(queryId){
    queryId = (typeof queryId == 'undefined')? -1: queryId;
    var srcollql = document.getElementById("wlf:scrollQueryList");
    
    if(srcollql){     
        var childCount = srcollql.children.length-1;
        if(childCount > 0){
            for(var i=0; i<childCount; i++){                
                if((srcollql.children[i].getElementsByClassName("qIndex")[0].value-0) == queryId){
                    removeCSS(srcollql.children[i], "blackc");
                    removeCSS(srcollql.children[i], "tal");
                    addCSS(srcollql.children[i], "panelColor border1PanelClr font-bold tal");                    
                } else {
                    removeCSS(srcollql.children[i], "panelColor");                    
                    removeCSS(srcollql.children[i], "border1PanelClr");                    
                    removeCSS(srcollql.children[i], "font-bold");                    
                    removeCSS(srcollql.children[i], "tal");    
                    addCSS(srcollql.children[i], "blackc tal");                    
                }
            }
        }
    }
}

function sbqlhandler(mid,option,param){
    option = (typeof option == 'undefined')? '': option;
    param = (typeof param == 'undefined')? '': param;
    
    if(option == 'e'){
        var qryRef = document.getElementById("wlf:qryWrapper:"+mid+":qryId");
        if(qryRef){
            openAdvanceSearchPopup(qryRef,qryRef.value,param);
        }
        return false;
    } else {
        fetchWIBasedFromQueryListSB(mid);
    }
}                    

function initMainContainer(){    
    var sbcont = document.getElementById("wlf:sbcont");
        
    var nonQKSContW=0,qksContPM=0,sqContW=0,childRef=null,fitChildW=0,moptW = 0;;
    var childCount = sbcont.tBodies[0].rows[0].cells.length,pmdim=0;
    for(var i=0; i < childCount; i++){
        childRef = sbcont.tBodies[0].rows[0].cells[i].firstElementChild;
        
        if(i==0){
            pmdim = getRealDimension(childRef,true);
            qksContPM=pmdim.PH+pmdim.MH;
        } else if(i==(childCount-1)){
            var vChildW = 0;
            
            pmdim = getRealDimension(childRef,true);            
            vChildW=pmdim.PH+pmdim.MH;            
            
            var vChild = childRef.getElementsByClassName('v');
            if(vChild){                
                var firstEleTop = 0, nextEleTop = 0;
                for(var j=0; j < vChild.length; j++){
                    nextEleTop = findPosY(vChild[j]);
                    
                    if(j==0){
                        firstEleTop = nextEleTop;
                    }
                    
                    if(firstEleTop==nextEleTop){
                        fitChildW += getRealDimension(vChild[j],true).Width;   
                    }
                }   
                
                vChildW+=fitChildW;
            }
            
            sqContW+=vChildW;  
            
            var moptRef = document.getElementsByClassName('oa-fmenu-opt');
            if(moptRef && moptRef.length>0){
                moptRef = moptRef[0];
                moptW = getRealDimension(moptRef, true).Width;
            }

            sqContW+=moptW; 
            
            nonQKSContW += sqContW;
        } else {            
            if(childRef){
                nonQKSContW += getRealDimension(childRef,true).Width;
            }
        }
    }
    
    var advSW = 0;
    var advSWRef = document.getElementsByClassName('advs');
    if(advSWRef && advSWRef.length>0){
        advSWRef = advSWRef[0];
        advSW = getRealDimension(advSWRef, true).Width;
    }

    var advSIW = 0;
    var advSIWRef = document.getElementsByClassName('advsi');
    if(advSIWRef && advSIWRef.length>0){
        advSIWRef=advSIWRef[0];
        advSIW = getRealDimension(advSIWRef, true).Width;            
    }

    var availWidth = getRealDimension(window.frameElement).Width;
    var requiredWidth = getRealDimension(sbcont).Width;
           
    if(requiredWidth > availWidth){
        if(fitChildW>0){
            var actualReqW = requiredWidth - fitChildW; 
            var marginWrap = 3;
            actualReqW += moptW + marginWrap;            
            
            if(actualReqW > availWidth){
                advSWRef.style.display='none';
                advSIWRef.style.display='';
            } else {
                advSIWRef.style.display='none';    
                advSWRef.style.display='';  
            }
        } else {
            advSWRef.style.display='none';
            advSIWRef.style.display='';
        }
    } else {
        var recentSW = 0;
        var recentSRef = document.getElementsByClassName('rs');
        if(recentSRef && recentSRef.length>0){
            recentSW = getRealDimension(recentSRef[0], true).Width;
        }

        var qkGroupW = 0;
        var qkGroupRef = document.getElementsByClassName('oa-group');
        if(qkGroupRef){
            for(var i=0; i < qkGroupRef.length; i++){
                if(qkGroupRef[i].style.display != 'none'){
                    qkGroupW += getRealDimension(qkGroupRef[i],true).Width;
                }
            }
        }

        var tempQKSGroupW = qkGroupW+advSW;
        var tempQKSGroupIW = qkGroupW+advSIW;
        var fixedW = nonQKSContW+recentSW+qksContPM;        
        var actualAvailW=availWidth-fixedW;
    
        if(advSIWRef.style.display != 'none'){
            if(tempQKSGroupW < actualAvailW){
                advSIWRef.style.display='none';    
                advSWRef.style.display='';      
            } else if(fitChildW>0){
                advSIWRef.style.display='none';    
                advSWRef.style.display='';  
            }
        }        
    }
}

function resizeRSWorkList(isOAPMenuOpt){
    hideAllMenu();
    //var s= new Date().getTime();
//    initMainContainer();    
//    initFlexCombo(isOAPMenuOpt,250,false);
    initFlexMenu(isOAPMenuOpt, true); 
    //var e= new Date().getTime();
    //alert(e-s)    
}

function showWlistMenu(thisRef,tMenu){
    var menuHandler = thisRef;
    
    var tMenuRef = document.getElementById(tMenu);
    if(tMenuRef){
        var bVisible = (tMenuRef.style.display != "none");
        
        if(bVisible){
            tMenuRef.style.display="none";
        } else {
            var t=findPosY(menuHandler),l=findPosX(menuHandler);
            var rd = getRealDimension(menuHandler);
            
            menuHandler.setAttribute('mid',tMenuRef.id);
            if(menuHandler.parentNode){
                menuHandler.parentNode.setAttribute('mid',tMenuRef.id);
            }
            
            tMenuRef.style.display='block';
            
            
            t += rd.Height+1;   
                        
            tMenuRef.style.top=(t+1)+'px'; 
            tMenuRef.style.minWidth=rd.Width+'px';            
            
            var mrd = getRealDimension(tMenuRef);            
            tMenuRef.style.left=(l-mrd.Width+rd.Width)+'px';            
        }
    }
}

function wiocw(id){
    document.getElementById(id).children[0].click();
}

function clickNavCmdLinkWlist(linkId){      
    document.getElementById("wlf:queueProcessLoaded").value = "N";
    clickNavCmdLinkWrapper(linkId);
}

function reloadWlistWrapper(linkId){
    var bSearchCriteria = false;
    
    var ref = document.getElementById('wlf:hidCtrSrch');
    if(ref){
        if(ref.value == 'true'){
            bSearchCriteria = true;
        }
    }
    
    if(bSearchCriteria){
        clickLink("wlf:searchCriteria");
    } else {
        clickLink("wlf:lnkSortData");
    }
}

function refreshQueryListSB()
{
    clickLink("wlf:refreshQueryListSB");
}
function refreshQueryDivSB(data)
{
    if(data.status=='success')
        {
           initFlexMenu(true); 
        }
}