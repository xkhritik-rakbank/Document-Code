
function AddAudit(ref,userid,username)
{
    var procActidlist=getProcActList(ref);
   
    var url= "/webdesktop/components/usermgmt/addmodifyworkaudit.app?Action=1&Mode=A";

    var WindowHeight=380;
    var WindowWidth=ScreenWidth/2-50;
    
    var isChrome = window.chrome;
    if(typeof isChrome != 'undefined') {
        WindowHeight=WindowHeight+15;
        WindowWidth=WindowWidth+15;
    }
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);

    url = appendUrlSession(url);

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;

    var listParam=new Array();
  
    listParam.push(new Array("userid",encode_ParamValue(userid)));
    listParam.push(new Array("username",encode_ParamValue(username)));
    listParam.push(new Array("constraints",encode_ParamValue(procActidlist)));

    var win = openNewWindow(url,'workaudit_add'+userid,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}


function getProcActList(ref)
{
   //setworkaudit:blankPanel:bp:auditlist:0:processId
   //setworkaudit:blankPanel:bp:auditlist:2:activityId
    var tableid="setworkaudit:auditlist";
    var list='';
    try
    {
        var noofrows = document.getElementById(tableid).tBodies[0].rows.length;
        for (var i=0;i< noofrows ;i++)
        {
            var procid = tableid+':'+i+':processId';
            var actid = tableid+':'+i+':activityId';

            if(i!=0)
                list+=";";

            
            list+=MakeProcActList(document.getElementById(procid).value,document.getElementById(actid).value);

        }

        return list;
    }
    catch(e)
    {        
        return "";
    }

}

//to make the proc act list constraint
function MakeProcActList(procid,Actid)
{
    return procid+':'+Actid;
}



function ModifyAudit(ref,userid,username)
{
    var formid='setworkaudit';
    var index=GetSelected(ref);
    if(index < 0) //in case of invalid selection or multiple selection
      {
        return "";
      }
  
    var   procid=document.getElementById(  formid+':auditlist:'+index+':processId').value;
    var    actid=document.getElementById(   formid+':auditlist:'+index+':activityId').value;
    var procname=document.getElementById(formid+':auditlist:'+index+':processName').innerHTML.trimEx();
    var  actname=document.getElementById( formid+':auditlist:'+index+':activityName').innerHTML.trimEx();

    var  audname=document.getElementById( formid+':auditlist:'+index+':auditorName').innerHTML.trimEx();
    var    audid=document.getElementById(   formid+':auditlist:'+index+':auditorId').value;
    var   audper=document.getElementById(formid+':auditlist:'+index+':auditpercentage').innerHTML.trimEx();
    
    var url="/webdesktop/components/usermgmt/addmodifyworkaudit.app?Action=1&Mode=M";

    //alert(url);
    var WindowHeight=380;
    var WindowWidth=ScreenWidth/2-50;

    var isChrome = window.chrome;
    if(typeof isChrome != 'undefined') {
        WindowHeight=WindowHeight+15;
        WindowWidth=WindowWidth+15;
    }
    
    var WindowLeft=parseInt(ScreenWidth/2)-parseInt(WindowWidth/2);
    var WindowTop=parseInt(ScreenHeight/2)-parseInt(WindowHeight/2);
    url = appendUrlSession(url);

    var listParam=new Array();
    listParam.push(new Array("userid",encode_ParamValue(userid)));
    listParam.push(new Array("username",encode_ParamValue(username)));
    listParam.push(new Array("processname",encode_ParamValue(procname)));
    listParam.push(new Array("processid",encode_ParamValue(procid)));
    listParam.push(new Array("activityname",encode_ParamValue(actname)));
    listParam.push(new Array("activityid",encode_ParamValue(actid)));
    listParam.push(new Array("auditorid",encode_ParamValue(audid)));
    listParam.push(new Array("auditorname",encode_ParamValue(audname)));
    listParam.push(new Array("percentageaudit",encode_ParamValue(audper)));

    var wFeatures = 'height='+WindowHeight+',width='+WindowWidth+',resizable=1,status=1,titlebar=no,scrollbars=auto,top='+WindowTop+',left='+WindowLeft;

    var win = openNewWindow(url,'workaudit_mod'+userid,wFeatures, true,"Ext1","Ext2","Ext3","Ext4",listParam);
    try
    {
	addWindows(win);
    }
    catch(e)
    {}
}



function GetSelected(ref)
{  
    var formid='setworkaudit';
    var tableid=formid+':auditlist';
    try
    {
        var noofrows = document.getElementById(tableid).tBodies[0].rows.length;
        var flag=0;
        var iNum=0;
        var iSelIndex=-1;


        for (var i=0;i< noofrows ;i++)
        {
            var id=tableid+':'+i+':selectedAudit';
            var curElement=document.getElementById(id);
            if(curElement.checked)
              {
                iNum++ ;
                iSelIndex=i;
              }
        }

        if(iNum ==1)
            return iSelIndex;
        else
            {
                var messageWidth = 260;                    
                var left = (document.documentElement.clientWidth - messageWidth) / 2;
                if(iNum < 1){
                    //alert(INVALID_SELECTION_NONE);                    
                    notifierAbs('notifier', INVALID_SELECTION_NONE, "absolute", false, left, 35);    
                }
                else{
                    //alert(INVALID_SELECTION_MULTIPLE);                    
                    notifierAbs('notifier', INVALID_SELECTION_MULTIPLE, "absolute", false, left, 35);   
                }
                return -1;
            }
    }
    catch(e)
    {
        //alert(e);
        return -1;
    }

}



function EnableDisableWorkstep()
{
    if(document.getElementById('addmodifyworkaudit:hidprocessid').value > 0 )
    {
        document.getElementById('addmodifyworkaudit:activityPicklist').disabled=false;
    }
    else
    {
        document.getElementById('addmodifyworkaudit:activityPicklist').disabled=true;
    }
   
    document.getElementById('addmodifyworkaudit:hidactivityid').value='';
    document.getElementById('addmodifyworkaudit:hidactivityname').value='';
    document.getElementById('addmodifyworkaudit:activityName').value='';
     EnableDisableUserList();
}

function EnableDisableUserList(){
    if(document.getElementById('addmodifyworkaudit:hidprocessid').value > 0 )
    {
        document.getElementById('addmodifyworkaudit:userPicklist').disabled=false;
    }
    else
    {
        document.getElementById('addmodifyworkaudit:userPicklist').disabled=true;
    }
    document.getElementById('addmodifyworkaudit:hidauitorid').value='';
    document.getElementById('addmodifyworkaudit:hidauitorname').value='';
    document.getElementById('addmodifyworkaudit:auditorname').value='';
}