
var unlockflag="Y";//if unlockflag is Y then unlock workitem else donot call unlock on close;
var actionFlag="true";//TODO if actionflag is
var confirmSaveFlag=true;
var moreactionString="";
var strRemovefrommap="Y";//to remove workitem from map