var BOOTSTRAP_GRIDS = 12;
var CLIENT_COMPONENT_SPACING_WIDTH = 7;
var COMP_BORDER_WIDTH = 1;
var hPadding = (CLIENT_COMPONENT_SPACING_WIDTH - 2 * COMP_BORDER_WIDTH);
var vPadding = (CLIENT_COMPONENT_SPACING_WIDTH - 2 * COMP_BORDER_WIDTH);
var DESKTOP_DEVICE = 'd';
var MOBILE_DEVICE = 'm';
var lastIsMobileDevice = false;
var bscontid = 'bscont';
var bMobileDevice = isMobileDevice();
var EDIT_LAYOUT_GRID_WIDTH = 3;
// Allowed bootstrap breakpoints classes for mobile mode in Desktop
var MobileBPInDesktop = {
    'xs': true,
    'sm': true,
    'md': false,
    'lg': false,
    'xl': false
};
//Detect bootstrap breakpoints for edit layout edit layout
var DesktopELBP = {
    'xs': false,
    'sm': false,
    'md': false,
    'lg': true,
    'xl': true
};

var animationInProgress = false;
var animationStartCount = 0;
var animationFinishCount = 0;
var animDuration = 200;
var collapsedInterface = "";
var initialViewState = {
    LeftInterfaceWidth: 0,
    LeftInterfaceLeft: 0,
    LeftInterfaceTop: 0,
    LeftInterfaceClass: '',
    RightInterfaceWidth: 0,
    RightInterfaceLeft: 0,
    RightInterfaceTop: 0,
    RightInterfaceClass: ''
};
var bUpdateViewStateGlobal = true;

function renderRespWDesk() {
    //var s = new Date().getTime();

    var bscontref = document.getElementById(bscontid);

    //lastIsMobileDevice = getBSDeviceMode(); 

    // Initialize SIde Interfaces Tab panel and sidebars
    initWDeskPanels();

    // Initialize bootstrap for Workdesk Interfaces including both Desktop and Mobile/Merged layout
    initWDeskBaseLayout(bscontref);

    // Renders layout based on device type    
    initWDeskDeviceLayout();

    // Initialize Masonry layout
    initMasonryLayout(bscontid);

//var e = new Date().getTime();
//alert(e-s)
    //setInitialViewState(bscontref, true, false);
}

function initWDeskBasePanels() {
    // This function loads default configured/selected (If any) panel tab/interface on workdesk initialization

    var bDesktopInMobileMode = isDesktopInMobileMode();

    var lifmRef = document.getElementsByClassName('lsb-f');
    lifmRef = (lifmRef && lifmRef.length > 0) ? lifmRef[0] : null;

    var rifmRef = document.getElementsByClassName('rsb-f');
    rifmRef = (rifmRef && rifmRef.length > 0) ? rifmRef[0] : null;

    var isIEBrowser = window.navigator.userAgent.indexOf("MSIE ") > -1 || window.navigator.userAgent.indexOf("Trident/") > -1;
    if (isIEBrowser) {
        if (lifmRef && !hasCSS(lifmRef, "ie"))
            addCSS(lifmRef, "ie");
        if (rifmRef && !hasCSS(rifmRef, "ie"))
            addCSS(rifmRef, "ie");
    }
    //  Left Panel
    var lPanel = document.getElementsByClassName('lpanel');
    lPanel = (lPanel && lPanel.length > 0) ? lPanel[0] : null;

    //  Right Panel
    var rPanel = document.getElementsByClassName('rpanel');
    rPanel = (rPanel && rPanel.length > 0) ? rPanel[0] : null;

    var sbContRef = null, sbContSRef = null, overlay = 'true';

    if (lPanel != null && lPanel.children.length > 0) {
        if (!bDesktopInMobileMode) {
            removeCSS(lPanel, 'dn');
            addCSS(lPanel, 'df');

            sbContRef = document.getElementsByClassName('lsb');
            sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;
            if (sbContRef != null) {
                if (!sbContRef.Tabs) {
                    sbContRef.Tabs = {};
                }

                overlay = document.getElementById('lsbo').innerHTML.trimEx()
                if (overlay == 'true') {
                    addCSS(sbContRef.parentNode, 'overlay');
                    addCSS(sbContRef, 'overlay');
                    addCSS(sbContRef.nextElementSibling, 'overlay');
                } else {
                    removeCSS(sbContRef.parentNode, 'overlay');
                    removeCSS(sbContRef, 'overlay');
                    removeCSS(sbContRef.nextElementSibling, 'overlay');
                }

                //  Clicked Tab name on Left Panel
                var lSelPanelTab = '';
                if (sbContRef.SelPanelTabRef) {
                    lSelPanelTab = sbContRef.SelPanelTabRef.id;
                } else {
                    lSelPanelTab = document.getElementById('lselpn').innerHTML.trimEx();
                }

                //  Left sidebar in Expanded mode
                var lsbe = 'false';
                if (typeof sbContRef.Expanded != 'undefined') {
                    lsbe = sbContRef.Expanded;
                } else {
                    lsbe = document.getElementById('lsbe').innerHTML.trimEx();
                }

                if (lSelPanelTab != '' && lsbe == 'true') {
                    var lSelPanelTabRef = document.getElementById(lSelPanelTab);
                    selectPanelTab(lSelPanelTabRef);

                    removeCSS(sbContRef, 'dn');
                    addCSS(sbContRef, 'db');

                    sbContSRef = document.getElementsByClassName('lsb-s');
                    sbContSRef = (sbContSRef && sbContSRef.length > 0) ? sbContSRef[0] : null;
                    removeCSS(sbContSRef, 'dn');
                    addCSS(sbContSRef, 'db');

                    if (lifmRef && hasCSS(lifmRef, "ie")) {
                        removeCSS(lifmRef, 'dn');
                        addCSS(lifmRef, 'db');
                    }


                    // Left sidebar expanded and Panel tab selected            
                    sbContRef.SelPanelTabRef = lSelPanelTabRef;
                    sbContRef.Expanded = 'true';
                    lSelPanelTabRef.psb = sbContRef;
                    loadWdSidebarHandler(lSelPanelTab, sbContRef);
                }
                if (lifmRef && !hasCSS(lifmRef, "ie")) {
                    lifmRef.setAttribute("style", "display:none !important");
                }
            }
        } else {
            /*removeCSS(lPanel, 'df');
             addCSS(lPanel, 'dn');*/

            sbContRef = document.getElementsByClassName('lsb');
            sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;
            if (sbContRef != null) {
                removeCSS(sbContRef, 'db');
                addCSS(sbContRef, 'dn');
                deSelectPanelTab(sbContRef.SelPanelTabRef);

                sbContSRef = document.getElementsByClassName('lsb-s');
                sbContSRef = (sbContSRef && sbContSRef.length > 0) ? sbContSRef[0] : null;
                removeCSS(sbContSRef, 'db');
                addCSS(sbContSRef, 'dn');
                if (lifmRef) {
                    if (hasCSS(lifmRef, "ie")) {
                        removeCSS(lifmRef, 'db');
                        addCSS(lifmRef, 'dn');
                    } else {
                        lifmRef.setAttribute("style", "display:none !important");
                    }
                }
            }
        }
    }

    if (rPanel != null && rPanel.children.length > 0) {
        if (!bDesktopInMobileMode) {
            removeCSS(rPanel, 'dn');
            addCSS(rPanel, 'df');

            sbContRef = document.getElementsByClassName('rsb');
            sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;
            if (sbContRef != null) {
                if (!sbContRef.Tabs) {
                    sbContRef.Tabs = {};
                }

                overlay = document.getElementById('rsbo').innerHTML.trimEx()
                if (overlay == 'true') {
                    addCSS(sbContRef.parentNode, 'overlay');
                    addCSS(sbContRef, 'overlay');
                    addCSS(sbContRef.nextElementSibling, 'overlay');
                } else {
                    removeCSS(sbContRef.parentNode, 'overlay');
                    removeCSS(sbContRef, 'overlay');
                    removeCSS(sbContRef.nextElementSibling, 'overlay');
                }

                //  Clicked Tab name on Right Panel

                var rSelPanelTab = '';
                if (sbContRef.SelPanelTabRef) {
                    rSelPanelTab = sbContRef.SelPanelTabRef.id;
                } else {
                    rSelPanelTab = document.getElementById('rselpn').innerHTML.trimEx();
                }

                //  Right sidebar in Expanded mode
                var rsbe = 'false';
                if (typeof sbContRef.Expanded != 'undefined') {
                    rsbe = sbContRef.Expanded;
                } else {
                    rsbe = document.getElementById('rsbe').innerHTML.trimEx();
                }

                if (rSelPanelTab != '' && rsbe == 'true') {
                    var rSelPanelTabRef = document.getElementById(rSelPanelTab);
                    selectPanelTab(rSelPanelTabRef);

                    removeCSS(sbContRef, 'dn');
                    addCSS(sbContRef, 'db');

                    sbContSRef = document.getElementsByClassName('rsb-s');
                    sbContSRef = (sbContSRef && sbContSRef.length > 0) ? sbContSRef[0] : null;
                    removeCSS(sbContSRef, 'dn');
                    addCSS(sbContSRef, 'db');

                    if (rifmRef && hasCSS(rifmRef, "ie")) {
                        removeCSS(rifmRef, 'dn');
                        addCSS(rifmRef, 'db');
                    }

                    // Right sidebar expanded and Panel tab selected        
                    sbContRef.SelPanelTabRef = rSelPanelTabRef;
                    sbContRef.Expanded = 'true';
                    rSelPanelTabRef.psb = sbContRef;
                    loadWdSidebarHandler(rSelPanelTab, sbContRef);
                }
                if (rifmRef && !hasCSS(rifmRef, "ie")) {
                    rifmRef.setAttribute("style", "display:none !important");
                }
            }
        } else {
            /*removeCSS(rPanel, 'df');
             addCSS(rPanel, 'dn');*/

            sbContRef = document.getElementsByClassName('rsb');
            sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;
            if (sbContRef != null) {
                removeCSS(sbContRef, 'db');
                addCSS(sbContRef, 'dn');
                deSelectPanelTab(sbContRef.SelPanelTabRef);

                sbContSRef = document.getElementsByClassName('rsb-s');
                sbContSRef = (sbContSRef && sbContSRef.length > 0) ? sbContSRef[0] : null;
                removeCSS(sbContSRef, 'db');
                addCSS(sbContSRef, 'dn');
                if (rifmRef) {
                    if (hasCSS(rifmRef, "ie")) {
                        removeCSS(rifmRef, 'db');
                        addCSS(rifmRef, 'dn');
                    } else {
                        rifmRef.setAttribute("style", "display:none !important");
                    }
                }
            }
        }
    }
}

var customWidth = "";
function wdPanelTabClickHandler(thisRef, fSbContId, sSbContId, event) {
    // Panel's Tab click handler

    var sbContRef = document.getElementsByClassName(fSbContId);
    sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;

    var sSbContRef = document.getElementsByClassName(sSbContId);
    sSbContRef = (sSbContRef && sSbContRef.length > 0) ? sSbContRef[0] : null;
    if (editlayout == 'Y') {
        renderEditLayout();
        cancelSaveRespLayout();
    }
    
    if(leftSidebarOverlay == 'false' || rightSidebarOverlay == 'false') {
        repositionCollapsedInterface();
    } else {
        bUpdateViewStateGlobal = false;
    }
    
    enableCustomWDSideBarWidth = typeof enableCustomWDSideBarWidth == 'undefined' ? false :enableCustomWDSideBarWidth;
    
    if (sbContRef != null && sSbContRef != null) {
        var hasIECls = hasCSS(sbContRef.nextElementSibling.nextElementSibling, "ie");
        var sSbhasIECls = hasCSS(sSbContRef.nextElementSibling.nextElementSibling, "ie");
        var selPanelTab = thisRef.id;
        sbContRef.SelPanelTabRef = (typeof sbContRef.SelPanelTabRef == 'undefined') ? null : sbContRef.SelPanelTabRef;

        // Setting reference of parent sidebar
        thisRef.psb = sbContRef;

        deSelectPanelTab(sbContRef.SelPanelTabRef);

        var overlaycs = ''
        var bDesktopInMobileMode = isDesktopInMobileMode();

        if ((sbContRef.SelPanelTabRef != null) && (sbContRef.SelPanelTabRef.id == selPanelTab)) {
            // If same Panel Tab clicked again
            if (hasCSS(sbContRef, 'db')) {
                removeCSS(sbContRef, 'db');
                removeCSS(sbContRef.nextElementSibling, 'db');
                addCSS(sbContRef, 'dn');
                addCSS(sbContRef.nextElementSibling, 'dn');
                if (hasIECls) {
                    removeCSS(sbContRef.nextElementSibling.nextElementSibling, 'db');
                    addCSS(sbContRef.nextElementSibling.nextElementSibling, 'dn');
                }

                sbContRef.Expanded = 'false';

                updateMasonryLayout();
                return;
            } else {
                removeCSS(sbContRef, 'dn');
                removeCSS(sbContRef.nextElementSibling, 'dn');
                if (hasIECls)
                    removeCSS(sbContRef.nextElementSibling.nextElementSibling, 'dn');

                if (bDesktopInMobileMode) {
                    overlaycs = ' overlay';

                    removeCSS(sSbContRef, 'db');
                    removeCSS(sSbContRef.nextElementSibling, 'db');

                    addCSS(sSbContRef, 'dn');
                    addCSS(sSbContRef.nextElementSibling, 'dn');

                    if (sSbhasIECls) {
                        removeCSS(sSbContRef.nextElementSibling.nextElementSibling, 'db');
                        addCSS(sSbContRef.nextElementSibling.nextElementSibling, 'dn');
                    }
                    deSelectPanelTab(sSbContRef.SelPanelTabRef);
                    sSbContRef.Expanded = 'false';
                }
                addCSS(sbContRef.parentNode, overlaycs);
                addCSS(sbContRef, 'db' + overlaycs);
                addCSS(sbContRef.nextElementSibling, 'db' + overlaycs);
                if (hasIECls)
                    addCSS(sbContRef.nextElementSibling.nextElementSibling, 'db' + overlaycs);
                
                if (typeof getCustomWDSideBarWidth != 'undefined' && enableCustomWDSideBarWidth){
                    customWidth = getCustomWDSideBarWidth(selPanelTab);
                    updateWDSideBarWidth(sbContRef, customWidth);
                }
            }
        } else {
            removeCSS(sbContRef, 'dn');
            removeCSS(sbContRef.nextElementSibling, 'dn');
            if (hasIECls)
                removeCSS(sbContRef.nextElementSibling.nextElementSibling, 'dn');

            if (bDesktopInMobileMode) {
                overlaycs = ' overlay';

                removeCSS(sSbContRef, 'db');
                removeCSS(sSbContRef.nextElementSibling, 'db');

                addCSS(sSbContRef, 'dn');
                addCSS(sSbContRef.nextElementSibling, 'dn');

                if (sSbhasIECls) {
                    removeCSS(sSbContRef.nextElementSibling.nextElementSibling, 'db');
                    addCSS(sSbContRef.nextElementSibling.nextElementSibling, 'dn');
                }
                deSelectPanelTab(sSbContRef.SelPanelTabRef);
                sSbContRef.Expanded = 'false';
            }

            addCSS(sbContRef.parentNode, overlaycs);
            addCSS(sbContRef, 'db' + overlaycs);
            addCSS(sbContRef.nextElementSibling, 'db' + overlaycs);
            if (hasIECls)
                addCSS(sbContRef.nextElementSibling.nextElementSibling, 'db' + overlaycs);
            
            if (typeof getCustomWDSideBarWidth != 'undefined' && enableCustomWDSideBarWidth){
                customWidth = getCustomWDSideBarWidth(selPanelTab);
                updateWDSideBarWidth(sbContRef, customWidth);
            }
            
            sbContRef.SelPanelTabRef = thisRef;
            loadWdSidebarHandler(selPanelTab, sbContRef);
        }

        sbContRef.Expanded = 'true';
        selectPanelTab(thisRef);
    }

    updateMasonryLayout();
    cancelBubble(event);
}

function loadWdSidebarHandler(selPanelTab, sbContRef) {
    sbContRef.Tabs[selPanelTab] = (typeof sbContRef.Tabs[selPanelTab] == 'undefined') ? false : sbContRef.Tabs[selPanelTab];

    if (!bMobileDevice) {
        hideSBInterfaces(sbContRef);
    }

    if (!sbContRef.Tabs[selPanelTab]) {
        loadWdSidebar(selPanelTab, sbContRef);
    } else {
        showSBInterface(sbContRef, selPanelTab);
    }
}

/*  loadWdSidebar('Documents', contRef);
 loadWdSidebar('Documents', contRef, null, 'Action=2&Batch=5');
 loadWdSidebar('Documents', contRef, null, 'Action=2&Batch=5', 'scrollDiv'); // Loading only sub section i.e scrollDiv
 loadWdSidebar('Documents', contRef, 'customdoclist.app', 'Action=2&Batch=5');
 loadWdSidebar('Documents', contRef, 'customdoclist.app');
 */
function loadWdSidebar(selPanelTab, contRef, url, extParams, subSection, callBackFunction, fromOp) {
    url = (typeof url == 'undefined') ? null : url;
    extParams = (typeof extParams == 'undefined' || extParams == null) ? '' : extParams;
    subSection = (typeof subSection == 'undefined' || subSection == null) ? '' : subSection;
    callBackFunction = (typeof callBackFunction == 'undefined' || callBackFunction == null) ? '' : callBackFunction;
	fromOp = (typeof fromOp == 'undefined' || fromOp == null)? '': fromOp;
	
    var action = '';
    var isDefaultDoc = "";
    var isDefaultDocType = "";

    var docDirection = document.dir;
    /*if (docDirection != 'undefined' && docDirection.toString().toLowerCase() == 'rtl') {
        if (hasCSS(contRef, "lsb")) {
            removeCSS(contRef, "lsb");
            addCSS(contRef, "rsb");
        }
    }*/

    var PSide = (contRef) ? (hasCSS(contRef, "lsb") ? 'L' : 'R') : '';

    var requestString = "PSide=" + PSide + "&Panel=Y";

    var window_workdesk = "";
    if (windowProperty.winloc == "M")
        window_workdesk = window;
    else
        window_workdesk = window.opener;

    if (extParams != '') {
        requestString += '&' + extParams;
    }

    var wdJason = (newWDJason != null) ? newWDJason : oldWDJason;

    if (selPanelTab == 'Documents') {
        isDefaultDoc = document.getElementById('IsDefaultDoc').value;

        if (document.getElementById('IsDefaultDocType') != null) {
            isDefaultDocType = document.getElementById('IsDefaultDocType').value;
        }

        requestString += "&IsDefaultDoc=" + isDefaultDoc + "&IsDefaultDocType=" + isDefaultDocType;
		if(fromOp=="new" || fromOp=="addFromOD" || fromOp=="getdocument" || fromOp=="deletedoc"){
			clickLink('Documents');
        }
    } else if (selPanelTab == 'Info') {
        requestString += "&ProcessInstanceID=" + encode_utf8(wdJason.PId) + "&WorkitemID=" + encode_utf8(wdJason.WId) + "&URN=" + encode_utf8(strURN) + "&TaskID=" + encode_utf8(wdJason.taskid) + "&ProcessDefID=" + encode_utf8(wdJason.RouteId) + "&ActivityId=" + encode_utf8(wdJason.ActivityId) + "&ActivityName=" + encode_utf8(wdJason.ActivityName) + "&ProcessName=" + encode_utf8(wdJason.ProcessName)
    } else if (selPanelTab == 'Tasks' || selPanelTab == 'Progress') {
        requestString += "&Comp_height=" + getPanelHeight(PSide) + "&Comp_width=" + getPanelWidth(PSide);
    }

    action = getInterfaceId(selPanelTab);

    if (url == null) {
        url = getInterfaceUrl(selPanelTab);
    }

    if (url == '') {
        return;
    }

    var wdViewMode = document.getElementById('wdView').value;
    requestString += "&pid=" + encodeURIComponent(pid) + "&wid=" + encode_utf8(wid) + "&taskid=" + encode_utf8(taskid) + "&Action=" + action + "&vwsrc=nav&wdViewmode=" + wdViewMode + "&WD_SID=" + WD_SID;

    var contentLoaderRef = ContentLoaderWrapper(url, loadWdSidebarListner, loadWdSidebarError, "POST", requestString, true);

    function loadWdSidebarListner() {
        var respText = contentLoaderRef.req.responseText;
        var tempRef;
        var intContRef = getIntContRef(contRef, selPanelTab, subSection);

        if (selPanelTab == 'Documents') {
            respText = respText.substring(respText.indexOf('<doccontainer>') + 14, respText.lastIndexOf('</doccontainer>'));
            intContRef.innerHTML = respText;
            tempRef = document.getElementById('DocumentsDiv');
            if (tempRef)
                tempRef.setAttribute("style", "overflow:hidden !important");
            tempRef = document.getElementById('wdesk:scrolldocdiv');
            if (tempRef && !bMobileDevice) {
                tempRef.style.height = (getPanelHeight(PSide, true) - findAbsPosY(tempRef) + 10) + 'px';
            }
            if (typeof documentListWinHook != 'undefined')
                documentListWinHook(strprocessname, stractivityName, strQueueName, strqueueID);
            if(fromOp=="new" || fromOp=="addFromOD" || fromOp=="getdocument" || fromOp=="deletedoc" || fromOp=="ChkIn" || fromOp=="CheckOut"){
                if(typeof keepDocListSideBarOpen != 'undefined' && !keepDocListSideBarOpen(strprocessname, stractivityName, pid, wid, taskid, fromOp)){
                    clickLink('Documents');
                }
            }
        } else if (selPanelTab == 'Exceptions') {
            respText = respText.substring(respText.indexOf('<expcontainer>') + 14, respText.lastIndexOf('</expcontainer>'));

            intContRef.innerHTML = respText;

            addWindowToParent(windowList, 'exceptionGrid');

            InitHWExp();     //RESP-TBC

        } else if (selPanelTab == 'ToDoList') {
            respText = respText.substring(respText.indexOf('<todocontainer>') + 15, respText.lastIndexOf('</todocontainer>'));

            intContRef.innerHTML = respText;

            addWindowToParent(windowList, 'todoGrid');

            //InitHWTodoNew();  //RESP-TBC


        } else if (selPanelTab == 'Info') {
            intContRef.innerHTML = respText;

        } else if (selPanelTab == 'Progress') {
            intContRef.innerHTML = respText;

        } else if (selPanelTab == 'Tasks') {
            intContRef.innerHTML = respText;
            tempRef = document.getElementById('TasksDiv');
            var ref = document.getElementById('tabsPG');
            if (ref && tempRef)
                tempRef.style.paddingBottom = (getRealDimension(ref).Height + 2) + "px";
            else if (tempRef)
                tempRef.style.paddingBottom = "27px";
        }

        callIntfcPostHook(selPanelTab);
        if (!bMobileDevice) {
            contRef.Tabs[selPanelTab] = true;
            showSBInterface(contRef, selPanelTab);
        }

        if (callBackFunction != undefined && callBackFunction.length > 0) {
            try {
                parseJSON(callBackFunction);
            } catch (e) {
            }
		}
		  try {
            if (typeof isEnableDownloadPrint != 'undefined' && isEnableDownloadPrint(strprocessname, stractivityName, userName)) {
                var len = document.getElementById("wdesk:pdlist").rows.length;
                for (var i = 0; i < len; i++) {
                    document.getElementById("wdesk:pdlist:" + i + ":dldpg").style.display = "block";
                }
            }
        } catch (e) {
            console.log(e);				   
        }
    }
    function callIntfcPostHook(op) {
        if (typeof interfacePostHook != 'undefined') {
            switch (op) {
                case 'Documents':
                    interfacePostHook('documents');
                    break;
                case 'Exceptions':
                    interfacePostHook('exp');
                    break;
                case 'Tasks':
                    interfacePostHook('tasks');
                    break;
                case 'Progress':
                    interfacePostHook('progress');
                    break;
                case 'Info':
                    interfacePostHook('info');
                    break;
                case 'ToDoList':
                    interfacePostHook('todo');
                    break;
                default:
                    interfacePostHook('');
            }
        }
    }
    function loadWdSidebarError() {
        if (this.req.status == 250) {
            window.location = "/webdesktop/error/errorpage.app?msgID=-8002&HeadingID=8002";
        } else if (this.req.status == 310)
        {
            window.location = "/webdesktop/error/errorpage.app?msgID=-8003&HeadingID=8003";
        } else if (this.req.status == 350) {
            window.parent.parent.initPopUp();
            window.parent.parent.setPopupMask();
            window.parent.parent.createPopUpIFrameWrapper('genericErrorIframe', '/omniapp/pages/error/genericerror.app?msgID=4021&HeadingID=ERROR&Message=' + INVALID_REQUEST_IS_MADE, 140, 435);
            var screenHeight = window.screen.height;
            window.parent.parent.document.getElementById('genericErrorIframe').style.top = screenHeight / 6 + "px";
            window.parent.parent.document.getElementById('genericErrorIframe').style.zIndex = 300;
        }
    }
}

function hideSBInterfaces(sbContRef) {
    // Shows all Interface/Tab in the Sidebar

    var childNode = null;
    for (var i = 0; i < sbContRef.childNodes.length; i++) {
        childNode = sbContRef.childNodes[i];
        removeCSS(childNode, 'db');
        addCSS(childNode, 'dn');
    }
}

function getInterfaceId(selPanelTab, prefix) {
    prefix = (typeof prefix == 'undefined') ? '' : prefix;

    var intId = '';

    if (selPanelTab == 'FormView') {
        intId = 'form';
    } else if (selPanelTab == 'Document') {
        intId = 'doc';
    } else if (selPanelTab == 'Exceptions') {
        intId = 'exp';
    } else if (selPanelTab == 'ToDoList') {
        intId = 'todo';
    } else if (selPanelTab == 'Documents') {
        intId = 'paneldoclist';
    } else if (selPanelTab == 'Tasks') {
        intId = 'paneltasks';
    } else if (selPanelTab == 'Progress') {
        intId = 'panelprogress';
    } else if (selPanelTab == 'TaskView') {
        intId = 'task';
    } else if (selPanelTab == 'CaseView') {
        intId = 'form';
    } else {
        intId = selPanelTab;
    }

    intId = prefix + intId;

    return intId;
}

function getInterfaceUrl(interfaceName) {
    var url = '';

    if (interfaceName == 'FormView') {
        url = '/webdesktop/components/workitem/view/form_main_view.app';
    } else if (interfaceName == 'Document') {
        url = '/webdesktop/components/workitem/view/doc_main_view.app';
    } else if (interfaceName == 'Exceptions') {
        url = '/webdesktop/components/workitem/view/exp_main_view.app';
    } else if (interfaceName == 'ToDoList') {
        url = '/webdesktop/components/workitem/view/todo_main_view.app';
    } else if (interfaceName == 'Documents') {
        url = '/webdesktop/components/workitem/view/paneldoc_main_view.app';
    } else if (interfaceName == 'Info') {
        url = '/webdesktop/components/workitem/view/casedetails.app';
    } else if (interfaceName == 'Tasks') {
        url = '/webdesktop/components/task/tasks.app';
    } else if (interfaceName == 'Progress') {
        url = '/webdesktop/components/task/progress.app';
    } else if (interfaceName == 'CaseView') {
        url = '/webdesktop/components/workitem/view/form_main_view.app';
    }

    return url;
}

function showSBInterface(sbContRef, selPanelTab) {
    // Shows selected Interface/Tab in the Sidebar
    var intContRef = getIntContRef(sbContRef, selPanelTab);
    if (intContRef != null) {
        removeCSS(intContRef, 'dn');
        addCSS(intContRef, 'db');
    }
}

function deSelectPanelTab(panelTabRef) {
    if (panelTabRef != null) {
        removeCSS(panelTabRef, 'ptab-sel');
        removeCSS(panelTabRef.firstElementChild, 'ptab-sel');
    }
}

function selectPanelTab(panelTabRef) {
    if (panelTabRef != null) {
        addCSS(panelTabRef, 'ptab-sel');
        addCSS(panelTabRef.firstElementChild, 'ptab-sel');
    }
}

function initWDeskBaseLayout(bscontref) {
    var wdeskltdata = document.getElementById('wdeskltdata').innerHTML.trimEx();
    var respHTMLObj = getWDeskRespBaseHTML(wdeskltdata);
    bscontref.appendChild(respHTMLObj);

    initWDeskRespStruct(bscontref);
}

function initWDeskRespStruct(bscontref) {
    initWDeskBaseStruct(bscontref);

    if (bMobileDevice) {
        initWDeskMergedStruct(bscontref);
    }
}

function initWDeskBaseStruct(bscontref) {
    var respContainer = bscontref.firstElementChild;
    var gridWrapper = document.getElementById('bsgridcont');
    if (gridWrapper) {
        gridWrapper = null;
    }
    var respprefcolspanList = [leftIntPrefClass, rightIntPrefClass];
    respContainer.setAttribute("id", "bsrespcont");
    respContainer.setAttribute("class", "container-fluid bs-plr-0");

    // Desktop layout container
    var dRowWrapper = respContainer.firstElementChild;
    dRowWrapper.setAttribute("id", "rowd");
    dRowWrapper.setAttribute("class", "row");

    if (!bMobileDevice) {
        removeCSS(dRowWrapper, 'dn');
        addCSS(dRowWrapper, 'db');
    } else {
        removeCSS(dRowWrapper, 'db');
        addCSS(dRowWrapper, 'dn');
    }

    // Responsive Workdesk Layout data. Stores reference of Interface containers/Div
    bscontref.WDeskRespBaseInfo = {
        InterfacesCont: [],
        CellMatrix: {}
    };

    //var s=new Date().getTime();
    var sld = null;
    var verPadding = 0, currentChild = null, rowHeight = 0, slider = null, colIndex = 0, siblingColIndex = 0, sliderCellIndex = 0, siblingRowSpan, siblingRef, row = 0, rspClassInfo, currentChildWrapper = null, colCtr = 0, columns = respWDeskColumns - 0, colspan = 1, pColSpan = 0, fColSpan = 0, rowSpan = 1;
    for (var i = 0; i < dRowWrapper.childNodes.length; i++) {
        currentChildWrapper = dRowWrapper.childNodes[i];
        currentChild = currentChildWrapper.firstElementChild;

        if (i < BOOTSTRAP_GRIDS) {
            // Dummy row for Actual no of columns information            
            currentChildWrapper.className = getRSPClass(0, 0).Class;
            verPadding = 0;
            //currentChild.className += "cs crad";                
        } else {
            initInterfaceTabs(bscontref, currentChild);

            rowSpan = currentChild.getAttribute('rowspan') - 0;
            colspan = currentChild.getAttribute('colspan') - 0;
            pColSpan = currentChild.getAttribute('pColSpan') - 0;
            fColSpan = currentChild.getAttribute('fColSpan') - 0;

            var respprefcolspan = '';
            if (bTwoColLayout && isDesktopBPforEL() && !bMobileDevice) {
                respprefcolspan = respprefcolspanList[i - BOOTSTRAP_GRIDS];
            }
            rspClassInfo = getRSPClass(colspan, rowSpan, dRowWrapper.getAttribute("rows") - 0, colCtr + pColSpan, respprefcolspan);
            currentChildWrapper.className = rspClassInfo.Class;

            sliderCellIndex = colCtr + pColSpan + (colspan - 1);

            colCtr += colspan + pColSpan + fColSpan;
            colCtr = colCtr % (columns);
            currentChild.className += "cs crad";

            // Slider support
            sld = prepareSlider(currentChildWrapper, colCtr, bscontref, sliderCellIndex, rowSpan, row, rspClassInfo);
            if (sld) {
                gridWrapper = document.getElementById('bsgridcont');
                initBSGridLines(sld, bscontref, gridWrapper);
            }


            if (colCtr == 0) {
                row++;
            }

            verPadding = vPadding;
        }

        if (pageDirection == "ltr") {
            currentChildWrapper.setAttribute("style", "padding-right:" + hPadding + "px !important;padding-bottom:" + verPadding + "px !important;padding-top:0px !important");
        } else {
            currentChildWrapper.setAttribute("style", "padding-left:" + hPadding + "px !important;padding-bottom:" + verPadding + "px !important;padding-top:0px !important");
        }

        /*if(i < BOOTSTRAP_GRIDS){
         currentChildWrapper.style.border = "1px solid black";
         currentChildWrapper.style.height = "1px";
         }*/
    }
    sld = (typeof sld == 'undefined') ? document.getElementById('ws-slider') : sld;
    if (sld != null){
        respInterfaceInfo = {
            leftRefClass: sld.LIR.className,
            rightRefClass: sld.RIR.className,
            leftRefNewClass: '',
            rightRefNewClass: ''
        };
    }

    /*var e=new Date().getTime();
     alert(e-s)*/
}
var respInterfaceInfo = null;

function initBSGridLines(slider, bscontref, gridWrapper) {
    if (!gridWrapper) {
        gridWrapper = document.createElement('div');
        gridWrapper.id = "bsgridcont";
        gridWrapper.MSR = slider;
        gridWrapper.style.height = slider.style.height;
        gridWrapper.style.backgroundColor = "rgba(243, 243, 243, 0.7)";
        addCSS(gridWrapper, 'dn');
        bscontref.appendChild(gridWrapper);
    }
    if (gridWrapper) {
        var temp;
        var w = getRealDimension(bscontref).Width;
        var gridWidth = (w - (2 * CLIENT_COMPONENT_SPACING_WIDTH)) / 12;
        var leftFactor = gridWidth;
        for (var i = 1; i <= 12; i++) {
            temp = document.getElementById('sld-line-' + i);
            if (!temp) {
                temp = document.createElement('div');
                temp.LBSC = "col-lg-" + i + " col-xl-" + i; // Left Interface's Bootstrap Class
                temp.RBSC = "col-lg-" + (12 - i) + " col-xl-" + (12 - i); // Right Interface's Bootstrap Class
                temp.MSR = slider;// Main Slider Reference

                temp.style.height = slider.style.height;
                temp.id = 'sld-line-' + i;
                temp.style.top = "0px";
                temp.style.zIndex = (12 - i);
                temp.style.position = "absolute";
                temp.style.width = (leftFactor) + 'px';
                if(i<12){
                    if(pageDirection == "ltr")
                    temp.style.borderRight=(EDIT_LAYOUT_GRID_WIDTH) + "px dashed #4ca5b1";
                    else
                    temp.style.borderLeft=(EDIT_LAYOUT_GRID_WIDTH) + "px dashed #4ca5b1";    
                }
                leftFactor += gridWidth;
                if (i < 12) {
                    temp.onmouseover = function(event) {
                        if (this.MSR.MSS == 1) {
                            this.MSR.LGLR = this;
                            repositionMainSlider(this, this.MSR, event);
                        }
                    };
                }

                temp.onmouseout = function(event) {
                    //this.MSR.LGLR=this;
                };

                temp.onmousedown = function(e) {
                    if (this.MSR) {
                        this.MSR.MSS = 0;
                    }
                }

                temp.onmouseup = function(e) {
                    if (this.MSR.MSS == 1) {
                        if (this.MSR.LGLR != null) {
                            updateInterfaceLayout(this.MSR);
                        }

                        this.MSR.LGLR = null;
                    }
                    this.MSR.MSS = 0;
                    cancelBubble(e);
                }
                temp.onmousemove = function(e) {
                    if (this.MSR.MSS == 1) {
                        this.style.cursor = "ew-resize";
                    } else {
                        this.style.cursor = "auto";
                    }
                }

                gridWrapper.appendChild(temp);
            } else {
                temp.style.width = (leftFactor) + 'px';
                leftFactor += gridWidth;
            }
        }
    }
}
function repositionMainSlider(gridlineRef, mainSliderRef) {
    mainSliderRef.style.left = (gridlineRef.style.width.split('p')[0] - EDIT_LAYOUT_GRID_WIDTH) + 'px';
}
function updateInterfaceLayout(mainSliderRef){
    if (pageDirection == "ltr") {
        removeRespCSS(mainSliderRef.LIR, ['col-lg', 'col-xl']);
        addCSS(mainSliderRef.LIR, mainSliderRef.LGLR.LBSC);
        removeRespCSS(mainSliderRef.RIR, ['col-lg', 'col-xl']);
        addCSS(mainSliderRef.RIR, mainSliderRef.LGLR.RBSC);
    } else {
        removeRespCSS(mainSliderRef.RIR, ['col-lg', 'col-xl']);
        addCSS(mainSliderRef.RIR, mainSliderRef.LGLR.LBSC);
        removeRespCSS(mainSliderRef.LIR, ['col-lg', 'col-xl']);
        addCSS(mainSliderRef.LIR, mainSliderRef.LGLR.RBSC);
    }
    respInterfaceInfo.leftRefNewClass = mainSliderRef.LIR.className;
    respInterfaceInfo.rightRefNewClass = mainSliderRef.RIR.className;
    updateMasonryLayout();
}
function prepareSlider(currentChildWrapper, colCtr, bscontref, sliderCellIndex, rowSpan, row, rspClassInfo) {
    var siblingRef, siblingColIndex, slider, siblingRowSpan;
    var currentChild = currentChildWrapper.firstElementChild;
    var fColSpan = currentChild.getAttribute('fColSpan') - 0;
    if ((colCtr != 0) || (fColSpan > 0)) {
        siblingRef = currentChildWrapper.nextElementSibling && currentChildWrapper.nextElementSibling.firstElementChild;
        if (siblingRef) {
            siblingColIndex = siblingRef.getAttribute('colIndex') - 0;
        }

        if (siblingRef && (sliderCellIndex == (siblingColIndex - 1))) {
            siblingRowSpan = siblingRef.getAttribute('rowspan') - 0;
            slider = bscontref.WDeskRespBaseInfo.CellMatrix[sliderCellIndex];

            if (slider) {
                if ((row - slider.ERI) <= 1) {
                    if (rowSpan > siblingRowSpan) {
                        slider.style.height = getCompHeight(tableObject.rows, slider.SRI + 1, row + rowSpan - (slider.SRI)) + 'px';
                        slider.ERI = row + rowSpan - 1;
                    } else {
                        slider.style.height = getCompHeight(tableObject.rows, slider.SRI + 1, row + siblingRowSpan - (slider.SRI)) + 'px';
                        slider.ERI = row + siblingRowSpan - 1;
                    }
                } else {
                    // If found but not vertically sequential
                    //##arjun-to-do-lir and rir passing
                    slider = addBSSlider(currentChild, row, rowSpan, rspClassInfo.ColSpan, currentChild.parentNode, currentChild.parentNode.nextElementSibling);
                    addCSS(slider, "dn");

                    if (rowSpan > siblingRowSpan) {
                        slider.style.height = getCompHeight(tableObject.rows, slider.SRI + 1, rowSpan) + 'px';
                    } else {
                        slider.style.height = getCompHeight(tableObject.rows, slider.SRI + 1, siblingRowSpan) + 'px';
                    }

                    bscontref.WDeskRespBaseInfo.CellMatrix[sliderCellIndex] = slider;
                }
            } else {
                //##arjun-to-do-lir and rir passing
                slider = addBSSlider(currentChild, row, rowSpan, rspClassInfo.ColSpan, currentChild.parentNode, currentChild.parentNode.nextElementSibling);
                addCSS(slider, "dn");
                if (rowSpan > siblingRowSpan) {
                    slider.style.height = getCompHeight(tableObject.rows, slider.SRI + 1, rowSpan) + 'px';
                } else {
                    slider.style.height = getCompHeight(tableObject.rows, slider.SRI + 1, siblingRowSpan) + 'px';
                }

                bscontref.WDeskRespBaseInfo.CellMatrix[sliderCellIndex] = slider;
            }
        } else {
            slider = bscontref.WDeskRespBaseInfo.CellMatrix[sliderCellIndex];
            addCSS(slider, "dn");
            if (slider) {
                if ((row - slider.ERI) <= 1) {
                    slider.style.height = getCompHeight(tableObject.rows, slider.SRI + 1, row + rowSpan - (slider.SRI)) + 'px';
                    slider.ERI = row + rowSpan - 1;
                }
            }
        }
    }
    return slider;
}
function initWDeskMergedStruct(bscontref) {
    var respContainer = bscontref.firstElementChild;

    // Mobile/Merged layout container    
    var mRowWrapper = document.createElement('div');
    mRowWrapper.setAttribute("id", "rowm");
    mRowWrapper.setAttribute("rows", "1");
    mRowWrapper.setAttribute("class", "row");
    respContainer.appendChild(mRowWrapper);

    if (!bMobileDevice) {
        removeCSS(mRowWrapper, 'dn');
        addCSS(mRowWrapper, 'db');
    } else {
        removeCSS(mRowWrapper, 'db');
        addCSS(mRowWrapper, 'dn');
    }

    var columns = OAPRSPMap.length;

    var mRowWrapperBtChild = document.createElement('div');
    mRowWrapperBtChild.className = getRSPClass(columns, 1, 1, 0).Class + ' rowm';
    mRowWrapper.appendChild(mRowWrapperBtChild);

    if (pageDirection == "ltr") {
        mRowWrapperBtChild.setAttribute("style", "padding-right:" + hPadding + "px !important;padding-top:0px !important");
    } else {
        mRowWrapperBtChild.setAttribute("style", "padding-left:" + hPadding + "px !important;padding-top:0px !important");
    }

    var mInterfaceCont = document.createElement('div');
    mInterfaceCont.className += "cs crad rowm";
    mRowWrapperBtChild.appendChild(mInterfaceCont);

    // Responsive Workdesk Layout data. Stores reference of Interface containers/Div
    bscontref.WDeskRespMergedInfo = {
        InterfacesCont: []
    };

    initInterfaceMergedTabs(bscontref, mInterfaceCont);
}

var OAPRSPMap = [];
function populateRSPGridMap(cellRef, cellIndex) {
    OAPRSPMap[cellIndex] = cellRef.firstElementChild.innerHTML - 0;
}

var respWDeskColumns = 0;
var tableObject = null;
var bTwoColLayout = false;

function checkTwoColumnLayout(rowNum, viewableCells, respWDeskColumns) {
    var retVal = false;
    if (rowNum == 1 && viewableCells == 2 && viewableCells == respWDeskColumns) {
        retVal = true;
    } else if (rowNum > 1 && bTwoColLayout == true && viewableCells == 0) {
        retVal = true;
    } else if (rowNum > 1 && viewableCells != 0) {
        retVal = false;
    }
    bTwoColLayout = retVal;
}
function getWDeskRespBaseHTML(strHtml) {
    bTwoColLayout = false;
    var responsiveHTML = null, responsiveParent = null, respCompWrapper = null, responsiveChild = null;

    var viewTableStruct = strHtml;
    if (viewTableStruct != null && viewTableStruct.length > 0) {
        var tempContainer = document.createElement('div');
        tempContainer.style.display = "none";
        tempContainer.innerHTML = viewTableStruct;
        tempContainer.innerHTML = encode_ParamValue(tempContainer.childNodes[0].nodeValue);
        tableObject = tempContainer.firstElementChild;

        respWDeskColumns = tableObject.rows[0].cells.length - 1;

        responsiveParent = document.createElement('div');

        var rowSpan = 1, compHeight = 0;

        // Parsing Dummy row for structural info. It is first hidden row.
        for (var c = 0; c < BOOTSTRAP_GRIDS; c++) {
            responsiveChild = document.createElement('div');

            if (c < respWDeskColumns) {
                // Parsing Merged column info from dummy first row
                populateRSPGridMap(tableObject.rows[0].cells[c], c);
            }

            respCompWrapper = document.createElement('div');
            respCompWrapper.appendChild(responsiveChild);
            responsiveParent.appendChild(respCompWrapper);
        }

        responsiveChild = null;
        var adjVMergedCol = {}, colCtr = 0, viewableCells = 0, fColSpan = 0, columns = respWDeskColumns - 0, colSpan = 1, pColSpan = 0, virtualRowSpan = 0, virtualRow = 0;
        // Parsing rows other than dummy one            
        for (var r = 1; r < tableObject.rows.length; r++, colCtr = 0) {
            viewableCells = tableObject.rows[r].cells.length - 1;

            checkTwoColumnLayout(r, viewableCells, columns);
            
            for (var c = 0; c < viewableCells; c++, fColSpan = 0) {
                var  revC = c;
                if(pageDirection == "rtl") {
                    revC = (viewableCells - 1) - c;
                }
                
                pColSpan = getVMergedColSpan(adjVMergedCol, r, colCtr);
                if (pColSpan) {
                    colCtr += pColSpan;
                }

                rowSpan = tableObject.rows[r].cells[revC].rowSpan - 0;
                colSpan = tableObject.rows[r].cells[revC].colSpan - 0;

                /* Storing vertically merged (for cell having rowspan > 1) columns's colSpan in order to find actual colspan of cells 
                 * in next/future rows adjacent right side of this merged column */
                for (var tempC = revC, vMergedCell = true, tempRowSpan, tempColSpan, bNonConsMergedCellSpan = 0; tempC < viewableCells; tempC++) {
                    tempRowSpan = tableObject.rows[r].cells[tempC].rowSpan - 0;
                    tempColSpan = tableObject.rows[r].cells[tempC].colSpan - 0;

                    if (revC == (viewableCells - 1)) {
                        fColSpan = getVMergedColSpan(adjVMergedCol, r, colCtr, true, true);
                    }

                    if ((tempRowSpan > 1) && vMergedCell) {
                        if (!adjVMergedCol[colCtr]) {
                            adjVMergedCol[colCtr] = {};
                            adjVMergedCol[colCtr][0] = 0; // Stores row wise No of cosecutively merged cells 
                            adjVMergedCol[colCtr][1] = r;
                            adjVMergedCol[colCtr][2] = tempRowSpan;
                            bNonConsMergedCellSpan = 0;
                        } else {
                            // Not to add colspan if this cell is not consecutive to previous cell i.e cells[tempC-1]
                            bNonConsMergedCellSpan = getVMergedColSpan(adjVMergedCol, r, tempC);
                        }

                        if (!bNonConsMergedCellSpan) {
                            if (revC == (viewableCells - 1)) {
                                if (fColSpan > tempColSpan) {
                                    adjVMergedCol[colCtr][0] += (fColSpan - tempColSpan);
                                } else {
                                    adjVMergedCol[colCtr][0] += tempColSpan;
                                }
                            } else {
                                adjVMergedCol[colCtr][0] += (tempColSpan + fColSpan);
                            }
                        } else {
                            adjVMergedCol[colCtr][0] += bNonConsMergedCellSpan;
                        }
                    } else {
                        vMergedCell = false;
                    }
                }

                compHeight = getCompHeight(tableObject.rows, r, rowSpan);

                responsiveChild = document.createElement('div');
                responsiveChild.setAttribute("RowHeight", compHeight);
                responsiveChild.setAttribute("colspan", colSpan);
                if (pColSpan) {
                    // Stores No of previous consecutive merged cells
                    responsiveChild.setAttribute("pColSpan", pColSpan);
                }
                if (fColSpan) {
                    // Stores No of last future consecutive merged cells
                    responsiveChild.setAttribute("fColSpan", fColSpan);
                }
                responsiveChild.setAttribute("colIndex", colCtr);

                responsiveChild.setAttribute("rowspan", rowSpan);
                if (rowSpan > 1) {
                    responsiveChild.setAttribute("style", "height:" + (compHeight + 2 * COMP_BORDER_WIDTH - 2 * COMP_BORDER_WIDTH) + "px");
                } else {
                    responsiveChild.setAttribute("style", "height:" + (compHeight + 2 * COMP_BORDER_WIDTH) + "px");
                }

                responsiveChild.innerHTML = tableObject.rows[r].cells[revC].innerHTML;

                respCompWrapper = document.createElement('div');
                respCompWrapper.appendChild(responsiveChild);
                responsiveParent.appendChild(respCompWrapper);

                colCtr += colSpan;
                colCtr = colCtr % (columns);
            }
        }

        //responsiveHTML = "<div><div rows="+(tableObject.rows.length-1)+">" + responsiveParent.innerHTML + "</div></div>";        

        responsiveParent.setAttribute('rows', (tableObject.rows.length - 1));

        responsiveHTML = document.createElement('div');
        responsiveHTML.appendChild(responsiveParent);
    }

    return responsiveHTML;
}

function getVMergedColSpan(adjVMergedColRef, iRow, colIndex, forwardSearch, recursiveSearch) {
    forwardSearch = (typeof forwardSearch == 'undefined') ? false : forwardSearch;
    recursiveSearch = (typeof recursiveSearch == 'undefined') ? false : recursiveSearch;
    var pColSpan = 0, virtualRow = 0, virtualRowSpan = 0;

    if (forwardSearch) {
        colIndex++;
    }

    if (recursiveSearch) {
        for (var colCtr in adjVMergedColRef) {
            colCtr = colCtr - 0;

            if (forwardSearch) {
                if (colCtr >= colIndex) {
                    if (adjVMergedColRef[colCtr] && adjVMergedColRef[colCtr][0] && adjVMergedColRef[colCtr][1] != iRow) {
                        virtualRow = adjVMergedColRef[colCtr][1] - 0;
                        virtualRowSpan = adjVMergedColRef[colCtr][2] - 0;
                        if (iRow < (virtualRow + virtualRowSpan)) {
                            pColSpan += adjVMergedColRef[colCtr][0] - 0;
                        }
                    }
                }
            } else {
                if (colCtr <= colIndex) {
                    if (adjVMergedColRef[colCtr] && adjVMergedColRef[colCtr][0] && adjVMergedColRef[colCtr][1] != iRow) {
                        virtualRow = adjVMergedColRef[colCtr][1] - 0;
                        virtualRowSpan = adjVMergedColRef[colCtr][2] - 0;
                        if (iRow < (virtualRow + virtualRowSpan)) {
                            pColSpan += adjVMergedColRef[colCtr][0] - 0;
                        }
                    }
                }
            }
        }
    } else {
        colCtr = colIndex;

        if (adjVMergedColRef[colCtr] && adjVMergedColRef[colCtr][0] && adjVMergedColRef[colCtr][1] != iRow) {
            virtualRow = adjVMergedColRef[colCtr][1] - 0;
            virtualRowSpan = adjVMergedColRef[colCtr][2] - 0;
            if (iRow < (virtualRow + virtualRowSpan)) {
                pColSpan = adjVMergedColRef[colCtr][0] - 0;
            } else {
                delete adjVMergedColRef[colCtr];
            }
        }
    }


    return pColSpan;
}

function getCompHeight(rowsRef, rowIndex, rowSpan) {
    var compHeight = 0;
    for (var r = rowIndex; r < (rowIndex + rowSpan); r++) {
        if (rowsRef[r]) {
            compHeight += rowsRef[r].getAttribute("RowHeight") - 0;
        }
    }

    if(typeof DisplayFixedWDeskLayout!='undefined' && !DisplayFixedWDeskLayout(pid, wid, taskid, stractivityId, strprocessname, stractivityName)){
        var sd = getScreenResolution();
        //var sWidth = sd.ScreenWidth;
        var sHeight = sd.ScreenHeight;

        var wDeskJason = wDeskLayout;
        // ~~ converts float to integer fast
        compHeight = ~~((compHeight * sHeight)/wDeskJason.ScreenHeight);

        compHeight = compHeight + (rowSpan-1)*CLIENT_COMPONENT_SPACING_WIDTH + 2*(rowSpan - 1)*COMP_BORDER_WIDTH;
    } else {	
        var sd = getScreenDimension();
        compHeight = ~~(sd.ScreenHeight*0.92);
    }

    return compHeight;
}

function getRSPClass(colSpan, rowSpan, totalRows, colCtr, respPrefColSpan) {
    /*
     // The Bootstrap 4 (4.3.1) media query:
     
     // Extra small devices (portrait phones, less than 576px)
     // No media query since this is the default in Bootstrap
     
     // Small devices (landscape phones, 576px and up)
     @media (min-width: 576px) { ... }
     
     // Medium devices (tablets, 768px and up)
     @media (min-width: 768px) { ... }
     
     // Large devices (desktops, 992px and up)
     @media (min-width: 992px) { ... }
     
     // Extra large devices (large desktops, 1200px and up)
     @media (min-width: 1200px) { ... }
     
     
     The Bootstrap 4 (4.3.1) grid system has five classes:
     
     .col- (extra small devices - screen width less than 576px)
     .col-sm- (small devices - screen width equal to or greater than 576px)
     .col-md- (medium devices - screen width equal to or greater than 768px)
     .col-lg- (large devices - screen width equal to or greater than 992px)
     .col-xl- (xlarge devices - screen width equal to or greater than 1200px)
     
     The classes above can be combined to create more dynamic and flexible layouts.
     
     Tip: Each class scales up, so if you wish to set the same widths for sm and md, you only need to specify sm.
     */

    var respClass = "", respColSpan = 0;
    respPrefColSpan = (typeof respPrefColSpan == 'undefined') ? '' : respPrefColSpan;//will come as param

    if ((colSpan == 0) && (rowSpan == 0)) {
        // For first dummy row
        respClass = "col-select col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1 bs-plr-0";
        respColSpan = 1;
    } else {
        if (respPrefColSpan == '') {
            for (var i = 0; i < colSpan; i++) {
                respColSpan += OAPRSPMap[colCtr + i];
            }
        } else {
            respColSpan = respPrefColSpan;
        }


        respClass = "col-select col-xl-" + respColSpan + " col-lg-" + respColSpan + " col-md-12 col-sm-12 col-12 resp-comp-wrapper bs-plr-0";

        if ((colSpan == OAPRSPMap.length) && (totalRows == rowSpan)) {
            // Single component in View with full rows and columns merging
            respClass += " col-sm-12";
            respColSpan = 12;
        } else if (colSpan == OAPRSPMap.length) {
            // Single component in View with full columns merging
            respClass = "col-select col-xl-12 col-lg-12 col-md-12 col-12 col-sm-12 resp-comp-wrapper bs-plr-0";
            respColSpan = 12;
        } else {
            respClass += " col-sm-12";
            respColSpan = 12;
        }
    }

    return {
        'Class': respClass,
        'ColSpan': respColSpan
    };
}

function createTabsWrapper(currentChild) {
    var wstabw = document.createElement('div');
    wstabw.setAttribute("class", "ws-tabw");
    addCSS(wstabw, 'dn');
    currentChild.appendChild(wstabw);
    currentChild.TabsContParent = wstabw;
    wstabw.RootCont = currentChild;

    var wstabp = document.createElement('div');
    wstabp.setAttribute("class", "ws-tabp");
    wstabw.appendChild(wstabp);
    currentChild.TabsCont = wstabp;
    wstabp.RootCont = currentChild;

    // Adding Navigation if tabs extends beyond interface container width 
    addNavToTabsWrapper(currentChild, wstabp);

    return wstabp;
}

function addNavToTabsWrapper(currentChild, wstabp) {
    // Adding Navigation if tabs extends beyond interface container width        
    var tabNav = document.createElement('div');
    addCSS(tabNav, 'ws-tabn dn');
    wstabp.parentNode.appendChild(tabNav);
    currentChild.TabsNavCont = tabNav;

    // Left Navigation
    var leftNav = document.createElement('span');
    leftNav.TabsCont = wstabp;
    leftNav.onclick = function(e) {
        var contW = this.TabsCont.clientWidth;
        var diff = this.TabsCont.scrollLeft - contW;

        if (diff > 0) {
            this.TabsCont.scrollLeft -= this.TabsCont.clientWidth;

            removeCSS(this, 'navld-lg');
            addCSS(this, 'navle-lg');

            removeCSS(this.RightNav, 'navrd-lg');
            addCSS(this.RightNav, 'navre-lg');
        } else {
            this.TabsCont.scrollLeft = 0;

            removeCSS(this, 'navle-lg');
            addCSS(this, 'navld-lg');

            removeCSS(this.RightNav, 'navrd-lg');
            addCSS(this.RightNav, 'navre-lg');
        }
    }

    // By dafault hiding left navigation
    addCSS(leftNav, 'navld-lg');
    tabNav.appendChild(leftNav);

    // Right Navigation
    var rightNav = document.createElement('span');
    rightNav.TabsCont = wstabp;
    rightNav.onclick = function(e) {
        var contScrollW = this.TabsCont.scrollWidth;
        var contW = this.TabsCont.clientWidth;
        var diff = contScrollW - (this.TabsCont.scrollLeft + contW);

        if (diff > 0) {
            this.TabsCont.scrollLeft += contW;

            diff = contScrollW - (this.TabsCont.scrollLeft + contW);

            if (diff <= 0) {
                removeCSS(this, 'navre-lg');
                addCSS(this, 'navrd-lg');
            } else {
                removeCSS(this, 'navrd-lg');
                addCSS(this, 'navre-lg');
            }

            removeCSS(this.LeftNav, 'navld-lg');
            addCSS(this.LeftNav, 'navle-lg');
        } else {
            //this.TabsCont.scrollLeft = this.TabsCont.scrollLeft + diff;
            removeCSS(this, 'navre-lg');
            addCSS(this, 'navrd-lg');
        }
    }

    // By dafault enabling right navigation, visibility of its parent container will be updated in method updateInterfaceTabs
    addCSS(rightNav, 'navre-lg');

    // For easy reference access, storing navigations references mutually
    leftNav.RightNav = rightNav;
    rightNav.LeftNav = leftNav;

    tabNav.appendChild(rightNav);
}

function addDummyTab(wstabp) {
    // Dummy tab as last tab for extra underline
    var wstab = document.createElement('div');
    wstab.Dummy = true;
    wstabp.appendChild(wstab);

    return wstab;
}

function selectFirstTab(wstabp) {
    // Save reference of selected tab into its parent   
    wstabp.SelTab = wstabp.firstElementChild;
    addCSS(wstabp.firstElementChild, 'itab-sel');
}

function initInterfaceMergedTabs(bscontref, currentChild) {
    bscontref.WDeskRespMergedInfo.InterfacesCont[bscontref.WDeskRespMergedInfo.InterfacesCont.length] = currentChild;

    if (!currentChild.Tabs) {
        currentChild.Tabs = [];
    }

    if (bscontref.WDeskRespBaseInfo.InterfacesCont.length > 0) {
        var wstabp = createTabsWrapper(currentChild);

        appendTabsFromWDeskBaseLayout(bscontref, currentChild, wstabp);
        addTabsFromLeftPanel(bscontref, currentChild, wstabp);
        addTabsFromRightPanel(bscontref, currentChild, wstabp);

        // Save reference of selected tab into its parent   
        selectFirstTab(wstabp);

        // Dummy tab as last tab for extra underline
        addDummyTab(wstabp);

        if ((currentChild.Tabs.length - 1) == 1) {
            // If single Tab (excluding dummy tab) then hide
            addCSS(wstabp.parentNode, 'dn');
            currentChild.VisibleTabs = false;
        } else {
            currentChild.VisibleTabs = true;
        }
    }
}

function initInterfaceTabs(bscontref, currentChild) {
    // Parsing Tabs/Interfaces

    bscontref.WDeskRespBaseInfo.InterfacesCont[bscontref.WDeskRespBaseInfo.InterfacesCont.length] = currentChild;

    if (!currentChild.Tabs) {
        currentChild.Tabs = [];
    }

    var wsTabsCont = currentChild.firstElementChild, bMultiPaneSupported = false;
    if (wsTabsCont) {
        var strValue = '', interfaceTabs = wsTabsCont.children;

        var multiTabInterfaces = null, multiPaneObj = null;

        var wDeskJson = getCurrentWDeskJason();
        if (wDeskJson.WDeskLayout.InterfacesTabs) {
            /*
             "WDeskLayout": {"InterfacesTabs": 
             { "SAPGUIAdapter": {"SAP0": "SAPDefId1", "SAP1": "SAPDefId2"}},
             { "TaskView": {"TaskView": "TaskView", "CaseView": "CaseView"}}
             }
             */

            multiTabInterfaces = wDeskJson.WDeskLayout.InterfacesTabs;
        }

        if (!multiTabInterfaces) {
            multiTabInterfaces = {};
        }

        for (var i = 0; i < interfaceTabs.length; i++) {
            if (!currentChild.MultiPaneConts) {
                currentChild.MultiPaneConts = {};
            }

            strValue = interfaceTabs[i].getAttribute('MultiPane');
            currentChild.MultiPane = (strValue == null || strValue == '') ? false : (strValue == 'Y' ? true : false);

            strValue = interfaceTabs[i].innerHTML.trimEx();

            if ((strValue != null) && (strValue.length == 0)) {
                continue;
            }

            multiPaneObj = multiPaneInterfaces[strValue];

            if (!isViewableInterface(strValue)) {
                interfaceTabs[i].OTN = strValue;
                interfaceTabs[i].ViewRight = false;
                interfaceTabs[i].id = strValue;
                interfaceTabs[i].innerHTML = getInterfaceDisplayValue(interfaceTabs[i]);

                currentChild.Tabs[currentChild.Tabs.length] = interfaceTabs[i];

                initTabEventListner(interfaceTabs[i]);

                continue;
            } else {
                interfaceTabs[i].ViewRight = true;
            }

            if (multiPaneObj && multiPaneObj.MultiPane) {
                // Skip adding of Pane in this hidden Tab as Panes will be created at runtime and will be added into this hidden Tab

                currentChild.Tabs[currentChild.Tabs.length] = interfaceTabs[i];

                // Store Tab's original Name
                interfaceTabs[i].OTN = strValue;
                interfaceTabs[i].MultiPane = true;
                interfaceTabs[i].RootCont = currentChild;

                currentChild.MultiPaneConts[interfaceTabs[i].OTN] = interfaceTabs[i];

                interfaceTabs[i].parentNode.removeChild(interfaceTabs[i]);
                bMultiPaneSupported = true;
                continue;
            }

            if (!multiTabInterfaces[strValue]) {
                // Tab having single Interface

                addTab(i, currentChild, wsTabsCont, interfaceTabs[i], strValue);
            } else {
                /*  Tab having multiple Interface e.g 
                 CaseView will split into two tabs e.g FormView and CaseView
                 */

                var addedTabs = initMultiTabInterfaces(i, currentChild, wsTabsCont, interfaceTabs[i], strValue);
                if (addedTabs > 0) {
                    i = i + (addedTabs - 1);
                }
            }
        }

        // Dummy tab as last tab for extra underline
        addDummyTab(wsTabsCont)

        // Creating Wrapper parent element for tabs container and Navigation container
        var wsTabsWrapper = document.createElement('div');
        wsTabsCont.parentNode.appendChild(wsTabsWrapper);
        wsTabsWrapper.appendChild(wsTabsCont);
        currentChild.TabsCont = wsTabsCont;
        currentChild.TabsContParent = wsTabsWrapper;

        if ((interfaceTabs.length <= 2 && !bMultiPaneSupported) || (bMultiPaneSupported && interfaceTabs.length <= 1)) {
            // If single Tab (excluding dummy tab) then hide
            addCSS(wsTabsWrapper, 'ws-tabw dn');
            addCSS(wsTabsCont, 'ws-tabp');
            currentChild.VisibleTabs = false;
        } else {
            addCSS(wsTabsWrapper, 'ws-tabw df');
            addCSS(wsTabsCont, 'ws-tabp');
            currentChild.VisibleTabs = true;
        }

        // Adding Navigation if tabs extends beyond interface container width        
        addNavToTabsWrapper(currentChild, wsTabsCont);
    }
}

function updateInterfaceTabs(interfaceCont) {
    // Updating Interface tabs and navigation after bootstraps reordering

    var contScrollW = interfaceCont.TabsCont.scrollWidth;
    var contW = interfaceCont.TabsCont.clientWidth;

    if (contW < contScrollW) {
        removeCSS(interfaceCont.TabsNavCont, 'dn');
        addCSS(interfaceCont.TabsNavCont, 'df');
    } else {
        removeCSS(interfaceCont.TabsNavCont, 'df');
        addCSS(interfaceCont.TabsNavCont, 'dn');
    }
}

function loadWDeskBaseInerfaces(bscontref){
    var interfaceCont = null, bVisibleTabs = false, rd = null, tabValue='', intContRef = null,intContId = '', i, j;
    var wDeskJson = getCurrentWDeskJason();
    
    var bFormViewFound = false;
    for(i=0; i < bscontref.WDeskRespBaseInfo.InterfacesCont.length; i++) {
        interfaceCont = bscontref.WDeskRespBaseInfo.InterfacesCont[i];
        for(j=0; j < interfaceCont.Tabs.length; j++){
            if(getInterfaceTabValue(interfaceCont.Tabs[j]) == "FormView") {
                bFormViewFound = true;
                break;
            }
        }
        if(bFormViewFound) {
            break;
        }
    }
    if(!bFormViewFound) {
        isFormLoaded = true;
    }
    
    for(i=0; i < bscontref.WDeskRespBaseInfo.InterfacesCont.length; i++){
        interfaceCont = bscontref.WDeskRespBaseInfo.InterfacesCont[i];
        
        updateInterfaceTabs(interfaceCont);   
        
        for(j=0; j < interfaceCont.Tabs.length; j++){            
            if(!interfaceCont.Tabs[j].ViewRight){
                tabValue = getInterfaceTabValue(interfaceCont.Tabs[j]);
                intContId = 'nor'+tabValue;            
                
                intContRef = getIntContRef(interfaceCont, intContId);
                
                if(interfaceCont.TabsCont.SelTab){
                    if(interfaceCont.TabsCont.SelTab == interfaceCont.Tabs[j]){
                        removeCSS(intContRef, 'dn');
                        addCSS(intContRef, 'db');
                    } else {
                        removeCSS(intContRef, 'db');
                        addCSS(intContRef, 'dn');
                    }
                } else {
                    if(j == 0){
                        addCSS(interfaceCont.Tabs[j], 'itab-sel');
                        
                        removeCSS(intContRef, 'dn');
                        addCSS(intContRef, 'db');
                        
                        interfaceCont.TabsCont.SelTab=interfaceCont.Tabs[j];
                    } else {
                        removeCSS(intContRef, 'db');
                        addCSS(intContRef, 'dn');
                    }
                }
                
                getInterface("noright", '', '', tabValue);
            } else {            
                tabValue = getInterfaceTabValue(interfaceCont.Tabs[j]);
                intContRef = getIntContRef(interfaceCont, tabValue);
            
                if(intContRef.New){                
                    if(interfaceCont.TabsCont.SelTab){
                        if(interfaceCont.TabsCont.SelTab == interfaceCont.Tabs[j]){
                            removeCSS(intContRef, 'dn');
                            addCSS(intContRef, 'db');
                        } else {
                            removeCSS(intContRef, 'db');
                            addCSS(intContRef, 'dn');
                        }
                    } else {
                        if(j == 0){
                            addCSS(interfaceCont.Tabs[j], 'itab-sel');
                            
                            removeCSS(intContRef, 'dn');
                            addCSS(intContRef, 'db');
                            
                            interfaceCont.TabsCont.SelTab=interfaceCont.Tabs[j];
                        } else {
                            removeCSS(intContRef, 'db');
                            addCSS(intContRef, 'dn');
                        }
                    }
                
                    addCSS(intContRef, 'embed-responsive');

                    bVisibleTabs = hasViewableTabs(intContRef.parentNode);
                    if(bVisibleTabs){
                        rd = getRealDimension(intContRef.parentNode.TabsContParent);
                        intContRef.parentNode.style.paddingBottom = rd.Height + 'px';
                    }

                    intContId = getInterfaceId(tabValue);
                    var srcUrl = '';
                    var typeOf = '';
                
                    if(wDeskJson.WDeskLayout.ExtInterfaces){
                        if(wDeskJson.WDeskLayout.ExtInterfaces[tabValue]){
                            srcUrl = wDeskJson.WDeskLayout.ExtInterfaces[tabValue];
                            typeOf = 'Ext';
                        }
                    }
                    
                    //var url = getInterfaceUrl(tabValue);
                    //if(url != ''){
                    //getInterface(wDeskJason.Interfaces[i].Interface.DivId, wDeskJason.Interfaces[i].Interface.Url, wDeskJason.Interfaces[i].Interface.EXT);
                    getInterface(intContId, srcUrl, typeOf, null);
                //}
                } else {
                    if(interfaceCont.TabsCont.SelTab == interfaceCont.Tabs[j]){
                        removeCSS(intContRef, 'dn');
                        addCSS(intContRef, 'db');
                    } else {
                        removeCSS(intContRef, 'db');
                        addCSS(intContRef, 'dn');
                    }
                
                /*if(interfaceCont != intContRef.parentNode){
                    interfaceCont.appendChild(intContRef);
                }*/
                }
            }
        }
    }    
}

function updateWDeskBaseInerfaces(bscontref) {
    var interfaceCont = null;

    for (var i = 0; i < bscontref.WDeskRespBaseInfo.InterfacesCont.length; i++) {
        interfaceCont = bscontref.WDeskRespBaseInfo.InterfacesCont[i];

        updateInterfaceTabs(interfaceCont);
    }
}

function hasViewableTabs(respCont) {
    var bVisibleTabs = false;
    if (respCont.VisibleTabs) {
        bVisibleTabs = true;
    }
    return bVisibleTabs;
}

function getParentSidebar(selPanelTab) {
    var psbRef = null;

    var selPanelTabRef = document.getElementById(selPanelTab);
    if (selPanelTabRef) {
        psbRef = selPanelTabRef.psb;
    }

    return psbRef;
}

function initTabEventListner(interfaceTabRef) {
    interfaceTabRef.onclick = function(event) {
        removeCSS(this.parentNode.SelTab, 'itab-sel');
        addCSS(this, 'itab-sel');

        var tabValue = getInterfaceTabValue(this.parentNode.SelTab);
        var bViewRight = (typeof this.parentNode.SelTab.ViewRight == 'undefined') ? true : this.parentNode.SelTab.ViewRight;

        if (!bViewRight) {
            tabValue = 'nor' + tabValue;
        }

        var iContRef = getIntContRef(null, tabValue);
        iContRef = iContRef.mpparent ? iContRef.mpparent : iContRef;

        if (iContRef) {
            removeCSS(iContRef, 'db');
            addCSS(iContRef, 'dn');
        }

        tabValue = getInterfaceTabValue(this);
        bViewRight = (typeof this.ViewRight == 'undefined') ? true : this.ViewRight;

        if (!bViewRight) {
            tabValue = 'nor' + tabValue;
        }

        iContRef = getIntContRef(null, tabValue);
        iContRef = iContRef.mpparent ? iContRef.mpparent : iContRef;

        if (iContRef) {
            removeCSS(iContRef, 'dn');
            addCSS(iContRef, 'db');

            if (iContRef.ListPane) {
                if (iContRef.TabsCont.SelTab) {
                    removeCSS(iContRef.TabsCont.SelTab.ViewerCont, 'dn');
                    addCSS(iContRef.TabsCont.SelTab.ViewerCont, 'db');
                }
            }
        }

        this.parentNode.SelTab = this;
    }
}

function getBootstrapDeviceSize() {
    return $('#bt4').find('div:visible').first().attr('id');
}
function getBSDeviceMode() {
    // Bootstrap device mode
    var btds = getBootstrapDeviceSize();
    var isMobileDevice = false;

    switch (btds) {
        case 'xs':
        case 'sm':
        case 'md':
            isMobileDevice = true;
            break;
        case 'lg':
        case 'xl':
            isMobileDevice = false;
            break;
    }

    return isMobileDevice;
}
function isDesktopInMobileMode() {
    // Bootstrap device mode
    var btds = getBootstrapDeviceSize();

    return MobileBPInDesktop[btds];
}
function isDesktopBPforEL() {
    // Bootstrap device mode
    var btds = getBootstrapDeviceSize();

    return DesktopELBP[btds];
}

function checkDeviceModeOnResize() {
    var currentIsMobileDevice = getBSDeviceMode();

    if (lastIsMobileDevice != currentIsMobileDevice) {
        // On device layout change i.e Browser window resize in Desktop

        deviceModeChanged(currentIsMobileDevice);

        lastIsMobileDevice = currentIsMobileDevice;
    } else {
        var bscontref = document.getElementById(bscontid);

        // Loading Interfaces
        loadWDeskInerfaces(bscontref, currentIsMobileDevice);

        if (!currentIsMobileDevice) {
            // Update tabs
        } else {
            updateInterfaceTabs(bscontref.WDeskRespMergedInfo.InterfacesCont[0]);
        }
    }
}

function deviceModeChanged(deviceType) {
    initWDeskPanels(deviceType);

    initWDeskDeviceLayout(deviceType);

    var masonryFound = initMasonryLayout(bscontid, deviceType);

    if (masonryFound) {
        updateMasonryLayout(deviceType);
    }
}

function initWDeskDeviceLayout() {
    var dRowWrapper = document.getElementById('row' + DESKTOP_DEVICE);
    var mRowWrapper = document.getElementById('row' + MOBILE_DEVICE);
    var bscontref = document.getElementById(bscontid);

    if (!bMobileDevice) {
        // Desktop device
        removeCSS(mRowWrapper, 'db');
        addCSS(mRowWrapper, 'dn');

        removeCSS(dRowWrapper, 'dn');
        addCSS(dRowWrapper, 'db');

        if (bscontref.WDeskRespMergedInfo) {
            removeCSS(bscontref.WDeskRespMergedInfo.InterfacesCont[0].TabsContParent, 'df');
            addCSS(bscontref.WDeskRespMergedInfo.InterfacesCont[0].TabsContParent, 'dn');
        }
    } else {
        // Mobile device
        removeCSS(dRowWrapper, 'db');
        addCSS(dRowWrapper, 'dn');

        removeCSS(mRowWrapper, 'dn');
        addCSS(mRowWrapper, 'db');

        removeCSS(bscontref.WDeskRespMergedInfo.InterfacesCont[0].TabsContParent, 'dn');
        addCSS(bscontref.WDeskRespMergedInfo.InterfacesCont[0].TabsContParent, 'df');
    }
}


function preMasonryLayoutResize() {
    var bscont = document.getElementById('bscont');

    /* Scrollbar width adds to available responsive container width while updating masonry layout. After modification scrollbar auto hides
     which distorts the layout */
    bscont.style.overflow = 'hidden';
}

function postMasonryLayoutResize(thisMasonry, bWindowResized) {
    // bWindowResized = true, if browser's window is resized otherwise manual resize is called

    var bscont = getMasonryCont(thisMasonry);
    bscont.style.overflowY = 'auto';
    bscont.style.overflowX = 'hidden';

    bWindowResized = (typeof bWindowResized == 'undefined') ? true : bWindowResized;

    var bscontref = document.getElementById(bscontid);

    if (bWindowResized) {
        // Bootstrap media query executes only when device/Browser window size is changed
        //checkDeviceModeOnResize();    

        if (!bMobileDevice) {
            // For Desktop only
            initWDeskBasePanels();
            updateMasonryLayout();
        }
    } else {
        // Manual resize e.g expand/collapse of sidebar

        /*        
         // Loading Interfaces
         loadWDeskInerfaces(bscontref);    
         
         if(!bMobileDevice){
         // Update tabs
         } else{
         // No sidebar in Mobile mode
         }*/
    }

    // Update Interfaces e.g update prev/next of tabs
    updateWDeskInerfaces(bscontref);
    postWDeskRespDeviceLayout(bscontref, bWindowResized);
}

function postMasonryLayout(thisMasonry) {
    var bscontref = getMasonryCont(thisMasonry);
    bscontref.style.overflowY = 'auto';
    bscontref.style.overflowX = 'hidden';

    // Loading Interfaces
    loadWDeskInerfaces(bscontref);

    postWDeskRespDeviceLayout(bscontref);
}

function loadWDeskInerfaces(bscontref) {
    //var s = new Date().getTime();

    if (!bMobileDevice) {
        loadWDeskBaseInerfaces(bscontref);

        /*
         * reloadWDeskPanels();
         if(interfaceCont.Tabs[j].PanelTab){
         loadWdSidebarHandler(tabValue, intContRef);
         }*/
    } else {
        loadWDeskMergedInerfaces(bscontref);
    }

    /*var e = new Date().getTime();
     alert("loadWDeskInerfaces:::------"+(e-s));*/
}

function updateWDeskInerfaces(bscontref) {
    //var s = new Date().getTime();

    if (!bMobileDevice) {
        updateWDeskBaseInerfaces(bscontref);
    } else {
        updateWDeskMergedInerfaces(bscontref);
    }

    /*var e = new Date().getTime();
     alert("loadWDeskInerfaces:::------"+(e-s));*/
}

function loadWDeskMergedInerfaces(bscontref) {
    var interfaceCont = null, bVisibleTabs = false, rd = null, tabValue = '', intContRef = null, selRootContTab = null;
    var wDeskJson = getCurrentWDeskJason();

    for (var i = 0; i < bscontref.WDeskRespMergedInfo.InterfacesCont.length; i++) {
        interfaceCont = bscontref.WDeskRespMergedInfo.InterfacesCont[i];

        if (!interfaceCont.ListPane) {
            // Loading Level1 Tabs
            updateInterfaceTabs(interfaceCont);

            for (var j = 0; j < interfaceCont.Tabs.length; j++) {
                tabValue = getInterfaceTabValue(interfaceCont.Tabs[j])
                intContRef = getIntContRef(interfaceCont, tabValue);
                intContRef.ParentTab = interfaceCont.Tabs[j];

                if (intContRef.New) {
                    if (interfaceCont.TabsCont.SelTab) {
                        if ((interfaceCont.TabsCont.SelTab == interfaceCont.Tabs[j]) && !interfaceCont.Tabs[j].MultiPane) {
                            removeCSS(intContRef, 'dn');
                            addCSS(intContRef, 'db');
                        } else {
                            removeCSS(intContRef, 'db');
                            addCSS(intContRef, 'dn');
                        }

                        selRootContTab = interfaceCont.TabsCont.SelTab;
                    } else {
                        if (j == 0) {
                            removeCSS(intContRef, 'dn');
                            addCSS(intContRef, 'db');
                        } else {
                            removeCSS(intContRef, 'db');
                            addCSS(intContRef, 'dn');
                        }

                        selRootContTab = interfaceCont.TabsCont.SelTab;
                    }

                    addCSS(intContRef, 'embed-responsive');

                    bVisibleTabs = hasViewableTabs(intContRef.parentNode);
                    if (bVisibleTabs) {
                        rd = getRealDimension(intContRef.parentNode.TabsContParent);
                        intContRef.parentNode.style.paddingBottom = rd.Height + 'px';
                    }

                    var intContId = getInterfaceId(tabValue);
                    //var url = getInterfaceUrl(tabValue);
                    //if(url != ''){
                    if (interfaceCont.Tabs[j].PanelTab) {
                        loadWdSidebarHandler(tabValue, intContRef);
                    } else {
                        var srcUrl = '';
                        var typeOf = '';

                        if (wDeskJson.WDeskLayout.ExtInterfaces) {
                            if (wDeskJson.WDeskLayout.ExtInterfaces[tabValue]) {
                                srcUrl = wDeskJson.WDeskLayout.ExtInterfaces[tabValue];
                                typeOf = 'Ext';
                            }
                        }

                        //getInterface(wDeskJason.Interfaces[i].Interface.DivId, wDeskJason.Interfaces[i].Interface.Url, wDeskJason.Interfaces[i].Interface.EXT);
                        getInterface(intContId, srcUrl, typeOf, null);
                    }
                    //}
                } else {
                    if (interfaceCont.TabsCont.SelTab == interfaceCont.Tabs[j]) {
                        removeCSS(intContRef, 'dn');
                        addCSS(intContRef, 'db');
                    } else {
                        removeCSS(intContRef, 'db');
                        addCSS(intContRef, 'dn');
                    }
                }
            }
        } else {
            // List Pane

            if (interfaceCont.ListPanes) {
                var key = Object.keys(interfaceCont.ListPanes);
                if (key.length > 0) {
                    intContRef = getIntContRef(interfaceCont, key[0]);

                    if (selRootContTab) {
                        if (selRootContTab.MultiPane) {
                            // If MultiPane Tab is selected at Level1 then display Nested child panes container
                            removeCSS(intContRef.mpparent, 'dn');
                            addCSS(intContRef.mpparent, 'db');
                        } else {
                            removeCSS(intContRef.mpparent, 'db');
                            addCSS(intContRef.mpparent, 'dn');
                        }
                    }

                    loadWdSidebarHandler(key[0], intContRef);
                }
            }
        }
    }
}

function updateWDeskMergedInerfaces(bscontref) {
    var interfaceCont = null;

    for (var i = 0; i < bscontref.WDeskRespMergedInfo.InterfacesCont.length; i++) {
        interfaceCont = bscontref.WDeskRespMergedInfo.InterfacesCont[i];

        updateInterfaceTabs(interfaceCont);
    }
}

function initMasonryLayout(bscontid){    
    bscontid = (typeof bscontid == 'undefined')? null: bscontid;
    var masonryFound = false;
    
    var deviceType = bMobileDevice? MOBILE_DEVICE: DESKTOP_DEVICE;
    var rowWrapper = document.getElementById('row'+deviceType);
    
    if(!rowWrapper.Masonry){
        masonryFound = false;
        
        var mjson = {};
        mjson.itemSelector='.col-select';
        
        if(bscontid){
            mjson['bscont'] = bscontid;
        }
        try {
            $('#row' + deviceType).masonry(mjson);
        } catch(e) {
            var msnry = new Masonry(rowWrapper, {
                itemSelector: '.col-select',
                bscont: bscontid
            });
            if(!window.masonry){
                window.masonry = {};
                window.masonry['row' + deviceType]=msnry;
            } else {
                if(!window.masonry['row' + deviceType]){
                    window.masonry['row' + deviceType]=msnry;
                }
            }
                    
            try{
                window.postMasonryLayout && window.postMasonryLayout(msnry);
            }catch(e){}
        }
        rowWrapper.Masonry = true;
    } else {
        masonryFound = true;
    }
    
    return masonryFound;
}

function getMasonryCont(mresizerRef) {
    var mcont = null;
    if (mresizerRef) {
        mcont = document.getElementById(mresizerRef.options['bscont']);
    }

    return mcont;
}

function setMasonryProp(mresizerRef, option, value) {
    option = (typeof option == 'undefined') ? null : option;
    value = (typeof value == 'undefined') ? null : value;

    if (mresizerRef && option && value) {
        mresizerRef.options[option] = value;
    }
}

function updateMasonryLayout() {
    /*  Must function is to be called when display property/width of any container e.g sidebar etc. is changed as 
     Bootstrap media query executes only when device/Browser window size is changed.
     */

    var masonryRef = window.masonry && window.masonry['row' + (bMobileDevice ? MOBILE_DEVICE : DESKTOP_DEVICE)];
    if (masonryRef) {
        masonryRef.onresize(null, false);
    }
}

function getInterfaceTabValue(interfaceTab) {
    var value = '';
    if (interfaceTab.OTN) {
        value = interfaceTab.OTN;
    }

    return value;
}
function getInterfaceDisplayValue(interfaceTab) {
    var value = interfaceTab.innerHTML.trimEx();

    var valueRef = document.getElementById(value + 'P');
    if (valueRef != null) {
        value = valueRef.innerHTML.trimEx();
    }

    return value;
}

function isMobileDevice() {
    var a = navigator.userAgent || navigator.vendor || window.opera;
    var userAgentPart = a.substr(0, 4);
    var ch = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a)
            || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(userAgentPart);

    //    ch=true;

    return (ch);
}

function initWDeskPanels() {
    //var s = new Date().getTime();

    if (!bMobileDevice) {
        initWDeskBasePanels();
    } else {
        initWDeskMergedPanels();
    }

    /*var e = new Date().getTime();
     alert("loadWDeskInerfaces:::------"+(e-s));*/
}


function resetWDeskPanels() {
    if (!bMobileDevice) {
        resetWDeskBasePanels();
    } else {
        resetWDeskMergedPanels();
    }
}

function reloadWDeskInerfaces() {
    var bscontref = document.getElementById(bscontid);
    loadWDeskInerfaces(bscontref);
}

function resetWDeskBasePanels() {
    var sbContRef = document.getElementsByClassName('lsb');
    sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;

    if (sbContRef != null) {
        for (var key in sbContRef.Tabs) {
            if (sbContRef.Tabs[key]) {
                sbContRef.Tabs[key] = false;
            }
        }
    }

    sbContRef = document.getElementsByClassName('rsb');
    sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;

    if (sbContRef != null) {
        for (var key in sbContRef.Tabs) {
            if (sbContRef.Tabs[key]) {
                sbContRef.Tabs[key] = false;
            }
        }
    }
}

function resetWDeskMergedPanels() {
    var sbContRef = document.getElementsByClassName('lsb');
    sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;

    if (sbContRef != null) {
        for (var key in sbContRef.Tabs) {
            if (sbContRef.Tabs[key]) {
                sbContRef.Tabs[key] = false;
            }
        }
    }

    sbContRef = document.getElementsByClassName('rsb');
    sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;

    if (sbContRef != null) {
        for (var key in sbContRef.Tabs) {
            if (sbContRef.Tabs[key]) {
                sbContRef.Tabs[key] = false;
            }
        }
    }
}

function initWDeskMergedPanels() {
    // This function loads default configured/selected (If any) panel tab/interface on workdesk initialization
    var lifmRef = document.getElementsByClassName('lsb-f');
    lifmRef = (lifmRef && lifmRef.length > 0) ? lifmRef[0] : null;

    var rifmRef = document.getElementsByClassName('rsb-f');
    rifmRef = (rifmRef && rifmRef.length > 0) ? rifmRef[0] : null;

    var isIEBrowser = window.navigator.userAgent.indexOf("MSIE ") > -1 || window.navigator.userAgent.indexOf("Trident/") > -1;
    if (isIEBrowser) {
        if (lifmRef)
            addCSS(lifmRef, "ie");
        if (rifmRef)
            addCSS(rifmRef, "ie");
    }
    //  Left Panel
    var lPanel = document.getElementsByClassName('lpanel');
    lPanel = (lPanel && lPanel.length > 0) ? lPanel[0] : null;

    //  Right Panel
    var rPanel = document.getElementsByClassName('rpanel');
    rPanel = (rPanel && rPanel.length > 0) ? rPanel[0] : null;

    var sbContRef = null, sbContSRef = null;

    if (lPanel != null && lPanel.children.length > 0) {
        removeCSS(lPanel, 'df');
        addCSS(lPanel, 'dn');

        sbContRef = document.getElementsByClassName('lsb');
        sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;

        if (sbContRef != null) {
            if (!sbContRef.Tabs) {
                sbContRef.Tabs = {};
            }

            removeCSS(sbContRef, 'db');
            addCSS(sbContRef, 'dn');
        }
        sbContSRef = document.getElementsByClassName('lsb-s');
        sbContSRef = (sbContSRef && sbContSRef.length > 0) ? sbContSRef[0] : null;
        removeCSS(sbContSRef, 'db');
        addCSS(sbContSRef, 'dn');
        if (lifmRef) {
            if (hasCSS(lifmRef, "ie")) {
                removeCSS(lifmRef, 'db');
                addCSS(lifmRef, 'dn');
            } else {
                lifmRef.setAttribute("style", "display:none !important");
            }
        }
    }

    if (rPanel != null && rPanel.children.length > 0) {
        removeCSS(rPanel, 'df');
        addCSS(rPanel, 'dn');

        sbContRef = document.getElementsByClassName('rsb');
        sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;
        if (sbContRef != null) {
            if (!sbContRef.Tabs) {
                sbContRef.Tabs = {};
            }

            removeCSS(sbContRef, 'db');
            addCSS(sbContRef, 'dn');
        }
        sbContSRef = document.getElementsByClassName('rsb-s');
        sbContSRef = (sbContSRef && sbContSRef.length > 0) ? sbContSRef[0] : null;
        removeCSS(sbContSRef, 'db');
        addCSS(sbContSRef, 'dn');
        if (rifmRef) {
            if (hasCSS(rifmRef, "ie")) {
                removeCSS(rifmRef, 'db');
                addCSS(rifmRef, 'dn');
            } else {
                rifmRef.setAttribute("style", "display:none !important");
            }
        }
    }
}

function appendTabsFromWDeskBaseLayout(bscontref, currentChild, wstabp) {
    var baseInterfaceCont = null, interfaceTab = null, wstab = null, tabValue = '';

    for (var i = 0; i < bscontref.WDeskRespBaseInfo.InterfacesCont.length; i++) {
        baseInterfaceCont = bscontref.WDeskRespBaseInfo.InterfacesCont[i];

        for (var j = 0; j < baseInterfaceCont.Tabs.length; j++) {
            interfaceTab = baseInterfaceCont.Tabs[j];
            tabValue = getInterfaceDisplayValue(interfaceTab);

            wstab = document.createElement('div');

            if (!wstabp.SelTab) {
                // Save reference of selected tab into its parent   
                wstabp.SelTab = wstab;
                addCSS(wstab, 'itab-sel');
            }

            wstab.OTN = getInterfaceTabValue(interfaceTab);

            currentChild.Tabs[currentChild.Tabs.length] = wstab;
            wstab.Index = currentChild.Tabs.length - 1;
            wstab.RootCont = currentChild;

            /* In case of merged view or Mobile view Tab will have MultiPane info instead of tabs Container as in this view there will
             be a single container and Tab can have its own Multipane container in turn. When container for MultiPane Tab is created then
             MultiPane status will be copied to its new container.
             */

            //currentChild.MultiPane = baseInterfaceCont.MultiPane;            
            wstab.MultiPane = (typeof interfaceTab.MultiPane == 'undefined') ? false : interfaceTab.MultiPane;

            /* Currently Only Document has multipane support so if Level1 container has any of the Tabs as multipane then we assume 
             Level2 i.e this currentChild is multi pane
             */
            currentChild.MultiPane = currentChild.MultiPane || baseInterfaceCont.MultiPane;

            if (!currentChild.MultiPaneConts) {
                currentChild.MultiPaneConts = {};
            }

            if (wstab.MultiPane) {
                currentChild.MultiPaneConts[wstab.OTN] = wstab;
            }

            wstab.PanelTab = false;

            wstab.innerHTML = tabValue;
            wstabp.appendChild(wstab);

            initTabEventListner(wstab);
        }
    }
}

function addTabsFromLeftPanel(bscontref, currentChild, wstabp) {
    //  Left Panel
    var lPanel = document.getElementsByClassName('lpanel');
    lPanel = (lPanel && lPanel.length > 0) ? lPanel[0] : null;

    if (lPanel != null && lPanel.children.length > 0) {
        var interfaceTab = null, wstab = null, tabValue = '';

        var tabsRef = lPanel.getElementsByClassName('lpt');
        if (tabsRef) {
            var mpparentId = null, multiPaneObj = null, listTabFound = false;

            for (var i = 0; i < tabsRef.length; i++) {
                listTabFound = false;

                interfaceTab = tabsRef[i];

                tabValue = interfaceTab.innerHTML.trimEx();

                wstab = document.createElement('div');
                wstab.innerHTML = tabValue;

                if (!wstabp.SelTab) {
                    // Save reference of selected tab into its parent   
                    wstabp.SelTab = wstab;
                    addCSS(wstab, 'itab-sel');
                }

                wstab.OTN = interfaceTab.parentNode.id;
                wstab.PanelTab = true;
                wstab.RootCont = currentChild;

                // Check if this tab is ListTab, If yes then create nested tab
                mpparentId = interfaceTab.parentNode.getAttribute('mppid');
                if (mpparentId) {
                    if (mpparentId.length > 0) {
                        multiPaneObj = multiPaneInterfaces[mpparentId];

                        if (multiPaneObj && multiPaneObj.ListIntName) {
                            if (multiPaneObj.ListIntName.length > 0) {
                                listTabFound = true;

                                getMPWrapperForMobileEx(currentChild, mpparentId, multiPaneObj.ListIntName, tabValue);
                            }
                        }
                    }
                }

                if (!listTabFound) {
                    currentChild.Tabs[currentChild.Tabs.length] = wstab;
                    wstab.Index = currentChild.Tabs.length - 1;

                    wstabp.appendChild(wstab);
                }

                initTabEventListner(wstab);
            }
        }
    }
}

function addTabsFromRightPanel(bscontref, currentChild, wstabp) {
    //  Left Panel
    var lPanel = document.getElementsByClassName('rpanel');
    lPanel = (lPanel && lPanel.length > 0) ? lPanel[0] : null;

    if (lPanel != null && lPanel.children.length > 0) {
        var interfaceTab = null, wstab = null, tabValue = '';

        var tabsRef = lPanel.getElementsByClassName('rpt');
        if (tabsRef) {
            var mpparentId = null, multiPaneObj = null, listTabFound = false;

            for (var i = 0; i < tabsRef.length; i++) {
                listTabFound = false;

                interfaceTab = tabsRef[i];
                tabValue = interfaceTab.innerHTML.trimEx();

                wstab = document.createElement('div');
                wstab.innerHTML = tabValue;

                if (!wstabp.SelTab) {
                    // Save reference of selected tab into its parent   
                    wstabp.SelTab = wstab;
                    addCSS(wstab, 'itab-sel');
                }

                wstab.OTN = interfaceTab.parentNode.id;
                wstab.PanelTab = true;
                wstab.RootCont = currentChild;

                // Check if this tab is ListTab, If yes then create nested tab
                mpparentId = interfaceTab.parentNode.getAttribute('mppid');
                if (mpparentId) {
                    if (mpparentId.length > 0) {
                        multiPaneObj = multiPaneInterfaces[mpparentId];

                        if (multiPaneObj && multiPaneObj.ListIntName) {
                            if (multiPaneObj.ListIntName.length > 0) {
                                listTabFound = true;

                                getMPWrapperForMobileEx(currentChild, mpparentId, multiPaneObj.ListIntName, tabValue);
                            }
                        }
                    }
                }

                if (!listTabFound) {
                    currentChild.Tabs[currentChild.Tabs.length] = wstab;
                    wstab.Index = currentChild.Tabs.length - 1;

                    wstabp.appendChild(wstab);
                }

                initTabEventListner(wstab);
            }
        }
    }
}

function getMPWrapperForMobileEx(oldRootCont, mpparentId, mplistId, tabValue) {
    /*
     mpparentId -> Document
     mplistId -> Documents (tabValue: Document List)
     */
    var newRootCont = document.createElement('div');
    newRootCont.MultiPane = oldRootCont.MultiPane;
    addCSS(newRootCont, 'rowm lp');

    // Creating nested Tab Container
    oldRootCont.appendChild(newRootCont);

    var wstabp = createTabsWrapper(newRootCont);

    // Dummy tab as last tab for extra underline
    addDummyTab(wstabp);

    var paneHandlers = {
        'PaneClick': paneClickHandler,
        'PaneClose': paneCloseHandler
    }

    // Adding Tab's Content loader Container 
    var contRef = getIntContRef(newRootCont, mpparentId);
    contRef.mpparent = newRootCont;

    var wstabCont = getIntContRef(newRootCont, mplistId);
    wstabCont.mpparent = newRootCont;
    wstabCont.ListPane = true;

    var paneId = '0';
    var wstab = addPane(wstabCont, tabValue, paneId, newRootCont.MultiPane, 'list', 'dn', paneHandlers, true);
    wstab.ListPaneTab = true;
    wstab.ViewerCont = wstabCont;
    // Setting new parent reference in container div. This is used for hiding Multipane containers
    wstab.RootCont = newRootCont;

    linkViewerToPane(paneId, wstabCont);

    addCSS(wstab, 'itab-sel');
    removeCSS(wstabCont, 'dn');
    addCSS(wstabCont, 'db');

    if (!newRootCont.Tabs) {
        newRootCont.Tabs = [];
    }
    newRootCont.Tabs[newRootCont.Tabs.length] = wstab;
    wstab.Index = newRootCont.Tabs.length - 1;

    // Adding Tab to its parent Tab container
    wstabp.insertBefore(wstab, wstabp.lastElementChild);

    newRootCont.ListPane = true;
    if (!newRootCont.ListPanes) {
        newRootCont.ListPanes = {};
    }
    // Tab name of List item e.g Documents
    newRootCont.ListPanes[mplistId] = wstab;

    if (!newRootCont.MultiPaneConts) {
        //newRootCont.MultiPaneConts = {};
        newRootCont.MultiPaneConts = oldRootCont.MultiPaneConts;
    }
    // Tab name of List Parent item e.g Document
    //newRootCont.MultiPaneConts[mpparentId] = wstab;

    var bscontref = document.getElementById(bscontid);
    bscontref.WDeskRespMergedInfo.InterfacesCont[bscontref.WDeskRespMergedInfo.InterfacesCont.length] = newRootCont;

    return newRootCont;
}

function addBSSlider(siblingRef, rowIndex, rowSpan, colSpan, lir, rir) {
    var element = document.createElement('div');
    addCSS(element, 'ws-sld');
    element.style.width = CLIENT_COMPONENT_SPACING_WIDTH + 'px';
    element.style.height = siblingRef.style.height;
    if (pageDirection == "ltr") {
    element.style.right = '1px';
    }else{
    element.style.right = '-8px';    
    }
    element.LeftConts = [siblingRef];
    element.RightConts = [];
    element.Height = 0;
    element.Class = colSpan;
    element.SRI = rowIndex; // starting row index
    element.ERI = rowIndex + rowSpan - 1; // end row index
    element.id = "ws-slider";
    element.LGLR = null; // stores the reference of Local grid line which slider has just crossed 
    element.LIR = lir; // stores the reference of left interface container
    element.RIR = rir; // stores the reference of right interface container
    element.onmousedown = function(e) {
        e = e || window.event;
        this.MSS = 1;
        cancelBubble(e);
    }
    element.onmouseup = function(e) {
        e = e || window.event;
        if (this.MSS == 1) {
            this.MSS = 0;
            if (this.LGLR != null) {
                updateInterfaceLayout(this);
            }

            this.LGLR = null;
        }

        cancelBubble(e);
    }

    siblingRef.parentNode.appendChild(element);

    return element;
}

function postWDeskRespDeviceLayout(bscontref, bWindowResized) {
    // bscontref: Bootstrap container reference
    bWindowResized = (typeof bWindowResized == 'undefined') ? true : bWindowResized;

    if (!bMobileDevice) {
        // Large device device
        if (bWindowResized) {
            if (editlayout == 'Y') {
                renderEditLayout();
                cancelSaveRespLayout();
            }
        }
        if (typeof setInitialViewState != "undefined") {
            if (typeof viewStateChangeTimerId != 'undefined' && viewStateChangeTimerId) {
                clearTimeout(viewStateChangeTimerId);
            }
            viewStateChangeTimerId = setTimeout(function () {
                setInitialViewState(bscontref, true, false)
            }, 200);
        }
    } else {
        // Mobile device e.g Mobile and Tab (Portrait as well as Landscape)
        if (bWindowResized && window.frames['progressFrame'] && typeof window.frames['progressFrame'].cvRefresh() != 'undefined') {
            window.frames['progressFrame'].cvRefresh();
        }
    }

    /* hideWDSubMenu();
     showHideMoreOpt();*/
    hideAllOAPMenu(null);
    //if(bWindowResized){
    resizeDocOptions(bMobileDevice);
//}
}

function getMultiPaneContsValue(contRef) {
    var bMultiPane = false;

    if (contRef.parentNode.MultiPaneConts) {
        if (contRef.tid && contRef.parentNode.MultiPaneConts[contRef.tid]) {
            bMultiPane = contRef.parentNode.MultiPaneConts[contRef.tid].MultiPane;
            bMultiPane = (typeof bMultiPane == 'undefined') ? false : bMultiPane;
        }
    }

    return bMultiPane;
}

function addPane(contRef, tabName, paneId, bMultiPane, licon, ricon, paneHandlers, bListPane) {
    bMultiPane = (typeof bMultiPane == 'undefined') ? false : bMultiPane;
    paneId = (typeof paneId == 'undefined') ? tabName : paneId;
    licon = (typeof licon == 'undefined') ? '' : licon;
    ricon = (typeof ricon == 'undefined') ? '' : ricon;
    bListPane = (typeof bListPane == 'undefined') ? false : bListPane;
    paneHandlers = (typeof paneHandlers == 'undefined') ? null : paneHandlers;
    var paneWrapper = null;

    var wsTabsContWrapper = contRef.parentNode.firstElementChild;
    var wsTabsCont = wsTabsContWrapper.firstElementChild;

    if (wsTabsCont) {
        var lastTabRef = wsTabsCont.lastElementChild;

        if (wsTabsCont.SelTab) {
            removeCSS(wsTabsCont.SelTab, 'itab-sel');
        }

        paneWrapper = document.createElement('div');
        paneWrapper.id = paneId;
        addCSS(paneWrapper, 'pg');
        wsTabsCont.insertBefore(paneWrapper, lastTabRef);
        paneWrapper.ViewerCont = contRef;

        if (bMultiPane) {
            paneWrapper.MultiPane = bMultiPane;
        }

        // For single pane, storing multiple viewers
        paneWrapper.Viewers = {};

        //Selects this pane's Tab
        wsTabsCont.SelTab = paneWrapper;
        wsTabsCont.MultiPane = bMultiPane;
        wsTabsCont.VisibleTabs = true;

        var element = document.createElement('div');
        element.className = licon;
        paneWrapper.appendChild(element);

        element = document.createElement('div');
        element.innerHTML = tabName;
        element.title = tabName;
        paneWrapper.appendChild(element);

        element = document.createElement('div');
        element.className = ricon;
        paneWrapper.appendChild(element);

        if (!bListPane) {
            element.onclick = function(event) {
                var paneId = this.parentNode.id;

                var closeHandler = null;
                if (paneHandlers != null) {
                    closeHandler = paneHandlers['PaneClose'];
                }

                var nextPaneRef = removePane(this.parentNode, contRef);

                if (closeHandler != null) {
                    var newPaneId = (nextPaneRef == null || (typeof nextPaneRef == 'undefined')) ? '0' : nextPaneRef.id;
                    closeHandler(paneId, newPaneId);
                }

                cancelBubble(event);
            }


            removeCSS(contRef, 'dn');
            addCSS(contRef, 'db');
        }

        if (bMultiPane) {
            if ((wsTabsCont.children.length - 1) <= 1) {
                // If one pane left excluding dummy pane
                addCSS(element, 'dn');
            } else {
                removeCSS(wsTabsCont.children[wsTabsCont.children.length - 1].children[2], 'dn');
            }
        } else {
            var skipChildCount = 1;
            if (contRef.parentNode.ListPane) {
                skipChildCount = 2;
            }

            if ((wsTabsCont.children.length - 1) <= skipChildCount) {
                // If one pane left excluding dummy pane and ListPane
                addCSS(element, 'dn');
            } else {
                // Show ricon            
                removeCSS(wsTabsCont.children[wsTabsCont.children.length - 1].children[2], 'dn');
            }
        }

        var bVisibleTabs = hasViewableTabs(wsTabsCont);
        if (bVisibleTabs) {
            var wsTabsWrapper = wsTabsCont.parentNode;
            var rd = getRealDimension(wsTabsWrapper);
            if (wsTabsWrapper != null)
                wsTabsWrapper.parentNode.style.paddingBottom = rd.Height + 'px';
        }

        if (bMultiPane || bListPane || contRef.parentNode.ListPane) {
            // Initialize Pane click and close handlers
            initPaneEventListner(paneWrapper, paneHandlers);

            // By default call this Pane click handlers
            /*var clickHandler = null;
             if(paneHandlers != null){
             clickHandler = paneHandlers['PaneClick'];
             }
             
             if(clickHandler != null){
             clickHandler(paneId);
             }*/
        }

        if (bMobileDevice) {
            var bMultiPaneSupported = false;

            var multiPaneObj = multiPaneInterfaces[contRef.tid];

            if (multiPaneObj && multiPaneObj.MultiPane) {
                bMultiPaneSupported = true;
            }

            if (wsTabsCont.children.length <= 2 && !bMultiPaneSupported && !contRef.ListPane) {
                // If single Tab (excluding dummy tab) then hide
                if (wsTabsWrapper != null)
                {
                    addCSS(wsTabsWrapper, 'ws-tabw dn');
                    addCSS(wsTabsCont, 'ws-tabp');
                    wsTabsWrapper.parentNode.VisibleTabs = false;
                }
            } else {
                if (wsTabsWrapper != null) {
                    removeCSS(wsTabsWrapper, 'dn');
                    addCSS(wsTabsWrapper, 'ws-tabw df');
                    removeCSS(wsTabsCont, 'dn');
                    addCSS(wsTabsCont, 'ws-tabp');
                    wsTabsWrapper.parentNode.VisibleTabs = true;
                }
            }
        } else {
            if (wsTabsWrapper != null) {
                removeCSS(wsTabsWrapper, 'dn');
                addCSS(wsTabsWrapper, 'ws-tabw df');
                removeCSS(wsTabsCont, 'dn');
                addCSS(wsTabsCont, 'ws-tabp');
                wsTabsWrapper.parentNode.VisibleTabs = true;
            }
        }

        // Set current selected tab to this pane and renders current viewer 
        renderPane(paneId);

        updatePanes(contRef);
    }

    return paneWrapper;
}

function updatePane(contRef, paneId, tabName, bMultiPane, licon, ricon, bAttachListener) {
    bMultiPane = (typeof bMultiPane == 'undefined') ? false : bMultiPane;
    licon = (typeof licon == 'undefined') ? '' : licon;
    ricon = (typeof ricon == 'undefined') ? '' : ricon;
    bAttachListener = (typeof bAttachListener == 'undefined') ? false : bAttachListener;

    var wsTabsContWrapper = contRef.previousElementSibling;
    var wsTabsCont = wsTabsContWrapper.firstElementChild;

    if (wsTabsCont) {
        var tabElementsGroup = null;

        var paneRef = document.getElementById(paneId);
        if (paneRef) {
            tabElementsGroup = paneRef;
        }

        if (tabElementsGroup) {
            var firstChild = tabElementsGroup.children[0];
            firstChild.className = licon;

            var secondChild = tabElementsGroup.children[1];
            secondChild.innerHTML = tabName;

            var thirdChild = tabElementsGroup.children[2];
            thirdChild.className = ricon;
        }
    }
}

function linkViewerToPane(paneId, viewerRef) {
    var paneRef = document.getElementById(paneId);
    if (paneRef) {
        paneRef.SelViewer = viewerRef;

        if (paneRef.parentNode.MultiPane) {
            paneRef.Viewers[paneId] = viewerRef;

            if (paneRef.parentNode.SelTab == paneRef) {
                if (paneRef.ViewerCont) {
                    removeCSS(paneRef.ViewerCont, 'dn');
                    addCSS(paneRef.ViewerCont, 'db');
                }
            }
        } else {
            // Single Pane with one Tab only, but can have multiple viewer

            if (paneRef.Viewers[paneId]) {
                paneRef.Viewers[paneId][viewerRef.id] = viewerRef;
            } else {
                paneRef.Viewers[paneId] = {};
                paneRef.Viewers[paneId][viewerRef.id] = viewerRef;
            }
        }
    }
}

function linkOpallToPane(paneId, opall) {
    var paneRef = document.getElementById(paneId);
    if (paneRef) {
        if (paneRef.parentNode.Multipane) {
            paneRef.Opall = opall;
        } else {
            paneRef.Opall = opall;
        }
    }
}

function getPaneViewer(paneId) {
    var paneViewer = null;

    var paneRef = document.getElementById(paneId);
    if (paneRef) {
        if (paneRef.parentNode.Multipane) {
            paneViewer = paneRef.Viewers[paneId];
        } else {
            paneViewer = paneRef.Viewers[paneId];
        }
    }

    return paneViewer;
}

function getOpallForPane(paneId) {
    var opallRef = null;
    var paneRef = document.getElementById(paneId);

    if (paneRef) {
        if (paneRef.parentNode.Multipane) {
            opallRef = paneRef.Opall;
        } else {
            opallRef = paneRef.Opall;
        }
    }

    return opallRef;
}

function isPaneSelected(paneId) {
    var bPaneSelected = false;

    var paneRef = document.getElementById(paneId);
    if (paneRef) {
        var wsTabsCont = paneRef.parentNode;
        if (wsTabsCont.SelTab == paneRef) {
            bPaneSelected = true;
        }
    }

    return bPaneSelected;
}

function renderPane(paneId) {
    selectPane(paneId);

    var paneRef = document.getElementById(paneId);
    var wsTabsCont = paneRef.parentNode;

    if (wsTabsCont.SelTab) {
        var wsPaneList = wsTabsCont.getElementsByClassName('pg');
        if (wsPaneList) {
            for (var i = 0; i < wsPaneList.length; i++) {
                if (wsPaneList[i].SelViewer) {
                    if (wsTabsCont.SelTab != wsPaneList[i]) {
                        // Multi Pane, Each pane having single viewer

                        removeCSS(wsPaneList[i], 'itab-sel');
                        removeCSS(wsPaneList[i].SelViewer, 'db');
                        addCSS(wsPaneList[i].SelViewer, 'dn');
                    } else {
                        if (wsTabsCont.MultiPane) {
                            removeCSS(wsPaneList[i].SelViewer, 'dn');
                            addCSS(wsPaneList[i].SelViewer, 'db');
                        } else {
                            // Single Pane with one Tab only, but can have multiple viewer
                            if (wsPaneList[i].Viewers) {
                                var viewers = getObjectValues(wsPaneList[i].Viewers);
                                if (viewers) {
                                    // Single pane containes only one key
                                    viewers = viewers[0];

                                    for (var key in viewers) {
                                        if (wsPaneList[i].SelViewer != viewers[key]) {
                                            removeCSS(viewers[key], 'db');
                                            addCSS(viewers[key], 'dn');
                                        } else {
                                            removeCSS(viewers[key], 'dn');
                                            addCSS(viewers[key], 'db');
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

function selectPane(paneId) {
    var bPaneSelected = false;
    var paneRef = document.getElementById(paneId);

    if (paneRef) {
        removeCSS(paneRef.parentNode.SelTab, 'itab-sel');
        addCSS(paneRef, 'itab-sel');

        paneRef.parentNode.SelTab = paneRef;
        bPaneSelected = true;
    }

    return bPaneSelected;
}

function initPaneEventListner(paneRef, paneHandlers) {
    paneRef.onclick = function(event) {
        var paneRef = this.parentNode;
        var paneContRef = paneRef.parentNode;

        if (paneContRef.SelTab == paneRef) {
            return;
        }

        var paneId = this.id, clickHandler = null;

        if (paneHandlers != null) {
            clickHandler = paneHandlers['PaneClick'];
        }

        if (clickHandler != null) {
            clickHandler(paneId);
        }

        renderPane(paneId);
    }
}

function updatePanes(contRef) {
    updateInterfaceTabs(contRef.parentNode);
}

function removePane(paneRef, contRef) {
    // Remove Pane option will be available only for Multi Pane viewers

    //var paneRef = thisRef.parentNode;
    var paneViewerRef = paneRef.Viewers;
    var paneContRef = paneRef.parentNode;
    var bPaneSelected = false, nextPaneRef = null;

    if (paneContRef.SelTab == paneRef) {
        nextPaneRef = paneRef.nextElementSibling;

        if (nextPaneRef) {
            bPaneSelected = selectPane(nextPaneRef.id);
        }

        if (!bPaneSelected) {
            // If no Next pane then select previous pane

            nextPaneRef = paneRef.previousElementSibling;
            if (nextPaneRef) {
                bPaneSelected = selectPane(nextPaneRef.id);
            }
        }
    }

    // Remove Pane Viewer
    var viewerObj = getObjectValues(paneViewerRef), viewerObjKey;
    if (viewerObj) {
        // Multi Pane viewer has single key
        /*viewerObjKey = Object.keys(viewerObj[0]);
         viewerObj[0][viewerObjKey].parentNode.removeChild(viewerObj[0][viewerObjKey]);*/
        if (paneRef.parentNode.MultiPane) {
            viewerObj[0].parentNode.removeChild(viewerObj[0]);
        } else {
            viewerObjKey = Object.keys(viewerObj[0]);
            viewerObj[0][viewerObjKey].parentNode.removeChild(viewerObj[0][viewerObjKey]);
        }
    }

    // Remove Pane Tab
    paneContRef.removeChild(paneRef);

    if (nextPaneRef && nextPaneRef.ListPaneTab) {
        // If List Pane then hide selected pane's viewer container
        removeCSS(contRef, 'db');
        addCSS(contRef, 'dn');
    }

    if (bPaneSelected) {
        // If Pane removed was currently selected then select next opened pane's viewer
        viewerObj = getObjectValues(nextPaneRef.Viewers);
        if (viewerObj) {
            // Multi Pane viewer has single key
            /*viewerObjKey = Object.keys(viewerObj[0]);
             
             removeCSS(viewerObj[0][viewerObjKey], 'dn');
             addCSS(viewerObj[0][viewerObjKey], 'db');*/

            removeCSS(viewerObj[0], 'dn');
            addCSS(viewerObj[0], 'db');
        }
    }

    if ((paneContRef.children.length - 1) == 1) {
        // If one pane left excluding dummy pane, hide close button
        addCSS(paneContRef.firstElementChild.children[2], 'dn');
    }

    updatePanes(contRef);

    return nextPaneRef;
}
function getPanelHeight(PSide, showSB) {
    showSB = (typeof showSB == 'undefined') ? false : showSB;
    var rd = '';
    switch (PSide) {
        case 'L':
            {
                var lsbContRef = document.getElementsByClassName('lsb');
                lsbContRef = (lsbContRef && lsbContRef.length > 0) ? lsbContRef[0] : null;
                if (lsbContRef) {
                    if (showSB && hasCSS(lsbContRef, 'dn')) {
                        removeCSS(lsbContRef, 'dn');
                        addCSS(lsbContRef, 'db')
                    }
                    rd = getRealDimension(lsbContRef).Height;
//                if(showSB && hasCSS(lsbContRef,'db')) {removeCSS(lsbContRef,'db');addCSS(lsbContRef,'dn')}
                }
                break;
            }
        case 'R':
            {
                var rsbContRef = document.getElementsByClassName('rsb');
                rsbContRef = (rsbContRef && rsbContRef.length > 0) ? rsbContRef[0] : null;
                if (rsbContRef) {
                    if (showSB && hasCSS(rsbContRef, 'dn')) {
                        removeCSS(rsbContRef, 'dn');
                        addCSS(rsbContRef, 'db')
                    }
                    rd = getRealDimension(rsbContRef).Height;
//                if(showSB && hasCSS(rsbContRef,'db')) {removeCSS(rsbContRef,'db');addCSS(rsbContRef,'dn')}
                }
                break;
            }
        default:
            {
                //            rd = getRealDimension(document.getElementById(bscontid)).Height;    
            }
    }
    return rd;
}
function getPanelWidth(PSide) {
    var rd = '';
    switch (PSide) {
        case 'L':
            {
                var lsbContRef = document.getElementsByClassName('lsb');
                lsbContRef = (lsbContRef && lsbContRef.length > 0) ? lsbContRef[0] : null;

                if (lsbContRef)
                    rd = getRealDimension(lsbContRef).Width;
                break;
            }
        case 'R':
            {
                var rsbContRef = document.getElementsByClassName('rsb');
                rsbContRef = (rsbContRef && rsbContRef.length > 0) ? rsbContRef[0] : null;
                if (rsbContRef)
                    rd = getRealDimension(rsbContRef).Width;
                break;
            }
        default:
            {
                //            rd = getRealDimension(document.getElementById(bscontid)).Width;    
            }
    }
    return rd;
}

function addTab(index, currentChild, wsTabsCont, interfaceTab, origTabValue, origTabViewableValue, interfaceName) {
    interfaceTab.ViewRight = true;

    currentChild.Tabs[currentChild.Tabs.length] = interfaceTab;
    interfaceTab.Index = currentChild.Tabs.length - 1;

    // Store Tab's original Name
    interfaceTab.OTN = origTabValue;
    
    if(interfaceName == "SAPGUIAdapter"){
        interfaceTab.innerHTML = origTabValue + " ("+origTabViewableValue+")";
    } else {    
        interfaceTab.innerHTML = getInterfaceDisplayValue(interfaceTab);
    }
    
    interfaceTab.RootCont = currentChild;
    interfaceTab.MultiPane = false;

    if (index == 0) {
        // Save reference of selected tab into its parent
        wsTabsCont.SelTab = interfaceTab;
        addCSS(interfaceTab, 'itab-sel');
    }

    initTabEventListner(interfaceTab);

    return 1;
}

function initMultiTabInterfaces(index, currentChild, wsTabsCont, interfaceTab, strValue) {
    var wDeskJson = getCurrentWDeskJason();
    var nextSibling = interfaceTab.nextElementSibling;

    wsTabsCont.removeChild(interfaceTab);

    var addedTabs = 0, element = null;
    var interfaces = null, interfaceKeys = [], interfacesValues = [];

    if (wDeskJson.WDeskLayout.InterfacesTabs) {
        /*
         "WDeskLayout": {"InterfacesTabs": 
         { "SAPGUIAdapter": {"SAP0": "SAPDefId1", "SAP1": "SAPDefId2"}},
         { "TaskView": {"TaskView": "TaskView", "CaseView": "CaseView"}}
         }
         */

        interfaces = wDeskJson.WDeskLayout.InterfacesTabs[strValue];
        if (interfaces) {       
            var i = 0;
            for (var key in interfaces) {
                if (strValue == "SAPGUIAdapter") {
                    key = "SAP" + i++;
                }

                interfaceKeys[interfaceKeys.length] = key;
                if (interfaces.hasOwnProperty(key)) {
                    interfacesValues[interfacesValues.length] = interfaces[key];
                }
            }
        }
    }

    if (interfaceKeys && (interfaceKeys.length == 0)) {
        interfaceKeys = [strValue];
        interfacesValues = [strValue];
    }

    if (interfaceKeys != null && interfaceKeys != undefined)
        for (var i = 0; i < interfaceKeys.length; i++) {
            element = document.createElement('div');
            element.innerHTML = interfaceKeys[i];

            if (nextSibling == null) {
                wsTabsCont.appendChild(element);
            } else {
                wsTabsCont.insertBefore(element, nextSibling);
            }

            addedTabs += addTab(index + i, currentChild, wsTabsCont, element, interfaceKeys[i], interfacesValues[i], strValue);
        }

    return addedTabs;
}

function toggleRespMode() {
    bMobileDevice = !bMobileDevice;

    getRespInterfaceView();
    reRenderRespWDesk();
}

function reRenderRespWDesk() {
    resetRespVariables();
    renderRespWDesk();
}

function isMutiPane(contId) {
    var contRef = getIntContRef(null, contId);
	if(contRef == null)
	{
	refreshDocPanel();
	}
    var bMultiPane = false;

    if (bMobileDevice) {
        //bMultiPane = getMultiPaneValue(contRef);
        bMultiPane = (typeof contRef.parentNode.MultiPane == 'undefined') ? false : contRef.parentNode.MultiPane;
    } else {
        bMultiPane = (typeof contRef.parentNode.MultiPane == 'undefined') ? false : contRef.parentNode.MultiPane;
    }

    return bMultiPane;
}

function getMultiPaneValue(contRef) {
    var bMultiPane = false;

    if (contRef.parentNode.MultiPaneConts) {
        if (contRef.tid && contRef.parentNode.MultiPaneConts[contRef.tid]) {
            bMultiPane = contRef.parentNode.MultiPaneConts[contRef.tid].MultiPane;
            bMultiPane = (typeof bMultiPane == 'undefined') ? false : bMultiPane;
        }
    } else {
        bMultiPane = (typeof contRef.parentNode.MultiPane == 'undefined') ? false : contRef.parentNode.MultiPane;
    }

    return bMultiPane;
}

function resetRespVariables() {
    clearDocPanes();
    resetWDeskPanels();
}

function reloadRespWDeskInterfaces() {
    resetRespVariables();
    reloadWDeskPanels();

    resetInterfaceTabs();
    reloadWDeskInerfaces();
}

function resetInterfaceTabs() {
    if (!bMobileDevice) {
        resetMultiPaneConts();
    } else {
        resetMergedMultiPaneConts();
    }
}

function resetMultiPaneConts(intName) {
    intName = (typeof intName != 'undefined')? intName: null;
    var bscontref = document.getElementById(bscontid);
    var interfaceCont = null, tempInterfaceCont = null;

    for (var i = 0; i < bscontref.WDeskRespBaseInfo.InterfacesCont.length; i++) {
        interfaceCont = bscontref.WDeskRespBaseInfo.InterfacesCont[i];
        if (interfaceCont.MultiPaneConts) {
            var key = Object.keys(interfaceCont.MultiPaneConts);
            if (key.length > 0) {
                
                if(intName != null){
                   tempInterfaceCont = interfaceCont.MultiPaneConts[intName];
                   if(!tempInterfaceCont){
                       continue;
                   }
                }                
                
                removeAllChildNodes(interfaceCont.TabsCont);

                addDummyTab(interfaceCont.TabsCont);

                addCSS(interfaceCont.TabsContParent, 'ws-tabw dn');
                addCSS(interfaceCont.TabsCont, 'ws-tabp');

                interfaceCont.TabsCont.SelTab = null;
                interfaceCont.TabsCont.MultiPane = false;
                interfaceCont.TabsCont.VisibleTabs = false;
            }
        }
    }
}

function resetMergedMultiPaneConts() {
    var bscontref = document.getElementById(bscontid);
    var interfaceCont = null;

    // MultiPane in Mobile starts from firat child
    for (var i = 1; i < bscontref.WDeskRespMergedInfo.InterfacesCont.length; i++) {
        interfaceCont = bscontref.WDeskRespMergedInfo.InterfacesCont[i];
        if (interfaceCont.MultiPaneConts) {
            var key = Object.keys(interfaceCont.MultiPaneConts);
            if (key.length > 0) {
                var contRef = getIntContRef(null, key);

                if (contRef) {
                    removeCSS(contRef, 'db');
                    addCSS(contRef, 'dn');
                }

                for (var j = 0; j < interfaceCont.TabsCont.children.length; j++) {
                    if (interfaceCont.TabsCont.children[j].ListPaneTab && !interfaceCont.TabsCont.children[j].Dummy) {
                        addCSS(interfaceCont.TabsCont.children[j], 'itab-sel');
                        removeCSS(interfaceCont.TabsCont.children[j].SelViewer, 'dn');
                        addCSS(interfaceCont.TabsCont.children[j].SelViewer, 'db');
                    }

                    if (!interfaceCont.TabsCont.children[j].ListPaneTab && !interfaceCont.TabsCont.children[j].Dummy) {
                        interfaceCont.TabsCont.removeChild(interfaceCont.TabsCont.children[j]);
                        j--;
                    }
                }

                addCSS(interfaceCont.TabsContParent, 'ws-tabw');
                addCSS(interfaceCont.TabsCont, 'ws-tabp');

                //interfaceCont.TabsCont.SelTab=null;
                interfaceCont.TabsCont.MultiPane = false;
                interfaceCont.TabsCont.VisibleTabs = false;
            }
        }
    }
}

function reloadWDeskPanels() {
    if (!bMobileDevice) {
        var sbContRef = document.getElementsByClassName('lsb');
        sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;

        if (sbContRef != null) {
            var lSelPanelTab = '';
            if (sbContRef.SelPanelTabRef) {
                lSelPanelTab = sbContRef.SelPanelTabRef.id;
                loadWdSidebarHandler(lSelPanelTab, sbContRef);
            }
        }

        sbContRef = document.getElementsByClassName('rsb');
        sbContRef = (sbContRef && sbContRef.length > 0) ? sbContRef[0] : null;

        if (sbContRef != null) {
            if (sbContRef.SelPanelTabRef) {
                lSelPanelTab = sbContRef.SelPanelTabRef.id;
                loadWdSidebarHandler(lSelPanelTab, sbContRef);
            }
        }
    } else {
// No need as In Mobile mode there will be no Side panels
    }
}

function hideWdeskSidebar(sbdir) {
    if (bMobileDevice) {
        return;
    }

    var sbContRef = null, bOverlay = false;

    if (sbdir == 'L' || sbdir == 'H') {
        sbContRef = document.getElementsByClassName('lsb');
        sbContRef = sbContRef[0];
        if (sbContRef) {
            bOverlay = hasCSS(sbContRef, 'overlay');
            if (bOverlay && sbContRef.SelPanelTabRef) {
                if ((sbdir == 'H') && (sbContRef.Expanded == 'false')) {

                } else {
                    sbContRef.SelPanelTabRef.click();
                }
            }
        }
    }

    if (sbdir == 'R' || sbdir == 'H') {
        sbContRef = document.getElementsByClassName('rsb');
        sbContRef = sbContRef[0];
        if (sbContRef) {
            bOverlay = hasCSS(sbContRef, 'overlay');
            if (bOverlay && sbContRef.SelPanelTabRef) {
                if ((sbdir == 'H') && (sbContRef.Expanded == 'false')) {

                } else {
                    sbContRef.SelPanelTabRef.click();
                }
            }
        }
    }
}

function hideWdeskSidebarHandler(source) {
    var bSBEvent = false;

    while (source) {
        if (hasCSS(source, 'lsb') || hasCSS(source, 'rsb') || hasCSS(source, 'lpt') || hasCSS(source, 'rpt')) {
            bSBEvent = true;
            break;
        }
        source = source.parentNode;
    }

   /* if (!bSBEvent) {
        hideWdeskSidebar('H');
    } */
}

function regEventListener(evtObj) {
    if (evtObj != evtObj.document) {
        evtObj = evtObj.document;
    }

    if (evtObj.addEventListener) {
        evtObj.addEventListener("click", function(e) {
            e = e || evtObj.event;
            var source = e.target || e.srcElement;

            hideWdeskSidebarHandler(source);
        }, false);
    } else if (evtObj.attachEvent) {
        evtObj.attachEvent("onclick", function(e) {
            e = e || evtObj.event;
            var source = e.target || e.srcElement;

            hideWdeskSidebarHandler(source);
        });
    }
}

function getIntDisplayValueById(value) {
    var localeValue = value;

    if (value != null && (value.length > 0)) {
        var intRef = document.getElementById(value);
        if (intRef) {
            localeValue = getInterfaceDisplayValue(intRef);
        }
    }

    return localeValue;
}

function hideDocPanes() {
    var docContRef = getIntContRef(null, 'Document');
    if (docContRef) {
        var wsTabsWrapper = docContRef.previousElementSibling;
        if (wsTabsWrapper) {
            removeCSS(wsTabsWrapper, 'df');
            addCSS(wsTabsWrapper, 'dn');
        }
    }
}

function getDocPaneCount() {
    var pCount = 0;
    try {
        var docContRef = getIntContRef(null, 'Document');
        var wsTabsContWrapper = docContRef.parentNode.firstElementChild;
        var wsTabsCont = wsTabsContWrapper.firstElementChild;
        pCount = wsTabsCont.childElementCount - 1
    } catch(e){
    }
    
    return (pCount <= 0) ? 0 : pCount;
}

function updateWDSideBarWidth(objSbContRef, icustomWidth){
    
    if(icustomWidth == "" || icustomWidth  < 280){
        icustomWidth  = 280;
    }
    
    objSbContRef.style.width = icustomWidth + "px";
}

function setInitialViewState(bscontRef, bUpdateViewState, bHideAllControls) {
    if(!bUpdateViewStateGlobal) {
        bUpdateViewStateGlobal = true;
        bUpdateViewState = false;
    }
    bscontRef = (typeof bscontRef == 'undefined' || bscontRef == null) ? document.getElementById(bscontid) : bscontRef;
    bUpdateViewState = (typeof bUpdateViewState == 'undefined' || bUpdateViewState == null) ? true : bUpdateViewState;
    bHideAllControls = (typeof bHideAllControls == 'undefined' || bHideAllControls == null) ? false : bHideAllControls;
    
    if (bUpdateViewState && bRespWdesk && respWDeskColumns == 2) {
        var leftInterfaceRef = $(bscontRef.WDeskRespBaseInfo.InterfacesCont[0].parentNode);
        var rightInterfaceRef = $(bscontRef.WDeskRespBaseInfo.InterfacesCont[1].parentNode);
        initialViewState.LeftInterfaceWidth = Math.floor(leftInterfaceRef.width());
        initialViewState.LeftInterfaceLeft = Math.floor(leftInterfaceRef.position().left);
        initialViewState.LeftInterfaceTop = Math.floor(leftInterfaceRef.position().top);
        initialViewState.LeftInterfaceClass = leftInterfaceRef.attr("class");
        initialViewState.RightInterfaceWidth = Math.floor(rightInterfaceRef.width());
        initialViewState.RightInterfaceLeft = Math.floor(rightInterfaceRef.position().left);
        initialViewState.RightInterfaceTop = Math.floor(rightInterfaceRef.position().top);
        initialViewState.RightInterfaceClass = rightInterfaceRef.attr("class");
    }
    
    if (!bRespWdesk || respWDeskColumns != 2 || bHideAllControls) {
        hideAnimControl($("#leftExpand"));
        hideAnimControl($("#rightExpand"));
        hideAnimControl($("#leftCollapse"));
        hideAnimControl($("#rightCollapse"));
    } else {
        if (collapsedInterface == "" || collapsedInterface == "None") {
            showAnimControl($("#leftExpand"));
            showAnimControl($("#rightExpand"));
            hideAnimControl($("#leftCollapse"));
            hideAnimControl($("#rightCollapse"));
        } else if (collapsedInterface == "Right") {
            hideAnimControl($("#leftExpand"));
            hideAnimControl($("#rightExpand"));
            showAnimControl($("#leftCollapse"));
            hideAnimControl($("#rightCollapse"));
            if (editlayout == 'Y') {
                hideAnimControl($("#wdesk\\:editLayoutlbl"));
            }
        } else if (collapsedInterface == "Left") {
            hideAnimControl($("#leftExpand"));
            hideAnimControl($("#rightExpand"));
            hideAnimControl($("#leftCollapse"));
            showAnimControl($("#rightCollapse"));
            if (editlayout == 'Y') {
                hideAnimControl($("#wdesk\\:editLayoutlbl"));
            }
        }
    }
}

function repositionCollapsedInterface() {
    if (collapsedInterface == "Right") {
        toggleInterfaceHandler("leftCollapse", false);
    } else if (collapsedInterface == "Left") {
        toggleInterfaceHandler("rightCollapse", false);
    }
}

function toggleInterfaceHandler(action, bShowAnimation) {
    var bscontRef = document.getElementById(bscontid);
    var leftInterfaceRef = $(bscontRef.WDeskRespBaseInfo.InterfacesCont[0].parentNode);
    var rightInterfaceRef = $(bscontRef.WDeskRespBaseInfo.InterfacesCont[1].parentNode);
    var btnLeftCollapse = $("#leftCollapse");
    var btnLeftExpand = $("#leftExpand");
    var btnRightCollapse = $("#rightCollapse");
    var btnRightExpand = $("#rightExpand");
    var btnEditLayout = $("#wdesk\\:editLayoutlbl");
    var lStyle = leftInterfaceRef.attr("style");
    var rStyle = rightInterfaceRef.attr("style");
    
    if(typeof bShowAnimation == 'undefined' || bShowAnimation == null) {
        bShowAnimation = true;
    }
    
    showAnimControl(leftInterfaceRef);
    showAnimControl(rightInterfaceRef);
    
    var animControls = {
        LeftInterfaceRef: leftInterfaceRef,
        RightInterfaceRef: rightInterfaceRef,
        LeftInterfaceClass: leftInterfaceRef.attr("class"),
        RightInterfaceClass: rightInterfaceRef.attr("class"),
        LeftInterfaceStyle: getInlineCss(lStyle, "transform, transition-property, transition-duration"),
        RightInterfaceStyle: getInlineCss(rStyle, "transform, transition-property, transition-duration")
    };
    
    leftInterfaceRef.attr("style", removeInlineCss(lStyle, "transform, transition-property, transition-duration"));
    rightInterfaceRef.attr("style", removeInlineCss(rStyle, "transform, transition-property, transition-duration"));

    if (action == "leftExpand") {
        animControls.Show = [btnLeftCollapse];
        animControls.Hide = [btnLeftExpand, btnRightCollapse, btnRightExpand, rightInterfaceRef];
        if(editlayout == 'Y') {
            animControls.Hide.push(btnEditLayout);
        }
        animControls.AnimAction = "leftExpand";        

        leftInterfaceRef.css("width", initialViewState.LeftInterfaceWidth + "px");
        leftInterfaceRef.removeAttr("class");
        
        if(!bShowAnimation) {
            leftInterfaceRef.width(initialViewState.LeftInterfaceWidth + initialViewState.RightInterfaceWidth + hPadding);
            rightInterfaceRef.css({left: initialViewState.RightInterfaceLeft + initialViewState.RightInterfaceWidth});
            animationStartCount = 1;
            doAfterAnimationFinished(animControls);
        } else {
            expandLeftInterface(leftInterfaceRef, rightInterfaceRef, animControls);
        }
    } else if(action == "leftCollapse") {
        animControls.Show = [btnLeftExpand, btnRightExpand];
        if(editlayout == 'Y') {
            animControls.Show.push(btnEditLayout);
        }
        animControls.Hide = [btnLeftCollapse, btnRightCollapse];
        animControls.AnimAction = "leftCollapse";

        leftInterfaceRef.css("width", leftInterfaceRef.width() + "px");
        leftInterfaceRef.removeAttr("class");
        
        if (!bShowAnimation) {
            leftInterfaceRef.width(initialViewState.LeftInterfaceWidth);
            rightInterfaceRef.css({left: initialViewState.RightInterfaceLeft});
            animationStartCount = 1;
            doAfterAnimationFinished(animControls);
        } else {
            collapseLeftInterface(leftInterfaceRef, rightInterfaceRef, animControls);
        }
    } else if(action == 'rightExpand') {
        animControls.Show = [btnRightCollapse];
        animControls.Hide = [btnLeftExpand, btnLeftCollapse, btnRightExpand, leftInterfaceRef];
        if(editlayout == 'Y') {
            animControls.Hide.push(btnEditLayout);
        }
        animControls.AnimAction = "rightExpand";
        
        rightInterfaceRef.css("width", initialViewState.RightInterfaceWidth + "px");
        rightInterfaceRef.removeAttr("class");
        
        if (!bShowAnimation) {
            leftInterfaceRef.css({left: -initialViewState.LeftInterfaceWidth});
            rightInterfaceRef.css({left: initialViewState.LeftInterfaceLeft});
            rightInterfaceRef.width(initialViewState.LeftInterfaceWidth + initialViewState.RightInterfaceWidth + hPadding);
            animationStartCount = 1;
            doAfterAnimationFinished(animControls);
        } else {
            expandRightInterface(leftInterfaceRef, rightInterfaceRef, animControls);
        }        
    } else if(action == 'rightCollapse') {
        animControls.Show = [btnLeftExpand, btnRightExpand];
        if(editlayout == 'Y') {
            animControls.Show.push(btnEditLayout);
        }
        animControls.Hide = [btnRightCollapse, btnLeftCollapse];
        animControls.AnimAction = "rightCollapse";
        
        rightInterfaceRef.css("width", rightInterfaceRef.width() + "px");
        rightInterfaceRef.removeAttr("class");
        
        if (!bShowAnimation) {
            leftInterfaceRef.css({left: initialViewState.LeftInterfaceLeft});
            leftInterfaceRef.width(initialViewState.LeftInterfaceWidth);
            rightInterfaceRef.css({left: initialViewState.RightInterfaceLeft});
            rightInterfaceRef.width(initialViewState.RightInterfaceWidth);
            animationStartCount = 1;
            doAfterAnimationFinished(animControls);
        } else {
            collapseRightInterface(leftInterfaceRef, rightInterfaceRef, animControls);
        }
    }
}

function expandLeftInterface(leftInterfaceRef, rightInterfaceRef, animControls) {
    if (animationInProgress) {
        return false;
    }

    animationInProgress = true;
    animationStartCount = 2;

    leftInterfaceRef.animate(
        {
            width: initialViewState.LeftInterfaceWidth + initialViewState.RightInterfaceWidth + hPadding
        },
        animDuration,
        function () {
            doAfterAnimationFinished(animControls);
        }
    );

    rightInterfaceRef.animate(
        {
            left: initialViewState.RightInterfaceLeft + initialViewState.RightInterfaceWidth
        },
        animDuration,
        function () {
            doAfterAnimationFinished(animControls);
        }
    );

    return true;
}

function collapseLeftInterface(leftInterfaceRef, rightInterfaceRef, animControls) {
    if (animationInProgress) {
        return false;
    }

    animationInProgress = true;
    animationStartCount = 2;

    leftInterfaceRef.animate(
        {
            width: initialViewState.LeftInterfaceWidth
        },
        animDuration,
        function () {
            doAfterAnimationFinished(animControls);
        }
    );

    rightInterfaceRef.animate(
        {
            left: initialViewState.RightInterfaceLeft
        },
        animDuration,
        function () {
            doAfterAnimationFinished(animControls);
        }
    );

    return true;
}

function expandRightInterface(leftInterfaceRef, rightInterfaceRef, animControls) {
    if (animationInProgress) {
        return false;
    }

    animationInProgress = true;
    animationStartCount = 2;

    leftInterfaceRef.animate(
        {
            left: -initialViewState.LeftInterfaceWidth
        },
        animDuration,
        function () {
            doAfterAnimationFinished(animControls);
        }
    );

    rightInterfaceRef.animate(
        {
            left: initialViewState.LeftInterfaceLeft,
            width: initialViewState.LeftInterfaceWidth + initialViewState.RightInterfaceWidth + hPadding
        },
        animDuration,
        function () {
            doAfterAnimationFinished(animControls);
        }
    );
}

function collapseRightInterface(leftInterfaceRef, rightInterfaceRef, animControls) {
    if (animationInProgress) {
        return false;
    }

    animationInProgress = true;
    animationStartCount = 2;

    leftInterfaceRef.animate(
        {
            left: initialViewState.LeftInterfaceLeft,
            width: initialViewState.LeftInterfaceWidth
        },
        animDuration,
        function () {
            doAfterAnimationFinished(animControls);
        }
    );

    rightInterfaceRef.animate(
        {
            left: initialViewState.RightInterfaceLeft,
            width: initialViewState.RightInterfaceWidth
        },
        animDuration,
        function () {
            doAfterAnimationFinished(animControls);
        }
    );

    return true;
}

function doAfterAnimationFinished(animControls) {
    animationFinishCount++;
    if (animationStartCount == animationFinishCount) {
        animationInProgress = false;
        animationStartCount = 0;
        animationFinishCount = 0;
        
        var arr_Show = animControls.Show;
        for (var i = 0; i < arr_Show.length; i++) {
            showAnimControl(arr_Show[i]);
        }
        
        var arr_Hide = animControls.Hide;
        for (var i = 0; i < arr_Hide.length; i++) {
            hideAnimControl(arr_Hide[i]);            
        }
        
        if(animControls.AnimAction == "leftExpand") {
            var classList = animControls.LeftInterfaceClass.split(/\s+/);
            for(var i=1; i<12; i++) {                
                if(classList.contains("col-lg-"+i)) {
                    classList.remove("col-lg-"+i);
                    classList.push("col-lg-12");
                }
                if(classList.contains("col-xl-"+i)) {
                    classList.remove("col-xl-"+i);
                    classList.push("col-xl-12");
                }
            }
            
            for(var i=0; i<classList.length; i++) {
                animControls.LeftInterfaceRef.addClass(classList[i]);
            }
            collapsedInterface = "Right";
        } else if(animControls.AnimAction == "rightExpand") {
            var classList = animControls.RightInterfaceClass.split(/\s+/);
            for(var i=1; i<12; i++) {
                if(classList.contains("col-lg-"+i)) {
                    classList.remove("col-lg-"+i);
                    classList.push("col-lg-12");
                }
                if(classList.contains("col-xl-"+i)) {
                    classList.remove("col-xl-"+i);
                    classList.push("col-xl-12");
                }
            }
            
            for(var i=0; i<classList.length; i++) {
                animControls.RightInterfaceRef.addClass(classList[i]);
            }
            collapsedInterface = "Left";
        } else if(animControls.AnimAction == "leftCollapse" || animControls.AnimAction == "rightCollapse") {
            animControls.LeftInterfaceRef.attr("class", initialViewState.LeftInterfaceClass);
            animControls.RightInterfaceRef.attr("class", initialViewState.RightInterfaceClass);            
            animControls.LeftInterfaceRef.css({top: initialViewState.LeftInterfaceTop, left: initialViewState.LeftInterfaceLeft});
            animControls.RightInterfaceRef.css({top: initialViewState.RightInterfaceTop, left: initialViewState.RightInterfaceLeft});
            collapsedInterface = "None";
        }
        
        animControls.LeftInterfaceRef.css("width", "");
        animControls.RightInterfaceRef.css("width", "");
    }
}

function getInlineCss(cssString, remCssProp) {
    return inlineCssHandler(cssString, remCssProp, 'keep');
}

function removeInlineCss(cssString, remCssProp) {
    return inlineCssHandler(cssString, remCssProp, 'remove');
}

function inlineCssHandler(cssString, remCssProp, keepRemovePropFlag) {
    if (typeof cssString == "undefined" || cssString == null) {
        return "";
    }
    if (typeof remCssProp == "undefined" || remCssProp == null || (!Array.isArray(remCssProp) && (remCssProp = remCssProp.trim()) == "")) {
        return cssString;
    }

    if (remCssProp.indexOf(",") > -1) {
        remCssProp = remCssProp.split(",").map(function (e) {
            return e.trim()
        }).filter(function (e) {
            return e !== undefined && e.trim().length > 0;
        });
    }

    var newCssText = cssString.trim()
            .split(";")
            .map(function (cssAttribNameVal) {
                cssAttribNameVal = cssAttribNameVal.trim().split(":");
                if (cssAttribNameVal.length == 2) {
                    var propName = cssAttribNameVal[0].trim();
                    var propVal = cssAttribNameVal[1].trim();
                    if (keepRemovePropFlag == 'keep') {
                        if ((Array.isArray(remCssProp) && remCssProp.indexOf(propName) != -1)
                                || (!Array.isArray(remCssProp) && propName === remCssProp))
                        {
                            return propName + ": " + propVal + ";";
                        }
                    } else if (keepRemovePropFlag == 'remove') {
                        if ((Array.isArray(remCssProp) && remCssProp.indexOf(propName) == -1 )
                                || (!Array.isArray(remCssProp) && propName !== remCssProp))
                        {
                            return propName + ": " + propVal + ";";
                        }
                    }
                }
            })
            .filter(function (e) {
                return e !== undefined && e.trim().length > 0;
            })
            .join("");

    return newCssText;
}

function showAnimControl(control) {
    var id = control.attr("id");
    if (typeof id != 'undefined' && id != null
            && (id == 'leftCollapse' || id == 'leftExpand' || id == 'rightCollapse' || id == 'rightExpand'))
    {
        if (control.hasClass("d-lg-none")) {
            control.removeClass("d-lg-none");
        }
        control.addClass("d-lg-inline-flex");

        if (control.hasClass("d-xl-none")) {
            control.removeClass("d-xl-none");
        }
        control.addClass("d-xl-inline-flex");
    } else {
        if (control.hasClass("dn")) {
            control.removeClass("dn");
        }
        control.addClass("db");
    }
}

function hideAnimControl(control) {
    var id = control.attr("id");
    if (typeof id != 'undefined' && id != null
            && (id == 'leftCollapse' || id == 'leftExpand' || id == 'rightCollapse' || id == 'rightExpand'))
    {
        if (control.hasClass("d-lg-inline-flex")) {
            control.removeClass("d-lg-inline-flex");
        }
        control.addClass("d-lg-none");

        if (control.hasClass("d-xl-inline-flex")) {
            control.removeClass("d-xl-inline-flex");
        }
        control.addClass("d-xl-none");
    } else {
        if (control.hasClass("db")) {
            control.removeClass("db");
        }
        control.addClass("dn");
    }
}