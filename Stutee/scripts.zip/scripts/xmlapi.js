function appendTagAndValue(tagName,tagValue)
{
    var tagAndValue="";
    if(tagValue != "")
        tagAndValue = "<" + tagName + ">" + tagValue + "</" + tagName + ">";
    return tagAndValue;
}
            
function appendTagOnly(tagName,flag)
{
    var Tag="";
    if(flag==true)
        Tag="<" + tagName + ">";
    else if(flag==false)
        Tag="</" + tagName + ">";
    return Tag;
}



function WDParser(xml){
	
	this.parseString  = xml ;
	this.indexOfPrevSearch = 0;
	
	
};

WDParser.prototype.toString = function () {
	return this.parseString ;
}

WDParser.prototype.setInputXML = function (strXML)  {
	this.parseString = strXML;
}

WDParser.prototype.getInputXML = function () {
  return this.parseString;
}

WDParser.prototype.getValue = function (tag) {

	var idTag = this.parseString.toUpperCase().indexOf("<" + tag.toUpperCase()  + ">");
			
    if (idTag == -1)
        return "";

      return (this.parseString.substring((idTag + tag.length + 2), this.parseString.toUpperCase().indexOf("</" + tag.toUpperCase()  + ">")));
}

WDParser.prototype.getValueOf = function (tag, iStart, iEnd) {

	try
        {

          if (iEnd > 0 && iEnd < iStart)
            return "";

          var idTag = this.parseString.toUpperCase().indexOf("<" + tag.toUpperCase()  + ">",
              iStart);

          if (idTag == -1)
            return "";

          if (iEnd > 0)
            if (idTag > iEnd)
              return "";
          return (this.parseString.substring((idTag + tag.length + 2),this.parseString.toUpperCase().indexOf("</" + tag.toUpperCase()  + ">", idTag)));
        }
        catch (e)
        {
          //e.printStackTrace();
		  //alert(e);
          return "";
        }

}

WDParser.prototype.getFirstValueOf = function (strTag , iStart) {
	var iStartIndex ;
   var         iEndIndex ;
   var    strData  ;
   var     strStartTag  ;
   var strEndTag ;
   var iStartOffset ;

   try
   {
     strStartTag = "<" + strTag.toUpperCase()   + ">" ;
     strEndTag = "</" + strTag.toUpperCase()   + ">" ;
     iStartOffset = iStart ;
     iStartIndex = this.parseString.toUpperCase().indexOf(strStartTag,iStartOffset);

     if(iStartIndex < 0)
       return("") ;

     iEndIndex = this.parseString.toUpperCase().indexOf(strEndTag,iStartIndex);
     if(iEndIndex <= iStartIndex)
       return("") ;

     this.indexOfPrevSearch = iStartIndex + strStartTag.length ;
     return (this.parseString.substring( (iStartIndex + strStartTag.length),
                                             this.parseString.toUpperCase().indexOf(
              strEndTag, iStartIndex)));

    }
    catch (e)
    {
      //e.printStackTrace();
      return "";
    }

	
}

WDParser.prototype.getNextValueOf = function ( strTag)	{
var iStartIndex ;
var         iEndIndex ;
var     strData  ;
var     strStartTag  ;
var strEndTag ;
var iStartOffset ;

     try
     {
       strStartTag = "<" + strTag.toUpperCase()  + ">" ;
       strEndTag = "</" + strTag.toUpperCase()  + ">" ;
       iStartOffset = this.indexOfPrevSearch ;
       iStartIndex = this.parseString.toUpperCase().indexOf(strStartTag,iStartOffset);

       if(iStartIndex < 0)
         return("") ;

       iEndIndex = this.parseString.toUpperCase().indexOf(strEndTag,iStartIndex);
       if(iEndIndex <= iStartIndex)
         return("") ;

       this.indexOfPrevSearch = iStartIndex + strStartTag.length ;
       return (this.parseString.substring( (iStartIndex + strStartTag.length),
                                               this.parseString.toUpperCase().indexOf(
                strEndTag, iStartIndex)));

      }
      catch ( e)
      {
        //e.printStackTrace();
        return "";
      }
}

WDParser.prototype.getNoOfFields= function(strTag ,  iStart ,  iEnd ) {

var iStartIndex =iStart;
var iEndIndex = 0;
var iTagCount  = 0;
var strStartTag = "<" + strTag.toUpperCase()  + ">";
var strEndTag ="</" + strTag.toUpperCase()  + ">";

    try
    {
      do 
      {
		 
        iStartIndex = this.parseString.toUpperCase().indexOf(strStartTag,iStartIndex);
        //alert("iStartIndex="+iStartIndex);
		if(iStartIndex >= 0)
        {
          if(iEnd > 0)
            {
              if(iStartIndex <= iEnd)
                {
                  iTagCount++;
                  iStartIndex = iStartIndex + strStartTag.length ;
                }
              else
                break;
            }
          else
          {
            iTagCount++;
            iStartIndex = iStartIndex + strStartTag.length ;
          }
        }

      } while(iStartIndex > 0);//end while

      return iTagCount;
    }
    catch( e)
    {

	 //alert(e);
      return 0;
    }

}

WDParser.prototype.getStringValueOf=function (sTag ,sDefaultValue , bFlag) {
    var sData="";

    try {
      sData = this.getValueOf(sTag, 0, this.parseString.length);
      if (sData=="")
        if (bFlag)
          return (sDefaultValue);
        else
          return ("");
      else
        return (sData);
    }
    catch ( e) {
      
	  //alert("from getStringValue Of="+e);
      if (bFlag)
        return (sDefaultValue);
      else
        return ("");
    }
}

 WDParser.prototype.getBoolValueOf= function( sTag , bDefaultValue ,bFlag )   {
      var sData = "";
      try {
        sData = this.getValueOf(sTag, 0, this.parseString.length);
        if (sData=="") 
		{
          if (bFlag)
            return (bDefaultValue);
          else
            return (false);
        }
        else {
          sData = sData.toUpperCase();
          if (sData=="Y" || sData=="YES" || sData=="TRUE" ||
              sData=="T")
            return true;

          if (sData=="N" || sData=="NO" || sData=="FALSE" ||
              sData=="F")
            return false;

          try {
            if (parseInt(sData) > 0)
              return true;
            else
              return false;
          }
          catch (E) {
            if (bFlag)
              return (bDefaultValue);
            else
              return (false);
          }

        } //end if
      }
      catch ( e) {
        
		//alert("from getBoolValue Of="+e);
        if (bFlag)
          return (bDefaultValue);
        else
          return (false);
      }
    }

 WDParser.prototype.getIntValueOf = function(  sTag , iDefaultValue , bFlag )  {
          var sData ="";
          try
          {
              sData = this.getValueOf(sTag, 0, this.parseString.length);

			  if (sData=="")
			  {
				  if (bFlag)
                      return (iDefaultValue) ;
                  else
                      return (0);
			  }	
              else
                  return parseInt(sData);
          }
          catch (e)
          {
			//alert("from getIntValue Of="+e);
            if (bFlag)
              return (iDefaultValue) ;
            else
              return (0) ;
          }
  }
