package com.newgen.service;

import java.io.IOException;

import org.ini4j.InvalidFileFormatException;

public class ArchiveService extends Commons{

	public static void main(String[] args) {

		while(true)
		{
			try
			{
				initializeLogger();
				loadConfiguration();
				//Loop through all the config files
				for(int i=1;i<=Integer.parseInt(totalProcess);i++)
				{
					DBConnection DB=null;
					try
					{
						loadProcessSpecificConfiguration("Config_"+i+".ini");
						logger.info("Archival started for Process: "+processName);
						System.out.println("Archival started for Process: "+processName);
						//Check whether process is simple or complex
						DB=new DBConnection();
						DB.getDbConnection();
						String processType=DB.selectSingle("select processtype from usr_0_archival_type where processname ='"+ processName +"'");
						DB.connectionClose();
						logger.info("Process Type: "+processType);
						if(processType.equalsIgnoreCase("Simple"))
						{
							Simple simpleObj=new Simple("Config_"+i+".ini");
							simpleObj.processWorkitems();
						}
						else if(processType.equalsIgnoreCase("Complex"))
						{
							Complex complexObj=new Complex("Config_"+i+".ini","Config_"+i+".xml");
							complexObj.processWorkitems();
						}

					}
					catch(Exception e)
					{
						System.out.println("Exception occured in the archival of Process: "+processName);
						e.printStackTrace();
						logger.error("Exception occured in the archival of Process: "+processName,e);
					}
					finally
					{
						DB.connectionClose();
					}
					System.out.print("Sleeping for "+Long.parseLong(sSleepTime)/1000+" seconds");
					logger.info("Sleeping for "+Long.parseLong(sSleepTime)/1000+" seconds");
					Thread.sleep(Long.parseLong(sSleepTime));
				}
			}
			catch(InvalidFileFormatException e)
			{
				System.out.println("InvalidFileFormatException occured in Archival: ");
				e.printStackTrace();
				logger.error("InvalidFileFormatException occured in Archival: "+processName,e);
			}
			catch(IOException e)
			{
				System.out.println("IOException occured in Archival: ");
				e.printStackTrace();
				logger.error("IOException occured in Archival: "+processName,e);
			}
			catch(Exception e)
			{
				System.out.println("Exception occured in Archival: ");
				e.printStackTrace();
				logger.error("Exception occured in Archival: "+processName,e);
			}
			finally
			{
				
			}
			System.out.print("Sleeping for "+Long.parseLong(sSleepTime)/1000+" seconds");
			logger.info("Sleeping for "+Long.parseLong(sSleepTime)/1000+" seconds");
			try 
			{
				Thread.sleep(Long.parseLong(sSleepTime));
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

}
