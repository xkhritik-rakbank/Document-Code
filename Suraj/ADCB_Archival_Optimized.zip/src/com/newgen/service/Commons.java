/***************************************************************************
 *       Application     : Custom Archival Utility
 *       File            : Commons.java
 *       Purpose         : This class contains commons functions of Archival tility
 *
 * Change History  :
 *********************************************************************************************************************
 * Date			Problem No          	 description                                             changed by
 *---------		---------			-----------------------                                      -------------
 *15/02/2016	CH_15022016_001		Don't Archive again if document exists with same image index Pradeep Monga
 *18/07/2016	CH_18072016_001		Data class field values are wrongly updated as field names 
 *									in case not mentioned in folder structure.					 Pradeep Monga	
 *07/04/2019	CH_07042019_001		Change in versioning concept in OD 10						 Pradeep Monga
 ***********************************************************************************************************/
package com.newgen.service;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.ini4j.Ini;
import org.ini4j.InvalidFileFormatException;

import com.newgen.AESEncryption;
import com.newgen.wfdesktop.xmlapi.WFCallBroker;

public class Commons {
	
	public static String wmsIP="";
	public static String wmsPort="";
	public static String wmsDBUrl="";
	public static String wmsDBUser="";
	public static String wmsDBPass="";
	public static String sSleepTime="";
	public static String wmsCabinet="";
	public static String wmsUser="";
	public static String wmsPass="";
	public static String edmsIP="";
	public static String edmsPORT="";
	public static String edmsCabinet="";
	public static String edmsUser="";
	public static String edmsPass="";
	public static String totalProcess="";
	public static String utilName="";
	public static String processName="";
	public static String activityname="";
	public static String extTableName="";
	public static String txnTable="";
	public static String productTable="";
	public static String sComplete="";	
	public static String batchSize="";
	public static Logger logger = Logger.getLogger(ArchiveService.class);
	
	public static void initializeLogger() throws IOException
	{
		Properties p = new Properties();
		String log4JPropertyFile=new StringBuilder().append(System.getProperty("user.dir"))
				.append(System.getProperty("file.separator")).append("log4j.properties").toString();
		System.out.println("Path of log4j file: "+log4JPropertyFile);
		p.load(new FileInputStream(log4JPropertyFile));
		PropertyConfigurator.configure(p);
		logger.info("Logger is configured successfully");
	}
	public static void loadConfiguration() throws InvalidFileFormatException, IOException, Exception
	{
		String sConfigFile=new StringBuilder().append(System.getProperty("user.dir"))
				.append(System.getProperty("file.separator")).append("config.ini").toString();
		Ini ini=new Ini(new File(sConfigFile));
		wmsIP=ini.get("WMS", "IP");
		wmsPort=ini.get("WMS", "PORT");
		wmsDBUrl=ini.get("WMS", "DBURL");
		wmsDBUser=ini.get("WMS", "DBUSER");
		wmsDBPass=ini.get("WMS", "DBPASS");
		wmsDBPass=AESEncryption.decrypt(wmsDBPass);
		sSleepTime=ini.get("WMS", "SLEEPTIME");
		wmsCabinet=ini.get("WMS", "CABINET");
		wmsUser=ini.get("WMS", "USER");
		wmsPass=ini.get("WMS", "PASS");
		wmsPass=AESEncryption.decrypt(wmsPass);
		edmsIP=ini.get("EDMS", "IP");
		edmsPORT=ini.get("EDMS", "PORT");
		edmsCabinet=ini.get("EDMS", "CABINET");
		edmsUser=ini.get("EDMS", "USER");
		edmsPass=ini.get("EDMS", "PASS");
		edmsPass=AESEncryption.decrypt(edmsPass);
		totalProcess=ini.get("CONFIG", "TOTALPROCESS");
		utilName=ini.get("UTILITY","UTILNAME");	
		logger.info("Configuration loaded successfully");
		
	}
	public static void loadProcessSpecificConfiguration(String fileName) throws InvalidFileFormatException, IOException
	{
		String sConfigFile=new StringBuilder().append(System.getProperty("user.dir"))
				.append(System.getProperty("file.separator")).append(fileName).toString();
		Ini ini=new Ini(new File(sConfigFile));
		processName=ini.get("PROCESSINFO", "PROCESSNAME");
		activityname=ini.get("PROCESSINFO", "ACTIVITY");
		extTableName=ini.get("PROCESSINFO", "EXTTABLENAME");
		txnTable=ini.get("PROCESSINFO", "TRANSACTIONTABLE");
		productTable=ini.get("PROCESSINFO", "PRODUCTTABLE");
		sComplete=ini.get("PROCESSINFO", "WI_COMPLETE");
		batchSize=ini.get("PROCESSINFO", "BATCH_SIZE");
		logger.info("Process Specific Configuration loaded successfully");
	}
	public static boolean associateDataclass(String folderindex,String DCname,String DCVal,String sessionid,String IP,String PORT) throws NumberFormatException, IOException, Exception
	{
		DBUtil edmsdb=new DBUtil();
		String Query="select datadefindex from pdbdatadefinition where upper(datadefname)=upper('"+ DCname +"') ";

    	String dataclassindex = edmsdb.ExecuteCustomSelectQuery(Query,edmsCabinet, sessionid, IP, PORT);
    	TestXML xml=new TestXML();
    	dataclassindex=xml.getTagValue(dataclassindex, "td");
    	 Query="select '<IndexId>'||b.datafieldindex||'</IndexId><IndexType>'||datafieldtype||'</IndexType>'||"+
    	 "'<IndexValue>'||upper(datafieldname)||'</IndexValue>'"+
    	 " from pdbdatafieldstable a,pdbglobalindex b where a.datafieldindex=b.datafieldindex"+
    	 " and datadefindex='"+dataclassindex+"'";
    	
    	 String dataclassxml= edmsdb.ExecuteCustomSelectQuery(Query,edmsCabinet, sessionid, IP, PORT);
    	 dataclassxml=dataclassxml.replace("<td>", "<Field>");
    	 dataclassxml=dataclassxml.replace("</td>", "</Field>");
    	 dataclassxml=dataclassxml.replace("<tr>", "");
    	 dataclassxml=dataclassxml.replace("</tr>", "");
    	 dataclassxml=dataclassxml.replace("\n", "");
    	 dataclassxml=dataclassxml.replace("\r", "");
    	 dataclassxml=dataclassxml.replace("\t", "");    	 
    	 dataclassxml=dataclassxml.substring(dataclassxml.indexOf("<Records>")+9,dataclassxml.indexOf("</Records>"));
    	 
    	 //CH_18072016_001 starts
    	 TestXML xmlparser=new TestXML();
    	 String temp=xmlparser.getTagValues(dataclassxml,"IndexValue");
    	 String temp_array[]=temp.split(",");
    	//CH_18072016_001 ends
    	 
    	String[] dcvalues=DCVal.split("#");
    	for(int i=0;i<dcvalues.length;i++)
    	{
    		if(dcvalues[i].equalsIgnoreCase("")){
    			
    		}
    		else{
    		String[] val=dcvalues[i].split("=");
    		if(val.length==1)
    		{
    			
    			dataclassxml=dataclassxml.replace(val[0].toUpperCase(), "");
    		
    		}
    		else	
    		{
    			dataclassxml=dataclassxml.replace(val[0].toUpperCase(), val[1]);
    		}
    		}
    	}
    	
    	 //CH_18072016_001 starts
    	for(int i=0;i<temp_array.length;i++)
    	{
    		dataclassxml=dataclassxml.replaceAll(temp_array[i], "");
    	}
    	 //CH_18072016_001 ends
    	
    	dataclassxml="<?xml version=\"1.0\"?><NGOChangeFolderProperty_Input><Comment>ByP@$$M@kerChecker</Comment>" +
    			"<Option>NGOChangeFolderProperty</Option><CabinetName>"+edmsCabinet+"</CabinetName>" +
    					"<UserDBId>"+ sessionid +"</UserDBId><Folder><FolderIndex>"+folderindex+"</FolderIndex>" +
    							"<NameLength>255</NameLength><VersionFlag></VersionFlag>" +
    							"<DataDefinition><DataDefIndex>"+dataclassindex+"</DataDefIndex>" +
    									"<Fields>"+dataclassxml+"</Fields></DataDefinition></Folder></NGOChangeFolderProperty_Input>";
    	String retval=edmsdb.customQuery(dataclassxml,edmsCabinet, sessionid, IP, PORT);
    	if(retval.contains("<Status>0</Status>")){
    		return true;
    	}
    		
    	else{
    		return false;
    	}
   }
	public static String uploadDocument(String docname,String docindex,String folderind,String sessionid,String nopages,String doctype,String docsize,String appname,String DCname,String DCValues) throws Exception
	{
		
		String Query="";
		String documentindex="";
		DBUtil edmsdb=new DBUtil();
		TestXML xml=new TestXML();
		Query="select a.documentindex from pdbdocument a,pdbdocumentcontent b where a.documentindex=b.documentindex and parentfolderindex='"+folderind+"' and a.name='"+docname+"'";
		try
		{
			String out = edmsdb.ExecuteCustomSelectQuery(Query,edmsCabinet, sessionid, edmsIP, edmsPORT);
			out=out.replaceAll("\r","");
			out=out.replaceAll("\n","");
			out=out.replaceAll("\t","");			
			out=xml.getTagValue(out, "tr");	
						
			if(out.equalsIgnoreCase(""))
			{
				Query="<?xml version=\"1.0\"?><NGOAddDocument_Input><BypassHookTag></BypassHookTag>" +
						"<Option>NGOAddDocument</Option><CabinetName>"+edmsCabinet+"</CabinetName>" +
								"<UserDBId>"+sessionid+"</UserDBId><GroupIndex>0</GroupIndex>" +
										"<Document><ParentFolderIndex>"+folderind+"</ParentFolderIndex>" +
												"<NoOfPages>"+nopages+"</NoOfPages><AccessType>I</AccessType>" +
														"<DocumentName>"+docname+"</DocumentName>" +
																"<CreationDateTime></CreationDateTime>" +
																"<DocumentType>"+doctype+"</DocumentType>" +
																		"<DocumentSize>"+docsize+"</DocumentSize>" +
																				"<CreatedByAppName>"+appname+"</CreatedByAppName>" +
																						"<ISIndex>"+docindex+"</ISIndex>" +
																								"<ODMADocumentIndex></ODMADocumentIndex>" +
																								"<Comment></Comment>" +
																								"<EnableLog>Y</EnableLog>" +
																								"<FTSFlag>PP</FTSFlag>" +
																								"<DataDefinition></DataDefinition>" +
																								"<Keywords></Keywords></Document>" +
																								"</NGOAddDocument_Input>";
				out = edmsdb.customQuery(Query,edmsCabinet, sessionid, edmsIP, edmsPORT);
				out=out.replaceAll("\r","");
				out=out.replaceAll("\n","");
				out=out.replaceAll("\t","");	
				documentindex=xml.getTagValue(out, "DocumentIndex");	
			}
			else
			{
				documentindex=chekincheckout( docindex, docsize, doctype, nopages, appname, folderind, sessionid,docname);
				
			}
			if(!documentindex.equalsIgnoreCase(""))
			{
				associateDataClassDoc(documentindex,DCname,DCValues,sessionid);
				logger.info("associated data class");
			}
			else
			{
				logger.info("Problem in DOcument Addition");
				throw new Exception("Document addition failed");
			}
		}
		catch(Exception e)
		{
			logger.error("Exception in uploadDocument: ",e);
			throw e;
		}
		return documentindex;
	}
	public static String chekincheckout(String docindex,String docsize,String doctype,String nopages,String appname,String folderindex,String session,String docname) throws Exception
	{
		DBUtil edmsdb=new DBUtil();
		TestXML xml=new TestXML();
		String output="";
		try
		{
			/*
			//rownum=1 added in case multiple documents are present with same name
			String 	Query="select a.documentindex,a.volumeid,a.imageindex from pdbdocument a,pdbdocumentcontent b where a.documentindex=b.documentindex and parentfolderindex='"+folderindex+"' and name='"+docname+"' and rownum=1";
			output=edmsdb.ExecuteCustomSelectQuery(Query,edmsCabinet, session, edmsIP, edmsPORT);
			output=output.replaceAll("\r","");
			output=output.replaceAll("\n","");
			output=output.replaceAll("\t","");			
			output=xml.getTagValue(output, "tr");
			Query="<?xml version=\"1.0\"?><NGOCheckinCheckoutExt_Input><Option>NGOCheckinCheckoutExt</Option>" +
					"<CabinetName>"+edmsCabinet+"</CabinetName><UserDBId>"+session+"</UserDBId>" +
							"<CurrentDateTime></CurrentDateTime><LimitCount>1000</LimitCount>" +
							"<CheckInOutFlag>Y</CheckInOutFlag><SupAnnotVersion>N</SupAnnotVersion>" +
							"<Documents><Document><DocumentIndex>"+output.split(",")[0]+"</DocumentIndex>" +
									"<ISIndex>"+output.split(",")[2]+"#"+output.split(",")[1]+"#</ISIndex>" +
											"</Document></Documents></NGOCheckinCheckoutExt_Input>";
			String output1=edmsdb.customQuery(Query,edmsCabinet, session, edmsIP, edmsPORT);			
			Query="<?xml version=\"1.0\"?><NGOCheckinCheckoutExt_Input><Option>NGOCheckinCheckoutExt</Option>" +
					"<CabinetName>"+edmsCabinet+"</CabinetName><UserDBId>"+session+"</UserDBId><CurrentDateTime>" +
							"</CurrentDateTime><LimitCount>1000</LimitCount><CheckInOutFlag>N</CheckInOutFlag>" +
							"<SupAnnotVersion>N</SupAnnotVersion><Documents><Document>" +
							"<DocumentIndex>"+output.split(",")[0]+"</DocumentIndex>" +
									"<ISIndex>"+docindex+"</ISIndex><VersionComment>" +
											"</VersionComment><DocumentType>"+doctype+"</DocumentType>" +
													"<NoOfPages>"+nopages+"</NoOfPages>" +
															"<DocumentSize>"+docsize+"</DocumentSize>" +
																	"<CreatedByAppName>"+appname+"</CreatedByAppName>" +
																			"<MajorVersion>N</MajorVersion>" +
																			"</Document></Documents>" +
																			"</NGOCheckinCheckoutExt_Input>";
			
			output=edmsdb.customQuery(Query,edmsCabinet, session, edmsIP, edmsPORT);
			output=output.replaceAll("\r","");
			output=output.replaceAll("\n","");
			output=output.replaceAll("\t","");			
			output=xml.getTagValue(output, "DocumentIndex");*/
			logger.info("CheckOutCheckIn call started");
			String 	Query="select a.documentindex,a.volumeid,a.imageindex,a.versionnumber,b.ParentFolderIndex,a.owner,a.createdbyuser, a.NOOFPAGES,a.appname,a.DocumentSize, a.FTSFlag, a.PullPrintFlag, a.DocumentType from pdbdocument a,pdbdocumentcontent b where a.documentindex=b.documentindex and parentfolderindex='"+folderindex+"' and name='"+docname+"' and rownum=1";
			output=edmsdb.ExecuteCustomSelectQuery(Query,edmsCabinet, session, edmsIP, edmsPORT);
			output=output.replaceAll("\r","");
			output=output.replaceAll("\n","");
			output=output.replaceAll("\t","");			
			output=xml.getTagValue(output, "tr");
			String values[]=output.split(",");
			String old_documentindex=values[0];
			String old_volumeid=values[1];
			String old_imageindex=values[2];
			
			//CH_07042019_001
			//Commented after OD10 Upgrade
//			String old_versionnumber=values[3];
//			String old_ParentFolderIndex=values[4];
//			String old_owner=values[5];
//			String old_createdbyuser=values[6];
//			String old_noofpages=values[7];
//			String old_appname=values[8];
//			String old_documentsize=values[9];
//			String old_ftsflag=values[10];
//			String old_printflag=values[11];
//			String old_doctype=values[12];
			
			String new_imageindex=docindex.split("#")[0];
//			String new_volid=docindex.split("#")[1];
			
			//CH_15022016_001
			if(old_imageindex.equalsIgnoreCase(new_imageindex))
			{
				System.out.println("Document with same imageindex already exits. So bypassing this document");
				logger.info("Document with same imageindex already exits. So bypassing this document");
				return old_documentindex;
			}
			//CH_07042019_001
			
			//Unlock the document
			String columnName="documentlock,lockbyuser,checkoutstatus,checkoutbyuser,lockmessage";
			String strValues="'N','','N','0',''";
			String sWhere="documentindex='"+old_documentindex+"'";			
			edmsdb.ExecuteCustomUpdateQuery("pdbdocument", columnName, strValues, sWhere, edmsCabinet, session, edmsIP, edmsPORT);
			
			
			//Check out the document
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			Date d = new Date();
			Query="<?xml version=\"1.0\"?><NGOCheckinCheckoutExt_Input><Option>NGOCheckinCheckoutExt</Option>" +
					"<CabinetName>"+edmsCabinet+"</CabinetName><UserDBId>"+session+"</UserDBId>" +
							"<CurrentDateTime>"+sdf.format(d)+"</CurrentDateTime><LimitCount>1000</LimitCount>" +
							"<CheckInOutFlag>Y</CheckInOutFlag><SupAnnotVersion>N</SupAnnotVersion>" +
							"<Documents><Document><DocumentIndex>"+old_documentindex+"</DocumentIndex>" +
									"<ISIndex>"+old_imageindex+"#"+old_volumeid+"#</ISIndex>" +
											"</Document></Documents></NGOCheckinCheckoutExt_Input>";
			edmsdb.customQuery(Query,edmsCabinet, session, edmsIP, edmsPORT);
			
			//Check in the document
			d = new Date();
			Query="<?xml version=\"1.0\"?><NGOCheckinCheckoutExt_Input><Option>NGOCheckinCheckoutExt</Option>" +
					"<CabinetName>"+edmsCabinet+"</CabinetName><UserDBId>"+session+"</UserDBId><CurrentDateTime>" +
							""+sdf.format(d)+"</CurrentDateTime><LimitCount>1000</LimitCount><CheckInOutFlag>N</CheckInOutFlag>" +
							"<SupAnnotVersion>N</SupAnnotVersion><Documents><Document>" +
							"<DocumentIndex>"+old_documentindex+"</DocumentIndex>" +
									"<ISIndex>"+docindex+"</ISIndex><VersionComment>" +
											"</VersionComment><DocumentType>"+doctype+"</DocumentType>" +
													"<NoOfPages>"+nopages+"</NoOfPages>" +
															"<DocumentSize>"+docsize+"</DocumentSize>" +
																	"<CreatedByAppName>"+appname+"</CreatedByAppName>" +
																			"<MajorVersion>N</MajorVersion>" +
																			"</Document></Documents>" +
																			"</NGOCheckinCheckoutExt_Input>";
			
			edmsdb.customQuery(Query,edmsCabinet, session, edmsIP, edmsPORT);
			output=old_documentindex;
			//CH_07042019_001 ENDS
			
			//Commented below after OD10 upgrade
			/*
			Date today_date=new Date();
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yyyy");
			String today=sdf.format(today_date);
			logger.info("Todays date: "+today);
			logger.info("old_versionnumber: "+old_versionnumber);
			//if(old_versionnumber.equalsIgnoreCase("1") || old_versionnumber.equalsIgnoreCase("1.0"))
			//{
				String ColName="DocumentIndex ,ParentFolderIndex, VersionNumber,VersionComment, " +
						"CreatedDateTime, Name, Owner, CreatedByUserIndex,ImageIndex, VolumeIndex," +
						" NoOfPages, LockFlag, LockByUser, AppName, DocumentSize, FTSFlag, PullPrintFlag, DocumentType, lockmessage";
				String Values="'"+old_documentindex+"','"+old_ParentFolderIndex+"','"+old_versionnumber+"','','"+today+"','"+docname+"','"+old_owner+"','"+old_createdbyuser+"','"+old_imageindex+"','"+old_volumeid+"','"+old_noofpages+"','','','"+old_appname+"','"+old_documentsize+"','"+old_ftsflag+"','"+old_printflag+"','"+old_doctype+"',''";
				edmsdb.ExecuteCustomInsertVersionQuery("pdbdocumentversion", ColName, Values, edmsCabinet, session, edmsIP, edmsPORT);
			//}
		
			if(old_versionnumber.contains("."))
				old_versionnumber=old_versionnumber.substring(0, old_versionnumber.indexOf("."));
			
			int new_versionnumber=Integer.parseInt(old_versionnumber)+1;
			logger.info("New versionnumber: "+new_versionnumber);
			Query="select userindex from pdbuser where upper(username)='"+edmsUser.toUpperCase()+"'";
			output=edmsdb.ExecuteCustomSelectQuery(Query,edmsCabinet, session, edmsIP, edmsPORT);
			output=output.replaceAll("\r","");
			output=output.replaceAll("\n","");
			output=output.replaceAll("\t","");			
			output=xml.getTagValue(output, "tr");
			
			String new_owner=output.trim();
			
			logger.info("new_owner: "+new_owner+", new_imageindex: "+new_imageindex+",new_volid: "+new_volid);
			/*
			String ColName="DocumentIndex ,ParentFolderIndex, VersionNumber,VersionComment, " +
					"CreatedDateTime, Name, Owner, CreatedByUserIndex,ImageIndex, VolumeIndex," +
					" NoOfPages, LockFlag, LockByUser, AppName, DocumentSize, FTSFlag, PullPrintFlag, DocumentType, lockmessage";
			String Values="'"+old_documentindex+"','"+old_ParentFolderIndex+"','"+new_versionnumber+"','Created by archival','"+today+"','"+docname+"','"+new_owner+"','"+new_owner+"','"+new_imageindex+"','"+new_volid+"','"+nopages+"','','','"+appname+"','"+docsize+"','"+old_ftsflag+"','"+old_printflag+"','"+doctype+"',''";
			edmsdb.ExecuteCustomInsertQuery("pdbdocumentversion", ColName, Values, edmsCabinet, session, edmsIP, edmsPORT);
			
			*/
			/*
			String columnName="RevisedDateTime,AccessedDateTime,DocumentType,ImageIndex,VolumeId,NoOfPages,DocumentSize,CheckOutStatus,CheckOutByUser,versionnumber,AppName,DocumentLock,LockMessage";
			String strValues="'"+today+"','"+today+"','"+doctype+"','"+new_imageindex+"','"+new_volid+"','"+nopages+"','"+docsize+"','N','0','"+new_versionnumber+"','"+appname+"','N',''";
			String sWhere="documentindex='"+old_documentindex+"'";
			
			edmsdb.ExecuteCustomUpdateQuery("pdbdocument", columnName, strValues, sWhere, edmsCabinet, session, edmsIP, edmsPORT);
			
			output=old_documentindex;	
			*/
			
						
		}
		catch(Exception e)
		{
			logger.error("Exception in check in check out: ",e);
			throw e;
		}
		return output;
		
	}
	public static void associateDataClassDoc(String docindex,String DCname,String DCVal,String sessionid) throws Exception
	{
		DBUtil edmsdb=new DBUtil();
		String Query="select datadefindex from pdbdatadefinition where upper(datadefname)=upper('"+ DCname +"') ";
		try
		{
			String dataclassindex = edmsdb.ExecuteCustomSelectQuery(Query,edmsCabinet, sessionid, edmsIP, edmsPORT);
			TestXML xml=new TestXML();
			dataclassindex=xml.getTagValue(dataclassindex, "td");
			Query="select '<IndexId>'||b.datafieldindex||'</IndexId><IndexType>'||datafieldtype||'</IndexType>'||"+
					"'<IndexValue>'||upper(datafieldname)||'</IndexValue>'"+
					" from pdbdatafieldstable a,pdbglobalindex b where a.datafieldindex=b.datafieldindex"+
					" and datadefindex='"+dataclassindex+"'";

			String dataclassxml= edmsdb.ExecuteCustomSelectQuery(Query,edmsCabinet, sessionid, edmsIP, edmsPORT);
			dataclassxml=dataclassxml.replace("<td>", "<Field>");
			dataclassxml=dataclassxml.replace("</td>", "</Field>");
			dataclassxml=dataclassxml.replace("<tr>", "");
			dataclassxml=dataclassxml.replace("</tr>", "");
			dataclassxml=dataclassxml.replace("\n", "");
			dataclassxml=dataclassxml.replace("\r", "");
			dataclassxml=dataclassxml.replace("\t", "");    	 
			dataclassxml=dataclassxml.substring(dataclassxml.indexOf("<Records>")+9,dataclassxml.indexOf("</Records>"));

			//CH_18072016_001 starts
	    	 TestXML xmlparser=new TestXML();
	    	 String temp=xmlparser.getTagValues(dataclassxml,"IndexValue");
	    	 String temp_array[]=temp.split(",");
	    	//CH_18072016_001 ends
			
			String[] dcvalues=DCVal.split("#");

			for(int i=0;i<dcvalues.length;i++)
			{
				String[] val=dcvalues[i].split("=");
				if(val.length==1)
				{

					dataclassxml=dataclassxml.replace(val[0].toUpperCase(), "");

				}
				else	
				{
					dataclassxml=dataclassxml.replace(val[0].toUpperCase(), val[1]);
				}

			}
			
			//CH_18072016_001 starts
	    	for(int i=0;i<temp_array.length;i++)
	    	{
	    		dataclassxml=dataclassxml.replaceAll(temp_array[i], "");
	    	}
	    	 //CH_18072016_001 ends
	    	
			dataclassxml="<?xml version=\"1.0\"?><NGOChangeDocumentProperty_Input><Comment>ByP@$$M@kerChecker</Comment>" +
					"<Option>NGOChangeDocumentProperty</Option><CabinetName>"+edmsCabinet+"</CabinetName>" +
							"<UserDBId>"+sessionid+"</UserDBId><GroupIndex>0</GroupIndex><Document>" +
									"<DocumentIndex>"+docindex.split("#")[0]+"</DocumentIndex>" +
											"<DataDefinition><DataDefName>"+DCname+"</DataDefName>" +
													"<Fields>"+dataclassxml+"</Fields></DataDefinition>" +
															"</Document></NGOChangeDocumentProperty_Input>";
			edmsdb.customQuery(dataclassxml,edmsCabinet, sessionid, edmsIP, edmsPORT);
		}
		catch(Exception e)
		{
			logger.error("Exception in associateDataClassDoc: ",e);
			throw e;
		}
		
	}
	public void CompleteWorkitem(String processInstanceId, String workItemId, String sessionId, DBConnection DB) throws NumberFormatException, IOException, Exception 
	{
		String sQuery="select distinct(activityid) from queuetable where activityname ='"+activityname+"'  and processname='"+processName+"'";
		String activityid=DB.selectSingle(sQuery);
		logger.debug("Archival Activity ID: "+activityid);

		getGetWorkItemXML( processInstanceId, workItemId, sessionId, wmsCabinet,wmsIP,wmsPort) ;

		String xml = "<?xml version=\"1.0\" ?>" + "\n" +
				"<WMCompleteWorkItem_Input>" + "\n" +
				"<Option>WMCompleteWorkItem</Option>" + "\n" +
				"<EngineName>"+ wmsCabinet + "</EngineName>" + "\n" +
				"<SessionId>" + sessionId + "</SessionId>" + "\n" +
				"<ProcessInstanceId>" + processInstanceId + "</ProcessInstanceId>" + "\n" +
				"<WorkItemId>" + workItemId + "</WorkItemId>" + "\n" +
				"<AuditStatus></AuditStatus>" + "\n" +
				"<Comments></Comments>" + "\n" +
				"<ActivityId>"+activityid+"</ActivityId>" + "\n" +
				"<YesBringNextWI>Y</YesBringNextWI>" + "\n" +
				"</WMCompleteWorkItem_Input>";
		logger.debug("Input: "+xml);
		String wi_OutputXml= WFCallBroker.execute(xml,wmsIP,Integer.parseInt(wmsPort),1);
		logger.debug("Output: "+wi_OutputXml);
		XMLParser xmlparser=new XMLParser(wi_OutputXml);
		if(!xmlparser.getValueOf("MainCode").trim().equalsIgnoreCase("0"))
		{
			throw new Exception("Complete workitem call failed for workitem "+processInstanceId);
		}

	}
	public void getGetWorkItemXML( String processInstanceId, String workItemId, String sessionId, String cabinetName,String jtsIP,String jtsPort) throws NumberFormatException, IOException, Exception 
	{
		String xml = "<?xml version=\"1.0\" ?>" + "\n" +
				"<WMGetWorkItem_Input>"+ "\n" +
				"<Option>WMGetWorkItem</Option>"+ "\n" +
				"<EngineName>" + cabinetName + "</EngineName>"+ "\n" +
				"<SessionId>" + sessionId + "</SessionId>"+ "\n" +
				"<ProcessInstanceId>" + processInstanceId + "</ProcessInstanceId>" + "\n" +
				"<WorkItemId>" + workItemId + "</WorkItemId>"+ "\n" +
				"</WMGetWorkItem_Input>";
		
		logger.debug("Input: "+xml);
		String wi_OutputXml= WFCallBroker.execute(xml,jtsIP,Integer.parseInt(jtsPort),1);
		logger.debug("Output: "+wi_OutputXml);
		XMLParser xmlparser=new XMLParser(wi_OutputXml);
		if(!xmlparser.getValueOf("MainCode").trim().equalsIgnoreCase("0"))
		{
			throw new Exception("getGetWorkItemXML call failed for workitem "+processInstanceId);
		}
	}
	public String readComplexXml(String TagName,String Xml) throws Exception{
		logger.info("Inside readComplexXml");
		String INI=Xml;
		String sTable="";
		String sWhere="";
		String sField="";
		String sValue="";
		String out="";
		File configFile = new File(INI);
		if(!configFile.exists())
		{
			logger.error(Xml+" File doesn't exists.");
			throw new Exception(Xml+" File doesn't exists.");
		}
		else
		{
			FileInputStream fstream = null;
			fstream = new FileInputStream(INI);
			DataInputStream in = new DataInputStream(fstream);
			InputStreamReader isr=new InputStreamReader(in);
			BufferedReader br1 = new BufferedReader(isr);
			String strLine,finalStr="";

			try 
			{
				if (( strLine = br1.readLine()) == null)    
				{
					logger.debug("Oops!!");
				}
				else
				{
					while ((strLine = br1.readLine()) != null)     
					{
						finalStr=finalStr+strLine;
					}
					XMLParser xmlDataParser = new XMLParser();
					xmlDataParser.setInputXML(finalStr);	
					TestXML xml=new TestXML();
					try {
						sValue=xml.getTagValues(finalStr, TagName);
						} catch (Exception e) {
						e.printStackTrace();
						logger.error("Exception in readComplexXml: ",e);
						throw e;
					}
					XMLParser xmlDataParser1 = new XMLParser();
					xmlDataParser1.setInputXML(sValue);	
					TestXML xml1=new TestXML();
					try {
						sTable=xml1.getTagValues(sValue, "Tables");
						sWhere=xml1.getTagValues(sValue, "Where");
						sField=xml1.getTagValues(sValue, "FieldSet");
						logger.debug("sTable"+sTable);
						logger.debug("sWhere"+sWhere);
						logger.debug("sField"+sField);

						XMLParser xmlDataParser2 = new XMLParser();
						xmlDataParser2.setInputXML(sField);	
						TestXML xml2=new TestXML();
						sField=xml.getTagValues(sValue, "Field");
						logger.debug("sField.length()"+sField);


					} catch (Exception e) {
						e.printStackTrace();
						logger.error("Exception in readComplexXml: ",e);
						throw e;
					}

					out="select "+sField+" from "+sTable+" where "+sWhere;
					logger.info(out);

				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Exception in readComplexXml: ",e);
				throw e;
				
			}
		}
		return out;
	}
	public String readSimpleXml(String TagName){
		String INI="Config.xml";
		String sValue="";
		File configFile = new File(INI);
		if(!configFile.exists())
		{
			System.out.println("Config File does not exist.");
		}
		else{
		
		FileInputStream fstream = null;
		try {
			fstream = new FileInputStream(INI);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DataInputStream in = new DataInputStream(fstream);
		InputStreamReader isr=new InputStreamReader(in);
		BufferedReader br1 = new BufferedReader(isr);
		String strLine,finalStr="";
		
			try {
					if (( strLine = br1.readLine()) == null)    
					{
						System.out.println("Oops!!");
					}
					else{
						while ((strLine = br1.readLine()) != null)     
						{
						finalStr=finalStr+strLine;
						}
						XMLParser xmlDataParser = new XMLParser();
						xmlDataParser.setInputXML(finalStr);	
						TestXML xml=new TestXML();
						
						try {
							sValue=xml.getTagValues(finalStr, TagName);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						System.out.println("sValue"+sValue);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return sValue;
	}

	
}
