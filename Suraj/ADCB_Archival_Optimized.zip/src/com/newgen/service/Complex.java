/***************************************************************************
 *       Application     : Custom Archival Utility
 *       File            : Simple.java
 *       Purpose         : This class contains archival code of complex processes
 *
 * Change History  :
 *********************************************************************************************************************
 * Date			Problem No          	 description                                             											changed by
 *---------		---------			-----------------------                                     											 -------------
 *15/02/2016	CH_15022016_001		Handling for Array Out of bound exception																 Pradeep Monga
 *25/02/2016	CH_25022016_001		Handling of folder structure in case acc_no is null or final folder name is null						 Pradeep Monga			
 ***********************************************************************************************************/
package com.newgen.service;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.ini4j.InvalidFileFormatException;
import org.xml.sax.SAXException;

public class Complex extends Commons{

	public String sXml="";
	public static String prevfolderindex="";
	DBUtil edms=null;
	DBUtil wms=null;

	public Complex(String sConfig, String sXml) throws InvalidFileFormatException, IOException
	{
		loadProcessSpecificConfiguration(sConfig);
		this.sXml=sXml;
	}
	public void processWorkitems() throws Exception
	{
		DBConnection DB=null;
		edms=new DBUtil();
		wms=new DBUtil();
		String edmsSession="";
		String wmsSession="";
		try
		{
			//creating edms worksflow connection
			edmsSession=edms.ExecuteConnectionQuery(edmsCabinet, edmsUser, edmsPass, edmsIP, edmsPORT);
			//creating wms workflow connection
			wmsSession=wms.ExecuteConnectionQuery(wmsCabinet, wmsUser, wmsPass, wmsIP, wmsPort);
			DB=new DBConnection();
			DB.getDbConnection();
			String query="select a.processinstanceid from queueview a,  "+ extTableName +"  b " +
					"where upper(a.activityname)=upper('"+ activityname +"') and a.processname='"+ processName +"' " +
					"and a.processinstanceid=b.wi_name and (b.archiveflag is null or b.archiveflag in ('1','2','3')) and " +
					"(a.lockstatus is null or lockstatus='N') and rownum<"+batchSize+"+1";
			ArrayList<String> workitems=DB.selectWorkitems(query);		
			for(String wi_name : workitems)
			{
				try
				{
					if(!wi_name.trim().equalsIgnoreCase(""))
					{
						archiveDocs(wi_name,DB, edmsSession, wmsSession);
					}
				}
				catch(Exception e)
				{
					logger.error("Excepiton in archiveDocs for workitem: "+wi_name,e);
					e.printStackTrace();
				}
			}			
		}
		catch(Exception e)
		{
			logger.error("Excepiton in processWorkitems: ",e);
			e.printStackTrace();
			//throw the exception to calling function
			throw e;
		}
		finally
		{
			DB.connectionClose();
			if(!edmsSession.equalsIgnoreCase(""))
			{
				edms.Disconnect(edmsCabinet, edmsSession, edmsIP, edmsPORT);
			}
			if(!wmsSession.equalsIgnoreCase(""))
			{
				wms.Disconnect(edmsCabinet, wmsSession, wmsIP, wmsPort);
			}
		}
	}
	public void archiveDocs(String wi_name,DBConnection DB, String edmsSession, String wmsSession) throws ParserConfigurationException, SAXException, IOException, Exception
	{
		try
		{
			logger.info("Processing started for "+wi_name);
			System.out.println("Processing started for "+wi_name);
			String query="select count(1) from "+ txnTable +" where wi_name='"+ wi_name +"' ";
			String output=DB.selectOwnership(query);
			if(output.equalsIgnoreCase("1"))
			{
				archieveDocumentsSingle(wi_name,DB, edmsSession,wmsSession, sXml);
			}
			else 
			{
				archieveDocumentsJoint(wi_name,DB, edmsSession,wmsSession, sXml);
			}

		}
		catch(Exception e)
		{
			logger.error("Excepiton in archiveDocs for workitem: ",e);
			e.printStackTrace();
			logger.info("Archival failed for workitem: "+wi_name);
			System.out.println("Archival failed for workitem: "+wi_name);
			logger.info("Updating archival flag for error case");
			System.out.println("Updating archival flag for error case");
			try
			{
				String archiveflag="";
				String query="select archiveflag from "+extTableName+" where wi_name='"+wi_name+"'";
				String output=DB.selectSingle(query);
				if(output==null)
					output="";
				String flag=output.equalsIgnoreCase("")?"0":output;
				switch(Integer.parseInt(flag))
				{
					case 0:		archiveflag="1";	
								break;
					case 1:		archiveflag="2";
								break;
					case 2:		archiveflag="3";
								break;
					case 3:		archiveflag="E";
								break;
				}
				DB.updateProcess("update "+ extTableName +" set archiveflag='"+archiveflag+"' where wi_name='"+wi_name+"'");
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				logger.error("Exception in updating error status: ",ex);
			}
			throw e;
		}
		finally
		{

		}

	}
	public void archieveDocumentsSingle(String wi_name,DBConnection DB, String edmsSession, String wmsSession, String sXml) throws Exception
	{
		try
		{
			logger.info("Processing started for "+wi_name);
			System.out.println("Processing started for "+wi_name);
			String query="select a.documentindex,name,imageindex,volumeid,noofpages,documenttype,documentsize,appname  " +
					"from pdbdocument a,pdbdocumentcontent b where a.documentindex=b.documentindex and " +
					"b.parentfolderindex=(select folderindex from pdbfolder where name='"+ wi_name +"') ";
			String output=DB.selectDocs(query);
			output="<output>"+output+"</output>";
			TestXML xml=new TestXML();
			String Documents=xml.getTagValue(output,"TR");
			logger.debug("Documents: "+Documents);
			if(!Documents.trim().equalsIgnoreCase(""))
			{
				String[] DocArray=Documents.split(";");		
				for(String Document: DocArray)
				{
					//CH_15022016_001
					Document=Document+" ,";
					//end
					prevfolderindex="";
					String[] DocParams=Document.split(",");
					logger.info("Archiving document "+DocParams[1]);
					System.out.println("Archiving document "+DocParams[1]);
					query="select * from usr_0_folder_structure where doc='"+ DocParams[1] +"'and processname='"+ processName +"'";
					output=DB.selectFolderStruct(query);
					if(output.equalsIgnoreCase(""))
					{
						logger.info("Folder strcuture not found for "+DocParams[1]);
						System.out.println("Folder strcuture not found for "+DocParams[1]);
						continue;
					}
					String folderpath=output.split(";")[1];
					String dataclassHierarchy=output.split(";")[2];
					String DCValues=output.split(";")[3];
					String docdc=output.split(";")[4];
					logger.info("folderpath: "+folderpath+", dataclassHierarchy: "+dataclassHierarchy+", DCValues: "+DCValues+", docdc: "+docdc);
					String[] folder=folderpath.split("/");
					String[] dataclass=dataclassHierarchy.split("/");
					String folderindex="";
					String folder_path="";
					String[] DCval=DCValues.split("#");
					String DCQUERY="";
					for(int j=0;j<DCval.length;j++)
					{
						if(DCval[j].contains("$"))
						{
							String tmp=DCval[j].replace("=$", "='||");
							tmp=tmp.replace("$", "||'#'||");
							DCQUERY+="'"+tmp+"'";
						}
						else
						{
							String tmp=DCval[j]+"#'||";	    				
							DCQUERY+="'"+tmp+"'";
						}
					}
					DCQUERY=DCQUERY.replace("''", "'");
					boolean acc_case=false;
					for(int j=0;j<folder.length;j++)
					{
						if(folder[j].contains("acc_no"))
							acc_case=true;
					}
					if(acc_case)
					{
						logger.info("Inside If case of archieveDocumentsSingle acc_case");
						String Query=readComplexXml("CustInfo",sXml);
						logger.info("Query returned from readComplexXml: "+Query);
						Query=Query.replaceAll("##", "'"+ wi_name +"'");
						String cust_acc=DB.selectCustAcc(Query);
						String[] cust_acc_dat=cust_acc.split(";");

						for(int lop=0;lop<cust_acc_dat.length;lop++)
						{
							String[] tmpAcc=cust_acc_dat[lop].split(",");
							//CH_25022016_001 implemented outer join
							Query="select "+DCQUERY.substring(0,DCQUERY.length()-3)+" from "+txnTable+","+extTableName+","+productTable+" where "+txnTable+".wi_name="+extTableName+".wi_name "+
									" and "+extTableName+".wi_name='"+ wi_name +"' and "+productTable+".wi_name(+)="+extTableName+".wi_name and "+productTable+".acc_no(+)='"+tmpAcc[1]+"'";
							//CH_25022016_001 ends
							DCValues=DB.selectSingle(Query);
							folder_path="";
							prevfolderindex="";

							String tmpReplcepath="";
							for(int j=0;j<folder.length;j++)
							{
								if(folder[j].contains("$"))
								{
									String val=folder[j].replace("$", " ");
									if(val.contains("cust_id"))
									{
										tmpReplcepath=tmpAcc[0];
									}
									else if(val.contains("acc_no") && (tmpAcc[1].trim().equalsIgnoreCase("null") || tmpAcc[1].trim().equalsIgnoreCase("")))
									{
										logger.info("Skipping for null account no. folder");
										System.out.println("Skipping for null account no. folder");
										continue; //CH_25022016_001 skip the folder creation
										//tmpReplcepath="Catgegory Change Only";
									}
									else
									{
										if(val.trim().equalsIgnoreCase(""))
										{
											logger.info("Skipping for null folder");
											System.out.println("Skipping for null folder");
											continue; //CH_25022016_001 skip the folder creation
											//tmpReplcepath="Catgegory Change Only";
										}
										else
										{
											//CH_25022016_001 implemetented outer join
											Query="select "+val+" from "+txnTable+","+extTableName+","+productTable+" where "+txnTable+".wi_name="+extTableName+".wi_name "+
													" and "+extTableName+".wi_name='"+ wi_name +"' and "+productTable+".wi_name(+)="+extTableName+".wi_name and "+txnTable+".cust_id='"+tmpAcc[0]+"' and "+productTable+".acc_no(+)='"+tmpAcc[1]+"'";
											//CH_25022016_001 ends
											logger.info(Query);
											tmpReplcepath=DB.selectSingle(Query);

										}
									}
								}
								else
								{
									tmpReplcepath=folder[j];
								}
								tmpReplcepath=tmpReplcepath.replaceAll("\n", "").trim();
								//CH_25022016_001 check for empty folder name
								if(tmpReplcepath.equalsIgnoreCase(""))
								{
									logger.info("Skipping for null folder");
									System.out.println("Skipping for null folder");
									continue;
								}
								//CH_25022016_001 ends
								folder_path+=tmpReplcepath+"/";	
								logger.info("Folder creation starts for "+folder_path);
								folderindex=createFolder(folder_path.substring(0, folder_path.length()-1),edmsSession,dataclass[j],DCValues);
							}		    			
							logger.info("Created Folder Path: "+folder_path);
							String DocumentIndex=uploadDocument(DocParams[1], DocParams[2]+"#"+DocParams[3]+"#", folderindex,edmsSession, DocParams[4],DocParams[5],DocParams[6],DocParams[7].trim(),docdc,DCValues); //CH_15022016_001 use trim function
							logger.info("Doument Uploaded: "+DocumentIndex);
							System.out.println("Doument Uploaded: "+DocumentIndex);		    			
						}
					}
					else
					{
						logger.info("Inside else case of archieveDocumentsSingle acc_case");
						//CH_25022016_001 implemetented outer join
						String Query="select "+DCQUERY.substring(0,DCQUERY.length()-3)+" from "+txnTable+","+extTableName+","+productTable+" where "+txnTable+".wi_name="+extTableName+".wi_name "+
								" and "+extTableName+".wi_name='"+ wi_name +"' and "+productTable+".wi_name(+)="+extTableName+".wi_name and rownum=1";
						//CH_25022016_001 implemetented outer join
						DCValues=DB.selectSingle(Query);
						for(int j=0;j<folder.length;j++)
						{
							if(folder[j].contains("$"))
							{
								String val=folder[j].replace("$", " ");
								//CH_25022016_001 implemetented outer join
								Query="select "+val+" from "+txnTable+","+extTableName+","+productTable+" where "+txnTable+".wi_name="+extTableName +".wi_name "+
										" and "+extTableName +".wi_name='"+ wi_name +"' and "+productTable+".wi_name(+)="+extTableName +".wi_name";
								//CH_25022016_001 ends
								folder[j]=DB.selectSingle(Query);
									
							}
							folder[j]=folder[j].replaceAll("\n", "").trim();
							//CH_25022016_001 check for empty folder name
							if(folder[j].equalsIgnoreCase(""))
							{
								logger.info("Skipping for null folder");
								System.out.println("Skipping for null folder");
								continue;
							}
							//CH_25022016_001 ends
							folder_path+=folder[j]+"/";
							logger.info("Folder creation starts for "+folder_path);
							folderindex=createFolder(folder_path.substring(0, folder_path.length()-1),edmsSession,dataclass[j],DCValues);	    			
						}
						logger.info("Created Folder Path: "+folder_path);
						String DocumentIndex=uploadDocument(DocParams[1], DocParams[2]+"#"+DocParams[3]+"#", folderindex,edmsSession, DocParams[4],DocParams[5],DocParams[6],DocParams[7].trim(),docdc,DCValues); //CH_15022016_001 use trim function
						logger.info("Doument Uploaded: "+DocumentIndex);
						System.out.println("Doument Uploaded: "+DocumentIndex);	
					}

				}
				logger.info("No. of documents uploaded for workitem "+wi_name+": "+DocArray.length);
			}
			else
			{
				logger.info("No documents found for this workitem");
				System.out.println("No documents found for this workitem");
			}
			
			logger.info("Complete flag: "+sComplete);
			if(sComplete.equalsIgnoreCase("Y"))
			{
				DB.updateProcess("update "+ extTableName +" set cro_dec='Approve' where wi_name='"+wi_name+"'");
				logger.info("CRO Decision updated");
				System.out.println("CRO Decision updated");
				CompleteWorkitem(wi_name, "1", wmsSession, DB);
				logger.info("Workitem "+wi_name+" has been moved to next workstep");
			}
			
			DB.updateProcess("update "+ extTableName +" set archiveflag='Archived' where wi_name='"+wi_name+"'");
			logger.info("Archival flag updated");
			System.out.println("Archival flag updated");
		}
		catch(Exception e)
		{
			logger.error("Exception in archieveDocumentsSingle: ",e);
			e.printStackTrace();
			throw e;
		}
		finally
		{

		}
	}
	public void archieveDocumentsJoint(String wi_name,DBConnection DB, String edmsSession, String wmsSession, String sXml) throws Exception
	{
		try
		{
			logger.info("Processing started for "+wi_name);
			System.out.println("Processing started for "+wi_name);
			String Query=readComplexXml("Custom",sXml);
			Query=Query.replaceAll("##", "'"+ wi_name +"'");
			String output=DB.selectDocs(Query);
			if(output.equalsIgnoreCase(""))
			{
				logger.info("No documents found for "+wi_name);			
				System.out.println("No documents found for "+wi_name);
			}
			else
			{
				output="<output>"+output+"</output>";
				TestXML xml=new TestXML();
				String Documents=xml.getTagValue(output,"TR");
				logger.debug("Documents: "+Documents);
				String[] DocArray=Documents.split(";");		
				for(String Document: DocArray)
				{
					//CH_15022016_001
					Document=Document+" ,";
					//end
					prevfolderindex="";
					String[] DocParams=Document.split(",");
					logger.info("Archiving document "+DocParams[3]);
					System.out.println("Archiving document "+DocParams[3]);
					if(DocParams[3].equalsIgnoreCase(""))
					{
						throw new Exception("Empty document name for "+wi_name);
					}
					else
					{
						Query="select * from usr_0_folder_structure where doc='"+ DocParams[3] +"'  and processname='"+ processName +"'";
						output=DB.selectFolderStruct(Query);
						if(output.equalsIgnoreCase(""))
						{
							logger.info("Folder strcuture not found for "+DocParams[1]);
							System.out.println("Folder strcuture not found for "+DocParams[1]);
							continue;
						}
						String folderpath=output.split(";")[1];
						String dataclassHierarchy=output.split(";")[2];
						String DCValues=output.split(";")[3];
						String docdc=output.split(";")[4];
						logger.info( "Folder structure:"+folderpath);
						String[] folder=folderpath.split("/");
						String[] dataclass=dataclassHierarchy.split("/");
						String folderindex="";
						String folder_path="";
						String[] DCval=DCValues.split("#");
						Query="";
						String DCQUERY="";
						for(int j=0;j<DCval.length;j++)
						{
							if(DCval[j].contains("$"))
							{
								String tmp=DCval[j].replace("=$", "='||");
								tmp=tmp.replace("$", "||'#'||");
								DCQUERY+="'"+tmp+"'";
							}
							else
							{
								String tmp=DCval[j]+"#'||";	    				
								DCQUERY+="'"+tmp+"'";
							}
						}
						DCQUERY=DCQUERY.replace("''", "'");

						String [] values=DCValues.split("#");
						String cid=values[0].substring(values[0].indexOf("=")+1);
						boolean acc_case=false;
						for(int j=0;j<folder.length;j++)
						{
							if(folder[j].contains("acc_no"))
								acc_case=true;
						}
						if(acc_case)
						{
							Query=readComplexXml("CustInfo",sXml);
							Query=Query.replaceAll("##", "'"+ wi_name +"'");
							String cust_acc=DB.selectCustAcc(Query);
							String flag="0";
							if(cust_acc.equalsIgnoreCase("")){
								flag="1";

							}
							String[] cust_acc_dat=cust_acc.split(";");
							for(int lop=0;lop<cust_acc_dat.length;lop++)
							{
								folder_path="";
								prevfolderindex="";
								String[] tmpAcc=cust_acc_dat[lop].split(",");
								//CH_25022016_001 implemented outer join
								Query="select "+DCQUERY.substring(0,DCQUERY.length()-3)+" from "+ txnTable +","+ extTableName +","+ productTable +" where "+ txnTable +".wi_name="+ extTableName +".wi_name "+
										" and "+ extTableName +".wi_name='"+ wi_name +"' and "+ productTable +".wi_name(+)="+ extTableName +".wi_name and "+ productTable +".acc_no(+)='"+tmpAcc[1]+"'";
								//CH_25022016_001 ends
								DCValues=DB.selectSingle(Query);
								logger.info("DCValues: "+DCValues);
								String tmpReplcepath="";
								for(int j=0;j<folder.length;j++)
								{
									if(folder[j].contains("$"))
									{
										String val=folder[j].replace("$", " ");
										//CH_25022016_001 implemented outer join
										Query="select "+val+" from "+ txnTable +","+ extTableName +", "+ productTable +" where "+ txnTable +".wi_name="+ extTableName +".wi_name "+
												" and "+ extTableName +".wi_name='"+ wi_name +"' and "+ productTable +".wi_name(+)="+ extTableName +".wi_name and "+ txnTable +".cust_id='"+tmpAcc[0]+"' and "+ productTable +".acc_no(+)='"+tmpAcc[1]+"' and "+ txnTable +".cust_id='"+DocParams[0]+"'";
										//CH_25022016_001 implemented outer join
										tmpReplcepath=DB.selectSingle(Query);
									}
									else
									{
										tmpReplcepath=folder[j];
									}
									tmpReplcepath=tmpReplcepath.replaceAll("\n", "").trim();
									//CH_25022016_001 check for empty folder name
									if(tmpReplcepath.equalsIgnoreCase(""))
									{
										logger.info("Skipping for null folder");
										System.out.println("Skipping for null folder");
										continue;
									}
									//CH_25022016_001 ends
									folder_path+=tmpReplcepath+"/";
									logger.info("Folder creation starts for "+folder_path);
									folderindex=createFolder(folder_path.substring(0, folder_path.length()-1),edmsSession,dataclass[j],DCValues);

								}
								logger.info("Created Folder Path: "+folder_path);
								String DocumentIndex=uploadDocument(DocParams[3], DocParams[1]+"#"+DocParams[2]+"#", folderindex,edmsSession, DocParams[4],DocParams[5],DocParams[6],DocParams[7].trim(),docdc,DCValues); //CH_15022016_001 use trim function
								logger.info("Doument Uploaded: "+DocumentIndex);
								System.out.println("Doument Uploaded: "+DocumentIndex);	

							}

						}
						else
						{
							//CH_25022016_001 implemented outer join
							Query="select "+DCQUERY.substring(0,DCQUERY.length()-3)+" from "+ txnTable +","+ extTableName +","+ productTable +" where "+ txnTable +".wi_name="+ extTableName +".wi_name "+
									" and "+ extTableName +".wi_name='"+ wi_name +"' and "+ productTable +".wi_name(+)="+ extTableName +".wi_name and rownum=1";
							//CH_25022016_001 ends
							DCValues=DB.selectSingle(Query);
							logger.info("DCValues:"+DCValues);
							for(int j=0;j<folder.length;j++)
							{
								if(folder[j].contains("$"))
								{
									String val=folder[j].replace("$", " ");
									//CH_25022016_001 implemented outer join
									Query="select "+val+" from "+ txnTable +","+ extTableName +","+ productTable +" where "+ txnTable +".wi_name="+ extTableName +".wi_name "+
											" and "+ extTableName +".wi_name='"+ wi_name +"' and "+ productTable +".wi_name(+)="+ extTableName +".wi_name and "+ txnTable +".cust_id='"+DocParams[0]+"'";
									//CH_25022016_001 ends
									folder[j]=DB.selectSingle(Query);
								}
								folder[j]=folder[j].replaceAll("\n", "").trim();
								//CH_25022016_001 check for empty folder name
								if(folder[j].equalsIgnoreCase(""))
								{
									logger.info("Skipping for null folder");
									System.out.println("Skipping for null folder");
									continue;
								}
								//CH_25022016_001 ends
								folder_path+=folder[j]+"/";
								logger.info("Folder creation starts for "+folder_path);
								folderindex=createFolder(folder_path.substring(0, folder_path.length()-1),edmsSession,dataclass[j],DCValues);

							}
							logger.info("Created Folder Path: "+folder_path);
							String DocumentIndex=uploadDocument(DocParams[3], DocParams[1]+"#"+DocParams[2]+"#", folderindex,edmsSession, DocParams[4],DocParams[5],DocParams[6],DocParams[7].trim(),docdc,DCValues); //CH_15022016_001 use trim function
							logger.info("Doument Uploaded: "+DocumentIndex);
							System.out.println("Doument Uploaded: "+DocumentIndex);	
						}


					}
				}
				logger.info("No. of documents uploaded for workitem "+wi_name+": "+DocArray.length);
				
			}
			
			logger.info("Complete flag: "+sComplete);
			if(sComplete.equalsIgnoreCase("Y"))
			{
				DB.updateProcess("update "+ extTableName +" set cro_dec='Approve' where wi_name='"+wi_name+"'");
				logger.info("CRO Decision updated");
				System.out.println("CRO Decision updated");
				CompleteWorkitem(wi_name, "1", wmsSession, DB);
				logger.info("Workitem "+wi_name+" has been moved to next workstep");
			}
			
			DB.updateProcess("update "+ extTableName +" set archiveflag='Archived' where wi_name='"+wi_name+"'");
			logger.info("Archival flag updated");
			System.out.println("Archival flag updated");
		}
		catch(Exception e)
		{
			logger.error("Exception in archieveDocumentsJoint: ",e);
			e.printStackTrace();
			throw e;
		}
		finally
		{

		}
	}
	public String createFolder(String folderpath,String sessionid,String DataClass,String DCVal) throws Exception
	{
		TestXML xml=new TestXML(); 
		String[] Folder=folderpath.split("/");
		String Query="select folderindex from pdbfolder where upper(name)=upper('"+ Folder[Folder.length-1] +"') and location<>'T' ";
		if (prevfolderindex.equalsIgnoreCase(""))
			Query=Query+" and parentfolderindex='0'";
		else
			Query=Query+" and parentfolderindex='"+prevfolderindex+"'";
		String folderindex="";
		try 
		{
			folderindex = edms.ExecuteCustomSelectQuery(Query,edmsCabinet, sessionid, edmsIP, edmsPORT);
			folderindex=folderindex.replaceAll("\r","");
			folderindex=folderindex.replaceAll("\n","");
			folderindex=folderindex.replaceAll("\t","");			
			folderindex=xml.getTagValue(folderindex, "tr");	
			if(folderindex.equalsIgnoreCase(""))
			{
				Query="<?xml version=\"1.0\"?><NGOAddFolder_Input><Comment>ByP@$$M@kerChecker</Comment>" +
						"<Option>NGOAddFolder</Option><CabinetName>"+edmsCabinet+"</CabinetName>" +
						"<UserDBId>"+ sessionid +"</UserDBId><Folder>" +
						"<ParentFolderIndex>"+ prevfolderindex +"</ParentFolderIndex>" +
						"<FolderName>"+Folder[Folder.length-1]+"</FolderName>" +
						"<CreationDateTime></CreationDateTime>" +
						"<AccessType>I</AccessType><ImageVolumeIndex></ImageVolumeIndex>" +
						"<FolderType>G</FolderType><Location>G</Location>" +
						"<Comment>User Folder</Comment><EnableFTSFlag>Y</EnableFTSFlag>" +
						"<NoOfDocuments>0</NoOfDocuments>" +
						"<NoOfSubFolders>0</NoOfSubFolders>" +
						"<DataDefinition></DataDefinition></Folder>" +
						"</NGOAddFolder_Input>";
				folderindex = edms.customQuery(Query,edmsCabinet, sessionid, edmsIP, edmsPORT);
				folderindex=folderindex.replaceAll("\r","");
				folderindex=folderindex.replaceAll("\n","");
				folderindex=folderindex.replaceAll("\t","");			
				folderindex=xml.getTagValue(folderindex, "FolderIndex");
			}
			logger.info("Folder index: "+folderindex);
			if(folderindex.equalsIgnoreCase(""))
				throw new Exception("Folder Creation failed");

			logger.info("Folder "+Folder[Folder.length-1]+" created with folderindex: "+folderindex);
			if(!DataClass.equalsIgnoreCase("null"))
			{
				boolean t=associateDataclass(folderindex,DataClass,DCVal,sessionid,edmsIP,edmsPORT);
				if(t==true)
					logger.info("Dataclass "+DataClass+" Associated to folderindex: "+folderindex);
				else
					throw new Exception("Data class association failed for folderindex: "+folderindex);
			}

			prevfolderindex=folderindex;
		} 
		catch (Exception e) 
		{
			logger.error("Exception in createFolder: ",e);			
			throw e;
		}

		return folderindex;
	}

}
