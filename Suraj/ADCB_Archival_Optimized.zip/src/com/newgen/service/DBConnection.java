package com.newgen.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

public class DBConnection extends Commons{

	private Connection connection = null;
	public Logger logger = Logger.getLogger(DBConnection.class);

	public DBConnection() throws IOException
	{
		initializeLogger();
	}
	public  Connection getDbConnection() throws ClassNotFoundException, SQLException
	{
		if(connection!=null)
			return connection;
		else
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@"+wmsDBUrl,wmsDBUser,wmsDBPass);
			return connection;
		}
	}
	public void connectionClose()
	{
		try
		{
			if(connection != null && !connection.isClosed())
				connection.close();
			connection = null;
		}
		catch (SQLException e) 
		{
			logger.error("Error in closing DBConnection: ",e);
			e.printStackTrace();
		}

	}
	public String selectSingle(String Query) throws Exception
	{
		logger.info(Query);
		String Output="";
		Statement st=null;
		ResultSet rs=null;
		try
		{
			st = connection.createStatement();
			rs = st.executeQuery(Query);
			while(rs.next())
			{
				Output=rs.getString(1);
			}
			logger.debug("Output: "+Output);
		}
		catch(Exception e)
		{
			logger.error("Excepiton in selectSingle: ",e);
			e.printStackTrace();
			//throw the exception to calling function
			throw e;
		}
		finally
		{
			//close Resultset
			try
			{
				if(rs!=null)
					rs.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing Resultset: ",e);
				e.printStackTrace();
			}
			//close statement
			try
			{
				if(st!=null)
					st.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing statement: ",e);
				e.printStackTrace();
			}
		}
		return Output;
	}
	public ArrayList<String> selectWorkitems(String Query) throws Exception
	{
		ArrayList<String> output=new ArrayList<String>();
		logger.info(Query);
		Statement st=null;	
		ResultSet rs=null;
		try
		{
			st = connection.createStatement();
			rs = st.executeQuery(Query);
			while(rs.next())
			{
				logger.debug("Inside rs");
				output.add(rs.getString(1));
			}
		}
		catch(Exception e)
		{
			logger.error("Excepiton in selectWorkitems: ",e);
			e.printStackTrace();
			//throw the exception to calling function
			throw e;
		}
		finally
		{
			//close Resultset
			try
			{
				if(rs!=null)
					rs.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing Resultset: ",e);
				e.printStackTrace();
			}
			//close statement
			try
			{
				if(st!=null)
					st.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing statement: ",e);
				e.printStackTrace();
			}
			
		}
		return output;
	}
	public String selectDocs(String Query) throws Exception
	{
		logger.info(Query);
		Statement st=null;
		ResultSet rs=null;
		String Output="";
		try
		{
			st = connection.createStatement();
			rs = st.executeQuery(Query);
			while(rs.next())
			{
				Output+="<TR>"+
						"<td>"+rs.getString(1)+"</td>"+
						"<td>"+rs.getString(2)+"</td>"+
						"<td>"+rs.getString(3)+"</td>"+
						"<td>"+rs.getString(4)+"</td>"+
						"<td>"+rs.getString(5)+"</td>" +
						"<td>"+rs.getString(6)+"</td>" +
						"<td>"+rs.getString(7)+"</td>" +
						"<td>"+rs.getString(8)+"</td>" +
						"</TR>";
			}
			logger.debug("Output: "+Output);
		}
		catch(Exception e)
		{
			logger.error("Excepiton in selectDocs: ",e);
			e.printStackTrace();
			//throw the exception to calling function
			throw e;
		}
		finally
		{
			//close Resultset
			try
			{
				if(rs!=null)
					rs.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing Resultset: ",e);
				e.printStackTrace();
			}
			//close statement
			try
			{
				if(st!=null)
					st.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing statement: ",e);
				e.printStackTrace();
			}
			
		}
		return Output;
	}
	public String selectFolderStruct(String Query) throws Exception
	{
		logger.info(Query);
		Statement st=null;
		ResultSet rs=null;
		String Output="";
		try
		{
			st = connection.createStatement();
			rs = st.executeQuery(Query);
			while(rs.next())
			{
				Output=rs.getString(1)+";"+rs.getString(2)+";"+rs.getString(3)+";"+rs.getString(4)+";"+rs.getString(5);
			}
		}
		catch(Exception e)
		{
			logger.error("Excepiton in selectFolderStruct: ",e);
			e.printStackTrace();
			//throw the exception to calling function
			throw e;
		}
		finally
		{
			//close Resultset
			try
			{
				if(rs!=null)
					rs.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing Resultset: ",e);
				e.printStackTrace();
			}
			//close statement
			try
			{
				if(st!=null)
					st.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing statement: ",e);
				e.printStackTrace();
			}

		}
		return Output;
	}
	public int updateProcess(String Query) throws Exception
	{
		logger.info("update query"+Query);
		int result=-1;
		Statement st=null;
		try
		{
			st = connection.createStatement();
			result = st.executeUpdate(Query);
		}
		catch(Exception e)
		{
			logger.error("Excepiton in updateProcess: "+e);
			e.printStackTrace();
			throw e;
		}
		finally
		{
			//close statement
			try
			{
				if(st!=null)
					st.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing statement: ",e);
				e.printStackTrace();
			}
		}
		return result;
	}
	public String selectOwnership(String Query) throws Exception
	{
		logger.info(Query);
		Statement st=null;
		ResultSet rs=null;
		String Output="";
		try
		{
			st = connection.createStatement();
			rs = st.executeQuery(Query);
			while(rs.next())
			{
				Output=rs.getString(1);
			}
		}
		catch(Exception e)
		{
			logger.error("Excepiton in selectOwnership: "+e);
			e.printStackTrace();
			throw e;
		}
		finally
		{
			//close Resultset
			try
			{
				if(rs!=null)
					rs.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing Resultset: ",e);
				e.printStackTrace();
			}
			//close statement
			try
			{
				if(st!=null)
					st.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing statement: ",e);
				e.printStackTrace();
			}

		}
		return Output;
	}
	public String selectCustAcc(String Query) throws Exception
	{
		logger.info(Query);
		Statement st=null;
		ResultSet rs=null;
		String Output=""; 
		try
		{
			st = connection.createStatement();
			rs = st.executeQuery(Query);
			while(rs.next())
			{
				Output+=rs.getString(1)+","+rs.getString(2)+";";
			}

		}
		catch(Exception e)
		{
			logger.error("Excepiton in selectCustAcc: "+e);
			e.printStackTrace();
			throw e;
		}
		finally
		{
			//close Resultset
			try
			{
				if(rs!=null)
					rs.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing Resultset: ",e);
				e.printStackTrace();
			}
			//close statement
			try
			{
				if(st!=null)
					st.close();
			}
			catch(Exception e)
			{
				logger.error("Exception in closing statement: ",e);
				e.printStackTrace();
			}

		}
		return Output;
	}
	
	

}
