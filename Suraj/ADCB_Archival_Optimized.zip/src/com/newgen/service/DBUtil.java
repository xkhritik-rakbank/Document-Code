package com.newgen.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.newgen.wfdesktop.xmlapi.WFCallBroker;

public class DBUtil 
{


	private static Logger logger = Logger.getLogger(DBUtil.class);
	GenerateXml objXmlGen = null;

	public DBUtil()
	{

		objXmlGen = new GenerateXml();
	}

	public String ExecuteConnectionQuery(String cabinetName,String username,String password ,String jtsIP,String jtsPort) throws Exception
	{
		try
		{		
			String connectInputXML = "<?xml version=\"1.0\"?><NGOConnectCabinet_Input><Option>NGOConnectCabinet</Option><CabinetName>"+cabinetName+"</CabinetName><UserName>"+username+"</UserName><UserPassword>"+password+"</UserPassword><CurrentDateTime></CurrentDateTime><UserExist>N</UserExist><MainGroupIndex>0</MainGroupIndex><UserType>S</UserType><Locale>en-us</Locale><ApplicationName>N</ApplicationName><Hook>Omnidocs Admin</Hook></NGOConnectCabinet_Input>";
			String connectOutputXML = WFCallBroker.execute(connectInputXML,jtsIP,Integer.parseInt(jtsPort),1);
			XMLParser xml=new XMLParser(connectOutputXML);	
			String mainCode = xml.getValueOf("Status");
			mainCode = mainCode.trim();	
			if (!mainCode.equalsIgnoreCase("0")) 
			{

				String errorDesc =xml.getValueOf("Error").trim();
				logger.error("Error in connecting to server: "+errorDesc);
				throw new Exception("Workflow Server Down");
			}  

			String sessionId = xml.getValueOf("UserDBId");
			sessionId = sessionId.trim();


			if (sessionId.equalsIgnoreCase("") || sessionId.equalsIgnoreCase("null"))
			{

				logger.error("Unable to login, some problem occurred.");
				throw new Exception("Workflow Server Down");

			}


			logger.info("\nSuccessfully logged in into workflow");

			return sessionId;

		}
		catch(Exception e)
		{
			throw e;

		}
	}
	public void Disconnect(String cabinetName,String sessionId,String jtsIP,String jtsPort) 
	{
		try
		{
			String input ="<?xml version=\"1.0\"?><NGODisconnectCabinet_Input><Option>NGODisconnectCabinet</Option><CabinetName>"+cabinetName+"</CabinetName><UserDBId>"+sessionId+"</UserDBId></NGODisconnectCabinet_Input>";
			String output = WFCallBroker.execute(input,jtsIP,Integer.parseInt(jtsPort),1);
			XMLParser xml=new XMLParser(output);	
			String mainCode = xml.getValueOf("Status");
			mainCode = mainCode.trim();	
			if (!mainCode.equalsIgnoreCase("0")) 
			{
				logger.error("Error in disconnecting from server");
				logger.debug("Disconnect input: "+input+" \n Disconnect output: "+output);
			}  
			
		}
		catch(Exception e)
		{
			logger.error("Exception in Disconnecting from server: ",e);
		}
	}
	public String ExecuteCustomSelectQuery(String Query,String cabinetName,String sessionId,String jtsIP,String jtsPort) throws NumberFormatException, IOException, Exception
	{
		String selectInputXml = objXmlGen.PrepareQuery_APSelect(Query,cabinetName,sessionId);
		logger.debug("Input: "+selectInputXml);
		String selectOutputXml = WFCallBroker.execute(selectInputXml,jtsIP,Integer.parseInt(jtsPort),1);
		logger.debug("Output: "+selectOutputXml);
		XMLParser xml=new XMLParser(selectOutputXml);
		if(!xml.getValueOf("MainCode").trim().equalsIgnoreCase("0"))
			throw new Exception("ExecuteCustomSelectQuery is not successful");
		return selectOutputXml;
	}
	public String ExecuteCustomInsertQuery(String TableName,String ColName, String Values,String cabinetName,String sessionId,String jtsIP,String jtsPort) throws NumberFormatException, IOException, Exception
	{
		String insertInputXml = objXmlGen.PrepareQuery_APInsert(TableName,ColName, Values, cabinetName,sessionId);
		logger.debug("Input: "+insertInputXml);
		String insertOutputXml = WFCallBroker.execute(insertInputXml,jtsIP,Integer.parseInt(jtsPort),1);
		logger.debug("Output: "+insertOutputXml);
		XMLParser xml=new XMLParser(insertOutputXml);
		if(!xml.getValueOf("MainCode").trim().equalsIgnoreCase("0"))
			throw new Exception("ExecuteCustomInsertQuery is not successful");
		return insertOutputXml;
	}
	public String ExecuteCustomInsertVersionQuery(String TableName,String ColName, String Values,String cabinetName,String sessionId,String jtsIP,String jtsPort) throws NumberFormatException, IOException, Exception
	{
		String insertInputXml = objXmlGen.PrepareQuery_APInsert(TableName,ColName, Values, cabinetName,sessionId);
		logger.debug("Input: "+insertInputXml);
		String insertOutputXml = WFCallBroker.execute(insertInputXml,jtsIP,Integer.parseInt(jtsPort),1);
		logger.debug("Output: "+insertOutputXml);
		XMLParser xml=new XMLParser(insertOutputXml);
		if(!xml.getValueOf("MainCode").trim().equalsIgnoreCase("0") && xml.getValueOf("Output").trim().contains("ORA-00001"))
		{}
		else if(!xml.getValueOf("MainCode").trim().equalsIgnoreCase("0"))
			throw new Exception("ExecuteCustomInsertQuery is not successful");
		
		return insertOutputXml;
	}
	public String ExecuteCustomUpdateQuery(String tableName,String columnName, String strValues,String sWhere, String cabinetName,String sessionId,String jtsIP,String jtsPort) throws NumberFormatException, IOException, Exception
	{
		String updateInputXml = objXmlGen.XMLIn_APUpdate(tableName,columnName, strValues, sWhere, cabinetName,sessionId);
		logger.debug("Input: "+updateInputXml);
		String updateOutputXml = WFCallBroker.execute(updateInputXml,jtsIP,Integer.parseInt(jtsPort),1);
		logger.debug("Output: "+updateOutputXml);
		XMLParser xml=new XMLParser(updateOutputXml);
		if(!xml.getValueOf("MainCode").trim().equalsIgnoreCase("0"))
			throw new Exception("ExecuteCustomInsertQuery is not successful");
		return updateOutputXml;
	}
	public String customQuery(String Query,String cabinetName,String sessionId,String jtsIP,String jtsPort) throws NumberFormatException, IOException, Exception
	{
		logger.debug("Input: "+Query);
		String wi_OutputXml = WFCallBroker.execute(Query,jtsIP,Integer.parseInt(jtsPort),1);
		logger.debug("Output: "+wi_OutputXml);
		XMLParser xml=new XMLParser(wi_OutputXml);
		if(!xml.getValueOf("Status").trim().equalsIgnoreCase("0"))
		{
			XMLParser parser=new XMLParser(Query);
			String option=xml.getValueOf("Option").trim();
			throw new Exception("customQuery is not successful for "+option);
		}
		return wi_OutputXml;
	}
	
}
