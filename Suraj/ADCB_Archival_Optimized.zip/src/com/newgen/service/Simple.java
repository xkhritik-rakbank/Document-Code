/***************************************************************************
 *       Application     : Custom Archival Utility
 *       File            : Simple.java
 *       Purpose         : This class contains archival code of simple processes
 *
 * Change History  :
 *********************************************************************************************************************
 * Date			Problem No          	 description                                             							changed by
 *---------		---------			-----------------------                                      							-------------
 *15/02/2016	CH_15022016_001		Handling for Array Out of bound exception												 Pradeep Monga
 *25/02/2016	CH_25022016_001		Handling for folder structure when final folder name is null							 Pradeep Monga
 ***********************************************************************************************************/
package com.newgen.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.ini4j.InvalidFileFormatException;
import org.xml.sax.SAXException;

public class Simple extends Commons{

	public static String prevfolderindex="";
	DBUtil edms=null;
	DBUtil wms=null;
	public Simple(String sConfig) throws InvalidFileFormatException, IOException
	{
		loadProcessSpecificConfiguration(sConfig);
	}
	public void processWorkitems() throws Exception
	{
		DBConnection DB=null;
		edms=new DBUtil();
		wms=new DBUtil();
		String edmsSession="";
		String wmsSession="";
		try
		{
			//creating edms worksflow connection
			edmsSession=edms.ExecuteConnectionQuery(edmsCabinet, edmsUser, edmsPass, edmsIP, edmsPORT);
			//creating wms workflow connection
			wmsSession=wms.ExecuteConnectionQuery(wmsCabinet, wmsUser, wmsPass, wmsIP, wmsPort);
			DB=new DBConnection();
			DB.getDbConnection();
			String query="select a.processinstanceid from queueview a,  "+ extTableName +"  b " +
					"where upper(a.activityname)=upper('"+ activityname +"') and a.processname='"+ processName +"' " +
					"and a.processinstanceid=b.wi_name and (b.archiveflag is null or b.archiveflag in ('1','2','3')) and " +
					"(a.lockstatus is null or lockstatus='N') and rownum<"+batchSize+"+1";
			ArrayList<String> workitems=DB.selectWorkitems(query);		
			for(String wi_name : workitems)
			{
				try
				{
					if(!wi_name.trim().equalsIgnoreCase(""))
					{
						archiveDocs(wi_name,DB, edmsSession, wmsSession);
					}
				}
				catch(Exception e)
				{
					logger.error("Excepiton in archiveDocs for workitem: "+wi_name,e);
					e.printStackTrace();
				}
			}


		}
		catch(Exception e)
		{
			logger.error("Excepiton in processWorkitems: ",e);
			e.printStackTrace();
			//throw the exception to calling function
			throw e;
		}
		finally
		{
			DB.connectionClose();
			if(!edmsSession.equalsIgnoreCase(""))
			{
				edms.Disconnect(edmsCabinet, edmsSession, edmsIP, edmsPORT);
			}
			if(!wmsSession.equalsIgnoreCase(""))
			{
				wms.Disconnect(edmsCabinet, wmsSession, wmsIP, wmsPort);
			}
		}
	}
	public void archiveDocs(String wi_name,DBConnection DB, String edmsSession, String wmsSession) throws ParserConfigurationException, SAXException, IOException, Exception
	{
		try
		{
			logger.info("Processing started for "+wi_name);
			System.out.println("Processing started for "+wi_name);
			String query="select a.documentindex,a.name,a.imageindex,a.volumeid,a.noofpages,a.documenttype," +
					"a.documentsize,a.appname from pdbdocument a,pdbdocumentcontent b  " +
					"where a.documentindex=b.documentindex and parentfolderindex=(select folderindex from pdbfolder " +
					"where name ='"+ wi_name +"') union select a.documentindex,a.name,a.imageindex,d.volumeid,a.noofpages," +
					"a.documenttype,a.documentsize,a.appname from pdbdocumentversion a,pdbdocumentcontent b," +
					"pdbdocument d  where a.documentindex=b.documentindex and b.parentfolderindex=" +
					"(select folderindex from pdbfolder c where c.name ='"+ wi_name +"') and " +
					"a.documentindex=d.documentindex order by imageindex";
			String output=DB.selectDocs(query);
			output="<output>"+output+"</output>";
			TestXML xml=new TestXML();
			String Documents=xml.getTagValue(output,"TR");
			logger.debug("Documents: "+Documents);
			if(!Documents.trim().equalsIgnoreCase(""))
			{
				String[] DocArray=Documents.split(";");		
				for(String Document: DocArray)
				{
					prevfolderindex="";
					//CH_15022016_001
					Document=Document+" ,";
					//end
					String[] DocParams=Document.split(",");
					logger.info("Archiving document "+DocParams[1]);
					System.out.println("Archiving document "+DocParams[1]);
					query="select * from usr_0_folder_structure where doc='"+ DocParams[1] +"'and processname='"+ processName +"'";
					output=DB.selectFolderStruct(query);
					if(output.equalsIgnoreCase(""))
					{
						logger.info("Folder strcuture not found for "+DocParams[1]);
						System.out.println("Folder strcuture not found for "+DocParams[1]);
						continue;
					}
					String folderpath=output.split(";")[1];
					String dataclassHierarchy=output.split(";")[2];
					String DCValues=output.split(";")[3];
					String docdc=output.split(";")[4];
					logger.info("folderpath: "+folderpath+", dataclassHierarchy: "+dataclassHierarchy+", DCValues: "+DCValues+", docdc: "+docdc);
					String[] folder=folderpath.split("/");
					String[] dataclass=dataclassHierarchy.split("/");
					String folderindex="";
					String folder_path="";
					String[] DCval=DCValues.split("#");
					String DCQUERY="";
					for(int j=0;j<DCval.length;j++)
					{
						if(DCval[j].contains("$"))
						{
							String tmp=DCval[j].replace("=$", "='||");
							tmp=tmp.replace("$", "||'#'||");
							DCQUERY+="'"+tmp+"'";
						}
						else
						{
							String tmp=DCval[j]+"#'||";	    				
							DCQUERY+="'"+tmp+"'";
						}
						
						
						
					}
					DCQUERY=DCQUERY.replace("''", "'");
					query="select "+DCQUERY.substring(0,DCQUERY.length()-3)+" from "+ extTableName +" where wi_name ='"+ wi_name +"'";
					DCValues=DB.selectSingle(query);
					for(int j=0;j<folder.length;j++)
					{
						if(folder[j].contains("$"))
						{
							String val=folder[j].replace("$", " ");
							query="select "+val+" from "+ extTableName +" where wi_name ='"+ wi_name +"'";
							folder[j]=DB.selectSingle(query);
						}
						
						folder[j]=folder[j].replaceAll("\n", "").trim();
						//CH_25022016_001 check for empty folder name
						if(folder[j].equalsIgnoreCase(""))
						{
							logger.info("Skipping for null folder");
							System.out.println("Skipping for null folder");
							continue;
						}
						//CH_25022016_001 ends
						folder_path+=folder[j]+"/";
						
						//LG Changes
						if(dataclass[j].contains("$"))
						{
							String val=dataclass[j].replace("$", " ");
							query="select "+val+" from "+ extTableName +" where wi_name ='"+ wi_name +"'";
							dataclass[j]=DB.selectSingle(query);
							System.out.println("LG FOLER DATACLASS folder"+dataclass[j]);
						}
						logger.info("Folder creation starts for "+folder_path);
						folderindex=createFolder(folder_path.substring(0, folder_path.length()-1),edmsSession,dataclass[j],DCValues);
					}
					logger.info("Created Folder Path: "+folder_path);
					//LGChnages
					if(docdc.contains("$"))
					{
						String val=docdc.replace("$", " ");
						query="select "+val+" from "+ extTableName +" where wi_name ='"+ wi_name +"'";
						docdc=DB.selectSingle(query);
					}
					
					System.out.println("LG DATACLASS DATACLASS folder"+docdc);
					String DocumentIndex=uploadDocument(DocParams[1], DocParams[2]+"#"+DocParams[3]+"#", folderindex,edmsSession, DocParams[4],DocParams[5],DocParams[6],DocParams[7].trim(),docdc,DCValues); //CH_15022016_001 use trim function
					logger.info("Doument Uploaded: "+DocumentIndex);
					System.out.println("Doument Uploaded: "+DocumentIndex);
				}
				logger.info("No. of documents uploaded for workitem "+wi_name+": "+DocArray.length);
			}
			else
			{
				logger.info("No documents found for this workitem");
				System.out.println("No documents found for this workitem");
			}
			
			logger.info("Complete flag: "+sComplete);
			if(sComplete.equalsIgnoreCase("Y"))
			{
				CompleteWorkitem(wi_name, "1", wmsSession, DB);
				logger.info("Workitem "+wi_name+" has been moved to next workstep");
			}
			DB.updateProcess("update "+ extTableName +" set archiveflag='Y' where wi_name='"+wi_name+"'");
			logger.info("Archival flag updated");
			System.out.println("Archival flag updated");

		}
		catch(Exception e)
		{
			logger.error("Exception in archiveDocs: ",e);
			e.printStackTrace();
			logger.info("Archival failed for workitem: "+wi_name);
			System.out.println("Archival failed for workitem: "+wi_name);
			logger.info("Updating archival flag for error case");
			System.out.println("Updating archival flag for error case");
			try
			{
				String archiveflag="";
				String query="select archiveflag from "+extTableName+" where wi_name='"+wi_name+"'";
				String output=DB.selectSingle(query);
				if(output==null)
					output="";
				String flag=output.equalsIgnoreCase("")?"0":output;
				switch(Integer.parseInt(flag))
				{
				case 0:		archiveflag="1";	
				break;
				case 1:		archiveflag="2";
				break;
				case 2:		archiveflag="3";
				break;
				case 3:		archiveflag="E";
				break;
				}
				DB.updateProcess("update "+ extTableName +" set archiveflag='"+archiveflag+"' where wi_name='"+wi_name+"'");
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				logger.error("Exception in updating error status: ",ex);
			}
			throw e;
		}
		finally
		{

		}

	}
	public String createFolder(String folderpath,String sessionid,String DataClass,String DCVal) throws Exception
	{
		TestXML xml=new TestXML(); 
		String[] Folder=folderpath.split("/");
		String Query="select folderindex from pdbfolder where upper(name)=upper('"+ Folder[Folder.length-1] +"') and location<>'T' ";
		if (prevfolderindex.equalsIgnoreCase(""))
			Query=Query+" and parentfolderindex='0'";
		else
			Query=Query+" and parentfolderindex='"+prevfolderindex+"'";
		String folderindex="";
		try 
		{
			folderindex = edms.ExecuteCustomSelectQuery(Query,edmsCabinet, sessionid, edmsIP, edmsPORT);
			folderindex=folderindex.replaceAll("\r","");
			folderindex=folderindex.replaceAll("\n","");
			folderindex=folderindex.replaceAll("\t","");			
			folderindex=xml.getTagValue(folderindex, "tr");	
			if(folderindex.equalsIgnoreCase(""))
			{
				Query="<?xml version=\"1.0\"?><NGOAddFolder_Input><Comment>ByP@$$M@kerChecker</Comment>" +
						"<Option>NGOAddFolder</Option><CabinetName>"+edmsCabinet+"</CabinetName>" +
						"<UserDBId>"+ sessionid +"</UserDBId><Folder>" +
						"<ParentFolderIndex>"+ prevfolderindex +"</ParentFolderIndex>" +
						"<FolderName>"+Folder[Folder.length-1]+"</FolderName>" +
						"<CreationDateTime></CreationDateTime>" +
						"<AccessType>I</AccessType><ImageVolumeIndex></ImageVolumeIndex>" +
						"<FolderType>G</FolderType><Location>G</Location>" +
						"<Comment>User Folder</Comment><EnableFTSFlag>Y</EnableFTSFlag>" +
						"<NoOfDocuments>0</NoOfDocuments>" +
						"<NoOfSubFolders>0</NoOfSubFolders>" +
						"<DataDefinition></DataDefinition></Folder>" +
						"</NGOAddFolder_Input>";
				folderindex = edms.customQuery(Query,edmsCabinet, sessionid, edmsIP, edmsPORT);
				folderindex=folderindex.replaceAll("\r","");
				folderindex=folderindex.replaceAll("\n","");
				folderindex=folderindex.replaceAll("\t","");			
				folderindex=xml.getTagValue(folderindex, "FolderIndex");
			}
			logger.info("Folder index: "+folderindex);
			if(folderindex.equalsIgnoreCase(""))
				throw new Exception("Folder Creation failed");

			logger.info("Folder "+Folder[Folder.length-1]+" created with folderindex: "+folderindex);
			if(!DataClass.equalsIgnoreCase("null"))
			{
				boolean t=associateDataclass(folderindex,DataClass,DCVal,sessionid,edmsIP,edmsPORT);
				if(t==true)
					logger.info("Dataclass "+DataClass+" Associated to folderindex: "+folderindex);
				else
					throw new Exception("Data class association failed for folderindex: "+folderindex);
			}

			prevfolderindex=folderindex;
		} 
		catch (Exception e) 
		{
			logger.error("Exception in createFolder: ",e);			
			prevfolderindex=folderindex;
			throw e;
		}

		return folderindex;
	}



}
