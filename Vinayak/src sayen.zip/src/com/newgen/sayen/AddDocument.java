package com.newgen.sayen;

import java.io.File;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import com.newgen.util.PropertyReaderUtil;
import com.newgen.util.XMLParser;

public class AddDocument {

	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}

	public static String[] attachDoc(String sessionId,String filePath,String folderIndex,String docName,String appName) {
		String[] status = new String[2];
		String serviceUrl = PropertyReaderUtil.getAttachDocODDetail().get("url");
		logger.debug("serviceUrl"+serviceUrl);
		
		docName = docName.replaceAll("&", "&amp;");

		String xmlRequest = getNGOAddDocumentBDOInputXml(sessionId, folderIndex, docName, appName);        
		logger.debug("xmlRequest"+xmlRequest);
		logger.debug("filePath"+filePath);

		File file = new File(filePath);

		try {
			HttpClient httpClient = HttpClientBuilder.create().build();
			HttpPost httpPost = new HttpPost(serviceUrl);

			FileBody fileBody = new FileBody(file, ContentType.DEFAULT_BINARY);
			MultipartEntityBuilder builder = MultipartEntityBuilder.create();
			builder.addPart("file", fileBody);
			builder.addTextBody("NGOAddDocumentBDO", xmlRequest, ContentType.APPLICATION_XML);

			HttpEntity multipart = builder.build();
			httpPost.setEntity(multipart);

			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity responseEntity = response.getEntity();

			logger.debug("Response code ::"+response.getStatusLine().getStatusCode());
			if (responseEntity != null) {
				String responseString = EntityUtils.toString(responseEntity);
				logger.info("responseString::"+responseString);

				if(response.getStatusLine().getStatusCode()==200)
				{
					XMLParser parser = new XMLParser(responseString);
					if(parser.getValueOf("statusCode").equals("0"))
					{
						status[0]="Success";
						status[1]="Success";
						logger.info("Doc attached successfully");
						return status;
					}
					else
					{
						status[0]="Fail";
						status[1]=parser.getValueOf("message");
						return status;
					}
				}
				else
				{
					status[0]="Fail";
					status[1]=responseString;
					logger.info("Error while attching doc::"+responseString);
					return status;
				}
			}
			else
			{
				status[0]="Fail";
				status[1]="Response entiy is null";
				logger.info("Error while attching doc:: Response entiy is null");
				return status;
			}
		} catch (Exception e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.info("Error while attching doc::"+e.getMessage());
			return status;
		}
	}
	
	public static String[] CheckInDocument(String docName, String filePath, String appName, String folderIndex, String sessionId) {
		String[] status = new String[2];
		docName = docName.replaceAll("&", "&amp;");
		String CheckInOutFlag="N";
		File file = new File(filePath);
		String serviceUrl = PropertyReaderUtil.getAttachDocODDetail().get("CheckInServiceUrl");
		String xmlRequest = getNGOCheckInDocumentBDOInputXml(docName, appName, CheckInOutFlag, folderIndex, sessionId);
		logger.info("getNGOCheckInDocumentBDOInputXml : " + xmlRequest);

		try {
			HttpClient httpClient = HttpClientBuilder.create().build();
			HttpPost httpPost = new HttpPost(serviceUrl);

			FileBody fileBody = new FileBody(file, ContentType.DEFAULT_BINARY);
			MultipartEntityBuilder builder = MultipartEntityBuilder.create();
			builder.addPart("file", fileBody);
			builder.addTextBody("NGOCheckInDocumentBDO", xmlRequest, ContentType.APPLICATION_XML);

			HttpEntity multipart = builder.build();
			httpPost.setEntity(multipart);
			
			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity responseEntity = response.getEntity();

			logger.info("CheckInDocument : Response code ::"+response.getStatusLine().getStatusCode());
			
			if (responseEntity != null) {
				String responseString = EntityUtils.toString(responseEntity);
				logger.info("CheckInDocument : responseString :: " + responseString);

				if (response.getStatusLine().getStatusCode() == 200) {
					XMLParser parser = new XMLParser(responseString);
					if (parser.getValueOf("status").equals("0")) {
						logger.info("CheckInDocument : " + parser.getValueOf("message"));
						status[0]= "Success";
						status[1]="Success";
					} else {
						logger.info("CheckInDocument : Error in response :: " + responseString);
						status[0]="Fail";
						status[1]=responseString;
					}
				} else {
					logger.info("CheckInDocument : Error in response :: " + responseString);
					status[0]="Fail";
					status[1]=responseString;
				}
			} else {
				logger.info("CheckInDocument : Error responseEntity is null");
				status[0]="Fail";
				status[1]="CheckInDocument : Error responseEntity is null";
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("CheckInDocument : Exception " + e.getMessage());
			status[0]="Fail";
			status[1]=e.getMessage();
		}
		return status;
	}

	public static String getNGOCheckInDocumentBDOInputXml(String docName, String appName, String CheckInOutFlag, String DocumentIndex, String sessionID) {
		return "<NGOCheckInDocumentBDO>\r\n"
		+ " <cabinetName>"+PropertyReaderUtil.getCabName()+"</cabinetName>\r\n"
		+ " <userDBId>"+sessionID+"</userDBId>\r\n"
		+ " <currentDateTime></currentDateTime>\r\n"
		+ " <limitCount>1000</limitCount>\r\n"
		+ " <checkInOutFlag>"+CheckInOutFlag+"</checkInOutFlag>\r\n"
		+ " <supAnnotVersion>Y</supAnnotVersion>\r\n"
		+ " <documentIndex>"+DocumentIndex+"</documentIndex>\r\n"
		+ " <versionComment>AddDocument Version</versionComment>\r\n"
		+ " <createdByAppName>"+appName+"</createdByAppName>\r\n"
		+ " <majorVersion></majorVersion>\r\n"
		+ " <volumeId>"+PropertyReaderUtil.getVolumeId()+"</volumeId>\r\n"
		+ " <documentName>"+docName+"</documentName>\r\n"
		+ " <userName></userName>\r\n"
		+ " <userPassword></userPassword>\r\n"
		+ " <locale>en_US</locale>\r\n"
		+ "</NGOCheckInDocumentBDO>";
	}
	


	private static String getNGOAddDocumentBDOInputXml(String sessionId, String folderIndex, String docName,
			String appName) {
		return "<NGOAddDocumentBDO>"
			+ " <cabinetName>"+PropertyReaderUtil.getCabName()+"</cabinetName>"
			+ " <folderIndex>"+folderIndex+"</folderIndex>"
			+ " <documentName>"+docName+"</documentName>"
			+ " <userDBId>"+sessionId+"</userDBId>"
			+ " <volumeId>"+PropertyReaderUtil.getVolumeId()+"</volumeId>"
			+ " <accessType>I</accessType>"
			+ " <createdByAppName>"+appName+"</createdByAppName>"
			+ " <enableLog>Y</enableLog>"
			+ " <versionFlag></versionFlag>"
			+ " <textAlsoFlag></textAlsoFlag>"
			+ " <ownerType>U</ownerType>"
			+ " <ownerIndex></ownerIndex>"
			+ " <nameLength></nameLength>"
			+ "<thumbNailFlag>N</thumbNailFlag>"
			+ " <imageData></imageData>"
			+ " <encrFlag></encrFlag>"
			+ " <passAlgoType></passAlgoType>"
			+ " <userName></userName>"
			+ " <userPassword></userPassword>"
			+ " <comment></comment>"
			+ " <locale>en_US</locale>"
			//	+ " <NGOAddDocDataDefCriterionBDO>"
			//	+ " <dataDefIndex>4</dataDefIndex>"
			//	+ " <dataDefName>Document QC</dataDefName>"
			//	+ " </NGOAddDocDataDefCriterionBDO>"
			+ "</NGOAddDocumentBDO>";
	}
}
