package com.newgen.sayen;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.newgen.util.PropertyReaderUtil;

public class ApplyTemplate {

	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}

	public static String[] applyTemplate(String packageId,String docId,String accessToken,String templateName,String noOfPages) {
		String[] status = new String[2];
		String url = PropertyReaderUtil.getAddTemplateDetail().get("url");
		url=url.replace("package_id", packageId);
		url=url.replace("doc_id", docId);
		JSONObject user = new JSONObject();
		logger.debug("templateName:"+templateName);
		logger.debug("template Id:"+PropertyReaderUtil.getAddTemplateDetail().get(templateName));
		user.put("template_name", PropertyReaderUtil.getAddTemplateDetail().get(templateName)+noOfPages);
		user.put("apply_to_all", false);
		String requestBody = user.toString();
			
		logger.debug("requestBody for template application::"+requestBody);
		logger.debug("url for template application"+url);
		HttpClient httpClient = HttpClients.createDefault();
		// Set proxy settings if required
		HttpHost proxy = new HttpHost(PropertyReaderUtil.getProxyIP(), PropertyReaderUtil.getProxyPort());
		RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
		httpClient = HttpClients.custom().setDefaultRequestConfig(config).build();
		HttpPost httpPost = new HttpPost(url);

		// Set request headers
		httpPost.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken);
		httpPost.setHeader(HttpHeaders.CONTENT_TYPE, PropertyReaderUtil.getAddTemplateDetail().get("Content-Type"));
		httpPost.setHeader(HttpHeaders.ACCEPT, PropertyReaderUtil.getAddTemplateDetail().get("Accept"));

		// Set request body
		StringEntity stringEntity = null;
		try {
			stringEntity = new StringEntity(requestBody);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("UnsupportedEncodingException::"+e.getMessage());
			return status;
		}
		httpPost.setEntity(stringEntity);

		// Execute the request
		HttpResponse response = null;
		try {
			response = httpClient.execute(httpPost);
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("ClientProtocolException::"+e.getMessage());
			return status;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("IOException::"+e.getMessage());
			return status;
		}

		// Get response status code
		int statusCode = response.getStatusLine().getStatusCode();
		logger.info("Response Status Code: " + statusCode);

		// Get response body
		HttpEntity entity = response.getEntity();
		String responseBody = null;
		try {
			responseBody = EntityUtils.toString(entity);
			logger.info("Response body: " + responseBody);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("ParseException::"+e.getMessage());
			return status;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("IOException1::"+e.getMessage());
			return status;
		}
		JSONObject jsonResponse = new JSONObject(responseBody);
		if(statusCode==200)
		{
			status[0]="Success";
			status[1]="Success";
			return status;
		}
		else
		{
			String Message = jsonResponse.getString("Message");
			logger.error("Message: " + Message);
			status[0]="Fail";
			status[1]=Message;
			return status;
		}
	}


}
