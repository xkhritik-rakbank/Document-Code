package com.newgen.sayen;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import org.apache.log4j.Logger;

import com.newgen.util.PropertyReaderUtil;

public class DeleteDocument {
	static final Logger logger;
	static {
		PropertyReaderUtil.loadLog4j();
		logger = Logger.getLogger("Sayan");
	}

	public static String[] delete(String accessToken, String packageId) {
		HttpsURLConnection connection = null;
		String[] status = new String[3];
		try {
			String apiUrl = PropertyReaderUtil.getDeleteDetail().get("url");
			logger.debug("apiUrl:::" + apiUrl);
			apiUrl = apiUrl.replace("package_id", packageId);
			logger.debug("apiUrl after replace :::" + apiUrl);
			URL url = new URL(apiUrl);

			Proxy webProxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PropertyReaderUtil.getProxyIP(), PropertyReaderUtil.getProxyPort()));
			connection = (HttpsURLConnection) url.openConnection(webProxy);
			connection.setRequestMethod("DELETE");

			// Set the Content-Type and Accept headers
			connection.setRequestProperty("Content-Type",
					PropertyReaderUtil.getDeleteDetail().get("Content-Type"));
			connection.setRequestProperty("Accept", PropertyReaderUtil.getDeleteDetail().get("Accept"));
			connection.setRequestProperty("Authorization", "Bearer " + accessToken);
			// Replace {access_token} with the actual access token

			// Enable input and output streams
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setConnectTimeout(60000);
			connection.setReadTimeout(60000);
			
			// Get response code
			int responseCode = connection.getResponseCode();
			logger.info("Response Code: " + responseCode);
			
			if (responseCode == 200) {
				status[0] = "Success";
				status[1] = "Success";
				return status;
			} else if (responseCode == 400) {
				logger.info("The document is no longer available for viewing");
			    status[0] = "Success";
				status[1] = "Success";
				return status;
			} else {
				logger.error("response Code: " + responseCode);
				status[0] = "Fail";
				status[1] = "Fail";
				return status;
			}
		} catch (Exception e) {
			e.printStackTrace();
			status[0] = "Fail";
			status[1] = e.getMessage();
			logger.error("Exception::" + e.getMessage());
			return status;
		} finally {
			try {
				if (connection != null)
					connection.disconnect();
			} catch (Exception e) {
				e.printStackTrace();
				status[0] = "Fail";
				status[1] = e.getMessage();
				logger.error("Exception::" + e.getMessage());
			}

		}
	}
}
