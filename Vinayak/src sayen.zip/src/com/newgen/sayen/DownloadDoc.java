package com.newgen.sayen;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Proxy;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.log4j.Logger;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import com.newgen.util.PropertyReaderUtil;

public class DownloadDoc {
	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}
	public static String[] docDownload(String accessToken ,String packageId,int documentId,String packageName,String docName, String appName) {
		String proxyHost = PropertyReaderUtil.getProxyIP();
		int proxyPort = PropertyReaderUtil.getProxyPort();
		String[] status = new String[2];
		Proxy webProxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));  
		HttpHost targetHost = new HttpHost(PropertyReaderUtil.getDownloadDocDetail().get("targetHost"), 443, "https");

		RequestConfig config = RequestConfig.custom()
				.setProxy(new HttpHost(proxyHost, proxyPort))
				.build();

		// Create the HTTP client with the proxy
		HttpClient httpClient = HttpClients.custom()
				.setDefaultRequestConfig(config)
				.build();

		String endpoint = PropertyReaderUtil.getDownloadDocDetail().get("url");

		HttpGet request = new HttpGet(endpoint.replace("package_id", packageId).replace("doc_id", Integer.toString(documentId)));
		request.addHeader(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken);
		request.addHeader(HttpHeaders.ACCEPT, PropertyReaderUtil.getDownloadDocDetail().get("Accept"));
		InputStream inputStream = null;
		FileOutputStream outputStream = null;
		try {
			HttpResponse response = httpClient.execute(targetHost, request);
			int responseCode=response.getStatusLine().getStatusCode();
			logger.info("responseCode::"+responseCode);
			String path = System.getProperty("user.dir")+	System.getProperty("file.separator") +PropertyReaderUtil.getSignedDocDownloadPath() +
					System.getProperty("file.separator")+packageName;
			//String path = "E:\\Disha"+	System.getProperty("file.separator") +PropertyReaderUtil.getSignedDocDownloadPath() +
			//System.getProperty("file.separator")+packageName;
			File Folder_path = new File(path);
			boolean folderExist=true;
			if(!Folder_path.exists())
			{
				folderExist = Folder_path.mkdirs();
			}
			if(folderExist)
			{
				logger.debug("Download Path : "+path);
				path+=System.getProperty("file.separator")+docName+"."+appName;
				logger.debug("Doc Path : "+path);
				HttpEntity entity = response.getEntity();
				if (entity != null && responseCode==200) {
					inputStream = entity.getContent();
					outputStream = new FileOutputStream(new File(path));
					int inByte;
					while ((inByte = inputStream.read()) != -1) {
						outputStream.write(inByte);
					}
				}
				EntityUtils.consume(entity);
				status[0]="Success";
				status[1]=path;
				return status;
			}
			else
			{
				status[0]="Fail";
				status[1]="Unable to create directory";
				return status;
			}

		} catch (Exception e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.info("Error while download doc::"+e.getMessage());
			return status;
		} 
		finally
		{
			try
			{
				inputStream.close();
				outputStream.close();
			}
			catch (Exception e) {
				e.printStackTrace();
				status[0]="Fail";
				status[1]=e.getMessage();
				logger.info("Error while download doc::"+e.getMessage());
				//return status;
			} 
		}
	}
}

