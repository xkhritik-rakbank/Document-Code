package com.newgen.sayen;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;

import org.apache.log4j.Logger;

import com.newgen.util.PropertyReaderUtil;


public class DownloadDocumentOD {
	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}


	public static String[] fetchDoc(String docIndex,String sessionId,String path) {
		String[] status = new String[2];
		OutputStreamWriter writer=null;
		BufferedReader reader = null;
		HttpURLConnection conn = null;

		String serviceUrl = "http://"+PropertyReaderUtil.getAppServerIp()+":"+PropertyReaderUtil.getAppServerPort()+"/OmniDocsRestWS/rest/services/getDocument";
		String requestBody = "<NGOGetDocumentBDO>"
				+ " <cabinetName>"+PropertyReaderUtil.getCabName()+"</cabinetName>"
				+ " <docIndex>"+docIndex+"</docIndex>"
				+ " <siteId>"+PropertyReaderUtil.getSiteId()+"</siteId>"
				+ " <volumeId>"+PropertyReaderUtil.getVolumeId()+"</volumeId><userName></userName>"
				+ "<userPassword></userPassword>"
				+ " <userDBId>"+sessionId+"</userDBId>"
				+ " <locale>en_US</locale>"
				+ "</NGOGetDocumentBDO>";


		try {
			// Set up the HTTP connection
			URL url = new URL(serviceUrl);
			conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/xml");
			conn.setRequestProperty("Accept", "application/xml");

			// Write the request body to the connection
			writer = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
			writer.write(requestBody);
			writer.flush();

			// Read the response from the connection
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
			StringBuilder responseBuilder = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null) {
				responseBuilder.append(line);
			}
			String responseXml = responseBuilder.toString();
			//logger.debug("responseXml::"+responseXml);

			if(getTagValues(responseXml, "statusCode").equals("0")) 
			{ 
				byte[] decodedBytes = Base64.getDecoder().decode(getTagValues(responseXml, "docContent"));

				try {
					// Create a file with the decoded bytes
					FileOutputStream fos = new FileOutputStream(path);
					fos.write(decodedBytes);
					fos.close();
					System.out.println("Document created successfully.");
				} catch (IOException e) {
					e.printStackTrace();
				}

				status[0]="Success";
				status[1]=getTagValues(responseXml, "docContent"); 
				return status;

			} else {
				logger.error("Error from API get documnet::"+getTagValues(responseXml,"message")); 
				status[0]="Fail"; 
				status[1]=getTagValues(responseXml,"message"); 
				return status; 
			}

		} catch (Exception e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("Exception while fetching doc from SMS::"+e.getMessage());
			return status;
		}
		finally
		{
			try {
				writer.close();
				reader.close();
				conn.disconnect();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Error while closing connection::"+e.getMessage());
				//return status;
			}

		}
	}

	private static String getTagValues(String sXML, String sTagName) {
		String sTagValues = "";
		String sStartTag = "<" + sTagName + ">";
		String sEndTag = "</" + sTagName + ">";
		String tempXML = sXML;
		tempXML = tempXML.replaceAll("&", "#amp#");
		try {

			for (int i = 0; i < sXML.split(sEndTag).length - 1; i++) {
				if (tempXML.indexOf(sStartTag) != -1) {
					sTagValues += tempXML.substring(tempXML.indexOf(sStartTag)
							+ sStartTag.length(), tempXML.indexOf(sEndTag));
					//logger.debug("sTagValues"+sTagValues);
					tempXML = tempXML.substring(tempXML.indexOf(sEndTag)
							+ sEndTag.length(), tempXML.length());
				}
				if (tempXML.indexOf(sStartTag) != -1) {
					sTagValues += ",";
					//logger.debug("sTagValues"+sTagValues);
				}
			}
			if (sTagValues.indexOf("#amp#") != -1) {
				logger.debug("Index found");
				sTagValues = sTagValues.replaceAll("#amp#", "&");
			}
			//logger.debug(" Final sTagValues"+sTagValues);
		} catch (Exception e) {
		}
		return sTagValues;
	}
}

