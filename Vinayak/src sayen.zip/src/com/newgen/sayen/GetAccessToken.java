package com.newgen.sayen;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.newgen.util.PropertyReaderUtil;


public class GetAccessToken {
	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}


	public static String[] getAccessToken() {
		String[] status = new String[2];
		HttpClient httpClient = HttpClients.createDefault();

		// Set proxy settings if required
		logger.debug("ProxyIp:"+PropertyReaderUtil.getProxyIP());
		logger.debug("ProxyPort:"+PropertyReaderUtil.getProxyPort());
		logger.debug("URL:"+PropertyReaderUtil.getAccessTokenDetail().get("url"));

		HttpHost proxy = new HttpHost(PropertyReaderUtil.getProxyIP(), PropertyReaderUtil.getProxyPort());
		RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
		httpClient = HttpClients.custom().setDefaultRequestConfig(config).build();

		HttpPost httpPost = new HttpPost(PropertyReaderUtil.getAccessTokenDetail().get("url"));

		// Request body parameters
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("grant_type", PropertyReaderUtil.getAccessTokenDetail().get("grantType")));
		params.add(new BasicNameValuePair("client_id", PropertyReaderUtil.getAccessTokenDetail().get("clientId")));
		params.add(new BasicNameValuePair("client_secret", PropertyReaderUtil.getAccessTokenDetail().get("clientSecret")));
		params.add(new BasicNameValuePair("username", PropertyReaderUtil.getAccessTokenDetail().get("username")));
		params.add(new BasicNameValuePair("password", PropertyReaderUtil.getAccessTokenDetail().get("password")));

		logger.debug("Params setting finished");
		try {
			httpPost.setEntity(new UrlEncodedFormEntity(params));
			logger.debug("set entity finished");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("UnsupportedEncodingException::"+e.getMessage());
			return status;
		}

		// Set request headers
		httpPost.setHeader("Content-Type", PropertyReaderUtil.getAccessTokenDetail().get("Content-Type"));
		httpPost.setHeader("Accept", PropertyReaderUtil.getAccessTokenDetail().get("Accept"));
		logger.debug("set header finished");
		// Execute the request
		HttpResponse response = null;
		while (true)
		{
			try {
				response = httpClient.execute(httpPost);
				break;
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				status[0]="Fail";
				status[1]=e.getMessage();
				logger.error("ClientProtocolException::"+e.getMessage());
				//return status;
			} catch (IOException e) {
				// TODO Auto-generated catch block		
				e.printStackTrace();
				status[0]="Fail";
				status[1]=e.getMessage();
				logger.error("IOException::"+e.getMessage());
				logger.error("Exception details:", e);

				//return status;
			}
		}

		// Get response status code
		int statusCode = response.getStatusLine().getStatusCode();
		logger.info("Response Status Code: " + statusCode);

		// Get response body
		HttpEntity entity = response.getEntity();
		String responseBody = null;
		try {
			responseBody = EntityUtils.toString(entity);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("ParseException::"+e.getMessage());
			return status;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("IOException1::"+e.getMessage());
			return status;
		}
		logger.info("Response Body: " + responseBody);
		JSONObject jsonResponse = new JSONObject(responseBody);
		if(statusCode==200)
		{
			String accessToken = jsonResponse.getString("access_token");
			logger.info("Access Token: " + accessToken);
			status[0]="Success";
			status[1]=accessToken;
			return status;
		}
		else
		{
			String errorMsg = jsonResponse.getString("error_description");
			logger.error("errorMsg: " + errorMsg);
			status[0]="Fail";
			status[1]=errorMsg;
			return status;
		}
	}
}
