package com.newgen.sayen;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.newgen.util.PropertyReaderUtil;

public class GetStatus {
	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}
	public static String[] status(String accessToken,String packageId) {
		BufferedReader bufferedReader=null;
		HttpsURLConnection connection=null;
		String[] status = new String[3];
		try {
			String apiUrl = PropertyReaderUtil.getfetchStatusDetail().get("url");
			apiUrl= apiUrl.replace("package_id", packageId);
			logger.debug("apiUrl:::"+apiUrl);
			URL url = new URL(apiUrl);

			Proxy webProxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PropertyReaderUtil.getProxyIP(), PropertyReaderUtil.getProxyPort()));  
			connection   = (HttpsURLConnection) url.openConnection(webProxy);
			connection.setRequestMethod("GET");

			// Set the Content-Type and Accept headers
			connection.setRequestProperty("Content-Type",PropertyReaderUtil.getfetchStatusDetail().get("Content-Type"));
			connection.setRequestProperty("Accept",PropertyReaderUtil.getfetchStatusDetail().get("Accept"));
			connection.setRequestProperty("Authorization", "Bearer " + accessToken);        
			// Replace {access_token} with the actual access token

			// Enable input and output streams
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setConnectTimeout(60000);
			connection.setReadTimeout(60000);
			// Get response code
			int responseCode = connection.getResponseCode();
			logger.info("Response Code: " + responseCode);

			// Read response body
			bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String line;
			StringBuilder response = new StringBuilder();
			while ((line = bufferedReader.readLine()) != null) {
				response.append(line);
			}
			logger.debug("Response Body for get status: " + response.toString());
			JSONObject jsonResponse = new JSONObject(response.toString());
			if (responseCode == 200) {
				String packageStatus=jsonResponse.getString("package_status");
				status[0]="Success";
				status[1]=packageStatus;
				if(packageStatus.equalsIgnoreCase("COMPLETED"))
				{
					JSONArray documents = jsonResponse.getJSONArray("documents");
					logger.debug("JSON for doc details ::"+documents.toString());
					status[2]=documents.toString();
				}
				return status;
			} 
			else {
				String Message = jsonResponse.getString("Message");
				logger.error("Message: " + Message);
				status[0]="Fail";
				status[1]=Message;
				return status;
			}
		} catch (Exception e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("Exception::"+e.getMessage());
			return status;
		}
		finally
		{
			try {
				if (bufferedReader != null)
					bufferedReader.close();
				if (connection != null)
					connection.disconnect();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				status[0]="Fail";
				status[1]=e.getMessage();
				logger.error("Exception::"+e.getMessage());
				//return status;
			}

		}
	}
}

