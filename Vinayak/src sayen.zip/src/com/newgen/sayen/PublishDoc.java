package com.newgen.sayen;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import org.json.*;
import javax.net.ssl.HttpsURLConnection;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.newgen.util.PropertyReaderUtil;

public class PublishDoc {
	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}
	
	public static String[] docPublish(String packageId, String accessToken) {
		// API endpoint URL
		String[] status = new String[2];
		OutputStream outputStream = null;
		BufferedReader bufferedReader = null;
		HttpsURLConnection connection  = null;

		try {
			String apiUrl = PropertyReaderUtil.getPublishDocDetail().get("url");
			apiUrl= apiUrl.replace("package_id", packageId);			
			URL url = new URL(apiUrl);

			Proxy webProxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PropertyReaderUtil.getProxyIP(), PropertyReaderUtil.getProxyPort()));  
			connection   = (HttpsURLConnection) url.openConnection(webProxy); 

			// Set request method
			connection.setRequestMethod("POST");

			// Set request headers
			connection.setRequestProperty("Content-Type",  PropertyReaderUtil.getPublishDocDetail().get("Content-Type"));
			connection.setRequestProperty("Accept", PropertyReaderUtil.getPublishDocDetail().get("Accept"));

			connection.setRequestProperty("Authorization", "Bearer " + accessToken);
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setConnectTimeout(60000);
			connection.setReadTimeout(60000);
			
			// Request body
			String requestBody = "{ \"property1\": \""+PropertyReaderUtil.getPublishDocDetail().get("property1")+"\", "
					+ "\"property2\": \""+PropertyReaderUtil.getPublishDocDetail().get("property2")+"\" }";
			// Replace with your actual request body JSON

			// Write request body to output stream
			outputStream = connection.getOutputStream();
			outputStream.write(requestBody.getBytes());

			// Get response code
			int responseCode = connection.getResponseCode();
			logger.info("Response Code: " + responseCode);

			// Read response body
			bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String line;
			StringBuilder response = new StringBuilder();
			while ((line = bufferedReader.readLine()) != null) {
				response.append(line);
			}
			bufferedReader.close();

			// Print response body
			logger.info("Response Body: " + response.toString());

			JSONArray jsonArray = new JSONArray(response.toString());
			JSONObject jsonResponse = jsonArray.getJSONObject(0);
			if (responseCode == 200) {
				status[0]="Success";
				status[1]="Success";
				return status;
			} 
			else {
				String Message = jsonResponse.getString("Message");
				logger.error("Message: " + Message);
				status[0]="Fail";
				status[1]=Message;
				return status;
			}

		} catch (Exception e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("IOException::"+e.getMessage());
			return status;
		}
		finally
		{
			try {
				outputStream.flush();
				outputStream.close();
				bufferedReader.close();
				connection.disconnect();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				status[0]="Fail";
				status[1]=e.getMessage();
				logger.error("IOException::"+e.getMessage());
				//return status;
			}
		}
	}
}
