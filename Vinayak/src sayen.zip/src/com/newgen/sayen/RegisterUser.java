package com.newgen.sayen;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.newgen.util.PropertyReaderUtil;

public class RegisterUser {

	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}

	public static String[] register(String accessToken, String email, String userName,String mobileNo,String nationalId) {
		String[] status = new String[2];
		OutputStream outputStream = null;
		BufferedReader bufferedReader = null;
		try {
			String apiUrl = PropertyReaderUtil.getAddUserDetail().get("urlRegister");
			// Create the request body as a JSON string
			String requestBody = "{ \"user_email\": \""+email+"\", \"user_name\": \""+userName+"\", "
					+ "\"user_role\": \""+PropertyReaderUtil.getAddUserDetail().get("role")+"\", "
					+ "\"email_notification\": "+PropertyReaderUtil.getAddUserDetail().get("email_notification")+", "
					+ "\"mobile_number\": "+mobileNo+", "
					+ "\"user_national_id\": "+nationalId+" }";
			logger.debug("requestBody"+requestBody);

			URL url = new URL(apiUrl);
			Proxy webProxy      = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PropertyReaderUtil.getProxyIP(), PropertyReaderUtil.getProxyPort()));  
			HttpsURLConnection connection   = (HttpsURLConnection) url.openConnection(webProxy); 

			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type",  PropertyReaderUtil.getAddUserDetail().get("Content-Type"));
			connection.setRequestProperty("Accept", PropertyReaderUtil.getAddUserDetail().get("Accept"));

			// Set the Authorization header with the access token
			connection.setRequestProperty("Authorization", "Bearer " + accessToken);
			connection.setConnectTimeout(60000);
			connection.setReadTimeout(60000);
			// Enable input and output streams
			connection.setDoOutput(true);
			connection.setDoInput(true);

			// Write the request body to the output stream
			outputStream = connection.getOutputStream();
			outputStream.write(requestBody.getBytes());

			// Get the response code
			int responseCode = connection.getResponseCode();
			logger.debug("responseCode :: "+requestBody);

			if (responseCode == 422) {
				status[0]="Success";
				status[1]="Success";
				return status;
			} 
			
			logger.debug("BufferedReader Start :: ");

			// Read the response from the input stream
			bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = bufferedReader.readLine()) != null) {
				response.append(inputLine);
			}
			logger.debug("Response Body: " + response.toString());

			// Print the response
			System.out.println("Response Code: " + responseCode);
			System.out.println("Response Body: " + response.toString());

			if (responseCode == 201) {
				status[0]="Success";
				status[1]="Success";
				return status;
			} 
			else if(responseCode == 200)
			{
				JSONObject jsonResponse = new JSONObject(response.toString());
				String Message = jsonResponse.getString("Message");
				logger.info("While registeration:"+Message);
				status[0]="Success";
				status[1]=Message;
				return status;
			}
			else {
				JSONObject jsonResponse = new JSONObject(response.toString());
				String Message = jsonResponse.getString("Message");
				logger.error("Message: " + Message);
				status[0]="Fail";
				status[1]=Message;
				return status;
			}
		} catch (Exception e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("Exception::"+e.getMessage());
			return status;
		}
		finally
		{
			try {
				outputStream.flush();
				outputStream.close();
				if (bufferedReader != null)
					bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
				status[0]="Fail";
				status[1]=e.getMessage();
				logger.error("IOException::"+e.getMessage());
			//	return status;
			}
		}
	}
}
