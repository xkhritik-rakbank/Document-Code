//DGFPL-224 Sanchi/Silki 30-11-2023	Takaful questionnaire changes

package com.newgen.sayen;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.json.JSONArray;
import org.json.JSONObject;

import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.util.DocDetail;
import com.newgen.util.PropertyReaderUtil;
import com.newgen.util.UserDetail;
import com.newgen.util.XMLParser;

public class SayenIntegration {

	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}

	public static void main(String[] args) {
		PropertyReaderUtil.setProperty();
		Thread thread = new Thread(new Runnable() {
			@Override
			public void run() {
				
				String[] docToSign= PropertyReaderUtil.getDocNameToBeSigned().split(",");
				String[] docSigned= PropertyReaderUtil.getDocNameSigned().split(",");
				HashMap<String,String> docMapping = new HashMap<>();
				for(int j=0; j<docSigned.length; j++)
				{
					docMapping.put(docToSign[j], docSigned[j]);
				}

				logger.info("Length:"+docSigned.length);
				if(docSigned.length==docToSign.length)
				{
					while (true) {
						String sessionId = checkExistingSession();
						if ("".equals(sessionId)) {
							String input = getConnectInput();
							logger.debug("inputConnect::" + input);
							String output = ExecuteAPI(input);
							logger.debug("output connect" + output);
							if (output.equalsIgnoreCase("error")) {
								logger.error("error received while connecting " + output);
							} else {
								if (getTagValues(output, "Status").equals("0")) {
									sessionId = getTagValues(output, "UserDBId");
									logger.debug("sessionId ::" + sessionId);
								}
							}
						}
						
						if ("".equals(sessionId)) {
							logger.error("Unable to fetch session id");
							return;
						}
						
//						String input = getConnectInput();
//						logger.debug("inputConnect::"+input);
//						String output=ExecuteAPI(input);
//						logger.debug("output connect"+output);

						/*if(output.equalsIgnoreCase("error"))
						{
							logger.error("error received while connecting "+output);
						}
						else
						{
							XMLParser parser = new XMLParser();
							if(getTagValues(output, "Status").equals("0"))
							{
								sessionId=getTagValues(output, "UserDBId");
								logger.debug("sessionId ::" +sessionId);*/
								
						String input = getApselectWithColumnNamesXML(sessionId,PropertyReaderUtil.getDbQuery());
						logger.debug("input::"+input);
						String output=ExecuteAPI(input);
						logger.debug("output from table:: "+output);
						if(output.equalsIgnoreCase("error"))
						{
							logger.error("error received while getting data  from db ");
						}
						else
						{
							XMLParser parser = new XMLParser();
							if(getTagValues(output, "MainCode").equals("0"))
							{
								int recordCount=Integer.parseInt(getTagValues(output, "TotalRetrieved"));
								logger.debug("Total Record Count ::" +recordCount);
								parser.setInputXML(output);
								for (int i =1 ; i <=recordCount ;i++){

									String str=parser.getNextValueOf("Record");
									logger.debug("str::" +str);
									System.out.println("Processing started....");
									try {
										String row = getTagValues(str, "SNo");
										String packageName = getTagValues(str, "workItemId");
										String applicantId="";
										String applicantMobile="";
										//String email = getTagValues(str, "email");
										//String userName = getTagValues(str, "userName");
										String docstatus = getTagValues(str, "status");
										//String nationalId = getTagValues(str, "nationalId");
										//String mobileNo = getTagValues(str, "mobileNo");
										String docDeletedStatus = getTagValues(str, "docDeletedStatus");
										

										String accessToken = "";
										String[] status = GetAccessToken.getAccessToken();
										if(status[0]=="Success")
										{
											accessToken=status[1];
										}
										else {
											logger.debug("Unable to generate token");
											try {
												throw new Exception("Error occurred while getting access token::"+status[1]);
											} catch (Exception e) {
												e.printStackTrace();
											}
											return;
										}
										logger.debug("accessToken :: " +accessToken);
										String packageId = getTagValues(str, "packageId");

										//DGFPL-224 start
										String workstepName = getTagValues(str, "WorkStepName");//DGFPL-224
										//DGFPL-224 end
										ArrayList<DocDetail> listDoc = new ArrayList<DocDetail>();
										ArrayList<UserDetail> userList = new ArrayList<>();
										/** Ravindra 11-01-2024
										 * Delete the document after x number of days and days should be configured in config file. 
										 * completed Declined Inprogress*/
										String sentDate = getTagValues(str, "sentDate");
										if (sentDate != null && !"".equals(sentDate)) {
											long days = getDaysBtwTwoDates(sentDate);
											if (days > PropertyReaderUtil.getDocDeleteInXDays()) {
												if(!docstatus.equalsIgnoreCase("Initiated")) {
													deleteDocument(accessToken, packageId, row, sessionId, docstatus);
												} else {
													deleteRecordsWithInitiateStatus(row, sessionId);
												}
												continue;
											}
										}
										
										// By Ravindra 10-01-2024 DGFPL-250
										//If sell type is not valid.
										if ("DELETE DOCUMENT".equalsIgnoreCase(docDeletedStatus)) {
											logger.debug("delete document status is DELETE DOCUMENT so delete doc :: " +docDeletedStatus);
											deleteDocument(accessToken, packageId, row, sessionId, docstatus);
										}
										
										if(docstatus.equalsIgnoreCase("Initiated"))
										{
											//String docToFetch = PropertyReaderUtil.getDocNameToBeSigned();//DGFPL-224
											//docToFetch = docToFetch.replace(",", "','");//DGFPL-224
											//DGFPL-224 start
											String docToFetch = "";
											if(workstepName.equalsIgnoreCase("Initiate Request"))
											{
												docToFetch = PropertyReaderUtil.getDocNameToBeSigned_Initiate();//DGFPL-224
												docToFetch = docToFetch.replace(",", "','");
												
											}
											else if(workstepName.equalsIgnoreCase("Contract Generation"))
											{
												docToFetch = PropertyReaderUtil.getDocNameToBeSigned_Contract();//DGFPL-224
												docToFetch = docToFetch.replace(",", "','");
												logger.debug("docToFetch::: " +docToFetch);
											}
											//DGFPL-224 end
											
											String Query = "SELECT name,documentindex,AppName FROM PDBDocument WITH (NOLOCK) WHERE DocumentIndex IN (SELECT DocumentIndex FROM PDBDocumentContent a WITH (NOLOCK) "
													+ "JOIN PDBFolder b WITH (NOLOCK) ON b.FolderIndex = a.ParentFolderIndex WHERE Name = '"+packageName+"' ) AND Name in ('"+docToFetch+"')";
											String inputFetchDoc = getApselectWithColumnNamesXML(sessionId,Query);
											logger.debug("input fetch docindex::"+inputFetchDoc);
											String outputFetchDoc=ExecuteAPI(inputFetchDoc);
											logger.debug("output fetch doc index"+outputFetchDoc);

											if(outputFetchDoc.equalsIgnoreCase("error"))
											{
												logger.error("error received while fetching doc index "+outputFetchDoc);
											}
											else
											{
												if(getTagValues(outputFetchDoc, "MainCode").equals("0"))
												{
													int docCount=Integer.parseInt(getTagValues(outputFetchDoc, "TotalRetrieved"));
													XMLParser parseDocId = new XMLParser(outputFetchDoc);

													for(int j=1;j<=docCount;j++)
													{
														DocDetail objDoc = new DocDetail();
														String strRecord=parseDocId.getNextValueOf("Record");
														objDoc.setDocIndex(getTagValues(strRecord, "documentindex"));
														objDoc.setAppName(getTagValues(strRecord, "AppName"));
														objDoc.setName(getTagValues(strRecord, "name"));
														listDoc.add(objDoc);
													}
													logger.debug("No of Docs initial"+listDoc.size());

													String path = System.getProperty("user.dir")+System.getProperty("file.separator")+
															PropertyReaderUtil.getDocDownloadPath()+System.getProperty("file.separator")+packageName+System.getProperty("file.separator");

													File Folder_path = new File(path);
													boolean folderExist=true;
													if(!Folder_path.exists())
													{
														folderExist = Folder_path.mkdirs();
													}
													if(folderExist)
													{
														status[0]="Fail";
														int counter=0;
														for(DocDetail objDoc:listDoc)
														{
															String completePath = path+objDoc.getName()+"."+objDoc.getAppName();
															status  = DownloadDocumentOD.fetchDoc(objDoc.getDocIndex(),sessionId,completePath);

															PDDocument pdfDoc;
															int pageCount = 0;
															try {
																pdfDoc = PDDocument.load(new File(completePath));
																pageCount = pdfDoc.getNumberOfPages();
																pdfDoc.close();
															} catch (IOException ex) {
																ex.printStackTrace();
															}
															logger.info("NoOfPages in pdf  :" + pageCount);
															objDoc.setNoOfPages(Integer.toString(pageCount));
															listDoc.set(counter, objDoc);

															counter++;

														}


														if(status[0].equals("Fail"))
														{
															logger.info("Issue while downloading the document "+status[1]);
														}
														else
														{
															String fetchCustomerDetail = PropertyReaderUtil.getDbQueryFetchCustDetail();
															fetchCustomerDetail=fetchCustomerDetail.replaceAll("\\$WI_NAME\\$", packageName);
															String inputfetchCustomerDetail = getApselectWithColumnNamesXML(sessionId,fetchCustomerDetail);
															logger.debug("input fetchCustomerDetail::"+inputfetchCustomerDetail);
															String outputfetchCustomerDetail=ExecuteAPI(inputfetchCustomerDetail);
															logger.debug("output fetchCustomerDetail"+outputfetchCustomerDetail);

															if(outputfetchCustomerDetail.equalsIgnoreCase("error"))
															{
																logger.error("error received while fetching user detail "+outputfetchCustomerDetail);
															}
															else
															{
																if(getTagValues(outputfetchCustomerDetail, "MainCode").equals("0"))
																{
																	int userCount=Integer.parseInt(getTagValues(outputfetchCustomerDetail, "TotalRetrieved"));
																	XMLParser parseUser = new XMLParser(outputfetchCustomerDetail);

																	for(int j=1;j<=userCount;j++)
																	{
																		UserDetail objUser = new UserDetail();
																		String strRecord=parseUser.getNextValueOf("Record");
																		String applicantType = getTagValues(strRecord, "application_type");
																		if(applicantType.equalsIgnoreCase("Applicant"))
																		{
																			applicantMobile=getTagValues(strRecord, "phone_no");
																			applicantId=getTagValues(strRecord, "id_number");
																		}
																		objUser.setApplicantType(applicantType);
																		objUser.setEmail(getTagValues(strRecord, "email"));
																		objUser.setMobile(getTagValues(strRecord, "phone_no"));
																		objUser.setName(getTagValues(strRecord, "APPLICANT_FULLNAME"));
																		objUser.setNationalId(getTagValues(strRecord, "id_number"));
																		objUser.setOrder(PropertyReaderUtil.getOrderDetail().get(applicantType));
																		userList.add(objUser);
																	}

																}
																else
																{
																	logger.error("error  while fetching userDetails "+getTagValues(outputfetchCustomerDetail, "Output"));
																}
															}

															for(UserDetail objUserDetail:userList)
															{
																status = new String[2];
																status = RegisterUser.register(accessToken, objUserDetail.getEmail(), objUserDetail.getName(),objUserDetail.getMobile() ,objUserDetail.getNationalId() );
															}

															if(status[0]=="Success")
															{
																status = new String[2];
																status = PackageCreation.createPackage(packageName,accessToken);
																if(status[0]=="Success")
																{
																	packageId=status[1];
																	status = new String[2];
																	status[0]="Fail";
																	int count=0;
																	logger.debug("No of Docs:"+listDoc.size());
																	for(DocDetail objDoc:listDoc)
																	{
																		boolean isValidNoOfPages = false;
																		logger.debug("Doc Name : "+ objDoc.getName());
																		logger.debug("Doc Page : "+ objDoc.getNoOfPages());
																		if(objDoc.getName().contains("CONTRACT"))
																		{
																			logger.debug("output fetchCustomerDetail"+outputfetchCustomerDetail);
																			String pageNo = PropertyReaderUtil.getDocPagesDetails().get("contractAppOnly");
																			logger.debug("Doc should contains "+ pageNo + " no of pages.");
																			if (Integer.parseInt(pageNo) >= Integer.parseInt(objDoc.getNoOfPages()))
																				isValidNoOfPages = true;
																		}
																		else if(objDoc.getName().contains("APPLICA"))
																		{
																			String pageNo = PropertyReaderUtil.getDocPagesDetails().get("applicationAppOnly");
																			logger.debug("Doc should contains "+ pageNo + " no of pages.");
																			if (Integer.parseInt(pageNo) == Integer.parseInt(objDoc.getNoOfPages()))
																				isValidNoOfPages = true;
																		}
																		//DGFPL-224 start
																		else if(objDoc.getName().contains("TAKAFUL"))
																		{
																			String pageNo = PropertyReaderUtil.getDocPagesDetails().get("takafulQuestion");
																			logger.debug("Doc should contains "+ pageNo + " no of pages.");
																			if (Integer.parseInt(pageNo) == Integer.parseInt(objDoc.getNoOfPages()))
																				isValidNoOfPages = true;
																		}
																		
																		if (isValidNoOfPages) {
																			String docName = objDoc.getName()+"."+objDoc.getAppName();
																			String completePath = path+docName;
																			status = UploadDoc.docUpload(packageId,accessToken,completePath,docName);
																			if(status[0]=="Success")
																			{
																				logger.debug("status"+status[1]);
																				objDoc.setSayenDocId(status[1]);
																				listDoc.set(count, objDoc);
																			}
																		}
																		count++;
																	}

																	if(status[0]=="Success")
																	{
																		status = new String[2];
																		String docIdFinal = "";
																		for(DocDetail obj : listDoc)
																		{	
																			String templateName="";
																			String page="";
																			logger.debug("Doc Name:"+obj.getName());
																			if(obj.getName().contains("CONTRACT"))
																			{
																				if(userList.size()>1)
																				{
																					templateName="contractBoth";																												
																				}
																				else
																				{
																					templateName="contractAppOnly";
																				}
																				page = "_"+obj.getNoOfPages();
																			}
																			else if(obj.getName().contains("APPLICA"))
																			{
																				templateName="applicationAppOnly";
																			}
																			//DGFPL-224 start
																			else if(obj.getName().contains("TAKAFUL"))
																			{
																				templateName="takafulQuestion";
																				//page = "_"+obj.getNoOfPages();
																			}
																			//DGFPL-224 end
																			status =ApplyTemplate.applyTemplate(packageId,obj.getSayenDocId(),accessToken,templateName,page);
																			if(!status[0].equalsIgnoreCase("Success"))
																			{
																				break;
																			}

																			docIdFinal+=obj.getSayenDocId()+"#";

																		}
																		if(!docIdFinal.equals(""))
																		{
																			docIdFinal=docIdFinal.substring(0,docIdFinal.lastIndexOf("#"));
																		}
																		if(status[0]=="Success")
																		{
																			for(UserDetail objUser : userList)
																			{
																				status = new String[2];
																				status = UpdatePlaceHolder.placeHolderUpdation(accessToken, packageId, objUser);
																				if(!status[0].equalsIgnoreCase("Success"))
																				{
																					break;
																				}
																			}
																			if(status[0]=="Success")
																			{
																				status = new String[2];
																				status = PublishDoc.docPublish(packageId, accessToken);
																				if(status[0]=="Success")
																				{
																					logger.info("All done");

																					input = getApselectWithColumnNamesXML(sessionId,"UPDATE NG_SAYEN_INTEGRATION_DATA SET status='Sent',docId='"+docIdFinal+"',packageID='"+packageId+"',sentDate=getdate() WHERE SNo="+row );																
																					logger.debug("inputUpdate::"+input);
																					output=ExecuteAPI(input);
																					logger.debug("output update"+output);

																					if(output.equalsIgnoreCase("error"))
																					{
																						logger.error("error received while connecting "+output);
																					}
																					else
																					{
																						if(getTagValues(output, "MainCode").equals("0"))
																						{
																							logger.info("Record Update");

																							//anuj
																							/*
																							 * String
																							 * smsInsertQuery
																							 * =
																							 * "INSERT INTO dbo.NG_NBFC_SMSDETAILS_MASTER (IDNumber, MobileNumber, SMSBody, SentStatus, ServiceStatus, SMSSentDate, CaseRefNumber, StageName, Remarks)\r\n"
																							 * + "VALUES ('"
																							 * +applicantId+"', '"
																							 * +applicantMobile+"', 'أهلا، لإتمام توقيع المستندات اللازمة يرجى زيارة الرابط أدناه https://stage-shweb.sirar.com.sa/Login\r\n"
																							 * + "\r\n" +
																							 * "Hi, to complete signing the required documents please visit the below link https://stage-shweb.sirar.com.sa/Login', 'P', NULL, NULL, '"
																							 * +packageName+"', NULL, NULL)"
																							 * ;
																							 */	
																						//	String smsInsertQuery = "INSERT INTO dbo.NG_NBFC_SMSDETAILS_MASTER (IDNumber, MobileNumber, SMSBody, SentStatus, ServiceStatus, SMSSentDate, CaseRefNumber, StageName, Remarks) VALUES ('"+applicantId+"', '"+applicantMobile+"', N'أهلا، لإتمام توقيع المستندات اللازمة يرجى زيارة الرابط أدناه https://\stage-shweb.sirar.com.sa/Login Hi, to complete signing the required documents please visit the below link https://\stage-shweb.sirar.com.sa/Login', 'P', NULL, NULL, '"+packageName+"', NULL, NULL)";
																						//	String smsInsertQuery = "INSERT INTO dbo.NG_NBFC_SMSDETAILS_MASTER (IDNumber, MobileNumber, SMSBody, SentStatus, ServiceStatus, SMSSentDate, CaseRefNumber, StageName, Remarks) VALUES ('" + applicantId + "', '" + applicantMobile + "', N'أهلا، لإتمام توقيع المستندات اللازمة يرجى زيارة الرابط أدناه https://\\stage-shweb.sirar.com.sa/Login Hi, to complete signing the required documents please visit the below link https://\\stage-shweb.sirar.com.sa/Login', 'P', NULL, NULL, '" + packageName + "', NULL, NULL)";
																							String smsInsertQuery = "INSERT INTO dbo.NG_NBFC_SMSDETAILS_MASTER (IDNumber, MobileNumber, SMSBody, SentStatus, ServiceStatus, SMSSentDate, CaseRefNumber, StageName, Remarks) VALUES ('" + applicantId + "', '" + applicantMobile + "',	(select SMS_BODY_ARB from NG_NBFC_SMS_DESCRIPTION where ACTIVITYNAME ='Sayen') , 'P', NULL, NULL, '" + packageName + "', NULL, NULL)";																
																							input = getApselectWithColumnNamesXML(sessionId,smsInsertQuery);																
																							logger.debug("inputUpdateSMS::"+input);
																							output=ExecuteAPI(input);
																							logger.debug("output update SMS"+output);

																							if(output.equalsIgnoreCase("error"))
																							{
																								logger.error("error received while inserting sms entry "+output);
																							}
																							else
																							{
																								if(getTagValues(output, "MainCode").equals("0"))
																								{
																									logger.info("Record inserted");

																								}
																								else
																								{
																									logger.error("error  while inserting record for sms "+getTagValues(output, "Output"));
																								}	
																							}
																							

																							//anuj
																						}
																						else
																						{
																							logger.error("error  while updating "+getTagValues(output, "Output"));
																						}	
																					}
																				}
																				else
																				{
																					logger.error("Error occurred while publish doc::"+status[1]);
																				}
																			}
																			else
																			{
																				logger.error("Error occurred while updating place holder :"+status[1]);
																			}
																		}
																		else
																		{
																			logger.error("Error occurred while add template::"+status[1]);
																		}

																	}
																	else
																	{
																		logger.error("Error occurred while doc upload::"+status[1]);
																	}
																}
																else
																{
																	logger.error("Error occurred while package creation::"+status[1]);
																}
															}
															else
															{
																logger.error("Error occurred while user registeration::"+status[1]);
															}

														}
													}												
												}
												else
												{
													logger.error("error  while updating "+getTagValues(outputFetchDoc, "Output"));
												}	

											}
										}
										else
										{
											input = getFolderIdFromNameInput(sessionId, packageName);
											logger.debug("input getFolderIdFromNameInput::"+input);
											output=ExecuteAPI(input);
											logger.debug("output getFolderIdFromNameInput"+output);

											if(output.equalsIgnoreCase("error"))
											{
												logger.error("error received while getFolderIdFromNameInput "+output);
											}
											else
											{
												if(getTagValues(output, "Status").equals("0"))
												{
													String folderIndex = getTagValues(output, "FolderIndex");

													logger.debug("packageId::"+packageId);
													if(!packageId.equals(""))
													{
														String[] statusGet = GetStatus.status(accessToken, packageId);
														if(statusGet[0]=="Success")
														{
															if(statusGet[1].equalsIgnoreCase("COMPLETED"))
															{
																boolean complete = true;
																String detailOfSignedDoc=statusGet[2];
																JSONArray documents = new JSONArray(detailOfSignedDoc);

																for (int m = 0; m < documents.length(); m++) {
																	JSONObject doc = documents.getJSONObject(m);
																	status = new String[2];
																	status=DownloadDoc.docDownload(accessToken, packageId, doc.getInt("document_id"), packageName,docMapping.get(doc.getString("document_name")),doc.getString("document_type"));
																	if(status[0]=="Success")
																	{
																		String path = status[1];
																		status = new String[2];
																		/*** Versioning by Ravindra DGFPL-249 ***/
																		String DocumentIndex = isDocExisistingInOD(folderIndex,docMapping.get(doc.getString("document_name")), sessionId);
																		if (!"".equals(DocumentIndex)) {
																			status = checkinCheckoutDocument(docMapping, sessionId, doc, path, DocumentIndex);
																		} else {
																			status = AddDocument.attachDoc(sessionId, path,folderIndex,docMapping.get(doc.getString("document_name")),doc.getString("document_type"));
																		}
																		
																		if(status[0]=="Success")
																		{
																			complete=true;
																			logger.info("Doc attached:"+path);
																		}
																		else
																		{
																			complete = false;
																			logger.error("Error occurred while doc upload to workitem::"+status[1]);
																			break;
																		}
																	}
																	else
																	{
																		complete = false;
																		logger.error("Error occurred while doc download::"+status[1]);
																		break;
																	}
																}
																
																
																if(complete)
																{
																	logger.info("All done");
																	input = getApselectWithColumnNamesXML(sessionId,"UPDATE NG_SAYEN_INTEGRATION_DATA SET status='Completed',completionDate=getdate() WHERE SNo="+row );																
																	logger.debug("inputUpdate::"+input);
																	output=ExecuteAPI(input);
																	logger.debug("output update"+output);

																	if(output.equalsIgnoreCase("error"))
																	{
																		logger.error("error received while updating "+output);
																	}
																	else
																	{
																		if(getTagValues(output, "MainCode").equals("0"))
																		{
																			logger.info("Record Update");
																		}
																		else
																		{
																			logger.error("error  while updating "+getTagValues(output, "Output"));
																		}	
																	}
																	
																	//deleteDocument(accessToken, packageId, row, sessionId);
																}
																else
																{
																	logger.info("Error occurred while  downlad  and attaching loop");
																}

															}
															else
															{
																//for multiple status return update the table
																String updatedStatus = statusGet[1];
																updatedStatus = updatedStatus.substring(0, 1).toUpperCase() + updatedStatus.substring(1).toLowerCase();
																String query = "UPDATE NG_SAYEN_INTEGRATION_DATA SET status='"+updatedStatus+"' WHERE SNo="+row;
																logger.debug("Query to update status:"+query);
																input = getApselectWithColumnNamesXML(sessionId, query);																
																logger.debug("inputUpdate::"+input);
																output=ExecuteAPI(input);
																logger.debug("output update"+output);

																if(output.equalsIgnoreCase("error"))
																{
																	logger.error("error received while updating "+output);
																}
																else
																{
																	if(getTagValues(output, "MainCode").equals("0"))
																	{
																		logger.info("Record Update");
																	}
																	else
																	{
																		logger.error("error  while updating "+getTagValues(output, "Output"));
																	}	
																}

															}
														}
														else
														{
															logger.error("Error occurred while fetching the doc status ::"+status[1]);
														}
													}
												}
											}

										}


									} catch (Exception e1) {
										logger.error("Exception occurred while getting access token::"+e1.getMessage());
										e1.printStackTrace();
									}

								}
							}
							else
							{
								logger.error("Error occurerd while fetch data :"+getTagValues(output, "Output"));
							}
						}

							/*}
							else
							{
								logger.error("Error occurerd while connect:"+getTagValues(output, "Error"));
							}
						}*/

						try {
							input = getDisConnectInput(sessionId);
							logger.debug("inputDisconnect::"+input);
							output=ExecuteAPI(input);
							logger.debug("output disconnect"+output);

							if(output.equalsIgnoreCase("error"))
							{
								logger.error("error received while connecting "+output);
							}
							else
							{
								if(getTagValues(output, "Status").equals("0"))
								{
									logger.info("Cabinet disconnected");
								}
								else
								{
									logger.error("error  while disconnecting "+getTagValues(output, "Error"));
								}	
							}
							logger.info("Utility on sleep....");
							Thread.sleep(Integer.parseInt(PropertyReaderUtil.getSleepTime())); 
							logger.info("Utility awake....");
						}catch (InterruptedException e) {
							logger.error("Error occurred while thread sleep:"+e.getMessage());
							System.out.println("Error occurred while thread sleep:"+e.getMessage());
							e.printStackTrace();
						}
						catch (NumberFormatException e) {
							logger.error("NumberFormatException occurred while thread sleep:"+e.getMessage());
							System.out.println("NumberFormatException occurred while thread sleep:"+e.getMessage());
							e.printStackTrace();
						}
					}

				}
				else
				{
					logger.error("Doc type of document to be signed does not equally map with doc type of signed docs");
				}
			}
			
		});
		thread.start();
	}
	
	
	public static String getApselectWithColumnNamesXML(String sessionId, String Query){
		String ret ="<?xml version=\"1.0\"?>" +
				"<APSelect_Input>" +
				"<Option>APSelectWithColumnNames</Option>" +
				"<Query>"+Query+"</Query>" +
				"<EngineName>"+PropertyReaderUtil.getCabName()+"</EngineName>" +
				"<SessionId>"+sessionId+"</SessionId>" +
				"</APSelect_Input>";
		return ret;
	}

	private static String getConnectInput()
	{
		return "<?xml version=\"1.0\"?>" +
				"<NGOConnectCabinet_Input>" +
				"<Option>NGOConnectCabinet</Option>" +
				"<CabinetName>"+PropertyReaderUtil.getCabName()+"</CabinetName>" +
				"<UserName>"+PropertyReaderUtil.getUserName()+"</UserName>" +
				"<UserPassword>"+PropertyReaderUtil.getUserPassword()+"</UserPassword>"+    			
				"<UserType>U</UserType>" +
				"<UserExist>Y</UserExist>" +
				"<Locale></Locale>" +
				"</NGOConnectCabinet_Input>";
	}
	
	private static String checkExistingSession()
	{
		String getSessionQry="select SessionID from WFSESSIONVIEW with(nolock) where UserID in "
				+ "(select userindex from WFUSERVIEW with(nolock) where username='"+PropertyReaderUtil.getUserName()+"')";
		String sInputXML=getApselectWithColumnNamesXML("", getSessionQry);
		logger.debug("Input XML: "+sInputXML);
		String sOutputXML =  null;
		try
		{
			sOutputXML = ExecuteAPI(sInputXML);
			logger.debug("Output XML: "+sOutputXML);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			logger.debug("Exception in checkExistingSession "+e.getMessage());
			return "";
		}
		
		if(sOutputXML.equalsIgnoreCase("error"))
		{
			logger.error("error received while connecting ");
			return "";
		}
		else
		{
			String sSessionID=getTagValues(sOutputXML,"SessionID");
			logger.debug("SessionID: "+sSessionID);
			return sSessionID;
		}
	}


	public static String ExecuteAPI(String sInputXML) {
		logger.debug("Inside MakeCall");
		logger.debug("Parent method name is:---"+Thread.currentThread().getStackTrace()[2].getMethodName());
		String sOutputXML ="";

		NGEjbClient objNGEjbClient=null;
		try {
			objNGEjbClient = NGEjbClient.getSharedInstance();
			objNGEjbClient.initialize(PropertyReaderUtil.getAppServerIp(),PropertyReaderUtil.getAppServerPort(),PropertyReaderUtil.getServer());
			logger.debug("objNGEjbClient : "+objNGEjbClient);
			sOutputXML =objNGEjbClient.makeCall(sInputXML);
			logger.debug("sOutputXML is "+sOutputXML);
		}
		catch (Exception e) {
			sOutputXML="error";
			logger.debug("error from executor");
			e.printStackTrace();
		}			
		return sOutputXML;
	}

	private static String getTagValues(String sXML, String sTagName) {
		String sTagValues = "";
		String sStartTag = "<" + sTagName + ">";
		String sEndTag = "</" + sTagName + ">";
		String tempXML = sXML;
		tempXML = tempXML.replaceAll("&", "#amp#");
		try {

			for (int i = 0; i < sXML.split(sEndTag).length - 1; i++) {
				if (tempXML.indexOf(sStartTag) != -1) {
					sTagValues += tempXML.substring(tempXML.indexOf(sStartTag)
							+ sStartTag.length(), tempXML.indexOf(sEndTag));
					//logger.debug("sTagValues"+sTagValues);
					tempXML = tempXML.substring(tempXML.indexOf(sEndTag)
							+ sEndTag.length(), tempXML.length());
				}
				if (tempXML.indexOf(sStartTag) != -1) {
					sTagValues += ",";
					//logger.debug("sTagValues"+sTagValues);
				}
			}
			if (sTagValues.indexOf("#amp#") != -1) {
				logger.debug("Index found");
				sTagValues = sTagValues.replaceAll("#amp#", "&");
			}
			//logger.debug(" Final sTagValues"+sTagValues);
		} catch (Exception e) {
		}
		return sTagValues;
	}


	private static String getDisConnectInput(String sUserDBID)
	{
		return "<?xml version=\"1.0\"?>" +
				"<NGODisconnectCabinet_Input>" +
				"<Option>NGODisconnectCabinet</Option>" +
				"<CabinetName>"+PropertyReaderUtil.getCabName()+"</CabinetName>" +
				"<UserDBId>"+sUserDBID+"</UserDBId>" +
				"</NGODisconnectCabinet_Input>" ;
	}

	private static String getFolderIdFromNameInput(String sUserDBID,String folderName)
	{
		return "<NGOGetFolderIdForName_Input>"
				+ "<Option>NGOGetFolderIdForName</Option>"
				+ "<CabinetName>"+PropertyReaderUtil.getCabName()+"</CabinetName>"
				+ "<UserDBId>"+sUserDBID+"</UserDBId>"
				+ "<FolderName>"+folderName+"</FolderName>"
				+ "<ParentFolderIndex>"+PropertyReaderUtil.getAttachDocODDetail().get("lookInFolderIndex")+"</ParentFolderIndex>"
				+ "</NGOGetFolderIdForName_Input>";
	}



	/*************** By Ravindra 10-01-2024 DGFPL-250 **************************/
	/***************************** Start *********************************/
	private static void deleteDocument(String accessToken, String packageId, String row, String sessionId, String docstatus) {
		logger.debug("packageId::"+packageId);
		if(!packageId.equals(""))
		{
			String[] statusGet = DeleteDocument.delete(accessToken, packageId);
			if(statusGet[0]=="Success")
			{
				logger.error("Document deleted");
				updateDocDeletedStatus(row, sessionId);
			}
			else
			{
				logger.error("Error occurred while deleting the doc ::"+statusGet[1]);
			}
		} else if("Initiated".equalsIgnoreCase(docstatus)) {
			deleteRecordsWithInitiateStatus(row, sessionId);
		}
	}


	private static void updateDocDeletedStatus(String row, String sessionId) {
		String input = getApselectWithColumnNamesXML(sessionId,"UPDATE NG_SAYEN_INTEGRATION_DATA SET docDeletedStatus='Deleted' WHERE SNo="+row );																
		logger.debug("inputUpdate docDeletedStatus::"+input);
		String  output=ExecuteAPI(input);
		logger.debug("output update::"+output);

		if(output.equalsIgnoreCase("error"))
		{
			logger.error("error received while connecting "+output);
		}
		else
		{
			logger.error("docDeletedStatus Updated");
		}
	}

	private static void deleteRecordsWithInitiateStatus(String row, String sessionId) {
		String input = getApselectWithColumnNamesXML(sessionId,"DELETE FROM NG_SAYEN_INTEGRATION_DATA WHERE SNo="+row );																
		logger.debug("inputUpdate deleteRecordsWithInitiateStatus::"+input);
		String output=ExecuteAPI(input);
		logger.debug("output deleteRecordsWithInitiateStatus::"+output);

		if(output.equalsIgnoreCase("error"))
		{
			logger.error("error received while connecting "+output);
		}
		else
		{
			logger.error("docDeletedStatus Updated");
		}
	}
	
	public static String isDocExisistingInOD(String sFolderIndex, String sDocName, String sessionId) {
		try {
			String sQuery = "select docCont.DocumentIndex as DocumentIndex from PDBDocument doc, PDBDocumentContent docCont where doc.DocumentIndex = docCont.DocumentIndex and docCont.ParentFolderIndex = '"
					+ sFolderIndex + "' and doc.name = '" + sDocName + "' order by docCont.DocumentOrderNo asc";
			logger.info("sQuery for CRA/DM= "+sQuery);
			logger.info("sQuery for CRA/DM= " + sQuery);
			String XmlInput = getApselectWithColumnNamesXML(sessionId, sQuery);
			
			String XmlOut = ExecuteAPI(XmlInput);
			logger.info("isDocExisistingInOD XmlOut : " + XmlOut);
			if(XmlOut.equalsIgnoreCase("error"))
			{
				logger.error("error received while updating "+XmlOut);
			}
			else
			{
				if(getTagValues(XmlOut, "MainCode").equals("0"))
				{
					return getTagValues(XmlOut, "DocumentIndex");
				} else {
					logger.info("isDocExisistingInOD Main code is : "+getTagValues(XmlOut, "MainCode"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception in isDocExisistingInOD:" + e.getMessage());
		}
		return "";
	}

	public static String getNGOCheckinCheckoutExtInputXml(String CheckInOutFlag, String DocumentIndex, String sessionId) {
		return "<?xml version=\"1.0\"?><NGOCheckinCheckoutExt_Input><Option>NGOCheckinCheckoutExt</Option>"
				+ "<CabinetName>" + PropertyReaderUtil.getCabName() + "</CabinetName>"
				+ "<UserDBId>" + sessionId + "</UserDBId>"
				+ "<CheckInOutFlag>"+CheckInOutFlag+"</CheckInOutFlag>"
				+ "<Documents><Document>"
				+ "<DocumentIndex>" + DocumentIndex+ "</DocumentIndex>"
				+ "</Document></Documents></NGOCheckinCheckoutExt_Input>";
	}

	/*************** By Ravindra 11-01-2024 DGFPL-249 **************************/
	private static String[] checkinCheckoutDocument(HashMap<String, String> docMapping, String sessionId, JSONObject doc, String path, String DocumentIndex) {
		String[] status =new String[2];;
		/**Document is already exist so checkout the document then checkin with latest document**/
		String CheckInOutFlag= "Y";
		String inputXml =getNGOCheckinCheckoutExtInputXml(CheckInOutFlag, DocumentIndex, sessionId);
		
		logger.info("Check Out Input Xml: " + inputXml);
		String outputXml = ExecuteAPI(inputXml);
		logger.info("Check Out Output Xml: " + outputXml);
		
		/**check status and try to undo checkout then check out again.**/
		if (!"0".equals(getTagValues(outputXml, "Status")))
		{
			logger.info("Check out failed");
			logger.info("Trying to Undo Check Out");
			CheckInOutFlag= "U";
			inputXml =getNGOCheckinCheckoutExtInputXml(CheckInOutFlag, DocumentIndex,  sessionId);
			logger.info("Undo Check Out Input Xml: " + inputXml);
			outputXml = ExecuteAPI(inputXml);
			logger.info("Undo Check Out Output Xml: " + outputXml);
			
			if (!"0".equals(getTagValues(outputXml, "Status")))
		    {
				logger.info("Document is locked or checked out by other user");
				status[0]="Fail";
				status[1]="Document is locked or checked out by other user";
		    }
			
			logger.info("Trying to Check Out Again ");
			CheckInOutFlag= "Y";
			inputXml =getNGOCheckinCheckoutExtInputXml(CheckInOutFlag, DocumentIndex, sessionId);
			logger.info("Check Out Input Xml: " + inputXml);
			outputXml = ExecuteAPI(inputXml);
			logger.info("Check Out Output Xml: " + outputXml);

			if (!"0".equals(getTagValues(outputXml, "Status")))
		    {
				logger.info("Document is locked or checked out by other user");
				status[0]="Fail";
				status[1]="Document is locked or checked out by other user";
		    }
		}
		
		try
		{
			/** Check in document with latest document **/
			logger.info("CheckInDocument Start");
			status = AddDocument.CheckInDocument(docMapping.get(doc.getString("document_name")), path,doc.getString("document_type"), DocumentIndex, sessionId);
			logger.info("CheckInDocument End");
			if (status[0]=="Success")
		    {
				logger.info("Document is checked in result : " + status[0]);
		    } else {
		    	logger.info("Document is not checked in result : " + status[0]);
		    }
		}
		catch (NumberFormatException e)
		{
			logger.info("NumberFormatException : " + e.getMessage());
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
		}
		catch (Exception e)
		{
			logger.info("Exception : " + e.getMessage());
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
		}
		return status;
	}
	
	public static long getDaysBtwTwoDates(String fromDate) {
		// Current date and time
		LocalDate currentDate = LocalDate.now();

		// Specific date and time
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate specificDate = LocalDate.parse(fromDate, formatter);

		// Calculate the difference in days
		long daysDifference = ChronoUnit.DAYS.between(specificDate, currentDate);
		System.out.println("Number of days between the two dates: " + daysDifference);
		return daysDifference;
	}
	
	/***************************** End *********************************/
	
}
