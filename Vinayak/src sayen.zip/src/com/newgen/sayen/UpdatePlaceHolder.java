package com.newgen.sayen;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import com.newgen.util.*;


import com.newgen.util.PropertyReaderUtil;

public class UpdatePlaceHolder {

	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}

	public static String[] placeHolderUpdation(String accessToken, String packageId, UserDetail objUser) {
		String[] status = new String[2];
		OutputStream outputStream = null;
		BufferedReader bufferedReader = null;
		try {
			String apiUrl = PropertyReaderUtil.getAddUserDetail().get("url");
			apiUrl= apiUrl.replace("package_id", packageId);
			apiUrl= apiUrl.replace("sign_order", objUser.getOrder());

			JSONObject user = new JSONObject();
			user.put("user_email", objUser.getEmail());
			user.put("user_name", objUser.getName());
			user.put("role", PropertyReaderUtil.getAddUserDetail().get("role"));
			user.put("email_notification", PropertyReaderUtil.getAddUserDetail().get("email_notification"));
			user.put("signing_order", Integer.parseInt(objUser.getOrder()));
			user.put("mobile_number", objUser.getMobile());
			

			String requestBody = user.toString();
			logger.debug("requestBody for add place holder:"+requestBody);
			logger.debug("apiUrl:"+apiUrl);
			URL url = new URL(apiUrl);
			Proxy webProxy      = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PropertyReaderUtil.getProxyIP(), PropertyReaderUtil.getProxyPort()));  
			HttpsURLConnection connection   = (HttpsURLConnection) url.openConnection(webProxy); 

			connection.setRequestMethod("PUT");
			connection.setRequestProperty("Content-Type",  PropertyReaderUtil.getAddUserDetail().get("Content-Type"));
			connection.setRequestProperty("Accept", PropertyReaderUtil.getAddUserDetail().get("Accept"));

			// Set the Authorization header with the access token
			connection.setRequestProperty("Authorization", "Bearer " + accessToken);

			// Enable input and output streams
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setConnectTimeout(60000);
			connection.setReadTimeout(60000);
			
			// Write the request body to the output stream
			outputStream = connection.getOutputStream();
			outputStream.write(requestBody.getBytes());

			// Get the response code
			int responseCode = connection.getResponseCode();
			logger.debug("Response Code for add place holder: " + responseCode);
			// Read the response from the input stream
			bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = bufferedReader.readLine()) != null) {
				response.append(inputLine);
			}

			// Print the response
		
			logger.debug("Response Body addUserWorkflow: " + response.toString());

			if (responseCode == 200) {
				status[0]="Success";
				status[1]="Success";
				return status;
			} 
			else {
				JSONObject jsonResponse = new JSONObject(response.toString());
				String Message = jsonResponse.getString("Message");
				logger.error("Message: " + Message);
				status[0]="Fail";
				status[1]=Message;
				return status;
			}
		} catch (Exception e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("Exception::"+e.getMessage());
			return status;
		}
		finally
		{
			try {
				outputStream.flush();
				outputStream.close();
				bufferedReader.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				status[0]="Fail";
				status[1]=e.getMessage();
				logger.error("IOException::"+e.getMessage());
				//return status;
			}
		}
	}
}
