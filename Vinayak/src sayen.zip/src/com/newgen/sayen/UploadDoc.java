package com.newgen.sayen;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.newgen.util.PropertyReaderUtil;

public class UploadDoc {
	static final Logger logger;
	static
	{
		PropertyReaderUtil.loadLog4j();
		logger=Logger.getLogger("Sayan");
	}


	public static String[] docUpload(String packageId,String accessToken,String filepath,String docName)  {
		String[] status = new String[2];
		String apiUrl = PropertyReaderUtil.getDocUploadDetail().get("url");
		apiUrl= apiUrl.replace("package_id", packageId);
		File file = new File(filepath);
		InputStream inputStream = null;
		OutputStream outputStream = null;
		int responseCode=0;
		HttpsURLConnection connection = null ;
		try
		{
			URL url = new URL(apiUrl);
			// Open a connection to the API endpoint
			Proxy webProxy      = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PropertyReaderUtil.getProxyIP(), PropertyReaderUtil.getProxyPort()));  
			connection   = (HttpsURLConnection) url.openConnection(webProxy); 
			// HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type",  PropertyReaderUtil.getDocUploadDetail().get("Content-Type"));
			connection.setRequestProperty("Accept", PropertyReaderUtil.getDocUploadDetail().get("Accept"));
			connection.setRequestProperty("Authorization", "Bearer " + accessToken);
			connection.setRequestProperty("x-file-name", docName);
			connection.setRequestProperty("x-convert-document", PropertyReaderUtil.getDocUploadDetail().get("x-convert-document"));
			connection.setRequestProperty("x-source", PropertyReaderUtil.getDocUploadDetail().get("x-source"));
			connection.setConnectTimeout(60000);
			connection.setReadTimeout(60000);
			
			// Get the output stream for writing the file data to the API
			outputStream = connection.getOutputStream();
			// Read the file data and write it to the API
			inputStream = new FileInputStream(file);
			byte[] buffer = new byte[4096];
			int bytesRead;
			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outputStream.write(buffer, 0, bytesRead);
			}
			responseCode = connection.getResponseCode();
			logger.info("responseCode"+responseCode);
			logger.debug("responseBody"+connection.getResponseMessage());
		}
		catch(MalformedURLException e)
		{
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("MalformedURLException::"+e.getMessage());
			return status;
		} catch (ProtocolException e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("ProtocolException::"+e.getMessage());
			return status;
		} catch (IOException e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("IOException::"+e.getMessage());
			return status;
		}
		finally
		{
			try {
				if (inputStream != null)
					inputStream.close();
				if (outputStream != null)
					outputStream.flush();
			} catch (IOException e) {
				e.printStackTrace();
				status[0]="Fail";
				status[1]=e.getMessage();
				logger.error("IOException1 while closing input/output stream::"+e.getMessage());
				//return status;
			}
		}

		// API call successful
		InputStream responseStream = null;
		String finalResp ="";
		try {
			responseStream = connection.getInputStream();
			logger.info("responseBody"+responseStream.toString());
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(responseStream));
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				finalResp+=line;				}

			// Close the BufferedReader when finished
			bufferedReader.close();
			logger.info("finalResp::"+finalResp);
			JSONObject jsonResponse = new JSONObject(finalResp);
			if (responseCode == 201) {
				Integer docId = jsonResponse.getInt("documentid");
				logger.info("document_id: " + docId);
				status[0]="Success";
				status[1]=Integer.toString(docId);
				return status;
			} 
			else {
				String Message = jsonResponse.getString("Message");
				logger.error("Message: " + Message);
				status[0]="Fail";
				status[1]=Message;
				return status;

			}
		} catch (IOException e) {
			e.printStackTrace();
			status[0]="Fail";
			status[1]=e.getMessage();
			logger.error("IOException3::"+e.getMessage());
			return status;
		} finally {
			// Make sure to close the InputStream when done
			try {
				responseStream.close();
				connection.disconnect();
			} catch (IOException e) {
				e.printStackTrace();
				status[0]="Fail";
				status[1]=e.getMessage();
				logger.error("IOException4::"+e.getMessage());
				//return status;
			}
		}
	}
}
