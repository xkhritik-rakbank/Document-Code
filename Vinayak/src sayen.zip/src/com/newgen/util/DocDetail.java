package com.newgen.util;

public class DocDetail {
	
	private String name;
	private String docIndex;
	private String appName;
	private String sayenDocId;
	private String noOfPages;
	
	public String getNoOfPages() {
		return noOfPages;
	}
	public void setNoOfPages(String noOfPages) {
		this.noOfPages = noOfPages;
	}
	public String getSayenDocId() {
		return sayenDocId;
	}
	public void setSayenDocId(String sayenDocId) {
		this.sayenDocId = sayenDocId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDocIndex() {
		return docIndex;
	}
	public void setDocIndex(String docIndex) {
		this.docIndex = docIndex;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
}
