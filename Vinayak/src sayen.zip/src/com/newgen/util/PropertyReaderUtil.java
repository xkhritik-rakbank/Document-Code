//DGFPL-224 Sanchi/Silki 30-11-2023	Takaful questionnaire changes

package com.newgen.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author aditya.upadhyay
 */
public class PropertyReaderUtil {

	static String sleepTime;
	static String proxyIP;
	static String cabName;
	static String dbQuery;
	static String server;
	static String appServerIp;
	static String appServerPort;
	static int proxyPort;
	static String userName;
	static String userPassword;
	static String tableName;
	static String siteId;
	static String volumeId;
	static String docDownloadPath;
	static String signedDocDownloadPath;
	static String docNameToBeSigned;
	static String docNameSigned;
	static String signOrder;
	static String dbQueryFetchCustDetail;

	// DGFPL-224 start
	static String docNameToBeSigned_Contract;
	static String docNameToBeSigned_Initiate;
	static String docNameSigned_Contract;
	static String docNameSigned_Initiate;
	// DGFPL-224 end

	//By Ravindra 
	static long docDeleteInXDays;
	
	
	static HashMap<String, String> accessTokenDetail = new HashMap<String, String>();
	static HashMap<String, String> packageCreationDetail = new HashMap<String, String>();
	static HashMap<String, String> docUploadDetail = new HashMap<String, String>();
	static HashMap<String, String> addUserDetail = new HashMap<String, String>();
	static HashMap<String, String> addTemplateDetail = new HashMap<String, String>();
	static HashMap<String, String> publishDocDetail = new HashMap<String, String>();
	static HashMap<String, String> fetchStatusDetail = new HashMap<String, String>();
	static HashMap<String, String> downloadDocDetail = new HashMap<String, String>();
	static HashMap<String, String> attachDocODDetail = new HashMap<String, String>();
	static HashMap<String, String> orderDetail = new HashMap<String, String>();
	static HashMap<String, String> docPagesDetails = new HashMap<String, String>();

	// By Ravindra 10-01-2024
	static HashMap<String, String> deleteDetail = new HashMap<String, String>();

	public static String getDbQueryFetchCustDetail() {
		return dbQueryFetchCustDetail;
	}

	public static void setDbQueryFetchCustDetail(String dbQueryFetchCustDetail) {
		PropertyReaderUtil.dbQueryFetchCustDetail = dbQueryFetchCustDetail;
	}
	// DGFPL-224 start

	public static String getDocNameToBeSigned_Contract() {
		return docNameToBeSigned_Contract;
	}

	public static void setDocNameToBeSigned_Contract(String docNameToBeSigned_Contract) {
		PropertyReaderUtil.docNameToBeSigned_Contract = docNameToBeSigned_Contract;
	}

	public static String getDocNameToBeSigned_Initiate() {
		return docNameToBeSigned_Initiate;
	}

	public static void setDocNameToBeSigned_Initiate(String docNameToBeSigned_Initiate) {
		PropertyReaderUtil.docNameToBeSigned_Initiate = docNameToBeSigned_Initiate;
	}

	public static String getDocNameSigned_Contract() {
		return docNameSigned_Contract;
	}

	public static void setDocNameSigned_Contract(String docNameSigned_Contract) {
		PropertyReaderUtil.docNameSigned_Contract = docNameSigned_Contract;
	}

	public static String getDocNameSigned_Initiate() {
		return docNameSigned_Initiate;
	}

	public static void setDocNameSigned_Initiate(String docNameSigned_Initiate) {
		PropertyReaderUtil.docNameSigned_Initiate = docNameSigned_Initiate;
	}
	// DGFPL-224 start

	
	public static String getSignOrder() {
		return signOrder;
	}

	public static void setSignOrder(String signOrder) {
		PropertyReaderUtil.signOrder = signOrder;
	}

	public static long getDocDeleteInXDays() {
		return docDeleteInXDays;
	}

	public static void setDocDeleteInXDays(long docDeleteInXDays) {
		PropertyReaderUtil.docDeleteInXDays = docDeleteInXDays;
	}
	
	public static HashMap<String, String> getAddTemplateDetail() {
		return addTemplateDetail;
	}

	public static void setAddTemplateDetail(HashMap<String, String> addTemplateDetail) {
		PropertyReaderUtil.addTemplateDetail = addTemplateDetail;
	}

	public static HashMap<String, String> getOrderDetail() {
		return orderDetail;
	}

	public static void setOrderDetail(HashMap<String, String> orderDetail) {
		PropertyReaderUtil.orderDetail = orderDetail;
	}

	public static HashMap<String, String> getDeleteDetail() {
		return deleteDetail;
	}
	
	public static void setDeleteDetail(HashMap<String, String> deleteDetail) {
		PropertyReaderUtil.deleteDetail = deleteDetail;
	}
	
	public static String getDocNameToBeSigned() {
		return docNameToBeSigned;
	}

	public static void setDocNameToBeSigned(String docNameToBeSigned) {
		PropertyReaderUtil.docNameToBeSigned = docNameToBeSigned;
	}

	public static String getDocNameSigned() {
		return docNameSigned;
	}

	public static void setDocNameSigned(String docNameSigned) {
		PropertyReaderUtil.docNameSigned = docNameSigned;
	}

	public static HashMap<String, String> getAttachDocODDetail() {
		return attachDocODDetail;
	}

	public static void setAttachDocODDetail(HashMap<String, String> attachDocODDetail) {
		PropertyReaderUtil.attachDocODDetail = attachDocODDetail;
	}

	public static HashMap<String, String> getDownloadDocDetail() {
		return downloadDocDetail;
	}

	public static void setDownloadDocDetail(HashMap<String, String> downloadDocDetail) {
		PropertyReaderUtil.downloadDocDetail = downloadDocDetail;
	}

	public static HashMap<String, String> getfetchStatusDetail() {
		return fetchStatusDetail;
	}
	
	public static HashMap<String, String> getDocPagesDetails() {
		return docPagesDetails;
	}

	public static void setDocPagesDetails(HashMap<String, String> docPagesDetails) {
		PropertyReaderUtil.docPagesDetails = docPagesDetails;
	}

	public static void setfetchStatusDetail(HashMap<String, String> fetchStatusDetail) {
		PropertyReaderUtil.fetchStatusDetail = fetchStatusDetail;
	}

	public static String getSignedDocDownloadPath() {
		return signedDocDownloadPath;
	}

	public static void setSignedDocDownloadPath(String signedDocDownloadPath) {
		PropertyReaderUtil.signedDocDownloadPath = signedDocDownloadPath;
	}

	public static String getDocDownloadPath() {
		return docDownloadPath;
	}

	public static void setDocDownloadPath(String docDownloadPath) {
		PropertyReaderUtil.docDownloadPath = docDownloadPath;
	}

	public static String getSiteId() {
		return siteId;
	}

	public static void setSiteId(String siteId) {
		PropertyReaderUtil.siteId = siteId;
	}

	public static String getVolumeId() {
		return volumeId;
	}

	public static void setVolumeId(String volumeId) {
		PropertyReaderUtil.volumeId = volumeId;
	}

	public static String getUserName() {
		return userName;
	}

	public static void setUserName(String userName) {
		PropertyReaderUtil.userName = userName;
	}

	public static String getUserPassword() {
		return userPassword;
	}

	public static void setUserPassword(String userPassword) {
		PropertyReaderUtil.userPassword = userPassword;
	}

	public static String getTableName() {
		return tableName;
	}

	public static void setTableName(String tableName) {
		PropertyReaderUtil.tableName = tableName;
	}

	public static String getServer() {
		return server;
	}

	public static void setServer(String server) {
		PropertyReaderUtil.server = server;
	}

	public static String getAppServerIp() {
		return appServerIp;
	}

	public static void setAppServerIp(String appServerIp) {
		PropertyReaderUtil.appServerIp = appServerIp;
	}

	public static String getAppServerPort() {
		return appServerPort;
	}

	public static void setAppServerPort(String appServerPort) {
		PropertyReaderUtil.appServerPort = appServerPort;
	}

	public static String getCabName() {
		return cabName;
	}

	public static void setCabName(String cabName) {
		PropertyReaderUtil.cabName = cabName;
	}

	public static String getDbQuery() {
		return dbQuery;
	}

	public static void setDbQuery(String dbQuery) {
		PropertyReaderUtil.dbQuery = dbQuery;
	}

	public static HashMap<String, String> getPublishDocDetail() {
		return publishDocDetail;
	}

	public static void setPublishDocDetail(HashMap<String, String> publishDocDetail) {
		PropertyReaderUtil.publishDocDetail = publishDocDetail;
	}

	public static HashMap<String, String> getAddUserDetail() {
		return addUserDetail;
	}

	public static void setAddUserDetail(HashMap<String, String> addUserDetail) {
		PropertyReaderUtil.addUserDetail = addUserDetail;
	}

	public static HashMap<String, String> getPackageCreationDetail() {
		return packageCreationDetail;
	}

	public static void setPackageCreationDetail(HashMap<String, String> packageCreationDetail) {
		PropertyReaderUtil.packageCreationDetail = packageCreationDetail;
	}

	public static HashMap<String, String> getDocUploadDetail() {
		return docUploadDetail;
	}

	public static void setDocUploadDetail(HashMap<String, String> docUploadDetail) {
		PropertyReaderUtil.docUploadDetail = docUploadDetail;
	}

	public static String getProxyIP() {
		return proxyIP;
	}

	public static void setProxyIP(String proxyIP) {
		PropertyReaderUtil.proxyIP = proxyIP;
	}

	public static int getProxyPort() {
		return proxyPort;
	}

	public static void setProxyPort(int proxyPort) {
		PropertyReaderUtil.proxyPort = proxyPort;
	}

	public static HashMap<String, String> getAccessTokenDetail() {
		return accessTokenDetail;
	}

	public static void setAccessTokenDetail(HashMap<String, String> accessTokenDetail) {
		PropertyReaderUtil.accessTokenDetail = accessTokenDetail;
	}

	public static String getSleepTime() {
		return sleepTime;
	}

	public static void setSleepTime(String sleepTime) {
		PropertyReaderUtil.sleepTime = sleepTime;
	}

	@SuppressWarnings("unused")
	public static void setProperty() {
		HashMap<String, String> tempHash = new HashMap<String, String>();
		System.out.print("Inside PropertyReader");
		try {
			Properties prop = new Properties();

			String propFileName = System.getProperty("user.dir") + System.getProperty("file.separator") + "Config"
					+ System.getProperty("file.separator") + "Sayen" + System.getProperty("file.separator")
					+ "config.properties";

			InputStream inputStream = new FileInputStream(propFileName);

			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}
			setSleepTime(prop.getProperty("sleepTime").trim());
			setProxyIP(prop.getProperty("proxyIP").trim());
			setProxyPort(Integer.parseInt(prop.getProperty("proxyPort").trim()));
			setCabName(prop.getProperty("cabinetName").trim());
			setDbQuery(prop.getProperty("dbQuery").trim());
			setServer(prop.getProperty("server").trim());
			setAppServerIp(prop.getProperty("appServerIp").trim());
			setAppServerPort(prop.getProperty("appServerPort").trim());
			setUserName(prop.getProperty("userName").trim());
			setUserPassword(prop.getProperty("userPassword").trim());
			setTableName(prop.getProperty("tableName").trim());
			setSiteId(prop.getProperty("siteId").trim());
			setVolumeId(prop.getProperty("volumnId").trim());
			setDocDownloadPath(prop.getProperty("downloadPath").trim());
			setSignedDocDownloadPath(prop.getProperty("downloadPath_SignedDoc").trim());
			setDocNameSigned(prop.getProperty("docNameSigned").trim());
			setDocNameToBeSigned(prop.getProperty("docNameToBeSigned").trim());
			setSignOrder(prop.getProperty("signOrder").trim());
			setDbQueryFetchCustDetail(prop.getProperty("dbQueryFetchCustDetail").trim());

			// DGFPL-224 start
			setDocNameToBeSigned_Contract(prop.getProperty("docNameToBeSigned_Contract").trim());
			setDocNameToBeSigned_Initiate(prop.getProperty("docNameToBeSigned_Initiate").trim());
			setDocNameSigned_Contract(prop.getProperty("docNameSigned_Contract").trim());
			setDocNameSigned_Initiate(prop.getProperty("docNameSigned_Initiate").trim());
			
			// DGFPL-224 end
			
			setDocDeleteInXDays(Long.parseLong(prop.getProperty("docDeleteInXDays").trim()));

			// set sign order
			String[] orderArray = getSignOrder().split(",");
			int i = 1;
			for (String s : orderArray) {
				tempHash.put(s, Integer.toString(i));
				i++;
			}
			setOrderDetail(tempHash);

			// setting property for accessToken integration
			tempHash = new HashMap<>();
			tempHash.put("url", prop.getProperty("accessToken.url").trim());
			tempHash.put("grantType", prop.getProperty("accessToken.grantType").trim());
			tempHash.put("clientId", prop.getProperty("accessToken.clientId").trim());
			tempHash.put("clientSecret", prop.getProperty("accessToken.clientSecret").trim());
			tempHash.put("username", prop.getProperty("accessToken.username").trim());
			tempHash.put("password", prop.getProperty("accessToken.password").trim());
			tempHash.put("Content-Type", prop.getProperty("accessToken.Content-Type").trim());
			tempHash.put("Accept", prop.getProperty("accessToken.Accept").trim());
			setAccessTokenDetail(tempHash);

			// setting property for package creation integration
			tempHash = new HashMap<>();
			tempHash.put("url", prop.getProperty("packageCreation.url").trim());
			tempHash.put("workflow_mode", prop.getProperty("packageCreation.workflow_mode").trim());
			tempHash.put("Content-Type", prop.getProperty("packageCreation.Content-Type").trim());
			tempHash.put("Accept", prop.getProperty("packageCreation.Accept").trim());
			setPackageCreationDetail(tempHash);

			// setting property for doc upload integration
			tempHash = new HashMap<>();
			tempHash.put("url", prop.getProperty("uploadDoc.url").trim());
			tempHash.put("x-convert-document", prop.getProperty("uploadDoc.x-convert-document").trim());
			tempHash.put("x-source", prop.getProperty("uploadDoc.x-source").trim());
			tempHash.put("Content-Type", prop.getProperty("uploadDoc.Content-Type").trim());
			tempHash.put("Accept", prop.getProperty("uploadDoc.Accept").trim());
			setDocUploadDetail(tempHash);

			// setting property for add user integration
			tempHash = new HashMap<>();
			tempHash.put("url", prop.getProperty("addUserWorkflow.url").trim());
			tempHash.put("role", prop.getProperty("addUserWorkflow.role").trim());
			tempHash.put("email_notification", prop.getProperty("addUserWorkflow.email_notification").trim());
			tempHash.put("Content-Type", prop.getProperty("addUserWorkflow.Content-Type").trim());
			tempHash.put("Accept", prop.getProperty("addUserWorkflow.Accept").trim());
			tempHash.put("urlRegister", prop.getProperty("addUserWorkflow.urlRegister").trim());
			setAddUserDetail(tempHash);

			// setting property for apply template integration

			tempHash = new HashMap<>();
			tempHash.put("url", prop.getProperty("applyTemplate.url").trim());
			tempHash.put("contractAppOnly", prop.getProperty("applyTemplate.contractAppOnly").trim());
			tempHash.put("contractBoth", prop.getProperty("applyTemplate.contractBoth").trim());
			tempHash.put("applicationAppOnly", prop.getProperty("applyTemplate.applicationAppOnly").trim());
			tempHash.put("Content-Type", prop.getProperty("applyTemplate.Content-Type").trim());
			tempHash.put("Accept", prop.getProperty("applyTemplate.Accept").trim());
			tempHash.put("takafulQuestion", prop.getProperty("applyTemplate.takafulQuestion").trim());// DGFPL-224

			setAddTemplateDetail(tempHash);

			// setting property for publish document integration
			tempHash = new HashMap<>();
			tempHash.put("url", prop.getProperty("publishDoc.url").trim());
			tempHash.put("Content-Type", prop.getProperty("publishDoc.Content-Type").trim());
			tempHash.put("Accept", prop.getProperty("publishDoc.Accept").trim());
			tempHash.put("property1", prop.getProperty("publishDoc.property1").trim());
			tempHash.put("property2", prop.getProperty("publishDoc.property2").trim());
			setPublishDocDetail(tempHash);

			// setting property for fetch document status integration
			tempHash = new HashMap<>();
			tempHash.put("url", prop.getProperty("getStatus.url").trim());
			tempHash.put("Content-Type", prop.getProperty("getStatus.Content-Type").trim());
			tempHash.put("Accept", prop.getProperty("getStatus.Accept").trim());
			setfetchStatusDetail(tempHash);

			// setting property for download document integration
			tempHash = new HashMap<>();
			tempHash.put("url", prop.getProperty("downloadDoc.url").trim());
			tempHash.put("targetHost", prop.getProperty("downloadDoc.targetHost").trim());
			tempHash.put("Accept", prop.getProperty("downloadDoc.Accept").trim());
			setDownloadDocDetail(tempHash);

			// setting property for attach documentOD integration
			tempHash = new HashMap<>();
			tempHash.put("url", prop.getProperty("attachDocOD.url").trim());
			tempHash.put("lookInFolderIndex", prop.getProperty("attachDocOD.lookInFolderIndex").trim());
			tempHash.put("CheckInServiceUrl", prop.getProperty("attachDocOD.CheckInServiceUrl").trim());
			setAttachDocODDetail(tempHash);

			// setting property for delete document from sayen
			tempHash = new HashMap<>();
			tempHash.put("url", prop.getProperty("deleteDoc.url").trim());
			tempHash.put("Content-Type", prop.getProperty("deleteDoc.Content-Type").trim());
			tempHash.put("Accept", prop.getProperty("deleteDoc.Accept").trim());
			setDeleteDetail(tempHash);
			
			// setting no of pages for document
			tempHash = new HashMap<>();
			tempHash.put("takafulQuestion", prop.getProperty("doc.takaful").trim());
			tempHash.put("contractAppOnly", prop.getProperty("doc.contract").trim());
			tempHash.put("applicationAppOnly", prop.getProperty("doc.appliaction").trim());
			//tempHash.put("contractAndAppCombined", prop.getProperty("coc.contractAndApplication").trim());
			setDocPagesDetails(tempHash);
			
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
	}

	public static void loadLog4j() {
		Properties properties;

		try {
			properties = new Properties();

			String filepath = System.getProperty("user.dir") + System.getProperty("file.separator") + "Config"
					+ System.getProperty("file.separator") + "Sayen" + System.getProperty("file.separator")
					+ "log4j.properties";

			properties.load(new FileInputStream(filepath));

			System.out.println("loading log4j file from the following location - " + filepath);
			PropertyConfigurator.configure(properties);

			System.out.println("property file loaded");

		} catch (Exception glbExp) {

			glbExp.printStackTrace();

		}
	}

}
